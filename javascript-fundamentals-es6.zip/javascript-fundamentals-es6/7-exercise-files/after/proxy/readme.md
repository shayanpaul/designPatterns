extract the contents of this zip
run "npm install" from the command line
run "bower install" from the command line
run "npm install grunt-cli -g" from the command line if you haven't already
run "grunt" from the command line
open the default.html file in your browser (you can just double click on it)

when creating a new spec, be sure to add or edit the script tag in the default.html file