﻿myAppangular
    .run(['$rootScope','$state', '$location', '$window', '$timeout', function ($rootScope,$state, $location, $window, $timeout) {
        //var console = { };
        //console.log = function() {
        //};
        //window.console = console;
        $rootScope.$on('$stateChangeSuccess', function (event, to, toParams, from, fromParams) {
            $rootScope.$previousState = from;
            $rootScope.$state = $state;
            $rootScope.isChildPlanCalled = false;
            angular.element('html').css('overflow-y', 'auto');
            if ($state.current.name == 'Eidupload' || $state.current.name == 'childDetails' || $state.current.name == 'parentSaved' ||
                $state.current.name == 'parentDetails' || $state.current.name == 'summary' || $state.current.name == 'questionDetails' ||
                $state.current.name == 'Confirm' || $state.current.name == 'productDetails' || $state.current.name == 'subscription') {
                $("html, body").animate({ scrollTop: 0 }, 200);
                }
            else {
                if (!($state.current.name == "profile.edit" && localStorage.isSubscriptionFlow && JSON.parse(localStorage.isSubscriptionFlow)))
                localStorage.isSubscriptionFlow = false;
            }
            if ($state.current.name == 'child.detail.plan' || $state.current.name == 'child.detail.plan.termPlan') {
                $rootScope.isChildPlanCalled =true;
            }
            if (!from.name && $state.current.name != 'subscription' && $state.current.name != 'members' && $state.current.name != 'dashboard') {
                
                if ((localStorage.fromPaymentStatusScreen && !JSON.parse(localStorage.fromPaymentStatusScreen)) && (localStorage.isSubscriptionFlow && !JSON.parse(localStorage.isSubscriptionFlow))) {
                    window.location.href = "/";
				}
                else if (localStorage.isSubscriptionFlow && JSON.parse(localStorage.isSubscriptionFlow) && ($state.current.name == 'Eidupload' || $state.current.name == 'childDetails' || $state.current.name == 'parentSaved' ||
					$state.current.name == 'parentDetails' || $state.current.name == 'summary' || $state.current.name == 'questionDetails' ||
					$state.current.name == 'Confirm' || $state.current.name == 'productDetails' || $state.current.name == 'subscription')) {
						window.location.href = "/" + currentLanguage + "/Subscription/start";
					}
            }
            //if (!from.name && $state.current.name == 'members') {
            //    alert($rootScope.ischild);
            //}
            //$rootScope.$watch("isChild", function () {
            //    if (!from.name && $state.current.name == 'members') {
            //        alert($rootScope.ischild);
            //    }
            //});
            $rootScope.$watch("totalChildCount", function () {
                if ($rootScope.totalSupporterCount != undefined && $rootScope.totalChildCount != undefined) {
                    dataLayer.push({
                        'event': 'VirtualPageview',
                        'content category': contentCatagory(to.name),
                        'virtualPageURL': $location.path(),
                        'Own children': $rootScope.totalChildCount,
                        'Children supported': $rootScope.totalSupporterCount
                    });
                }
                
            });
            $rootScope.$watch("totalSupporterCount", function () {
                if ($rootScope.totalSupporterCount != undefined && $rootScope.totalChildCount != undefined) {
                    dataLayer.push({
                        'event': 'VirtualPageview',
                        'content category': contentCatagory(to.name),
                        'virtualPageURL': $location.path(),
                        'Own children': $rootScope.totalChildCount,
                        'Children supported': $rootScope.totalSupporterCount
                    });
                }

            });
            var contentCatagory = function (path) {
                var pageName = "";
                if(path.split(".").length > 1) {
                    pageName = path.split(".")[path.split(".").length -1]
                } else {
                    pageName = path;
				}
                return pageName;
            }
            $rootScope.$watch("totalChildCount", function () {
                if ($rootScope.totalSupporterCount != undefined && $rootScope.totalChildCount != undefined) {
                    dataLayer.push({
                        'event': 'VirtualPageview',
                        'content category': contentCatagory(to.name),
                        'virtualPageURL': $location.path(),
                        'Own children': $rootScope.totalChildCount,
                        'Children supported': $rootScope.totalSupporterCount
                    });
                }
                
            });
            $rootScope.$watch("totalSupporterCount", function () {
                if ($rootScope.totalSupporterCount != undefined && $rootScope.totalChildCount != undefined) {
                    dataLayer.push({
                        'event': 'VirtualPageview',
                        'content category': contentCatagory(to.name),
                        'virtualPageURL': $location.path(),
                        'Own children': $rootScope.totalChildCount,
                        'Children supported': $rootScope.totalSupporterCount
                    });
                }

            });
            var contentCatagory = function (path) {
                var pageName = "";
                if(path.split(".").length > 1) {
                    pageName = path.split(".")[path.split(".").length -1]
                } else {
                    pageName = path;
                }
                return pageName;
            }
            $timeout(function () {
                if (contentCatagory(to.name) != "members") {
                dataLayer.push({
                    'event': 'VirtualPageview',
                        'content category': contentCatagory(to.name),
                    'virtualPageURL': $location.path(),
                        'Own children': $rootScope.totalChildCount,
                        'Children supported': $rootScope.totalSupporterCount
                });
                }
            }, 0);
        });
    }])
    .config(['$stateProvider', '$locationProvider', '$urlMatcherFactoryProvider', '$urlRouterProvider', function ($stateProvider, $locationProvider, $urlMatcherFactoryProvider, $urlRouterProvider) {
        $urlMatcherFactoryProvider.caseInsensitive(true);
        $urlRouterProvider.when('', '/' + currentLanguage + '/Home/Members');
        $urlRouterProvider.when('/', '/' + currentLanguage + '/Home/Members');
        $urlRouterProvider.when('/' + currentLanguage , '/' + currentLanguage + '/Home/Members');
        
        $stateProvider
               
            //})
            .state('members', {
                url: '/{language}/Home/Members',
                params: {
                    language: { value: currentLanguage }
                },
                views: {
                    '@': {
                        templateUrl: function (params) { return '/' + getLanguage(params) + '/Home/ang/Members' },
                        controller: 'PersonController',
                        conrollerAs: 'member'
                    }
                }
            })
            .state('supporters', {
                url: '/{language}/supporters',
                templateUrl: function (params) { return '/' + getLanguage(params) + '/ang/Supporters' }
            })
            .state('dashboard', {
                url: '/{language}/home/dashboard',
                templateUrl: function (params) { return '/' + getLanguage(params) + '/ang/Dashboard' }
            })
            .state('partner', {
                url: '/{language}/partner',
                templateUrl: function (params) { return '/' + getLanguage(params) + '/ang/Partner' }
            })
            .state('credits', {
                url: '/{language}/credits',
                templateUrl: function (params) { return '/' + getLanguage(params) + '/ang/Credits' }
            })
            .state('moneyout', {
                url: '/{language}/moneyout',
                params: { childId: '', childState: '',obj:'' },
                templateUrl: function (params) { return '/' + getLanguage(params) + '/ang/Moneyout' }
            })
            .state('profile', {
                // This abstract state will prepend '/profile' onto the urls of all its children.
                url: '/{language}/home/profile',

                // With abstract set to true, that means this state can not be explicitly activated.
                // It can only be implicitly activated by activating one of its children.
                abstract: true,
                views: {
                    '@': {
                        templateUrl: function (params) { return '/' + getLanguage(params) + '/Home/ang/EditPerson' }
                    }
                }
            })
            .state('profile.edit', {
                // Using an empty url means that this child state will become active
                // when its parent's url is navigated to. Urls of child states are
                // automatically appended to the urls of their parent. So this state's
                // url is '/profile' (because '/profile' + '').
                url: '',
                // IMPORTANT: Now we have a state that is not a top level state. Its
                // template will be inserted into the ui-view within this state's
                // parent's template; so the ui-view within contacts.html. This is the
                // most important thing to remember about templates.
                views: {
                    '@profile': {
                        templateUrl: function (params) { return '/' + getLanguage(params) + '/Home/ang/Profile' }
                    }
                }
            })
            .state('profile.preference', {
                url: '/preference',
                views: {
                    '@profile': {
                        templateUrl: function (params) { return '/' + getLanguage(params) + '/Home/ang/EditPreference' }
                    }
                }
            })
            .state('profile.documents', {
                url: '/documents',
                views: {
                    '@profile': {
                        templateUrl: function (params) { return '/' + getLanguage(params) + '/Home/ang/ProfileDocuments' }
                    }
                }
            })

            .state('child', {
                url: '/{language}/home/child',
                params: {
                    language: { value: currentLanguage }
                },
                abstract: true,
                views: {
                    '@': {
                        templateUrl: function (params) { return '/' + getLanguage(params) + '/Home/ang/Child/'; }
                    }
                }
            })
            .state('child.detail', {
                url: '/:childId',
                params: { childId: '', routingEntry: '', childEntry: '', navigateToEventFromChildDB:'' },
                controller: 'childPageController',
                controllerAs: 'childPageController',
                abstract: true,
                views: {
                    // target the default unnamed view '' or absolute targetting through @child.detail
                    '': {
                        templateUrl: function (params) {
                            //alert(params.childId);
                            $.cookie("childId", params.childId);
                            return '/' + getLanguage(params) + '/home/ang/child/' + params.childId;

                        }
                    }
                }
            })
            .state('child.detail.plan', {
                url: '/plan',
                views: {
                    'overviewPartial@child.detail': {
                        templateUrl: function (params) {
                            return '/' + getLanguage(params) + '/home/ang/child/' + params.childId + '/PlanOverview';
                        }
                    }
                }
            })
            .state('child.detail.plan.termPlan', {
                url: '/:state',
                views: {
                    'upperBlockPartial@child.detail.plan': {
                        templateUrl: function (params) {
                            if (params.state == 1 || params.state == 3) {
                                return '/' + getLanguage(params) + '/home/ang/child/' + params.childId + '/PlanOverview/LongTermPlan';
                            }
                            if (params.state == 2) {
                                return '/' + getLanguage(params) + '/home/ang/child/' + params.childId + '/PlanOverview/ShortTermPlan';
                            }
                        }
                    },
                    'lowerBlockPartial@child.detail.plan': {
                        templateUrl: function (params) {
                            if (params.state == 1) {
                                return '/' + getLanguage(params) + '/home/ang/child/' + params.childId + '/PlanOverview/ShortTermPlan';
                            }
                            if (params.state == 2) {
                                return '/' + getLanguage(params) + '/home/ang/child/' + params.childId + '/PlanOverview/LongTermPlan';
                            }
                        }
                    }
                }
            })
        .state('child.detail.transaction-history', {
            url: '/transactionhistory',
            views: {
                'overviewPartial@child.detail': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/TransactionHistory';
                    }
                }
            }//,
            //onEnter: function () {
            //    //i hide header tabs, you can add your code here
            //    alert("Enter");
            //},
            //onExit: function () {
            //    //onExit is executed when we leave that state and go to another
            //    alert("Exit");
            //}
        })
        //.state('child.detail.plan.detail', {
        //    url: '/detail',
        //    views: {
        //        '': {
        //            templateUrl: function (params) {
        //                return '/' + currentLanguage + '/Home/ang/Child/' + params.childId + '/PlanDetail';
        //            }
        //        }
        //    }
        //})
        .state('child.detail.recurrentpayment', {
            url: '/recurrentpayment',
            params: { locationCalledFrom: '' },
            views: {
                'overviewPartial@child.detail': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/PlanOverview/RecurrentPayment';
                    }
                }
            }
        })
            .state('child.detail.contract', {
                url: '/contract',
                views: {
                    'overviewPartial@child.detail': {
                        templateUrl: function (params) {
                            return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/PlanOverview/Contract';
                        }
                    }
                }
            })
            .state('child.detail.contribute', {
                url: '/contribute',
                params: { childId: '', recurrentData: '' },
                views: {
                    '': {
                        templateUrl: function (params) {
                            return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/Contribute';
                        }
                    }
                }
            })
            //.state('childcontribute', {
            //    url: '/{language}/home/child/{childId}/contribute',
            //    views: {
            //        '@': {
            //            templateUrl: function (params) {
            //                return '/' + getLanguage(params) + '/ang/Contribute';
            //            }
            //        }
            //    }
            //})

            .state('child.detail.savingschool', {
                url: '/savingschool',
                params: { routingEntry: '',childFirstName: '', isTimeline:'',projectId:'',isNon_EligibleForMoneyOut:'',childImage:'',wishFlag:''},
                //controller: 'savingSchoolController',
                //controllerAs: 'savingSchoolController',
                views: {
                    'overviewPartial@child.detail': {
                        templateUrl: function (params) {
                            return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/ChildSavingSchool';
                        }
                    }
                }
            })

            .state('child.detail.supporter', {
                url: '/supporter',
                views: {
                    'overviewPartial@child.detail': {
                        templateUrl: function (params) {
                            return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/supporter';
                        }
                    }
                }
            })
             .state('child.detail.supporter.detail', {
                 url: '{supporterId}/detail',
                 views: {
                     '': {
                         templateUrl: function (params) {
                             return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/supporter' + params.supporterId + '/detail';
                         }
                     }
                 }
             })
             .state('child.detail.supporter.invite', {
                 url: '/Invite',
                 views: {
                     '': {
                         templateUrl: function (params) {
                             return '/' + getLanguage(params) + '/Home/ang/Child/Supporter/Invite';
                         }
                     }
                 }
             })
             .state('child.detail.event', {
                 url: '/event',
                 views: {
                     'overviewPartial@child.detail': {
                         templateUrl: function (params) {
                             return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/event';
                         }
                     }
                 }
             })
            .state('child.detail.event.create', {
                url: '/create',
                views: {
                    '': {
                        templateUrl: function (params) {
                            return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/event/create';
                        }
                    }
                }
            })
            .state('child.detail.event.edit', {
                url: '/edit',
                views: {
                    '': {
                        templateUrl: function (params) {
                            //uses the same template as the create
                            return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/event/create';
                        }
                    }
                }
            })
             .state('child.detail.event.detail', {
                 url: '/:eventId/detail',
                 params:{eventId:''},
                 views: {
                     'overviewPartial@child.detail': {
                         templateUrl: function (params) {
                             return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/event/' + params.eventId + '/detail';
                         }
                     }
                 }
             })
             .state('child.detail.profile', {
                 url: '/profile',
                 views: {
                     'overviewPartial@child.detail': {
                         templateUrl: function (params) {
                             return '/' + getLanguage(params) + '/Home/ang/Child/' + params.childId + '/profile';
                         }
                     }
                 }
             })

            
            .state('contribute', {
                url: '/{language}/contribute',
                params: { obj: null,childId: '', recurrentData: null, locationCalledFrom:'' },
                views: {
                    '@': {
                        templateUrl: function (params) { return '/' + getLanguage(params) + '/ang/Contribute' }
                    }
                }
            })
            .state('contribute.basket', {
                url: '/basket',
                params: { obj: null, locationCalledFrom: '' },
                views: {
                    'basketPartial@contribute': {
                        templateUrl: function (params) { return '/' + getLanguage(params) + '/ang/Basket' }
                    }
                }
            })
            .state('Eidupload', {
                url: '/{language}/subscription/Eidupload',
                params: { childId: '', dateOfBirth: '', isEidInserted: '' },
                views: {
                    'subscriptionSteps@': {
                        templateUrl: function (params) {
                            return '/' + getLanguage(params) + '/subscription/ang/subscriptionSteps';
                        }
                    },
                    'subscriptionMainContainer@': {
                        templateUrl: function (params) {
                            return '/' + getLanguage(params) + '/subscription/ang/Eidupload';
                        }
                    }
                }
            })

        .state('childDetails', {
            url: '/{language}/subscription/childDetails',
            params: { childId: '', dateOfBirth: '' },
            views: {
                'subscriptionSteps@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/subscriptionSteps';
                    }
                },
                'subscriptionMainContainer@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/childDetails';
                    }
                }
            }
        })
        .state('parentSaved', {
            url: '/{language}/subscription/parentSaved',
            params: { childId: '', dateOfBirth: '' },
            views: {
                'subscriptionSteps@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/subscriptionSteps';
                    }
                },
                'subscriptionMainContainer@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/parentSaved';
                    }
                }
            }
        })
        .state('parentDetails', {
            url: '/{language}/subscription/parentDetails',
            params: { childId: '', dateOfBirth: '' },
            views: {
                'subscriptionSteps@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/subscriptionSteps';
                    }
                },
                'subscriptionMainContainer@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/parentDetails';
                    }
                }
            }
        })
        .state('summary', {
            url: '/{language}/subscription/summary',
            params: { childId: '', dateOfBirth: '' },
            views: {
                'subscriptionSteps@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/subscriptionSteps';
                    }
                },
                'subscriptionMainContainer@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/summary';
                    }
                }
            }
        })
        .state('questionDetails', {
            url: '/{language}/subscription/questionDetails',
            params: { childId: '', dateOfBirth: '' },
            views: {
                'subscriptionSteps@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/subscriptionSteps';
                    }
                },
                'subscriptionMainContainer@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/questionDetails';
                    }
                }
            }
        })
             .state('Confirm', {
                 url: '/{language}/subscription/Confirm',
                 params: { childId: '', dateOfBirth: '' },
                 views: {
                     'subscriptionSteps@': {
                         templateUrl: function (params) {
                             return '/' + getLanguage(params) + '/subscription/ang/subscriptionSteps';
                         }
                     },
                     'subscriptionMainContainer@': {
                         templateUrl: function (params) {
                             return '/' + getLanguage(params) + '/subscription/ang/Confirm';
                         }
                     }
                 }
             })
        .state('productDetails', {
            url: '/{language}/subscription/productDetails',
            params: { childId: '', dateOfBirth: '' },
            views: {
                'subscriptionSteps@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/subscriptionSteps';
                    }
                },
                'subscriptionMainContainer@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/productDetails';
                    }
                }
            }
        })
        .state('subscription', {
            url: '/{language}/subscription/start',
            views: {
                'subscriptionMainContainer@': {
                    templateUrl: function (params) {
                        return '/' + getLanguage(params) + '/subscription/ang/MainPage'
                    }
                }
            }
        })
        .state('preferences', {
            url: '/{language}/preferences',
            templateUrl: function (params) { return '/' + getLanguage(params) + '/' }
        })
        .state('documents', {
            url: '/{language}/documents',
            templateUrl: function (params) { return '/' + getLanguage(params) + '/' }
        })
        ;
        $locationProvider.html5Mode(true);

        function getLanguage(params) {
            if (params.language && params.language != '') {
                return params.language;
            }
            params.language = currentLanguage;
            return currentLanguage;
        }
    }]);