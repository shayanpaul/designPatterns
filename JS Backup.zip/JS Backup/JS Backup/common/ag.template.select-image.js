﻿(function ($) {
    $.fn.selectImage = function (method) {
        var methods = {
            init: function () {
                bindAcceptSelection();

                return this.each(function () {
                    var $container = $(this);
                    var $elem = $(this).find('.select-image-dropzone');
                    initializeDropZone($elem);
                });
            },
            getImage: function () {
                return $(this).find('.demoImg').attr('src');
            },
            setImage: function (method, image) {
                var $container = $(this);
                $container.find('.demoImg').attr('src', image);
            }/*,
            destroy: function () {
                var element = $(this).
            }*/
        };

        if (methods[method]) {
            return methods[method].apply(this, arguments);
        }
        else {
            return methods.init.apply(this);
        }
    }

    // modal window template
    var modalId = 'cropping-modal',
        originalImageId = 'original-image',
        modalTemplate = '<div id="' + modalId + '" class="modal fade" tabindex="-1" role="dialog">'
                  + '    <div class="modal-dialog">'
                  + '        <div class="modal-content">'
                  + '            <div class="modal-header">'
                  + '                <h4 class="modal-title"></h4>'
                  + '                <input type="hidden" id="select-image-active" />'
                  + '            </div>'
                  + '            <div class="modal-body">'
                  + '                <div id="cropping-image-container"></div>'
                  + '                <div class="row clearfix cropping-image-controls">'
                  + '                    <div class="col-xs-6 text-right">'
                  + '                        <a href="#" id="rotateLeft"><svg xmlns="http://www.w3.org/2000/svg" width="1500" height="1500" viewBox="0 0 1500 1500"><path d="M1536 1280v-448q0 -26 -19 -45t-45 -19h-448q-42 0 -59 40q-17 39 14 69l138 138q-148 137 -349 137q-104 0 -198.5 -40.5t-163.5 -109.5t-109.5 -163.5t-40.5 -198.5t40.5 -198.5t109.5 -163.5t163.5 -109.5t198.5 -40.5q119 0 225 52t179 147q7 10 23 12q14 0 25 -9 l137 -138q9 -8 9.5 -20.5t-7.5 -22.5q-109 -132 -264 -204.5t-327 -72.5q-156 0 -298 61t-245 164t-164 245t-61 298t61 298t164 245t245 164t298 61q147 0 284.5 -55.5t244.5 -156.5l130 129q29 31 70 14q39 -17 39 -59z" /></svg></a>'
                  + '                    </div>'
                  + '                    <div class="col-xs-6">'
                  + '                        <a href="#" id="rotateRight"><svg xmlns="http://www.w3.org/2000/svg" width="1500" height="1500" viewBox="0 0 1500 1500"><path d="M1536 640q0 -156 -61 -298t-164 -245t-245 -164t-298 -61q-172 0 -327 72.5t-264 204.5q-7 10 -6.5 22.5t8.5 20.5l137 138q10 9 25 9q16 -2 23 -12q73 -95 179 -147t225 -52q104 0 198.5 40.5t163.5 109.5t109.5 163.5t40.5 198.5t-40.5 198.5t-109.5 163.5 t-163.5 109.5t-198.5 40.5q-98 0 -188 -35.5t-160 -101.5l137 -138q31 -30 14 -69q-17 -40 -59 -40h-448q-26 0 -45 19t-19 45v448q0 42 40 59q39 17 69 -14l130 -129q107 101 244.5 156.5t284.5 55.5q156 0 298 -61t245 -164t164 -245t61 -298z" /></svg></a>'
                  + '                    </div>'
                  + '                </div>'
                  + '                <div class="disclaimer-text-under-image"></div>'
                  //+ '            </div>'
                  + '        <div class="modal-footer">'
                  + '            <button type="button" class="btn btn-secondary jcrop-cancel-btn" data-dismiss="modal"></button>'
                  + '            <button type="button" class="btn btn-primary jcrop-confirm-btn" id="select-image-accept"></button>'
                  + '      </div>'
                  + '    </div><!-- /.modal-content -->'
                  + '  </div><!-- /.modal-dialog -->'
                  + '</div><!-- /.modal -->';

    Dropzone.autoDiscover = false;

    function initializeDropZone($elem) {
        var dropZoneId = $elem.attr('id');

        var acceptedFiles = 'image/jpeg,image/png,capture=camera';

        if ($elem.closest('.select-image-container').is('[data-allowpdf="true"]')) {
            acceptedFiles += ',.pdf';
        }

        var myDropZone = new Dropzone(
            '#' + dropZoneId,
            {
                url: '/upload',
                autoProcessQueue: false,
                acceptedFiles: acceptedFiles,
                maxFiles: 1,
                uploadMultiple: false,
            }
        );

        dropzoneThumbnailEvent(myDropZone, $elem);
        dropzoneErrorEvent(myDropZone, $elem);
    }

    function dropzoneThumbnailEvent(myDropZone, $elem) {
        myDropZone.on('addedfile', function (file) {
            var selected = file;
            clearIdUploadErrors($elem);

            switch (file.type) {
                case "application/pdf":
                    myDropZone.removeFile(file);

                    if (file.size / 1024 / 1024 < 2) {
                        var $container = $elem.closest('.select-image-container');

                        $container.trigger({
                            type: 'removeFile',
                            target: $container,
                        });

                        var fileReader = new FileReader();

                        fileReader.onload = function () {
                            $container.trigger({
                                type: 'pdfAdded',
                                target: $container,
                                pdf: fileReader.result
                            });
                        };

                        fileReader.readAsDataURL(file);
                    }
                    else {
                        if ($('.modal').is(':visible')) {
                            var modalId = $(".modal").not(":hidden").prop("id");
                            if (modalId == 'createProjectModal' || modalId == 'eventModal' || modalId == 'thankYouModal') {
                                genericModalErrorDisplayMessage($('#excessImageSize').val(), 'post-failure-notification');
                            }
                        } else {
                            genericErrorMessageDisplay($('#excessImageSize').val());
                        }

                        showIdUploadSizeError($elem);
                    }
                    break;
                default:
                    if (!/^image\//i.test(file.type)) {
                        var $container = $elem.closest('.select-image-container');

                        $container.trigger({
                            type: 'removeFile',
                            target: $container,
                        });
                        showIdUploadTypeError($elem);
                    }
                    break;
            }
        });

        myDropZone.on('thumbnail', function (file, dataUrl) {
            myDropZone.removeFile(file);
            //if (file.size / 1024 / 1024 < 2) {
                
                $('#' + modalId).remove();
                var $cropperModal = $(modalTemplate);
                $(".modal-title", $cropperModal).text(Resources.UploadImage_Title);
                $(".disclaimer-text-under-image", $cropperModal).text(Resources.DisclaimerMessageforEmageUpload);
                $(".jcrop-cancel-btn", $cropperModal).text(Resources.UploadImage_Cancel);
                $(".jcrop-confirm-btn", $cropperModal).text(Resources.UploadImage_Confirm);

                var $img = $('<img />', {
                    'id': originalImageId,
                    'class': 'hide'
                });

                // add uploaded and read image to modal
                //$cropperModal.find('#cropping-image-container').html($img);

                var $loading = $('<img />', {
                    src: '/Images/yongo-infinite-loader_final.gif',
                    alt: 'loading'
                });

                $cropperModal.find('#cropping-image-container').html($loading);

                $cropperModal.find('#select-image-active').val($elem.attr('id'));
                //$img.attr('src', reader.result);

                var imageToLoad = new Image();
                //image.src = reader.result;

                imageToLoad.onload = function () {

                    var originalHeight = this.height;
                    var originalWidth = this.width;
                    initializeCropping($img, originalHeight, originalWidth, $elem);
                };
                imageToLoad.src = dataUrl;

                $img.attr('src', dataUrl);

                //$("#pageLoader").removeClass('show');

                http://stackoverflow.com/questions/19305821/multiple-modals-overlay
                    $cropperModal.on('show.bs.modal', function (e) {
                        var zIndex = 1050 + (10 * $('.modal:visible').length);
                        $(this).css('z-index', zIndex);
                        setTimeout(function () {
                            $('.modal-backdrop').not('.modal-stack').css('z-index', zIndex - 1).addClass('modal-stack');
                        }, 0);
                        $('html').css('overflow-y', 'hidden');
                    });

                $cropperModal.modal({
                    show: true,
                    // prevent closing the popup by clicking outside or pressing [esc]
                    backdrop: 'static',
                    keyboard: false
                });

                $cropperModal.on('hidden.bs.modal', function () {

                    $('.modal-backdrop.modal-stack').css('z-index', '').removeClass('modal-stack');
                    $('html').css('overflow-y', 'auto');

                    var $originalImage = $('#' + originalImageId);
                    $originalImage.Jcrop('api').destroy();
                    $cropperModal.remove();
                    if ($(".modal").is(":visible")) {
                        $("body").addClass("modal-open");
                    }
                })
            //} else {
            //    if ($('.modal').is(':visible')) {
            //        var modalId = $(".modal").not(":hidden").prop("id");
            //        if (modalId == 'createProjectModal' || modalId == 'eventModal' || modalId == 'thankYouModal') {
            //            genericModalErrorDisplayMessage($('#excessImageSize').val(), 'post-failure-notification');
            //        }
            //    } else {
            //        genericErrorMessageDisplay($('#excessImageSize').val());
            //    }
            //}
        });
    }

    function dropzoneErrorEvent(myDropZone, $elem) {
        myDropZone.on('error', function (file, errorMessage, xhr) {
            myDropZone.removeFile(file);
           // alert(errorMessage);
        });
    }

    function initializeCropping($img, originalHeight, originalWidth, $elem) {
        // Wait till the modal popup is completely loaded
        if (!($('#' + modalId).data('bs.modal') || { isShown: false }).isShown) {
            setTimeout(initializeCropping, 100, $img, originalHeight, originalWidth, $elem);
        }
        else {
            applyJcrop($img, originalHeight, originalWidth, $elem);
        }
    }

    function applyJcrop($img, originalHeight, originalWidth, $elem) {
        var ratio = originalWidth / originalHeight;

        var $container = $('#cropping-image-container');


        var newWidth = originalWidth;
        var newHeight = originalHeight;

        if (originalWidth > $container.width()) {
            newWidth = $container.width();
            newHeight = newWidth / ratio;

        }
        $img.width(newWidth);
        $img.height(newHeight);
        $img.removeClass('hide');
        $container.html($img);

        var imageScale = originalHeight / newHeight;

        var setSelect = {
            x: 0,
            y: 0,
            x2: newWidth * imageScale,
            y2: newHeight * imageScale
        }

        if (setSelect.x2 > setSelect.y2) {
            var offset = (setSelect.x2 - setSelect.y2) / 2;
            setSelect.x = offset;
            setSelect.x2 = setSelect.y2 + offset;
        }
        else if (setSelect.y2 > setSelect.x2) {
            var offset = (setSelect.y2 - setSelect.x2) / 2;
            setSelect.y = offset;
            setSelect.y2 = setSelect.x2 + offset;
        }

        var $container = $elem.closest('.select-image-container');

        $container.data("imageScale", imageScale);
        var resultRatio = $container.outerWidth() / $container.outerHeight();

        var handles = ['n', 's', 'e', 'w', 'sw', 'ne', 'nw', 'se'];
        var selectorClass = 'rectangle';

        if ($container.hasClass('circle')) {
            handles = ['n', 's', 'e', 'w'];
            selectorClass = 'circle';
        }

        $img.Jcrop({
            // Change the default Selection component for new selections
            selectionComponent: circleSelector,
            // Use a default filter chain that omits shader
            applyFilters: ['constrain', 'extent', 'backoff', 'ratio', 'round'],

            // Start with circles only
            aspectRatio: resultRatio,

            // Set an initial selection
            setSelect: [setSelect.x, setSelect.y, setSelect.x2, setSelect.y2],
            handles: handles,
            boxWidth: newWidth,
            boxHeight: newHeight,
            minSize: [50, 50],

            // No dragbars or borders
            dragbars: [],
            borders: []
        }, function () {
            this.container.addClass('select-image-selector').addClass(selectorClass);
            // Add in a custom shading element...
            this.container.prepend($('<div />').addClass('select-image-shade'));
        });
    }


    function rotateClockwise(counter) {
        var $originalImage = $('#' +originalImageId);

        var newWidth = $originalImage.height();
        var newHeight = $originalImage.width();
        var src = $originalImage.attr('src');
        var $modal = $('#' + modalId);

        $originalImage.Jcrop('api').destroy();

        var $container = $modal.find('#cropping-image-container');
        $container.empty();

        var $loading = $('<img />', {
            src: '/Images/yongo-infinite-loader_final.gif',
            alt: 'loading'
        });

        $container.html($loading);

        var img = document.createElement('img');
        img.onload = function () {
            var $img = $('<img />', {
                'id': originalImageId,
                'class': 'hide'
            });
        
            var $elem = $('#' + $modal.find('#select-image-active').val());
            $modal.find('#cropping-image-container').html($img);

            var canvas = document.createElement('canvas');
            var ctx = canvas.getContext('2d');
            canvas.width = img.height;
            canvas.height = img.width;
            
            ctx.save();

            var width = canvas.width; var styleWidth = canvas.style.width;
            var height = canvas.height; var styleHeight = canvas.style.height;
        
            if (counter) {
                ctx.rotate(-0.5 * Math.PI);
                ctx.translate(-height, 0);
            }
            else {
                ctx.rotate(0.5 * Math.PI);
                ctx.translate(0, -width);
            }
            ctx.drawImage(img, 0, 0);
            $img.attr('src', canvas.toDataURL('image/png'));

            ctx.restore();
            applyJcrop($img, img.width, img.height, $elem);
        }

        img.src = src;
    }

    function bindAcceptSelection() {
        $(document).on('click', '#select-image-accept', function (e) {
            e.stopPropagation();
            e.stopImmediatePropagation();
            loadSelection();
        });
    }

    function loadSelection() {
        var $originalImage = $('#' + originalImageId);
        var imageObj = $originalImage[0];

        var $container = $('#' + $('#select-image-active').val()).closest('.select-image-container');
        $container.find('.pdf-icon').remove();

        var selection = $originalImage.Jcrop('api').getSelection();

        var tempCanvas = document.createElement('canvas');
        var tempContext = tempCanvas.getContext('2d');
        tempCanvas.width = $container.outerWidth() * 3; //canvas.width;
        tempCanvas.height = $container.outerHeight() * 3; // canvas.height;
        var contOuterWidth = $container.outerWidth() * 3;
        var contOuterHeight = $container.outerHeight() * 3;
        if ($container.hasClass('circle')) {
            var radius = ($container.outerWidth() * 3) / 2;
            tempContext.arc(radius, radius, radius, 0, Math.PI * 2, true);
        }
        else {
           
            tempContext.rect(0, 0, contOuterWidth, contOuterHeight);
        }

        var imageScale = $container.data('imageScale');

        tempContext.clip();
        tempContext.drawImage(imageObj,
                              Math.floor(selection.x * imageScale),
                              Math.floor(selection.y * imageScale),
                              Math.floor(selection.w * imageScale),
                              Math.floor(selection.h * imageScale),
                              0, 0, contOuterWidth, contOuterHeight);

        $container.find('.demoImg').attr('src', tempCanvas.toDataURL('image/png'));

        $container.addClass('loaded');
        $container.trigger({
            type: 'imageChanged',
            target: $container
        });
        //$container.find('.select-image-dropzone').empty();
        $('#' + modalId).modal('hide');
    }

    $(document).on("click", ".image-list-img", function () {
        //$("#pageLoader").addClass('show');
        $(this).closest(".select-image-dropzone").trigger("click");
    });

    $(document).on('click', '#rotateLeft', function (e) {
        e.preventDefault();

        rotateClockwise(true);
    });

    $(document).on('click', '#rotateRight', function (e) {
        e.preventDefault();
        rotateClockwise();
    });

    // Create a new Selection object extended from Selection
    var circleSelector = function () { };

    // Set the custom selection's prototype object to be an instance
    // of the built-in Selection object
    circleSelector.prototype = new $.Jcrop.component.Selection();

    // Then we can continue extending it
    $.extend(circleSelector.prototype, {
        zoomscale: 1,
        attach: function () {
            var $img = this.element.closest('#cropping-image-container').find('#original-image');
            var newWidth = $img.width();
            var newHeight = $img.height();

            this.frame.css({
                background: 'url(' + $img[0].src + ')',
                'background-size': newWidth + 'px ' + newHeight + 'px'
            });
        },
        positionBg: function (b) {
            var midx = (b.x + b.x2) / 2;
            var midy = (b.y + b.y2) / 2;
            var ox = (-midx * this.zoomscale) + (b.w / 2);
            var oy = (-midy * this.zoomscale) + (b.h / 2);
            this.frame.css({ backgroundPosition: -(b.x + 1) + 'px ' + (-b.y - 1) + 'px' });
        },
        redraw: function (b) {
            // Call original update() method first, with arguments
            $.Jcrop.component.Selection.prototype.redraw.call(this, b);

            this.positionBg(this.last);
            return this;
        },
        prototype: $.Jcrop.component.Selection.prototype
    });
}(jQuery));

function removeIdFile(id) {
    $('#' + id).trigger('removeFile');
}

function editIdFile(id) {
    $('#' + id + ' .select-image-dropzone').trigger('click');
}

function clearIdUploadErrors($elem) {
    var $container = $elem.closest('.sb-picture-blk');

    $container.find('.sb-file-type-error,.sb-max-file-size').hide();
}

function showIdUploadTypeError($elem) {
    $elem.closest('.sb-picture-blk').find('.sb-file-type-error').show();
}

function showIdUploadSizeError($elem) {
    $elem.closest('.sb-picture-blk').find('.sb-max-file-size').show();
}