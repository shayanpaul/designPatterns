﻿//var baseUrl = "https://aagje-api-t000.azurewebsites.net/";
var baseUrl = "http://localhost:57943/";
//var baseUrl = "https://aagje-api-d000.azurewebsites.net/";

// Different Sections in Subscription Page
var ProductIntroduction = "PRODUCTINTRODUCTION";
var KnowledgeAndExperience = "KNOWLEDGEANDEXPERIENCE";
var LongTermProduct = "LONGTERMPRODUCT";
var ShortTermProduct = "SHORTTERMPRODUCT";
var ParentPersonalDetails = "PARENTPERSONALDETAILS";
var ParentSpecificDetails = "PARENTSPECIFICDETAILS";
var ChildPersonalDetails = "CHILDPERSONALDETAILS";
var ChildSpecificDetails = "CHILDSPECIFICDETAILS";
var ContractExpiry = "CONTRACTEXPIRY";
var SummaryAndEdit = "SUMMARYANDEDIT";
var Supporter = "Supporter";
var PendingSupporter = "PENDINGSUPPORTER";
var MinimumAvailableAmount = 1.0;
//Edit Picture modal header
var edit_pic_Thankyou_en = "Edit Picture";
var edit_pic_Thankyou_fr = "Edit Picture_FR";
var edit_pic_Thankyou_nl = "Edit Picture_NL";
//Validation Messages
var childage17validation_en = "A subscription is only possible for child under 16";
var childage17validation_fr = "il est uniquement possible de souscrire un contrat pour un enfant de moins de 16ans";
var childage17validation_nl = "Het is alleen mogelijk om een contract voor een kind onder de 16 jaar te ondertekenen";

var childage6monthsvalidation_en = "The expected birthdate of your child must be maximum 6 months in the future";
var childage6monthsvalidation_fr = "The expected birthdate of your child must be maximum 6 months in the future _fr";
var childage6monthsvalidation_nl = "The expected birthdate of your child must be maximum 6 months in the future _nl";

var Parentage17validation_en = "A subscription is only possible for parent above 18 and below 60";
var Parentage17validation_fr = "A subscription is only possible for parent above 18 and below 60_fr";
var Parentage17validation_nl = "A subscription is only possible for parent above 18 and below 60_nl";

var Daycountvalidation_en = "Please enter a valid date";
var Daycountvalidation_fr = "Please enter a valid date_fr";
var Daycountvalidation_nl = "Please enter a valid date_nl";

var Monthcountvalidation_en = "Please enter a valid month";
var Monthcountvalidation_fr = "Please enter a valid month_fr";
var Monthcountvalidation_nl = "Please enter a valid month_nl";

var DateFormatevalidation_en = "Please enter a valid Date";
var DateFormatevalidation_fr = "Please enter a valid Date_fr";
var DateFormatevalidation_nl = "Please enter a valid Date_nl";

var emptyDateField_en = "Please fill in this mandatory field";
var emptyDateField_fr = "Please fill in this mandatory field_fr";
var emptyDateField_nl = "Please fill in this mandatory field_nl";

var noLongTermPlan_en = "You have no long term plan yet.";
var noLongTermPlan_fr = "Vous n'avez pas encore de plan à long terme.";
var noLongTermPlan_nl = "Je hebt nog geen lange termijn plan.";

//var noShortTermPlan_en = "You have no short term plan yet, you cannot use the Savings Academy.";
//var noShortTermPlan_fr = "Vous n'avez pas encore de plan à court terme. Vous ne pouvez pas utiliser l'Académie de l'épargne.";
//var noShortTermPlan_nl = "Je hebt nog geen korte termijn plan. Je kan de Spaaracademie niet gebruiken.";

var images = {
    longterm: "/Images/icon_pig_active.png",
    shortterm: "/Images/icon_saving_school.png",
    icon_saving: "/Images/icon_pig.png",
    supporter: "/Images/icon_supporter.png",
    supporter_active: "/Images/icon_supporter_active.png",
    trophie: "/Images/icon_trophie.png",
    event: "/Images/icon_event.png",
    edit: "/Images/icon_edit_settings.png",
    //active: "/Images/icon_pig_active.png",
    savingSchoolActive: "/Images/icon_saving_school_active.png",
    supporterActive: "Images/icon_supporter_active.png",
    trophieActive: "/Images/icon_trophie_active.png",
    eventActive: "/Images/icon_event_active.png",
    editActive: "/Images/icon_edit_settings_active.png",
    defaultPersonImage: "/Images/avatar-default.svg",
    dataImage: "data:image/jpg;base64,",
    defaultTimelineImage: "/Images/default-image.svg",
    defaultImage: "/Images/default-image.svg",
    //projectDefaultImage: "/Images/default_image_round.svg",// Image not in the solution and NA too if default image will fetch from azure
    thankYouDefaultImage: "/Images/default-image.svg",
    thankYouImage_en: "/Images/thanks_multi_en.jpg",
    thankYouImage_fr: "/Images/thanks_multi_fr.jpg",
    thankYouImage_nl: "/Images/thanks_multi_nl.jpg"
};

var english = "0";
var languages = {
    language: "language",
    languageEN: "EN",
    languageFR: "FR",
    languageNL: "NL",
    languageENSmall: "en"
};
var supporterType = {
    supporter: "Supporter",
    //freeSupporter: "FreeSupporter"
};
var planType = {
    latter: "LATER",
    now: "NOW",
    tax: "TAX"
};
var productTypes = {
    br21: "BR21",
    br23: "BR23",
    br26: "BR26"
};

var SavingSchoolLevel = {
    Level1: "1",
    Level2: "2"
}
//var projectStatus = {
//    Active: "Active",
//    PendingApproval: "PendingApproval",
//    Completed: "Completed"
//}

var shortTermEntryPoint = {
    ChildPage: "1",
    SavingSchool: "2"
}

var customAmountStatus = {
    Active: "1",
    InActive: "2",
    Deleted: "3"
}

var customAmountCategory = {
    MyReserve: "0",
    MyOtherSource: "1"
}

/*---enum subscription-----*/
var enumMother = 0;

/// <summary>
///Father
/// </summary>
var enumFather = 1;

/// <summary>
/// Tutor
/// </summary>
var enumTutor = 2;

/// <summary>
/// Other
/// </summary>
var enumOther = 3;

var enumNolinked = 0;

/// <summary>
/// Me
/// </summary>
var enumMelinked = 1;

/// <summary>
///  Person Linked To Me
/// </summary>
var enumPersonLinkedToMe = 2;

var enumMale = 1;

var enumFemale = 2;

/*-----enum subscription---*/

var noRecordMessage = "No more records found";
var showMore = "Show more details >>";
var personUpdateSuccessMessage = "Person Data is updated Successfully;";
var personUpdateErrorMessage = "Error While Updating Person Information";
var personInfoError = "Error while getting Person Information.";
var childrenInfoError = "Error while getting Children Information.";
var supporterInfoError = "Error while getting Supporter Information.";
var timeLineError = "Error while getting TimeLine Information.";
var acceptInvitationError = "Error in accepting invitation.";
var rejectInvitationError = "Error in rejecting invitation.";
var notificationSummaryError = "Error while getting Notification Summary";
var basketInfoError = "Error while getting Basket Information.";
var answer = {
    yes: "Yes",
    no: "No"
};
var languageUpdateSuccessMessage = "Language is updated Successfully;";
var languageUpdateFailureMessage = "Error in updating the language;";

//var entryPointForSubscription = 1;
//var entryPointForContribution = 2;
//var entryPointForNotification = 3;
//var entryPointForOnlinePayment = 4;
//var entryPointForBasket = 5;
//var entryPointForInvitation = 6;
//var entryPointForEventInvitation = 7;

var OneShot = "1";
var RecurrentPremium = "2";

var PaymentAccepted = "Accepted";
var PaymentRefused = "Refused";
var DocumentRetrieved = "Documents Retrieved Sucessfully";
var DocumentRetrievalFailure = "Documents Retrieval Failed";

var BelgiumAbbreviation = "BE";

var Belgium = "Belgium";
//Ajanta Basu: Change for 2559 and 3495
var roles = {
    subscribingParent: 0,
    admin: 1,
    supporter: 2,
    child: 3,
    adultChild: 4,
    none: 5,
    Any: 6,
    AG: 7,
    FINOP: 8,
    LIFE: 9,
    user: 10
};

var Status = {
    Draft: 0,
    Pending: 1,
    Active: 2,
    Inactive: 3,
    Cancelled: 4,
    Rejected: 5
}
var RoleParticularityCode = {
    NotApplicable: 0,
    Blocked: 1,
    Declined: 2
}

var timelineClass = {
    withChild: "col-md-8 col-sm-8",
    withNoChild: "col-md-12 col-sm-12"
};
var personRole = "personRole";
var isInfantSupporter = "isInfantSupporter";
var isChild = "isChild";
var boolFlag = {
    trueValue: "true",
    falseValue: "false"
};

var DIGITAL = "DIGITAL";
var SMSCODE = "SMSCODE";

var ReferencedFromSubscription = 'Subscription';
var ReferencedFromPayment = 'Payment';

var ConnectiveManualResponseUrlForSubscription = '/Home/Members';
var ConnectiveManualResponseUrlForPayment = '/home/child/{childId}/recurrentpayment';

var planId = "planId";
var transferToLongTerm = "0";
var transferToBankAccount = "1";
var freeTransfer = "Free Transfer";

var shortTermPlan = "Short Term plan";
var longTermPlan = "Long Term plan";

var eventEntryPoint = 7;
var inviteSupEntryPoint = 6;
var fromSuccessPayment = "fromSuccessPayment";
var parentID = "";

var promoCodeFailureMessageLine1_en = "This code is not correct.";
var promoCodeFailureMessageLine1_fr = "This code is not correct_FR.";
var promoCodeFailureMessageLine1_nl = "This code is not correct_NL."

var promoCodeFailureMessageLine2_en = "Please enter a valid promocode.";
var promoCodeFailureMessageLine2_fr = "Please enter a valid promocode_FR.";
var promoCodeFailureMessageLine2_nl = "Please enter a valid promocode_NL."

/// <summary>
/// action code for the notification and timeline
/// </summary>
var actioncode =
{
    /// <summary>
    /// the send
    /// </summary>
    send: 1,

    /// <summary>
    /// the approve
    /// </summary>
    approve: 2,

    /// <summary>
    /// the accept
    /// </summary>
    accept: 3,

    /// <summary>
    /// the reject
    /// </summary>
    reject: 4,

    /// <summary>
    /// the delete
    /// </summary>
    decline: 5,

    /// <summary>
    /// the request approval
    /// </summary>
    requestapproval: 6,

    /// <summary>
    /// the delete
    /// </summary>
    delete: 7,

    /// <summary>
    /// the failure
    /// </summary>
    failure: 8,

    /// <summary>
    /// the success
    /// </summary>
    success: 9,

    /// <summary>
    /// the received
    /// </summary>
    received: 10,

    /// <summary>
    /// thank you
    /// </summary>
    thankyou: 11,

    /// <summary>
    /// Promo Code
    /// </summary>
    PromoCode: 13
}

/// <summary>
///  message template code for notification and timeline
/// </summary>
var messagetemplatecode =
{
    /// <summary>
    /// the mandatory action
    /// </summary>
    mandatoryaction: 1,

    /// <summary>
    /// the optional action
    /// </summary>
    optionalaction: 2,

    /// <summary>
    /// the non actionable
    /// </summary>
    nonactionable: 3,

    /// <summary>
    /// the non applicable
    /// </summary>
    nonapplicable: 4
}

var ReadStatus =
{
    /// <summary>
    /// The read
    /// </summary>
    Read: 1,

    /// <summary>
    /// The un read
    /// </summary>
    UnRead: 2
}

/// <summary>
/// notification and timeline category
/// </summary>

var category =
{
    /// <summary>
    /// the invite supporter
    /// </summary>
    invitesupporter: 0,

    /// <summary>
    /// the create event
    /// </summary>
    createevent: 1,

    /// <summary>
    /// the become supporter
    /// </summary>
    becomesupporter: 2,

    /// <summary>
    /// the invite admin
    /// </summary>
    inviteadmin: 3,

    /// <summary>
    /// the activate project
    /// </summary>
    activateproject: 4,

    /// <summary>
    /// the contribution
    /// </summary>
    contribution: 5,

    /// <summary>
    /// The online payment
    /// </summary>
    onlinepayment: 6,

    /// <summary>
    /// the one shot payment
    /// </summary>
    payment: 7,

    /// <summary>
    /// the recurrent payment
    /// </summary>
    recurrentpayment: 8,

    /// <summary>
    /// The direct payment
    /// </summary>
    DirectPayment: 9,

    ///// <summary>
    ///// the information birthday reminder
    ///// </summary>
    //infobirthdayreminder: 9,

    /// <summary>
    /// the back office
    /// </summary>
    backOffice: 10,

    /// <summary>
    /// The batch
    /// </summary>
    Batch: 11,

    ///<summary>
    ///Back Office
    ///</summary>
    BackOffice: 12,

    /// <summary>
    /// Basket Payment
    /// </summary>
    BasketPayment: 13,

    ///<summary>
    /// Registraion Onboarding
    ///</summary>
    RegistraionOnboarding: 14,

    /// <summary>
    /// Subscription Onboarding
    /// </summary>
    SubscriptionOnboarding: 15,

    /// <summary>
    /// Promo Code
    /// </summary>
    PromoCode: 17
}

var defaultNotifcationPageNumber = 0;
var defaultNotificationPageSize = 3;
var defaultNotificationMaximumPageSize = 10;

var defaultTimelinePageNumber = 0;
var defaultTimelinePageSize = 3;
var defaultTimelineMaximumPageSize = 9999;

var lastStepSavedAtCode = {
    /// <summary>
    /// Getting the child data
    /// </summary>
    GetChildData: 0,
    /// <summary>
    /// The needs and knowledge
    /// </summary>
    DefineNeedsAndKnowledge: 1,
    /// <summary>
    /// Choosing products
    /// </summary>
    ChooseProducts: 2,
    /// <summary>
    /// The summary
    /// </summary>
    Summary: 3
};

//end
var errorExceptionCode = {
    inviteAdminSelf: "001",
    inviteParentSelf: "002",
    invitationBlockSupporter: "003",
    invitationToAdmin: "004",
    invitationToPendingSupporter: "005",
    invitationToExistingSupporter: "006",
    invitationToAwaitingSupporter: "007",
    inviationToOwnChild: "008"
};