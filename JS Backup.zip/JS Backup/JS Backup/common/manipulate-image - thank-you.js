﻿//alert($(".crop-cancel-button").val());
var originalImageWidth,
    originalImageHeight,
    imageScale,
    myDropzone,
    // modal window template
    modalTemplate = '<div id="cropping-modal" class="modal fade" tabindex="-1" role="dialog">'
                  + '    <div class="modal-dialog">'
                  + '        <div class="modal-content">'
                  + '            <div class="modal-header">'
                  + '                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'
                  + '                <h4 class="modal-title">' + $(".crop-modal-header").val() + '</h4>'
                  + '            </div>'
                  + '            <div class="modal-body">'
                  + '                <div id="cropping-image-container">'
                  + '            </div>'
                  
                  + '      </div>'
                  + '        <div class="modal-footer">'
                  + '            <div class="row text-container">'

                  + '                  <div class="col-sm-12 col-xs-12 row btn-container right-alin-invite">'
                  
                 
                                       
                  + '                       <button type="submit" id="button-accept" class="img-confirm-btn small-btn-base orange-btn" data-dismiss="modal"></button>'
                  + '                          <button type="submit" id="useDefaultImage" class="img-default-btn small-btn-base normal-btn event-normal-btn-gap" data-dismiss="modal"></button>'
                  + '                       <button type="submit" id="cancelImage" class="img-cancel-btn small-btn-base normal-btn event-normal-btn-gap" data-dismiss="modal"></button>'
                  + '                          </div>'

                  + '            </div>'
                  + '    </div><!-- /.modal-content -->'
                  + '  </div><!-- /.modal-dialog -->'
                  + '</div><!-- /.modal -->';

Dropzone.autoDiscover = false;

function initializeMyDropzone() {
    if (document.getElementById('my-dropzone-form-thankyou')) {
        $('#my-dropzone-form-thankyou').bind('drop dragover', function (e) {
            e.preventDefault();
        });
        myDropzone = new Dropzone(
            "#my-dropzone-form-thankyou",
            {
                url: "UploadFiles",
                autoProcessQueue: false,
                acceptedFiles: "image/*,capture=camera",
                maxFiles: 1,
                uploadMultiple: false
                // ..your other parameters..
            }
        );

        dropzoneThumbnailEvent();
    }
}

// listen to thumbnail event
function dropzoneThumbnailEvent() {
    myDropzone.on('thumbnail', function (file) {
        myDropzone.removeFile(file);

        $('#cropping-modal').remove();

        var $cropperModal = $(modalTemplate);

        var $img = $('<img />', {
            'id' : 'original-image'
        });

       

        // initialize FileReader which reads uploaded file
        var reader = new FileReader();
        reader.onloadend = function () {
            // add uploaded and read image to modal
            $cropperModal.find('#cropping-image-container').html($img);
            $img.attr('src', reader.result);

            var image = document.createElement("img");
            image.src = reader.result;

            image.onload = function () {
                originalImageHeight = this.height;
                originalImageWidth = this.width;
                initializeCropping($img);
            };
            var isUserSettings = localStorage.getItem("IsUserSettingsEntryPoint");
            var editPersonUrl = null;
            if (isUserSettings == "true") {
                 editPersonUrl = '/members/' + $.cookie("personId") + '/ispictureexists';
            }
            else
            {
                 editPersonUrl = '/members/' + $.cookie("childId") + '/ispictureexists';
            }
            var language = $.cookie("language");
            var updateImageUrl = baseUrl + editPersonUrl;
            var apiresposne = $.ajax({
                type: 'GET',
                url: updateImageUrl
            });
            if (apiresposne != undefined) {
                apiresposne.then(function (d) {
                    if (d == true) {
                        $("#useDefaultImage").css("display", "inline-block");
                        if ($(window).width() < 768) {
                            $("#cancelImage").css("float", "left");
                        }
                        }
                        else {
                        $("#useDefaultImage").css("display", "none");
                        if ($(window).width() < 768) {
                            $("#cancelImage").css("float", "right");
                        }
                    }
                    
                }, function (error) {
                });
            }
        };
        // read uploaded file (triggers code above)
        reader.readAsDataURL(file);

        $cropperModal.modal({
            show: true,
            backdrop: 'static',
            keyboard: true
        });
        $cropperModal.on("shown.bs.modal", function () {
            $("#wrapper").addClass("pic-load");
            $(".img-cancel-btn").text($(".crop-cancel-button").val());
            $(".img-default-btn").text($(".crop-default-button").val());
            $(".img-confirm-btn").text($(".crop-confirm-button").val());
            $("#cropping-modal .modal-title").text($(".crop-modal-header").val());
            setTimeout(applyJCrop, 100, $img);
        });

        $cropperModal.on("hidden.bs.modal", function () {
            $("#wrapper").removeClass("pic-load");
            $('#original-image').data('Jcrop').destroy();
        });

    });
    
}

function bindAcceptSelection() {
    $(document).on('click', '#button-accept', function (e) {
        e.preventDefault();
        loadSelection(true);
    });
    $(document).on('click', '#useDefaultImage', function (e) {
        e.preventDefault();
        loadSelection(false);
    });
}

function loadSelection(isAccept) {
    var image = null;
    var personId = $.cookie("personId");
    var childId = $.cookie("childId");
    if (isAccept == true) {
        var imageObj = $("#original-image")[0];
        var canvas = $("#preview")[0];
        var context = canvas.getContext("2d");

        var selection = $('#original-image').Jcrop('api').getSelection();

        context.arc(75, 75, 75, 0, Math.PI * 2, true);
        context.clip();
        context.drawImage(imageObj,
                          selection.x * imageScale,
                          selection.y * imageScale,
                          selection.w * imageScale,
                          selection.h * imageScale,
                          0, 0, 150, 150);
        image = getImageForUpload();
        var updateImageUrl = '/members/saveimage';
        updateImageUrl = baseUrl + updateImageUrl;
        var isUserSettings = null;
        if (localStorage.getItem("IsUserSettingsEntryPoint") == "true"){
            isUserSettings = true;
            $("#personImageHeader").attr("src", document.getElementById("preview").toDataURL("image/png"));
        }
        else if (localStorage.getItem("IsUserSettingsEntryPoint") == "false") {
            isUserSettings = false;
            $("#childPic").attr("src", document.getElementById("preview").toDataURL("image/png"));
            $("#childImgId" + $.cookie("childId")).attr("src", document.getElementById("preview").toDataURL("image/png"));
        }
        var responseObject = {
            ImageBase64ForSingleImage: image, PersonId: personId, ChildId: childId, IsUserSettings: isUserSettings
        }
        var dataResponse = JSON.stringify(responseObject);
        $.ajax({
            type: 'POST',
            url: updateImageUrl,
            data: JSON.stringify(responseObject),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8'            
        });
        var language = currentLanguage;
        if (language.toUpperCase() == "FR") {
            genericSuccessMessageDisplay(supporterRequestSuccessMessage_fr);
        }
        else if (language.toUpperCase() == "NL") {
            genericSuccessMessageDisplay(supporterRequestSuccessMessage_nl);
        }
        else if (language.toUpperCase() == "EN") {
            genericSuccessMessageDisplay(supporterRequestSuccessMessage_en);
        }
    }
    else if (isAccept == false) {
        var updateImageUrl = '/members/deleteimage'; 
        updateImageUrl = baseUrl + updateImageUrl;
        var isUserSettings = null;
        if (localStorage.getItem("IsUserSettingsEntryPoint") == "true") {
            isUserSettings = true;
            $("#personImageHeader").attr("src", images.defaultPersonImage);
            $("#editPersonImage").attr("src", images.defaultPersonImage);
        }
        else if (localStorage.getItem("IsUserSettingsEntryPoint") == "false") {
            isUserSettings = false; 
            $("#childPic").attr("src", images.defaultPersonImage);
            $("#editPersonImageChild").attr("src", images.defaultPersonImage);
        }
        var responseObject = {
          PersonId: personId, ChildId: childId, IsUserSettings: isUserSettings
        }
        $.ajax({
            type: 'POST',
            url: updateImageUrl,
            data: JSON.stringify(responseObject),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8'
        });
    }
    $('#my-dropzone-form-thankyou').empty();
    $('#cropping-modal').modal('hide');

    
}

function getImageForUpload() {
    var image = document.getElementById("preview").toDataURL("image/png");
    return image.replace('data:image/png;base64,', '');
}

function initializeCropping($elem) {
    // Wait till the modal popup is completely loaded
    waitTillPopupHasLoaded($elem);    
}

function waitTillPopupHasLoaded($elem) {
    //if (!($('#cropping-modal').data('bs.modal') || { isShown: false }).isShown) {
    //    setTimeout(waitTillPopupHasLoaded, 100, $elem)
    //}
    
    setTimeout(applyJCrop, 100, $elem);
    
}

function applyJCrop($elem) {
    var ratio = originalImageWidth / originalImageHeight;

    var $container = $('#cropping-image-container');

    var newWidth = originalImageWidth;
    var newHeight = originalImageHeight;

    if (originalImageWidth > $container.width()) {
        newWidth = $container.width();
        newHeight = newWidth / ratio;

        $elem.width(newWidth);
        $elem.height(newHeight);
    }
    else if (originalImageWidth < $container.width()) {
        newWidth = originalImageWidth;
        newHeight = newWidth / ratio;

        $elem.width(newWidth);
        $elem.height(newHeight);
    }
    
    imageScale = originalImageHeight / newHeight;

    // Create a new Selection object extended from Selection
    var CircleSel = function () { };

    // Set the custom selection's prototype object to be an instance
    // of the built-in Selection object
    CircleSel.prototype = new $.Jcrop.component.Selection();

    // Then we can continue extending it
    $.extend(CircleSel.prototype, {
        zoomscale: 1,
        attach: function () {
            this.frame.css({
                background: 'url(' + $elem[0].src + ')',
                'background-size': newWidth + 'px ' + newHeight + 'px'

            });
        },
        positionBg: function (b) {
            var midx = (b.x + b.x2) / 2;
            var midy = (b.y + b.y2) / 2;
            var ox = (-midx * this.zoomscale) + (b.w / 2);
            var oy = (-midy * this.zoomscale) + (b.h / 2);
            //this.frame.css({ backgroundPosition: ox+'px '+oy+'px' });
            this.frame.css({ backgroundPosition: -(b.x + 1) + 'px ' + (-b.y - 1) + 'px' });
        },
        redraw: function (b) {
            // Call original update() method first, with arguments
            $.Jcrop.component.Selection.prototype.redraw.call(this, b);

            this.positionBg(this.last);
            return this;
        },
        prototype: $.Jcrop.component.Selection.prototype
    });

    var setSelect = {
        x: 0,
        y: 0,
        x2: newWidth * imageScale,
        y2: newHeight * imageScale
    }

    if (setSelect.x2 > setSelect.y2) {
        var offset = (setSelect.x2 - setSelect.y2) / 2;
        setSelect.x = offset;
        setSelect.x2 = setSelect.y2 + offset;
    }
    else if (setSelect.y2 > setSelect.x2) {
        var offset = (setSelect.y2 - setSelect.x2) / 2;
        setSelect.y = offset;
        setSelect.y2 = setSelect.x2 + offset;
    }

    $elem.Jcrop({
        // Change default Selection component for new selections
        selectionComponent: CircleSel,
        // Use a default filter chain that omits shader
        applyFilters: ['constrain', 'extent', 'backoff', 'ratio', 'round'],

        // Start with circles only
        aspectRatio: 1,

        // Set an initial selection
        setSelect: [Number(setSelect.x+25*imageScale), Number(setSelect.y+25*imageScale), Number(setSelect.x2 - 50 * imageScale), Number(setSelect.y2 - 50 * imageScale)],
        
        // Only n/s/e/w handles
        handles: ['n', 's', 'e', 'w'],

        boxWidth: newWidth,
        boxHeight: newHeight,

        // No dragbars or borders
        dragbars: [],
        borders: [],
        allowSelect: false
    }, function () {
        this.container.addClass('jcrop-circle-demo');
        // Add in a custom shading element...
        this.container.prepend($('<div />').addClass('custom-shade'));
    });
    //$elem.click(function (e) {
    //    e.preventDefault();
    //})
}

$(function () {    
    initializeMyDropzone();
    bindAcceptSelection();    
});
function genericSuccessMessageDisplay(message) {
    if (message != "") {
        $("#successfulYourPersonalDetailsAreSaved").text(message);
        $("#failSuccessGlyphicon").removeClass("failure-notification");
        $("#failSuccessGlyphicon").addClass("success-notification");
    }

  //  $(".navigation-container").children().append($(".save-edit-details-notification"));
    $("#top .save-edit-details-notification").slideDown();
    setTimeout(function () {
        $("#top .save-edit-details-notification").slideUp();
    }, 10000);
}