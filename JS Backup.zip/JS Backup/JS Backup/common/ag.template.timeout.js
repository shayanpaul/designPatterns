﻿var _startTime = new Date();
var _keepSessionAliveUrl = "KeepSessionAlive.axd";

var timeoutComponent = (function () {
    // Default 18mins
    var _timeBeforePopupMustAppear = 1080000;
    // Default 20mins
    var _timeBeforeSessionTimeout = 1200000;
    var _timeoutRedirectUrl = "";
    var _verifyTimestampId;
    var _isPopupVisible = false;
    var _googleAnalyticsDataLayer;
    var countdown = _timeBeforeSessionTimeout - _timeBeforePopupMustAppear;
    var accessTokenTime;


    /* Public Functions */
    function init(timeBeforePopupMustAppear, timeBeforeSessionTimeout, timeoutContentUrl, timeoutRedirectUrl) {
        _timeBeforePopupMustAppear = parseInt(timeBeforePopupMustAppear);
        _timeBeforeSessionTimeout = parseInt(timeBeforeSessionTimeout);
        _timeoutContentUrl = timeoutContentUrl;
        _timeoutRedirectUrl = timeoutRedirectUrl;
        resetTimers();
        countdown = _timeBeforeSessionTimeout - _timeBeforePopupMustAppear;
    }

    function logout() {
        window.location.href = _timeoutRedirectUrl;
        resetTimers();
    }

    function setKeepSessionAliveUrl(keepSessionAliveUrl) {
        _keepSessionAliveUrl = keepSessionAliveUrl;
    }

    function keepSessionAlive() {
        resetTimers();
        $.post(_keepSessionAliveUrl);
    }

    function setGoogleAnalyticsDataLayer(googleAnalyticsDataLayer) {
        _googleAnalyticsDataLayer = googleAnalyticsDataLayer;
    }
    /* End Public Functions */

    /* Private Functions */

    function openTimeOutPopup() {
        if (!_isPopupVisible) {
            _isPopupVisible = true;
            countdown = _timeBeforeSessionTimeout - _timeBeforePopupMustAppear;
            var timerId = setInterval(function () {
                countdown -= 1000;
                var min = Math.floor(countdown / (60 * 1000));
                var sec = Math.floor((countdown - (min * 60 * 1000)) / 1000); //correct
                if (min < 10) {
                    min = "0" + min;
                }
                if (sec < 10) {
                    sec = "0" + sec;
                }
                if (countdown <= 0) {
                    clearInterval(timerId);
                } else {
                    $("#countTime").html(min + ":" + sec);
                }

            }, 1000);

            setTimeout(function () {
                $('#timeout').modal();
            }, 500);

            registerButtonEvents();
            registerGoogleAnalyticsTimeoutEvent();
            $('#StayLoggedButton').on("click", function () {
                clearInterval(timerId);
                $("#countTime").html('');
            });
        }
    }

    function resetTimers() {
        _startTime = new Date();
        clearInterval(_verifyTimestampId);
        removeTimeoutPopup();
        _verifyTimestampId = setInterval(verifyTimetamp, 1000);


    }

    function removeTimeoutPopup() {
        var $timeoutContainer = $("#timeout");
        if ($timeoutContainer != undefined) {
            $timeoutContainer.modal("hide");
            _isPopupVisible = false;
        }
    }

    function registerButtonEvents() {
        var $stayLoggedButton = $('#StayLoggedButton');
        if ($stayLoggedButton != undefined) {
            $stayLoggedButton.on("click", function (e) {
                e.preventDefault();
                keepSessionAlive();
                return false;
            });
        }
        var logoutButton = $('#LogoutButton');
        if (logoutButton != undefined) {
            logoutButton.on("click", function (e) {
                e.preventDefault();
                logout();
                return false;
            });
        }
    }

    function verifyTimetamp() {
        var ret;
        var runningTime = new Date().getTime();
        var timeoutTime = _startTime.getTime() + _timeBeforeSessionTimeout;
        if (runningTime > timeoutTime) {
            logout();
            ret = false;
        } else {
            if (!_isPopupVisible) {
                var popupTime = _startTime.getTime() + _timeBeforePopupMustAppear;
                if (runningTime > popupTime) {
                    openTimeOutPopup();
                }
            }
        }
        return ret;
    }

    function registerGoogleAnalyticsTimeoutEvent() {
        if (_googleAnalyticsDataLayer != undefined) {
            _googleAnalyticsDataLayer.push({
                'event': 'GAEvent',
                'eventAction': 'Open',
                'eventCategory': 'Time-Out_Warning',
                'eventLabel': window.location.href
            });
        }
    }

    /* End Private Functions */

    return {
        init: init,
        logout: logout,
        setKeepSessionAliveUrl: setKeepSessionAliveUrl,
        keepSessionAlive: keepSessionAlive,
        removeTimeoutPopup: removeTimeoutPopup,
        setGoogleAnalyticsDataLayer: setGoogleAnalyticsDataLayer
    }

})();