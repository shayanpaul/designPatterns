﻿eventTracking = function () {
    $(document).on('click', '[data-event="GAEvent"]', function (e) {
        var evAction = $(this).data('action') ? $(this).data('action') : '';
        var evCategory = $(this).data('category') ? $(this).data('category') : '';
        var evLabel = $(this).data('label') ? $(this).data('label') : '';
        var evValue = $(this).data('value') ? $(this).data('value') : '';
        try {
            dataLayer.push({
                'event': 'GAEvent',
                'eventAction': evAction,
                'eventCategory': evCategory,
                'eventLabel': evLabel,
                'eventValue': evValue
            });
        } catch (e) {
            
        }
    });
}

$(document).ready(function () {
    eventTracking();
});