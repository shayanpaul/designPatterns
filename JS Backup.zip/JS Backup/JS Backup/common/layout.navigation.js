﻿$(function () {
    var pageURL = $(location).attr("href").toLowerCase();

    //var activeItemIndex = 2;

    //if (pageURL.indexOf('displayperson') != -1) {
    //    activeItemIndex = 2;
    //}
    //else if (pageURL.indexOf('supporters') != -1) {
    //    activeItemIndex = 3;
    //}
    //else if (pageURL.indexOf('displaycredits') != -1) {
    //    activeItemIndex = 4;
    //}
    //else if (pageURL.indexOf('displaypartner') != -1) {
    //    activeItemIndex = 5;
    //}

    //$('#navigation-menu li:nth-child(' + activeItemIndex + ') a').addClass("active");
    //$('#navigation-menu li:nth-child(' + activeItemIndex + ')').addClass("active");

    /* TODO : use better solution to mark active menu item! */

    //$("#navigation-menu li:nth-child(1) a").addClass("active");

    //if (pageURL.toLowerCase().indexOf("displayperson") != -1) {
    //    $("#navigation-menu li:nth-child(1) a").addClass("active");
    //}
    //if (pageURL.toLowerCase().indexOf("supporters") != -1) {
    //    $("#navigation-menu li:nth-child(1) a").removeClass("active");
    //    $("#navigation-menu li:nth-child(2) a").addClass("active");
    //}
    //if (pageURL.toLowerCase().indexOf("displaycredits") != -1) {
    //    $("#navigation-menu li:nth-child(1) a").removeClass("active");
    //    $("#navigation-menu li:nth-child(3) a").addClass("active");
    //}
    //if (pageURL.toLowerCase().indexOf("displaypartner") != -1) {
    //    $("#navigation-menu li:nth-child(1) a").removeClass("active");
    //    $("#navigation-menu li:nth-child(4) a").addClass("active");
    //}


    navScrollbehaviours();
    addNotificationsEvent();
    var initial = true;
    $(window).resize(function () {
        //alert($(window).width());
        notificationheight();
        if (!initial) {
            if ($(window).width() < 768 && $("#notifications-container").hasClass("open")) {
                setTimeout(function () { $('body').css('overflow-y', 'hidden'); }, 10);
            }
            if ($(window).width() > 768) {
                setTimeout(function () { $('body').css('overflow-y', 'auto'); }, 200);
            }
        }
        initial = false;
    });
    //$(".navigation-menu > li:eq(0)").addClass("active");
//    $(document).on("click", ".navigation-menu > li", function () {
//        $(".navigation-menu > li").removeClass("active");
//        $(this).addClass("active");
//});
});

var styleStatus = {};
var className = {};
function addNotificationsEvent() {

    $('#notifications-trigger').on('click', function (e) {
        $('#notifications-container, #notifications-trigger').toggleClass('open');
        $('.user-profile').removeClass("open");
        $('#context-menu, #context-menu-trigger').removeClass('open');
        var viewPortW = $(window).width();
        var viewPortH = $(window).height();
        if (viewPortW < 768) {
            $('body').css('overflow-y', 'hidden');
        }
        if (viewPortW >= 768) {
            $('body').css('overflow-y', 'auto');
        }
        e.preventDefault();
        e.stopPropagation();
    });
    $('.notifications-header .close').on('click', function (e) {
        $('#notifications-container, #notifications-trigger').removeClass('open');

        $('body').css('overflow-y', 'inherit');
        e.preventDefault();
        e.stopPropagation();
    });

    notificationheight();

}
function notificationheight() {
    var viewPortW = $(window).width();
    var viewPortH = $(window).height();
    if (viewPortW < 768) {
        var containerHeight = viewPortH - ($('.notifications-header').outerHeight() + $('.notifications-action').outerHeight());
        $(".notifications-wrap").css({ 'max-height': containerHeight, 'height': 'auto' });
        //setTimeout(function () { $('body').css('overflow', 'hidden'); }, 10);
    }
    if (viewPortW >= 768) {
        var containerHeight = viewPortH - ($('.notifications-header').outerHeight() + $('.notifications-action').outerHeight());
        var deskContainerheight = containerHeight - $('.rectangle-header-top').outerHeight();
        $(".notifications-wrap").css('max-height', deskContainerheight);
        $(".notifications-wrap").css('height', 'auto');
        // setTimeout(function () { $('body').css('overflow', ''); }, 200);
    }
}



//Navigation

function navScrollbehaviours() {
    var didScroll;
    var lastScrollTop = 0;
    var delta = 5;
    var navbarHeight = 100;
    var scrollPos = 0;
    $(window).scroll(function (event) {
        didScroll = true;
        var st = $(window).scrollTop();
        if (Math.abs(lastScrollTop - st) <= delta)
            return;
        if (st > navbarHeight) {
            // Scroll Down
            $('html').removeClass('nav-down').addClass('nav-up');
        } else {
            // Scroll Up
            if (st < 130)
                $('html').removeClass('nav-up').addClass('nav-down');
        }
        lastScrollTop = st;
    });
}

function getScrollBarWidth() {
    var inner = document.createElement('p');
    inner.style.width = "100%";
    inner.style.height = "200px";

    var outer = document.createElement('div');
    outer.style.position = "absolute";
    outer.style.top = "0px";
    outer.style.left = "0px";
    outer.style.visibility = "hidden";
    outer.style.width = "200px";
    outer.style.height = "150px";
    outer.style.overflow = "hidden";
    outer.appendChild(inner);
    document.body.appendChild(outer);
    var w1 = inner.offsetWidth;
    outer.style.overflow = 'scroll';
    var w2 = inner.offsetWidth;
    if (w1 == w2) w2 = outer.clientWidth;
    document.body.removeChild(outer);
    return (w1 - w2);
}
function generateClassName() {
    // Generate a class-name for using with this modal
    className = 'wrapper-' + $.map(new Array(10), function () {
        return 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)];
    }).join('');
}
function setStyle(params) {
    var scrollBarWidth = getScrollBarWidth();
    var scriptContent = "<style type='text/css' id=" + params.id + ">" + "#wrapper." + params.className + " {" + "position: fixed;" + "left: 0px;" + "top: -" + params.scrollPosition + "px;" + "width:100%;" + "height:auto;" + "}   </style>";
    return scriptContent;
}
function freezeBackground() {
    var scrollBarWidth = getScrollBarWidth();
    // Save info for reversing styles
    generateClassName();
    styleStatus = {
        scrollTop: $(window).scrollTop(),
        styleId: className
    };

    $('head').append(setStyle({
        id: className,
        className: className,
        scrollPosition: styleStatus.scrollTop,
        bodyWidth: $('body').width()
    }));

    // Add the class to the body
    $('#wrapper').addClass(className);
    $('.nav-header').css({'padding-right': scrollBarWidth});
}
function unfreezeBackground() {
    // Remove the class (and removing the fixed background)
    setTimeout(function () {
        // Scroll to the position
        $(window).scrollTop(styleStatus.scrollTop);
        // Remove the style tag
        $('#' + styleStatus.styleId).remove();
        // Reset the styleStatus
        styleStatus = {};
    }, 0);
    $('#wrapper').removeClass();
    $('.nav-header').css({ 'padding-right': '0' });
}
$(document).ready(function () {
    $('body').on('show.bs.modal', function (event) {
        if (event.target.id != 'filterModal' && event.target.id != 'subscriptionSTextendModal' && event.target.id != 'deletePaymentModal' && event.target.id != 'unblockSupporter') {
            if (!$(event.target).hasClass('datepicker')) {
                freezeBackground();
            }
        }
    });
    $('body').on('hide.bs.modal', function (event) {
        if (!$(event.target).hasClass('datepicker') && $(".modal:visible").length == 1) {
            unfreezeBackground();
        }
    });

    $('.nav-toggle').on('click', function () {
        $('.navbar-offcanvas.collapse').collapse("show");
        $('html').css({ 'overflow-y': 'hidden' });
        freezeBackground();
    });
    $('.navbar-toggle, .navbar-offcanvas .cover, .navigation-menu li a, .user-settings li a').on('click', function () {
        $('.navbar-offcanvas.collapse').collapse("hide");
        $('html').css({ 'overflow-y': 'auto' });
        unfreezeBackground();
    });

    $(window).resize(function () {
        var viewPortW = $(window).width();
        var viewPortH = $(window).height();
        
        if ($('#navbar').hasClass("in")) {
            if (viewPortW > 768) {
                unfreezeBackground();
            }
            if (viewPortW < 768) {
                freezeBackground();
            }
        }

    });


    $('#userSetting').on('click', function () {
        $(this).parent().addClass("open");
        $('#notifications-container, #notifications-trigger').removeClass('open');
    });

    // Click outside and hide
    $('#webappContainer').click(function (e) {
        if (($(e.target).parents('#notifications-trigger').length === 0) && $(e.target).parents('.notifications-container').length === 0) {
            $('#notifications-container, #notifications-trigger').removeClass('open');
            //unfreezeBackground();
            if ($(".csm-selected-menu-mobile").hasClass("menu-is-closed") && !$(".cp-childlist-container").hasClass("cp-child-menu-open-in-mobile") && window.innerWidth < 768) {
                $('body').css('overflow', 'inherit');
            }
        }
        if (($(e.target).parents('.user-profile').length === 0) && $(e.target).next('.user-settings').length === 0) {
            $('.user-profile').removeClass("open");
        }
    });

});


