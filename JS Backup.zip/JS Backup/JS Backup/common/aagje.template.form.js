﻿$(function () {
    bindDefaultFormActions();
    phoneControlOnSubmit();
});

function bindDefaultFormActions() {
    var context = '.form-group .form-control'; // for textboxes & textareas
    context += ',.form-group .bootstrap-select .dropdown-toggle'; // for dropdowns (bootstrap-selectpicker)
    context += ',.form-group input[type="checkbox"]'; // for checkboxes
    context += ',.form-group input[type="radio"]'; // for checkboxes
    context += ',.form-group button.select-image-dropzone'; // for selectimage-control

    $(document).on('focus', context, function (e) {
        $(this).closest('.form-group').addClass('focus');
    });

    $(document).on('blur', context, function (e) {
        $(this).closest('.form-group').removeClass('focus');
    });


    $(document).on('click', '.radiobutton-list > label > .info-icon', function (e) {
        $(this).closest('.radiobutton-list').find('.radiobutton-list-extra-info').toggleClass('open');
        $(this).toggleClass('cross-icon');
    });
}

function phoneControlFilterKeyPresses(allowedCharactersRegex, keyPressEvent) {
    var regex = new RegExp(allowedCharactersRegex);
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    if (!regex.test(key)) {
        event.preventDefault();
        return false;
    }
}

function phoneControlOnSubmit() {
    $(document).on('submit', 'form', function (e) {
        // so that the international format will be passed.
        $('[data-aagjephone]').each(function () {
            var $phoneNumber = $(this);
            $phoneNumber.val($phoneNumber.intlTelInput('getNumber'));
        });
    });
}




