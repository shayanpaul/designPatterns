﻿(function ($) {
    $.fn.aagjeDatePicker = function (methodOrSettings, options) {

        var methods = {
            init: function (settings) {

                if (useBrowserDatepicker()) {
                    return this.each(function () {
                        $(this).attr('type', 'date');
                    })
                }

                var prefix = 'aagjeDatePickerContainer_';

                settings = addDefaultSettings(settings);

                var inputMask = hideDays ? 'd/m/y' : 'd/m/y';

                return this.each(function () {
                    var textBox = $(this);

                    if (!textBox.is(':text')) {
                        return;
                    }

                    var datePickerId = prefix + textBox.attr('id');

                    if ($("#" + datePickerId).length > 0) {
                        var datePicker = $("#" + datePickerId);
                    } else {
                        var datePicker = $('<div class="date datepicker input-group"></div>');
                        datePicker.attr('id', datePickerId);
                        $.each(textBox[0].attributes, function (index, attr) {
                            if (attr.name.startsWith('data-date-') || attr.name.startsWith('date-')) {
                                datePicker.attr(attr.name, attr.value);
                            }
                        });

                        datePicker = textBox.wrap(datePicker).parent();

                        $('<span class="input-group-addon"><i class="glyphicon glyphicon-aagje-calendar-2"></i></span>').insertAfter(textBox);
                    }


                    var currentDate = textBox.val();
                    if (currentDate != null && currentDate.length > 10) {
                        textBox.val(currentDate.substr(0, 10));
                    }

                    datePicker.datepicker(settings)
                    .on('show', function (e) {
                        var element = $(this);

                        if (element.find(':text').is(':disabled')) {
                            element.datepicker('hide');
                        }
                        else {
                            element.closest('.form-group').addClass('dp-focus');
                        }

                    })
                    .on('hide', function (e) {
                        var element = $(this);
                        element.closest('.form-group').removeClass('dp-focus');
                    })
                    //.find('input').inputmask({ "mask": inputMask, "autoUnmask": false })
                    .focus(function (e) {
                        datePicker.datepicker('hide');
                    })
                    .blur(function () {
                        if (hideDays) {
                            if (!isMonthsDate(textBox.val())) {
                                // re-initialize screen to today
                                datePicker.datepicker('update', defaultDate);
                                textBox.val('');
                                datePicker.datepicker('update');
                            }
                        }
                        else {
                            if (!isDate(textBox.val())) {
                                // re-initialize screen to today
                                datePicker.datepicker('update', defaultDate);
                                textBox.val('');
                                datePicker.datepicker('update');
                            }
                        }
                    })
                    .on('keydown', function (e) {
                        datePicker.datepicker('hide');
                    });

                    if (!textBox.is(':enabled')) {
                        disableDatePicker(datePicker);
                    }
                });
            },
            disable: function () {
                return this.each(function () {
                    var datePicker = getDatePickerForMethod(this);
                    disableDatePicker(datePicker);
                });
            },
            enable: function () {
                return this.each(function () {
                    var datePicker = getDatePickerForMethod(this);
                    enableDatePicker(datePicker);
                });
            },
            proxy: function (method, options) {
                if (method.indexOf('get') == 0) {

                    if (useBrowserDatepicker()) {
                        if (method == 'getDate') {
                            return new Date($(this).val());
                        }
                    }

                    var result;

                    this.each(function () {
                        var datePicker = getDatePickerForMethod(this);
                        var returnValue = datePicker.datepicker(method, options);

                        if (returnValue != null) {
                            result = returnValue;
                            return false;
                        }
                    });

                    return result;
                }
                else {
                    return this.each(function () {
                        var datePicker = getDatePickerForMethod(this);
                        datePicker.datepicker(method, options);
                    });
                }
            }
        };

        if (methods[methodOrSettings]) {
            return methods[methodOrSettings].apply(this, Array.prototype.slice.call(arguments, 1));
        }
        else if (typeof methodOrSettings === 'object' || !methodOrSettings) {
            return methods.init.apply(this, arguments);
        }
        else {
            return methods.proxy.apply(this, arguments, options);
        }
    };



    function useBrowserDatepicker() {
        return false;
        //return Modernizr.inputtypes.date && Modernizr.touch;
    }

    function getDatePickerForMethod(element) {
        var datePicker = $(element);

        if (!datePicker.hasClass('datepicker')) {
            datePicker = datePicker.closest('.datepicker');
        }

        return datePicker;
    }

    function addDefaultSettings(settings) {
        if (settings == null) {
            settings = {};
        }

        if (settings.hideDays != null && settings.hideDays === true) {
            hideDays = true;
        }

        if (settings.language == null) {
            settings.language = 'en';
            //TODO - Set at appropriate location.
            currentLanguage = $.cookie("language");

            if (currentLanguage != null) {
                switch (currentLanguage) {
                    case 'nl': settings.language = 'nl-BE'; break;
                    case 'fr': settings.language = 'fr'; break;
                }
            }
        }

        if (settings.orientation == null) {
            settings.orientation = "bottom auto";
        }

        if (settings.autoclose == null) {
            settings.autoclose = true;
        }

        if (settings.todayHighlight == null) {
            settings.todayHighlight = true;
        }

        if (settings.forceParse == null) {
            settings.forceParse = false;
        }

        if (settings.minViewMode == null) {
            settings.minViewMode = hideDays ? 1 : 0;
        }

        if (settings.format == null) {
            settings.format = hideDays ? 'dd/mm/yyyy' : 'dd/mm/yyyy';
        }


        return settings
    }

    function enableDatePicker(datePicker) {
        datePicker.removeClass('disabled');
        datePicker.find(':text').attr('disabled', false);
        datePicker.find('span.input-group-addon').removeClass('disabled');
    }

    function disableDatePicker(datePicker) {
        datePicker.addClass('disabled');
        datePicker.find(':text').attr('disabled', true);
        datePicker.find('span.input-group-addon').addClass('disabled');
    }

    function isMonthsDate(s) {
        return isDate('01/' + s);
    }

    function isDate(s) {
        // make sure it is in the expected format
        if (s.search(/^\d{1,2}\/\d{1,2}\/\d{4}/g) != 0)
            return false;

        var parts = s.split('/');

        // convert it into a date instance
        var dt = new Date(parts[2], parts[1] - 1, parts[0]);

        // check the components of the date
        // since Date instance automatically rolls over each component
        return (
            dt.getMonth() == parts[1] - 1 &&
            dt.getDate() == parts[0] &&
            dt.getFullYear() == parts[2]
        );
    }

    var hideDays = false;
    var defaultDate = new Date();
}(jQuery));