﻿$(function () {
    //validation_overrideDefaults();
    validation_registerValidators();

    $("form").each(function () {
        initializeFormValidation(this);
    });
    // remove error messages when reset
    $('form').on('reset', function (e) {
        var $form = $(this);
        $form.data('validator').resetForm();
    });

    $(document).on('hide.bs.modal', '.modal', function (e) {
        var $forms = $(this).find('form');

        $.each($forms, function () {
            var $form = $(this);
            if ($form.data('validator')) {
                $form.data('validator').resetForm();
            }
        });
    });

    $(document).on('change', '.bootstrap-select select', function (e) {
        $(this).trigger('blur');
    });
    var language = location.pathname.split("/")[1];
    if (language.toUpperCase() == "FR") {
        jQuery.extend(jQuery.validator.messages, {
            max: jQuery.validator.format("Le montant introduit dépasse le montant maximal autorisé de € {0}."),
            min: jQuery.validator.format("Veuillez contribuer au minimum € {0}."),
            required_group: jQuery.validator.format("Veuillez remplir au minimum {0} de ces champs.")
        });
    } else if (language.toUpperCase() == "NL") {
        jQuery.extend(jQuery.validator.messages, {
            max: jQuery.validator.format("Het ingevoerde bedrag is hoger dan het maximaal toegestane bedrag van € {0}."),
            min: jQuery.validator.format("Gelieve een bijdrage te leveren van ten minste € {0}."),
            required_group: jQuery.validator.format("Gelieve minstens {0} van deze velden in te vullen.")
        });
    }
});

function initializeFormValidation(element) {
    if (element) {
        var parentErrorClass = 'group-validation-error';

        $(element).validate({
            errorPlacement: function (error, element) {
                error.appendTo(element.closest('.form-group'));
            },
            ignore: ":hidden,.ignoreValidation",
            highlight: function (element, errorClass, validClass) {
                if (element.type === "radio") {
                    this.findByName(element.name).addClass(errorClass).removeClass(validClass);
                } else {
                    $(element).addClass(errorClass).removeClass(validClass);
                }

                $(element).closest('.form-group').addClass(parentErrorClass);
            },
            unhighlight: function (element, errorClass, validClass) {
                if (element.type === "radio") {
                    this.findByName(element.name).removeClass(errorClass).addClass(validClass);
                } else {
                    $(element).removeClass(errorClass).addClass(validClass);
                }

                $(element).closest('.form-group').removeClass(parentErrorClass);
            },
            onfocusout: function (element) {
                $(element).valid();
            }
        });
    }
}

function validation_registerValidators() {
    var nameRegex = /^(?=.*[a-zA-Z]).+$/;
    var cityRegex = /^(?=.*[a-zA-Z]).+$/;
    var numberCheckRegex = /^(?=.*[0-9]).+$/;
    var alphanumericRegex = /^[A-Za-z0-9]+$/;
    var numberRegex = /^\d*[0-9]?$/;
    var zipRegex = /^[0-9]{4}$/;
    var ElevenNumberRegex = /^[0-9]{11}$/;
    //var streetRegex = /^[^\w\d]*(([0-9]+.*[A-Za-z]+.*)|[A-Za-z]+.*([0-9]+.*))$/;
    var streetRegex = /[\d]*[a-zA-Z]+[\d]*/;
    var houseNumber = /[a-zA-Z]*[\d]+[a-zA-Z]*/;
    var dateRegex = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[6-9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[6-9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[6-9]|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/;
    //var emailregex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var emailregex = /^[a-z0-9A-Z\! \# \$ \% \& \' \* \+ \- \/ \= \? \^ \_ \` \{ \| \} \~]+([\.-]?[a-z0-9A-Z\! \# \$ \% \& \' \* \+ \- \/ \= \? \^ \_ \` \{ \| \} \~]+)*[\@][a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    var ibanRegex = /^[0-9]{14}$/;
    function isDateInThePast(value) {
        var date = getDate(value);

        if (date) {
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            date.setHours(0, 0, 0, 0);

            var timeDiff = today.getTime() - date.getTime();
            var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

            return diffDays >= 1;

            //var timeDiff = date2.getTime() - date1.getTime();
            //var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
            //if (diffDays == -1) { alert("Yesterday") }
        }

        return false;
    }

    function isUnder16Years(value) {
        var date = getDate(value);

        if (date) {
            //var age = moment({hour:0}).diff(moment(value, 'DD/MM/YYYY'), 'years', true);
            var age = moment({ hour: 0 }).diff(date, 'months', true);
            return age < 191;
        }

        return false;
    }

    function isToday(value) {
        var date = getDate(value);

        if (date) {
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            date.setHours(0, 0, 0, 0);

            var timeDiff = today.getTime() - date.getTime();
            var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

            return diffDays != 0;
        }

        return false;
    }

    function isLessThan6MonthsInFuture(value) {
        var date = getDate(value);

        if (date) {
            var age = moment({ hour: 0 }).diff(date, 'months', true);
            return age >= -6;
        }

        return false;
    }

    function isLessThan10YearsInFuture(value) {
        var date = getDate(value);

        if (date) {
            var expDate = moment({ hour: 0 }).diff(date, 'years', true);
            return expDate >= -10;
        }

        return false;
    }
    function isLessThan18YearsInFuture(value) {
        var date = getDate(value);

        if (date) {
            var expDate = moment({ hour: 0 }).diff(date, 'years', true);
            return expDate > 18;
        }

        return false;
    }

    function isGreaterThan99YearsInFuture(value) {
        var date = getDate(value);

        if (date) {
            var expDate = moment({ hour: 0 }).diff(date, 'years', true);
            return expDate < 99;
        }

        return false;
    }

    function isInTheFuture(value) {
        var date = getDate(value);

        if (date) {
            var age = moment({ hour: 0 }).diff(date, 'days', true);
            return age < 0;
        }

        return false;
    }

    function isInTheFuturecheck(value) {
        var date = getDate(value);

        if (date) {
            var age = moment({ hour: 0 }).diff(date, 'days', true);
            return age < 0;
        }

        return false;
    }

    function getDate(s) {
        // make sure it is in the expected format
        if (s.search(/^\d{1,2}\/\d{1,2}\/\d{4}/g) != 0)
            return null;

        var parts = s.split('/');

        // convert it into a date instance
        var dt = new Date(parts[2], parts[1] - 1, parts[0]);

        // check the components of the date
        // since Date instance automatically rolls over each component
        if (dt.getMonth() == parts[1] - 1 &&
            dt.getDate() == parts[0] &&
            dt.getFullYear() == parts[2]) {
            return dt;
        }
        return null;
    }

    function checkMinVal(value) {
        if (value) {
            return value != 0;
        }
        return false;
    }
    function checkLongTermVal(value) {
        if (value && $("#maxAvailableAmount").val()) {
            return value <= Number($("#maxAvailableAmount").val());
        }
        return false;
    }
   
    function checkIban(value) {
        if (ibanRegex.test(value)) {
            var countryCode = "BE";
            //var sanityCheckCode = value.slice(2, 4);
            var accountNumber = parseInt(value.slice(2, 12));
            var accountCheck = parseInt(value.slice(12, 14));

            var remainder = accountNumber % 97;
            //countryCode == BelgiumAbbreviation all time it will be true
            var boolAccountSame = accountCheck === remainder;
            return boolAccountSame;
        }
        return false;
    }
    function checkTinDate(value) {
        if (value) {
            var TinVal = value;
            var TinFirstTwoDigit = (TinVal.substring(0, 2));
            var TinscndTwoDigit = (TinVal.substring(2, 4));
            var TinthrdTwoDigit = (TinVal.substring(4, 6));


            if (document.getElementsByTagName('html')[0].className.split(" ").indexOf("MSIE") > -1 || document.getElementsByTagName('html')[0].className.split(" ").indexOf("msie") > -1 || document.getElementsByTagName('html')[0].className.split(" ").indexOf("rv") > -1 || document.getElementsByTagName('html')[0].className.split(" ").indexOf("rvX") > -1) { // if IE/Mozila
                var thisYear = new Date().getFullYear();
                var yearInt = parseInt(thisYear.toString().substring(2, 4));
                var currentYearInt = parseInt(TinFirstTwoDigit.toString());
                if (currentYearInt == 0 || currentYearInt < yearInt) {
                    currentYearInt = "20" + currentYearInt.toString();
                }
                else {
                    currentYearInt = "19" + currentYearInt.toString();
                }

                var tinDate = new Date(currentYearInt.toString() + "/" + TinscndTwoDigit.toString() + "/" + TinthrdTwoDigit.toString());
                var timeDiff = Math.abs(tinDate.getTime() - new Date().getTime());
                var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                if (diffDays / 365 > 18) {
                    return true;
                }
                            }
            else  // If another browser
            {
                var tinDate = new Date(TinFirstTwoDigit.toString() + "/" + TinscndTwoDigit.toString() + "/" + TinthrdTwoDigit.toString());
                var timeDiff = Math.abs(tinDate.getTime() - new Date().getTime());
                var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                if (diffDays / 365 > 18) {
                    return true;
                }
            }

        }
        return false;
    }
    function checkValidTin(value) {
        var TinVal = value;
        var TinFirstNineDigit = Number(TinVal.substring(0, 9));
        var TinLastTwoDigit = Number(TinVal.substring(9, 11));
        var TinFirstTwoDigit = Number(TinVal.substring(0, 2));
        var currentYear = new Date().getFullYear().toString().substr(2, 2);
        var yearOfBirth = "";

        if (TinFirstTwoDigit <= currentYear) {
            yearOfBirth = "20" + TinFirstTwoDigit;
        }
        else {
            yearOfBirth = "19" + TinFirstTwoDigit;
        }

        if (Number(yearOfBirth) <= 1999) {
            if ((97 - Number(TinFirstNineDigit % 97)) == TinLastTwoDigit) {
                return true;
            }
        }
        else if (Number(yearOfBirth) >= 2000) {
            if ((97 - Number(Number("2" + TinFirstNineDigit) % 97)) == TinLastTwoDigit) {
                return true;
            }
        }
        return false;
    }

    function checkRepeatitionOfTin(value, id) {
        var flag = true;
        $("[name^='subTinNumber_']").not("#" + id).each(function () {
            if ($(this).val() == value) {
                flag = false;
                return false;
            }
        });
        return flag;
    }
    $.validator.addMethod(
        "noRepeat",
        function (value, element) { // validation method
            var selectedTinId = $(element).attr("id");
            return this.optional(element) || checkRepeatitionOfTin(value, selectedTinId);
        }
        );
    $.validator.addMethod(
        "aagjeAplhanumeric", // name
        function (value, element) { // validation method
            return alphanumericRegex.test(value) && numberCheckRegex.test(value) && nameRegex.test(value);
        }
    );

    $.validator.addMethod(
       "aagjeNumericOnly", // name
       function (value, element) { // validation method
           return numberRegex.test(value);
       },
       "" // message (optional)
   );
    $.validator.addMethod(
           "aagjeMoneyOutLongTermValue", // name
           function (value, element) { // validation method
               return this.optional(element) || numberRegex.test(value);
           },
           "" // message (optional)
       );
    $.validator.addMethod(
            "minValueMoreThanZero", // name
            function (value, element) {
                return checkMinVal(value);
            },
            ""
            );
    $.validator.addMethod(
        "amountUnderAvailableAmount", // name
        function (value, element) {
            return checkLongTermVal(value);
        },
        ""
    );
    $.validator.addMethod(
      "aagjeElevenNumericOnly", // name
      function (value, element) { // validation method
          return this.optional(element) || ElevenNumberRegex.test(value);
      },
      "" // message (optional)
  );

    $.validator.addMethod(
       "aagjeName", // name
       function (value, element) { // validation method
           return this.optional(element) || nameRegex.test(value);
       }
   );
    $.validator.addMethod(
        "aagjeEmail", // name
        function (value, element) { // validation method
            return this.optional(element) || emailregex.test(value);
        }
    );
    $.validator.addMethod(
        "aagjeProjectAmount", // name
        function (value, element) { // validation method
            return this.optional(element);
        }
    );
    $.validator.addMethod(
        "aagjeCity", // name
        function (value, element) { // validation method
            return this.optional(element) || cityRegex.test(value);
        }
    );

    $.validator.addMethod(
        "aagjeZipCode", // name
        function (value, element) {
            return this.optional(element) || zipRegex.test(value);
        }
    );

    $.validator.addMethod(
        "aagjeStreet", // name
        function (value, element) {
            return this.optional(element) || streetRegex.test(value);
        }
    );

    $.validator.addMethod(
        "aagjeHouseNumber", // name
        function (value, element) {
            return this.optional(element) || houseNumber.test(value);
        }
    );

    $.validator.addMethod(
        "aagjeDate", // name
        function (value, element) {
            return this.optional(element) || dateRegex.test(value);
        }
    );

    $.validator.addMethod(
        "aagjePastDate", // name
        function (value, element) {
            return this.optional(element) || isDateInThePast(value);
        }
    );

    $.validator.addMethod(
        "aagjeNotfutureDate", // name
        function (value, element) {
            return this.optional(element) || isDateInThePast(value);
        }
    );

    $.validator.addMethod(
        "aagjeUnder16Years", // name
        function (value, element) {
            return this.optional(element) || isUnder16Years(value);
        }
    );
    $.validator.addMethod(
       "aagjeisToday", // name
       function (value, element) {
           return this.optional(element) || isToday(value);
       }
   );

    $.validator.addMethod(
        "aagjeLessThan6MonthsInFuture", // name
        function (value, element) {
            return this.optional(element) || isLessThan6MonthsInFuture(value);
        }
    );
    $.validator.addMethod(
        "aagjeLessThan10YearsInFuture", // name
        function (value, element) {
            return this.optional(element) || isLessThan10YearsInFuture(value);
        }
    );

    $.validator.addMethod(
        "aagjeLessThan18YearsInFuture", // name
        function (value, element) {
            return this.optional(element) || isLessThan18YearsInFuture(value);
        }
    );

    $.validator.addMethod(
        "aagjeGreaterThan99YearsInFuture", // name
        function (value, element) {
            return this.optional(element) || isGreaterThan99YearsInFuture(value);
        }
    );

    $.validator.addMethod(
        "aagjeInFuture", // name
        function (value, element) {
            return this.optional(element) || isInTheFuture(value);
        }
    );
    $.validator.addMethod(
        "aagjeInFutureCheck", // name
        function (value, element) {
            return isInTheFuturecheck(value);
        }
    );

    $.validator.addMethod(
        "aagjeDropdown", // name
        function (value, element) {
            return value !== null && value !== "" && value.toLowerCase() !== "select" && value.toLowerCase().indexOf("select") == -1 && value.toLowerCase().indexOf("choose") == -1 && value.toLowerCase().indexOf("string") == -1;
        }
    );

    $.validator.addMethod(
        "aagjeIban", // name
        function (value, element) {
            return this.optional(element) || checkIban(value);
        }
    );
    $.validator.addMethod(
       "checkTinDate", // name
       function (value, element) {
           return checkTinDate(value);
       }
   );
    $.validator.addMethod(
        "validTinNumber", // name
        function (value, element) {
            return checkValidTin(value);
        }
    );



    //$.validator.addMethod(
    //    "aagjeLongTermMandatory", // name
    //    function (value, element) {
    //        if ($("#shortTermValue").is(":visible") && $("#shortTermValue").val() == "" && value == "") {
    //            return false;
    //        } else {
    //            return true;
    //        }
    //    }
    //);

    //$.validator.addMethod(
    //    "aagjeShortTermMandatory", // name
    //    function (value, element) {
    //        if ($("#longTermValue").is(":visible") && $("#longTermValue").val() == "" && value == "") {
    //            return false;
    //        } else {
    //            return true;
    //        }
    //    }
    //);

    $.validator.addClassRules("contribute-amount", {
        required_group: [1, ".contribute-amount"]
    });

    $.validator.addMethod("required_group", function (value, element, options) {
        var $fields = $(options[1], element.form),
            $fieldsFirst = $fields.eq(0),
            validator = $fieldsFirst.data("valid_req_grp") ? $fieldsFirst.data("valid_req_grp") : $.extend({}, this),
            isValid = $fields.filter(function () {
                return validator.elementValue(this);
            }).length >= options[0];

        // Store the cloned validator for future validation
        $fieldsFirst.data("valid_req_grp", validator);

        // If element isn't being validated, run each require_from_group field's validation rules
        if (!$(element).data("being_validated")) {
            $fields.data("being_validated", true);
            $fields.each(function () {
                validator.element(this);
            });
            $fields.data("being_validated", false);
        }
        return isValid;
    }, $.validator.format("Please fill in at least {0} of these fields."));

    $.validator.addMethod(
        "aagjePhone",
        function (value, element) {
            return this.optional(element)
                || ($(element).intlTelInput("isValidNumber") && $(element).intlTelInput("getSelectedCountryData").dialCode);
        });

    $.validator.addMethod(
        "aagjeValidZipCode", // name
        function (value, element) { // validation method
            if (value.length == 4) {
                return (this.optional(element) || true);
            }
            else if (value.length == 0) {
                return this.optional(element)
            }
        }
    );

    $.validator.addMethod(
        "aagjeUserName", // name
        function (value, element) { // validation method
            return true;
        }
    );

    $.validator.addMethod(
    "aagjePasswordMatch", // name
    function (value, element) { // validation method
        //return true;
        if ($(element).attr('id') == 'password') {
            return this.optional(element)
        }
        else if ($(element).attr('id') == 'confirmPassword') {
            return this.optional(element) || ($('#confirmPassword').val() == $('#password').val());
        }
    }
);
}