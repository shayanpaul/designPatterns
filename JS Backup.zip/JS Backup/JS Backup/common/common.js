﻿
function CalculateAge(dateOfBirth) {
    var today = new Date();
    var dd = Number(today.getDate());
    var mm = Number(today.getMonth() + 1);
    var yyyy = Number(today.getFullYear());


    var dobDay = Number(dateOfBirth.split("/")[0]);
    var dobMonth = Number(dateOfBirth.split("/")[1]);
    var dobYear = Number(dateOfBirth.split("/")[2]);
    var age = yyyy - dobYear;
    if (mm < dobMonth) {
        age = age - 1;
    }
    else if (mm == dobMonth && dd < dobDay) {
        age = age - 1;
    }

    return age;
}



function CalculateAgeWithMonths(dateOfBirth) {

    var now = new Date();
    var today = new Date(now.getYear(), now.getMonth(), now.getDate());

    var yearNow = now.getFullYear();
    var monthNow = now.getMonth() + 1;
    var dateNow = now.getDate();

    var dobDay = Number(dateOfBirth.split("/")[0]);
    var dobMonth = Number(dateOfBirth.split("/")[1]);
    var dobYear = Number(dateOfBirth.split("/")[2]);

    if (dobMonth < 10)
        dobMonth = "0" + dobMonth;

    if (dobDay < 10)
        dobDay = "0" + dobDay;

    var formatteddate = dobMonth + "/" + dobDay + "/" + dobYear;

    var dob = new Date(formatteddate.substring(6, 10),
                       formatteddate.substring(0, 2) - 1,
                       formatteddate.substring(3, 5)
                       );

    var yearDob = dob.getFullYear();
    var monthDob = dob.getMonth() + 1;
    var dateDob = dob.getDate();
    var age = {};
    var ageString = "";
    var yearString = "";
    var monthString = "";
    var dayString = "";

    yearAge = yearNow - yearDob;

    var actualyearAge = yearAge;
    var monthAge = 0;

    if (yearAge > 0) {

        if (monthNow >= monthDob)
            monthAge = monthNow - monthDob;
        else {
            yearAge--;
            monthAge = 12 + monthNow - monthDob;
        }
    }

    if (actualyearAge == 0) {
        monthAge = monthNow - monthDob;
    }


    if (actualyearAge < 0) {

        monthAge = (12 - monthNow) + monthDob;
    }

    age = {
        years: yearAge,
        months: monthAge
    };

    ageString = age.years + "." + age.months;

    return ageString;
}



function GetDateFormat(date) {
    //Return response Format 12 - March - 2016

    var dateResponse = new String();
    var sptdate = String(date).split("/");
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var day = sptdate[0];
    var month = sptdate[1];
    var year = sptdate[2];
    dateResponse.combinedate = day + " - " + months[month - 1] + " - " + year;
    return dateResponse.combinedate;
}

function GetTodayDate() {

    //Return Reponse format dd/MM/YYYY

    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = "0" + dd
    }
    if (mm < 10) {
        mm = "0" + mm
    }

    today = dd + "/" + mm + "/" + yyyy;

    return today;
}

function ConvertDateFormat(date) {

    // input :YYYY-MM-DD
    //output : DD/MM/YYYY

    var datesplit = date.split("-");
    var yyyy = datesplit[0];
    var mm = datesplit[1];
    var dd = datesplit[2];

    formatteddate = dd + "/" + mm + "/" + yyyy;

    return formatteddate;
}

function FormatDate(value) {
    var date = new Date(value);
    var day = date.getDate();
    var month = date.getMonth() + 1;

    return (day < 10 ? '0' : '') + day + '/' + (month < 10 ? '0' : '') + month + '/' + date.getFullYear();
}
// to display image in dropzone
function PreviewThumbailFromUrl(opts) {
    var imgDropzone = Dropzone.forElement("#" + opts.selector);
    var mockFile = {
        name: opts.fileName,
        size: 12345,
        accepted: true,
        kind: "image"
    };
    imgDropzone.emit("addedfile", mockFile);
    imgDropzone.files.push(mockFile);
    imgDropzone.createThumbnailFromUrl(mockFile, opts.imageURL, function () {
        imgDropzone.emit("complete", mockFile);
    },true);
    $("#id_base64_eventUploadPicture").val(opts.imageURL);
}

function PreviewThumbnailFromProjectUrl(opts) {
    var imgProjectDropzone = Dropzone.forElement("#" + opts.selector);
    var mockProjectFile = {
        name: opts.fileName,
        size: 12345,
        accepted: true,
        kind: "image"
    };
    imgProjectDropzone.emit("addedfile", mockProjectFile);
    imgProjectDropzone.files.push(mockProjectFile);
    imgProjectDropzone.createThumbnailFromUrl(mockProjectFile, opts.imageURL, function () {
        imgProjectDropzone.emit("complete", mockProjectFile);
    },true);
    $("#id_base64_savingSchoolUploadPicture").val(opts.imageURL);
}

// to remove image from dropzone
function RemoveProjectThumbailFromUrl(projectimage) {
    var dropzoneFileProjectPicture = Dropzone.forElement("#" + projectimage.selector);
    dropzoneFileProjectPicture.removeAllFiles(true);
}
