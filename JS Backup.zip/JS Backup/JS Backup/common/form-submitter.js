﻿    myAppangular
        .factory("FormSubmitter", ['$rootScope', '$sce', FormSubmitter])
        .directive("formSubmitter", ['$timeout', formSubmitterDirective]);
    myAppangular.directive('myCustom', function () {
        return {
            restrict: "E",
            replace: true,
            //template: "<form id='dropzoneFrontView' class='dropzone uploaded-pic'></form>",
            template :  function(elem, attr) {
                return "<form id=' " + attr.id + " ' class='" + attr.class + "'><i class='gyphicon glyphicon-aagje-ID-card-" + attr.icon + " id-card-font-back'></i></form>";
            }
        };
    });

    function FormSubmitter($rootScope, $sce) {
        // Expose our Api
        return {
            submit: submit
        }


        function submit(url,method, params) {
              url = $sce.trustAsResourceUrl(url);
            $rootScope.$broadcast("form.submit", {
                url:url,
                method: method,
                params: params
            });
        }
    }

    function formSubmitterDirective($timeout) {
        return {
            restrict: "E",
            replace: true,
            template: "<form action='{{form.url}}' method='{{form.method}}' id='paymentForm'>" +
            "<div><input type='hidden' name='redirectionVersion' value='{{form.params.RedirectionVersion}}'> <input type='hidden' name='redirectionData' value='{{form.params.RedirectionData}}'></div>" +
            "</form>",
            link: function ($scope, $element, $attrs) {
                $scope.$on("form.submit", function (event, data) {
                    $scope.form = data;
                    $timeout(function () {
                        
                        $element.submit();
                    })
                })
            }
        }
    }