﻿myAppangular.factory('gemaltoFactory', ['$http', "$rootScope", "FactoryHelper", function ($http, $rootScope, FactoryHelper) {

    var eidUploadResponse = function (EidData) {
        var apiUrl = '/gemalto/processresponse';
        return FactoryHelper.CallApiPost(apiUrl, EidData);
    }
    return {
        eidUploadResponse: eidUploadResponse
    }
}]);