﻿////var gemaltoModule = angular.module('gemaltoModule', []);
//gemaltoModule.controller('gemaltoController', ["$scope", "gemaltoFactory", "$rootScope", "$state", function ($scope, gemaltoFactory, $rootScope, $state) {
//    var eidDataToPost = angular.element("#eidResponse").val();
//    var gematoPostObject = {
//        "GemaltoResponse": eidDataToPost,
//        "PersonId": $.cookie("personId")
//    };
//   //$('#gemaltoContainer').hide();
//   // angular.element("#gemaltoContainer").hide();
//    $('#pageLoader').addClass('show');
//    $('html').addClass('no-scroll');
//    gemaltoFactory.eidUploadResponse(gematoPostObject).then(function (data) {
//        console.log(data);
//            //Send status 
//        if (data.data.Result) {
//           // $('#gemaltoContainer').hide();
//           // localStorage.setItem("gemaltoFailed", true);
//            if (localStorage.identityInitiator == 'moneyOut' || localStorage.identityInitiator == 'payment') {
//                localStorage.setItem("eidUploadSucess", true);                
//                top.window.location.href = '/' + $.cookie('language') + '/home/child/' + localStorage.childIdMoneyOut + '/plan'
                
//            } else {
                
//            top.window.location.href = "/" + $.cookie('language') + "/subscription/Start?eid=" + data.data.Result;
//        }
            
//        }
//        else {           
//            if (localStorage.identityInitiator == 'moneyOut' || localStorage.identityInitiator == 'payment') {
//                localStorage.setItem("eidUploadSucess", false);               
//                top.window.location.href = '/' + $.cookie('language') + '/home/child/' + localStorage.childIdMoneyOut + '/plan'

//            } else {
                
//            top.window.location.href = "/" + $.cookie('language') + "/subscription/Start?eid=" + false;
//        }
//        }


//});

//}]);

    