﻿myAppangular.factory('InvitationService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    var url;
    /*Saving Invite Supporter*/
    function PostInvitedAdminDetail(postData) {
        var apiUrl = '/invitations/admin';
        //url = baseUrl + apiUrl;
        //request = $http({
        //    method: 'POST',
        //    url: url,
        //    data: postData
        //});
        //return request;
        return FactoryHelper.CallApiPost(apiUrl, postData);
    };

    return {
        PostInvitedAdminDetail: PostInvitedAdminDetail
    };
}]);
