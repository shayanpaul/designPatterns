﻿myAppangular.factory('EventService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    //function GetEventDetails(id) {
    //    var apiUrl = '/events/' + id;

    //    return FactoryHelper.CallApiGet(apiUrl);
    //}

    function SendEventInvitation(eventDetails) {
        var apiUrl = '/events/notification';

        return FactoryHelper.CallApiPost(apiUrl, eventDetails);
    };

    //function GetEmptyEventData() {
    //    var apiUrl = '/events/emptyinvitation';

    //    return FactoryHelper.CallApiGet(apiUrl);
    //}
    
    function ApproveEventInvitation(eventDetails) {
        var apiUrl = '/events/notification/status/true';
        return FactoryHelper.CallApiPost(apiUrl, eventDetails);
    }

    return {
        SendEventInvitation: SendEventInvitation,
      //  GetEventDetails: GetEventDetails,
        //GetEmptyEventData: GetEmptyEventData,
        ApproveEventInvitation: ApproveEventInvitation
    };
}]);