﻿angularAuthApp.factory('authInterceptorService', ["$q", "$injector", "$location", "authService", "idmErrorService", function ($q, $injector, $location, oauthSettings, idmErrorService) {

        var authInterceptorServiceFactory = {};

        var _request = function (config) {
            var token = accessToken;
            if (token != '') {
                config.headers.Authorization = 'Bearer ' + token;
            }
            return config;
        };

        var _responseError = function (rejection) {
            if (rejection.status === 401) {
                //idmTokenManager.removeToken();
                //Call here the RefreshToken action
            }
            if (rejection.status === 403) {
                //idmTokenManager.removeToken();
            }
            if (rejection.status === 400) {
                idmErrorService.show(rejection.data);
            }
            if (rejection.status === 500) {
                idmErrorService.show(rejection.data);
            }

            return $q.reject(rejection);
        };

        authInterceptorServiceFactory.request = _request;
        authInterceptorServiceFactory.responseError = _responseError;

        return authInterceptorServiceFactory;
    }]);

