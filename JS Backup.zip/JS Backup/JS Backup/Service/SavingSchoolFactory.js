﻿myAppangular.factory('savingSchoolService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    var url;
    var savingSchoolDetails = "";
    var WishDetails = [];
    
    //Get wish list
    function getWishList(childId) {
        var apiUrl = '/savingschool/child/' + childId + '/wishlist';
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function getSavingSchoolDetail(personId, childId) {
        var apiUrl = '/savingschool/person/' + personId + '/child/' + childId + '/savingschooldetails';

        return FactoryHelper.CallApiGet(apiUrl);
    };

    function activateLevel2(personId, childId)
    {
        var apiUrl = '/savingschool/person/' + personId + '/child/' + childId + '/activatelevel';
        return FactoryHelper.CallApiGet(apiUrl);
    }

    function saveActiveProjectByPriority(priorityData)
    {
        var apiUrl = '/savingschool/person/self/projectpriority';
        return FactoryHelper.CallApiPost(apiUrl, priorityData);
    }

    function saveCustomAmount(resources) {
        var apiUrl = '/savingschool/person/self/customamount';
        return FactoryHelper.CallApiPost(apiUrl, resources);
    }


    function saveProjectDetails(shortTermProjectData) {
        var apiUrl = '/savingschool/person/self';
        return FactoryHelper.CallApiPost(apiUrl, shortTermProjectData);
    };
    
    function updateProjectStatus(projectDetail, personId, childId) {
        var apiUrl = '/savingschool/person/' + personId + '/child/' + childId + '/savingschoolprojects';
        return FactoryHelper.CallApiPost(apiUrl, projectDetail);
    };

    function deleteProject(projectDetail) {
        var apiUrl = '/savingschool/person/self/savingschoolproject';
        return FactoryHelper.CallApiPost(apiUrl, projectDetail);
    };

    function updatePendingProjectStatus(projectDetail, personId, childId, isApprove, isInfantChild) {
        var apiUrl = '/savingschool/person/' + personId + '/child/' + childId + '/' + isApprove + '/' + isInfantChild + '/savingschoolpendingprojects';
        return FactoryHelper.CallApiPost(apiUrl, projectDetail);
    };
    function setSavingSchoolData(data) {
        savingSchoolDetails = data;

    };
    function getSavingSchoolData() {
        return savingSchoolDetails
    }
    function setWishData(data) {
        WishDetails = data;

    };
    function getWishData() {
        return WishDetails
    }
    return {
        
        getWishList: getWishList,
        getSavingSchoolDetail: getSavingSchoolDetail,
        activateLevel2: activateLevel2,
        saveActiveProjectByPriority: saveActiveProjectByPriority,
        saveProjectDetails: saveProjectDetails,
        saveCustomAmount: saveCustomAmount,
        updateProjectStatus: updateProjectStatus,
        deleteProject: deleteProject,
        updatePendingProjectStatus: updatePendingProjectStatus,
        getSavingSchoolData: getSavingSchoolData,
        setSavingSchoolData: setSavingSchoolData,
        getWishData: getWishData,
        setWishData: setWishData
    };
}]);
