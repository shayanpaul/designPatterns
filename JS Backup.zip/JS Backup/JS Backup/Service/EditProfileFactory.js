﻿myAppangular.factory('EditProfileService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    var parentalControlData = '';
    function GetUserProfile(personId) {
        //Not using self route for backoffice access
        var apiUrl = '/profiles/' + personId;
        return FactoryHelper.CallApiGet(apiUrl);
    }

    var EditSupporterNickName = function (url, data) {
        //var apiUrl = '/profiles/self';
        return FactoryHelper.CallApiPost(url, data);
    }
    function UpdateUserProfile(updateSettingPostData) {
         var apiUrl = '/profiles/self';
         return FactoryHelper.CallApiPost(apiUrl, updateSettingPostData);
    }

    function GetUsersChildProfile(personId, childId) {
        //Not using self route for backoffice access
        var apiUrl = '/profiles/' + personId + '/children/' + childId;
        return FactoryHelper.CallApiGet(apiUrl);
    }

    function UpdateChildProfile(childId, updateSettingPostData) {
        //Not using self route for backoffice access
        var apiUrl = '/profiles/self/children/' + childId;
        return FactoryHelper.CallApiPost(apiUrl, updateSettingPostData);
    }
    
    /* Saving Parental Control*/
    function SaveParentalControl(data) {       
        var apiUrl = '/childsaving/child/self/parentalcontrol';

        return FactoryHelper.CallApiPost(apiUrl, data);
    };

    /* Get Parental Information Based on Parent ID*/
    function GetParentalInformationBasedonParentID(parentId, childId) {
        var apiUrl = '/childsaving/person/' + parentId + '/child/' + childId + '/parentalcontrol';

        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetParentalInformationForImage(personId) {
        var apiUrl = '/members/' + personId + '/parentalsettingtoupdatepicture';

        return FactoryHelper.CallApiGet(apiUrl);
    }

   // function updateSettingData(updateSettingUrl, updateSettingPostData) {
    

    function UpdateChildPicture(data, childId) {
         var apiUrl = '/profiles/child/' +childId +'/images';

         return FactoryHelper.CallApiPost(apiUrl, data);
     }

     function UpdateUserPicture(data) {
         var apiUrl = '/profiles/self/images';

         return FactoryHelper.CallApiPost(apiUrl, data);
     }

     function DeleteUserPicture(data) {
         var apiUrl = '/members/deleteimage';

         return FactoryHelper.CallApiPost(apiUrl, data);
     }

    function CheckAdultChild(childId) {
        var apiUrl = '/childsaving/child/' + childId + '/checkinfant';
        
        return FactoryHelper.CallApiGet(apiUrl);
    }

    function CheckIfPersonIsAdult(personId) {
        var apiUrl = '/members/' + personId + '/isadult';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function GetLanguagePreference(personId) {
        var apiUrl = '/profiles/' + personId + '/preferredlanguage';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function SaveLanguagePreference(personId, language) {
        var apiUrl = '/profiles/self/preferredlanguage';

        var data = {
            PreferredLanguage: language
        };

        return FactoryHelper.CallApiPost(apiUrl, data);
    }

    function GetAdminByChildId(childId) {
        var apiUrl = '/invitations/child/' + childId + '/admin';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function DeleteAdmin(personId, childId, adminId) {
        var apiUrl = '/invitations/person/' + personId + '/child/' + childId + "/admin/" + adminId;

        return FactoryHelper.CallApiDelete(apiUrl);
    }

    function GetMandateDocument(personId) {
        var apiUrl = '/childsaving/person/' + personId + '/document';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function GetCityZipCode(zipCode) {
        
        var apiUrl = '/common/zipcode/' + zipCode + '/cityzipcodedetails';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function GetAllCountries() {

        var apiUrl = '/common/countries';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function CreateChildAccount(childId,data ) {

        var apiUrl = '/users/self/childuseraccount/' + childId;

        return FactoryHelper.CallApiPost(apiUrl, data);
    }

    function DownloadMandateDocument(personId) {
        var apiUrl = "/childsaving/person/" + personId + "/mandateDocument";
        return FactoryHelper.CallApiGet(apiUrl);
    }
    function checkUserNameExist(userName) {
        var apiUrl = "/users/self/childuseraccount/"+userName;
        return FactoryHelper.CallApiGet(apiUrl);
    }
    var setParentalControl = function (parentData) {
        parentalControlData = parentData;
    };
    var getParentalControl = function () {
        return parentalControlData;
    };
    return {
        GetUserProfile: GetUserProfile,
        UpdateUserProfile: UpdateUserProfile,
        GetUsersChildProfile:GetUsersChildProfile,
        UpdateChildProfile:UpdateChildProfile,
        SaveParentalControl : SaveParentalControl,
        GetParentalInformationBasedonParentID: GetParentalInformationBasedonParentID,
        GetParentalInformationForImage : GetParentalInformationForImage,       
        UpdateUserPicture: UpdateUserPicture,
        UpdateChildPicture:UpdateChildPicture,
        DeleteUserPicture: DeleteUserPicture,
        CheckAdultChild: CheckAdultChild,
        CheckIfPersonIsAdult: CheckIfPersonIsAdult,
        GetLanguagePreference : GetLanguagePreference,
        SaveLanguagePreference: SaveLanguagePreference,
        GetAdminByChildId : GetAdminByChildId,
        DeleteAdmin: DeleteAdmin,
        GetMandateDocument: GetMandateDocument,
        GetCityZipCode: GetCityZipCode,
        GetAllCountries: GetAllCountries,
        CreateChildAccount: CreateChildAccount,
        EditSupporterNickName: EditSupporterNickName,
        checkUserNameExist:checkUserNameExist,
        DownloadMandateDocument: DownloadMandateDocument,
        setParentalControl: setParentalControl,
        getParentalControl: getParentalControl
    };
}]);

myAppangular.factory('parentalsettingsService', function () {
    var parentalsettingsData = {};

    var setData = function (key, data) {
        parentalsettingsData[key] = data;
    }

    var getData = function (key) {
        return parentalsettingsData[key];
    }

    return {
        setData: setData,
        getData: getData
    }
});
