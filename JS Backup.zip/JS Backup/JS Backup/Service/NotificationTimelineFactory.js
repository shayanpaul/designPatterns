﻿myAppangular.factory('timelineService', ['$http', function ($http) {
    var url;
   
    // Get time line service
    function getTimelineList(timelinePageNumber, timelinePageSize) {
        var apiUrl = "/members/" + $.cookie("personId") + "/timeline?pageNumber=" + timelinePageNumber + "&pageSize=" + timelinePageSize;
        url = baseUrl + apiUrl;
        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    };


    // Get back office message
    function getBackOfficeMessage(auditId) {
        var apiUrl = "/members/" + auditId + "/backOfficeMessage";
        url = baseUrl + apiUrl;
        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    };

    return {
        getTimelineList: getTimelineList,
        getBackOfficeMessage : getBackOfficeMessage
    };
}]);