﻿myAppangular.factory('MemberService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {



    /* Saving Paental Control*/
    function GetMemberDetails() {
        var apiUrl = '/childsaving/child/self/parentalcontrol';

        return FactoryHelper.CallApiPost(apiUrl, data);
    };

    return {        
        GetMemberDetails: GetMemberDetails
    }

}]);