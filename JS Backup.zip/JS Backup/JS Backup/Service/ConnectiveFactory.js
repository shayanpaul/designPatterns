myAppangular.factory('connectiveService', ['$http', function ($http) {

    function getPackageDetail(packageExternalReference) {
        var apiUrl = '/connective/package/' + packageExternalReference;
        url = baseUrl + apiUrl;    
        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    };

    function updatePackage(packageExternalReference, status) {
        var apiUrl = '/connective/package/' + packageExternalReference + '/status/' + status;
        url = baseUrl + apiUrl;
        request = $http({
            method: 'PUT',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    };

    function confirmPackage(packageData) {
        var apiUrl = '/connective/package/confirm';
        url = baseUrl + apiUrl;
        request = $http({
            method: 'POST',
            url: url,
            data: packageData,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    };

    return {
        getPackageDetail: getPackageDetail,
        updatePackage: updatePackage,
        confirmPackage: confirmPackage
    };
}]);