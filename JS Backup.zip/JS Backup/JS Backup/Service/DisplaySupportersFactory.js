﻿myAppangular.factory('DisplaySupportersService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    /*Saving Invite Supporter*/
    function PostInvitedSupporterDetail(postData) {
        var apiUrl = '/invitations';
        return FactoryHelper.CallApiPost(apiUrl, postData);
    }

    /*Getting relatioship list*/
    function GetDefaultInviterDetails() {
        var apiUrl = '/invitations/default';
        return FactoryHelper.CallApiGet(apiUrl);
    };
    function ApproveRequestByParent(postData) {
        var apiUrl = '/invitations/approveinvitationbyparent';
        return FactoryHelper.CallApiPost(apiUrl, postData);
    };
    return {
        PostInvitedSupporterDetail: PostInvitedSupporterDetail,
        GetDefaultInviterDetails: GetDefaultInviterDetails,
        ApproveRequestByParent: ApproveRequestByParent
    };
}]);
