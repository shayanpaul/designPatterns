﻿myAppangular.service('WebApiService', ['$http', function ($http) {
    var apiresposne;
    var urlres;
   
    var getWebApiDataTimeline = function (url, language) {
        culture = language;
        if (culture == "EN") {
            culture = 0;
        }
        if (culture == "FR") {
            culture = 1;
        }
        if (culture == "NL") {
            culture = 2;
        }
        url = baseUrl + url + '/person/' + $.cookie("personId") + '/timelinemessages';
        apiresposne = $http({
            type: 'get', url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return apiresposne;
    }

    var getWebApiData = function (url, language) {
        url = baseUrl + url;
        apiresposne = $http({
            type: 'get', url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return apiresposne;
    }
    var getLocalUrl = function (localUrl) {
        localUrl = baseUrl + localUrl;
        urlres = $http({
            type: 'get', url: localUrl,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return urlres;
    }

    var getWebApiData1 = function (url, language, responseobject) {
        url = baseUrl + url;
        apiresposne = $http({
            type: 'get', url: url, params: responseobject,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return apiresposne;
    }

    var updateData = function (url, quoteDetail) {
        url = baseUrl + url;
        apiresposne = $http.post(url, quoteDetail, { headers: { 'Authorization': 'Bearer ' + accessToken } });//({ type: 'post', url: url, data: quoteDetail });
        return apiresposne;
    }
    var updateIdentity = function (url, IdentityDetails) {
        url = baseUrl + url;
        apiresposne = $http.post(url, IdentityDetails, { headers: { 'Authorization': 'Bearer ' + accessToken } });
        return apiresposne;
    }
    var sendOtp = function (url) {
        otpUrl = baseUrl + url;
        var otpResposne = $http({
            type: 'get', url: otpUrl,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return otpResposne;
    }
    var checkOtp = function (url) {
        otpCheckUrl = baseUrl + url;
        var otpResposne = $http({
            type: 'get', url: otpCheckUrl,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return otpResposne;
    }
    var getallCountries = function (parentID) {
        var apiUrl = baseUrl + '/common/countries';
        //var apiUrl = '/members/allprofessions';
        //return FactoryHelper.CallApiGetNew(apiUrl);
        urlres = $http({
            type: 'get', url: apiUrl,
            headers: { 'Ocp-Apim-Subscription-Key': apimKey }
        });
        return urlres;
    };
    function GetBlockedSupporterStatus(personid,supporterId, status) {
        //parentId = $.cookie("parentId");
        var apiUrlForBlock = '/members';
       // var personId = $.cookie("personId");
        var blockStatus = status;
        var urlblockunblocksupporter = baseUrl + apiUrlForBlock + '/blocksupporter';
        var supporterinfo =
        {
            PersonId: personid,
            SupporterId: supporterId,
            BlockStatus: blockStatus
        };
        request = $http({
            method: 'POST',
            url: urlblockunblocksupporter,
            data: supporterinfo,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    }
    //function GetSupporterTransactionHistory(supporterId) {
    //    var personId = $.cookie("personId");

    //    //http://localhost:57943/api/' + $.cookie("language") + '/contribution/GetTotalContributionForChild/2
    //    apiUrl = '/contribution';

    //    //var parentalId = 1;
    //    //supporterId = 1;
    //    //url = baseUrl + apiUrl + '/' + childId;
    //    url = baseUrl + apiUrl + '/person/' + personId + '/supporter/' + supporterId + '/child/' + personId + '/contributiondetails?pagenumber=1&ispagination=true';
    //    request = $http({
    //        method: 'GET',
    //        url: url
    //    });
    //    return request;
    //}
    function GetSupporterTransactionHistory(supporterId, pagenumber) {
        var personId = $.cookie("personId");

        //http://localhost:57943/api/' + $.cookie("language") + '/contribution/GetTotalContributionForChild/2
        apiUrl = '/contribution';

        //var parentalId = 1;
        //supporterId = 1;
        //url = baseUrl + apiUrl + '/' + childId;
        url = baseUrl + apiUrl + '/person/' + personId + '/supporter/' + supporterId + '/child/' + personId + '/contributiondetails?pagenumber=' + pagenumber + '&ispagination=true';
        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    }
    
    function GetDefaultInviterDetails(apiUrl) {
        url = baseUrl + apiUrl;
        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    };

    function GetMyChildrenDetail() {
        var apiUrl = '/members/' + $.cookie("personId") + '/children';
        url = baseUrl + apiUrl;
        
        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    };
    function GetPendingChildrenList() {
        var apiUrl = '/productonboarding/person/' + $.cookie('personId') + '/pendingSubscriptionDetails';
        url = baseUrl + apiUrl;

        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    }
    function GetPendingSupporterDetails(supporterId) {
        var apiUrl = '/invitations/'+supporterId+'/supporterinvitationdetail';
        url = baseUrl + apiUrl;

        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    }
    var sendMailToSupporter = function (emailUrl) {
        url = baseUrl + emailUrl;
        request = $http({
            method: 'POST',
            url: url,
            data: [],
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    }
    function GetBackOfficeMessage() {
        var apiUrl = '/members/self/getGenericUserMessage';
        url = baseUrl + apiUrl;

        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    };

    function GetPendingSupporterDetails(supporterId) {
        var apiUrl = '/invitations/'+supporterId+'/supporterinvitationdetail';
        url = baseUrl + apiUrl;

        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    }
    var sendMailToSupporter = function (emailUrl) {
        url = baseUrl + emailUrl;
        request = $http({
            method: 'POST',
            url: url,
            data: [],
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return request;
    } 


    return {
        getWebApiData: getWebApiData,
        getWebApiData1: getWebApiData1,
        getWebApiDataTimeline: getWebApiDataTimeline,
        GetBlockedSupporterStatus: GetBlockedSupporterStatus,
        GetSupporterTransactionHistory: GetSupporterTransactionHistory,
        getLocalUrl: getLocalUrl,
        updateData: updateData,
        updateIdentity:updateIdentity,
        sendOtp: sendOtp,
        checkOtp:checkOtp,
        GetDefaultInviterDetails: GetDefaultInviterDetails,
        GetMyChildrenDetail: GetMyChildrenDetail,
        getallCountries: getallCountries,
        GetBackOfficeMessage: GetBackOfficeMessage,
        GetPendingChildrenList: GetPendingChildrenList,
        GetPendingSupporterDetails: GetPendingSupporterDetails,
        sendMailToSupporter: sendMailToSupporter


    };
}]);