﻿myAppangular.factory('SupporterService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    // Sent invitation to become supporter
    function BecomeSupporter(data) {
        var apiUrl = '/invitations/parentinvitations';

        return FactoryHelper.CallApiPost(apiUrl, data);
    }

    function GetSupporterInvitation(supporterId) {
        var apiUrl = '/invitations/supporter/' + supporterId

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function AcceptInvitationBySupporter(notificationId) {
        return RespondToInvitationBySupporter(notificationId, true);
    }

    function DeclineInvitationBySupporter(notificationId) {
        return RespondToInvitationBySupporter(notificationId, false);
    }

    function RespondToInvitationBySupporter(notificationId, status) {
        var apiUrl = '/invitations/notification/' + notificationId;

        var data = {
            status: status,
            notificationId: notificationId
        };

        return FactoryHelper.CallApiPost(apiUrl, data);
    }
    function getBecomeSupporterDetails(timelineId) {
        var apiUrl = '/invitations/becomesupporter/' + timelineId;

        return FactoryHelper.CallApiGet(apiUrl);
    }

    return {
        BecomeSupporter: BecomeSupporter,
        GetSupporterInvitation: GetSupporterInvitation,
        AcceptInvitationBySupporter: AcceptInvitationBySupporter,
        DeclineInvitationBySupporter: DeclineInvitationBySupporter,
        getBecomeSupporterDetails: getBecomeSupporterDetails
    };
}]);