﻿myAppangular.factory('ChildProfileService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    function GetMyChildrenDetail(personId) {
        var apiUrl = '/members/' + personId + '/children';

        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetSupportChildrenDetail(personId) {
        var apiUrl = '/members/' + personId + '/supportedchildren';

        return FactoryHelper.CallApiGet(apiUrl);
    };

    function ShowItemsOnChildOverview(personId, childId) {
        var apiUrl = '/childsaving/person/' + personId + '/child/' + childId + '/showitemsonchildoverview';
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetChildSavingPlan(personId, childId) {
        var apiUrl = '/childsaving/person/' + personId + '/child/' + childId + '/planoverview';

        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetChildSavingPlanByChild(personId, childId) {
        var apiUrl = '/childsaving/person/' + personId + '/child/' + childId + '/planoverview/shortterm';

        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetTransactionHistory(parentId, childId, pagenumber) {
        var culture = 0; // en

        switch (currentLanguage) {
            case 'fr':
                culture = 1;
                break;
            case 'nl':
                culture = 2;
                break;
        }

        var apiUrl = '/person/' + parentId + '/child/' + childId + '/contributions?pagenumber=' + pagenumber + '&ispagination=true';

        return FactoryHelper.CallApiGet(apiUrl);
    }
    function GetTaxofTransaction(contractReference, paymentTransactionId) {
        var culture = 0; // en

        switch (currentLanguage) {
            case 'fr':
                culture = 1;
                break;
            case 'nl':
                culture = 2;
                break;
        }

        var apiUrl = '/contribution/contract/' + contractReference + '/payment/' + paymentTransactionId + '/contributioncalculation';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function getTransactionSupporterHistoryForChild(personId, childId, supporterId, pagenumber) {
        var apiUrl = '/contribution/person/' + personId + '/supporter/' + supporterId + '/child/' + childId + '/contributiondetails?pagenumber=' + pagenumber + '&ispagination=true';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function GetMyDetail(parentId) {
        var apiUrl = '/members/' + parentId;

        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetPlanDetail(planId, planType) {
        var apiUrl = '/childsaving/plan/' + planId + '/type/' + planType + '/detail';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function GetSupporterList(parentId) {
        var apiUrl = '/members/' + parentId + '/supporters';

        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetActiveEvents(personId, childId) {
        var apiUrl = '/person/' + personId + '/child/' + childId + '/events';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function GetAllEvents(childId) {
        var apiUrl = '/events/child/' + childId + '/events';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function GetPendingEvents(childId) {
        var apiUrl = '/child/' + childId + '/pendingevents';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function GetPastEvent(childId) {
        var apiUrl = '/events/child/' + childId + '/lasttwoevents';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function DefaultRelationship() {
        var apiUrl = '/events/allrelations';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function getAllProjectsByChild(childId) {
        var apiUrl = '/childsaving/child/' + childId + '/projects';

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function GetChildProfile(personId, childId) {
        var apiUrl = "/childsaving/" + personId + "/child/" + childId + "/profile";

        return FactoryHelper.CallApiGet(apiUrl);
    }

    function getChildProjectById(childId) {
        var apiUrl = '/events/child/' + childId + '/projects';
        return FactoryHelper.CallApiGet(apiUrl);
    }

    function getContractDocument(contractReferenceId) {
        var apiUrl = "/childsaving/contractreference/" + contractReferenceId + "/documents";
        return FactoryHelper.CallApiGet(apiUrl);
    }

    function getEndDate(frequency, longTermPlanId, childId) {
        var apiUrl = '/childsaving/frequency/' + frequency + '/planId/' + longTermPlanId + '/childId/' + childId + '/enddate'
        url = baseUrl + apiUrl;
        request = $http({
            method: 'GET',
            url: url,
            headers: { 'Ocp-Apim-Subscription-Key': apimKey }
        });
        return request;
    };
    return {
        GetSupportChildrenDetail: GetSupportChildrenDetail,
        GetMyChildrenDetail: GetMyChildrenDetail,
        GetChildSavingPlan: GetChildSavingPlan,
        GetTransactionHistory: GetTransactionHistory,
        GetMyDetail: GetMyDetail,
        getTransactionSupporterHistoryForChild: getTransactionSupporterHistoryForChild,
        GetPlanDetail: GetPlanDetail,
        GetSupporterList: GetSupporterList,
        GetActiveEvents: GetActiveEvents,
        GetPendingEvents: GetPendingEvents,
        GetPastEvent: GetPastEvent,
        DefaultRelationship: DefaultRelationship,
        getAllProjectsByChild: getAllProjectsByChild,
        GetChildProfile: GetChildProfile,
        GetChildSavingPlanByChild: GetChildSavingPlanByChild,
        getChildProjectById: getChildProjectById,
        ShowItemsOnChildOverview: ShowItemsOnChildOverview,
        GetTaxofTransaction: GetTaxofTransaction,
        GetAllEvents: GetAllEvents,
        getEndDate: getEndDate,
        getContractDocument: getContractDocument
    };
}]);