﻿myAppangular.factory('InviteSupporterModalService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    function getMyChildrenDetail(personId) {
        var apiUrl = '/members/' + personId + '/children';

        return FactoryHelper.CallApiGet(apiUrl);
    };

    return {
        getMyChildrenDetail: getMyChildrenDetail
    };
}]);