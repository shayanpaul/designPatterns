﻿myAppangular.factory('AnonymousUserService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    function AnonymousPaymentOneShot(entrypoint, invitation) {
        var culture = 0; // en

        switch (currentLanguage) {
            case 'fr':
                culture = 1;
                break;
            case 'nl':
                culture = 2;
                break;
        }

        var apiUrl = culture + '/freecontribution/entrypoint/' + entrypoint + '/invitation/' + invitation + '/initiatepaymentforunregistereduser';
        return FactoryHelper.CallApiGetAnonymous(apiUrl);
    };

    function PayOneShotAsAnonymous(freeContribution) {
        var apiUrl = '/freecontribution/oneshotAsAnonymous';
        return FactoryHelper.CallApiPostAnonymous(apiUrl, freeContribution);
    };

    function PaymentGateway(postData) {
        var apiUrl = '/payments/';
        return FactoryHelper.CallApiPostAnonymous(apiUrl, postData);
    };
    function GetPaymentDetailForFreeContribution(transactionId) {
        var apiUrl = '/freecontribution/contribution/' + transactionId;
        return FactoryHelper.CallApiGetAnonymous(apiUrl);
    };
    function updateTransactionStatus(paymentTransactionId, status) {
        var apiUrl = '/freecontribution/paymentReferenceNumber/' + paymentTransactionId + '/status/' + status + '/updatecontributionandbasketstatus/';
        return FactoryHelper.CallApiGetAnonymous(apiUrl);
    };
    return {
        AnonymousPaymentOneShot: AnonymousPaymentOneShot,
        PayOneShotAsAnonymous: PayOneShotAsAnonymous,
        PaymentGateway: PaymentGateway,
        GetPaymentDetailForFreeContribution: GetPaymentDetailForFreeContribution,
        updateTransactionStatus: updateTransactionStatus
    };
}]);