﻿myAppangular.factory('FactoryHelper', ['$http', '$window', function ($http, $window) {
    $http.defaults.useXDomain = true;
    delete $http.defaults.headers.common['X-Requested-With'];
    function CallApiGet(apiUrl, params) {
        resetTimeOut();
        var promise = $http({
            method: 'GET',
            url: baseUrl + apiUrl,
            params: params,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        })
        .then(function (d) {
            var response = JSON.stringify(d.data);
            var data = JSON.parse(response);

            return data;
        });
        return promise;
    }

    function CallApiGetAnonymous(apiUrl, params) {
        resetTimeOut();
        var promise = $http({
            method: 'GET',
            url: baseUrlAnonymous + apiUrl,
            params: params,
            headers: { 'Ocp-Apim-Subscription-Key': apimKey }
        })
        .then(function (d) {
            var response = JSON.stringify(d.data);
            var data = JSON.parse(response);

            return data;
        });
        return promise;
    }

    function CallApiPost(apiUrl, data) {
        resetTimeOut();
        var promise = $http({
            method: 'POST',
            url: baseUrl + apiUrl,
            data: data,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return promise;
    }

    function CallApiPostAnonymous(apiUrl, data) {
        resetTimeOut();
        var promise = $http({
            method: 'POST',
            url: baseUrlAnonymous + apiUrl,
            data: data,
            headers: { 'Ocp-Apim-Subscription-Key': apimKey }
        });
        return promise;
    }

    function CallApiPut(apiUrl, data) {
        resetTimeOut();
        var promise = $http({
            method: 'PUT',
            url: baseUrl + apiUrl,
            data: data,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return promise;
    }

    function CallApiDelete(apiUrl, data) {
        resetTimeOut();
        var promise = $http({
            method: 'DELETE',
            url: baseUrl + apiUrl,
            data: data,
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
        return promise;
    }
    function resetTimeOut() {
        _startTime = new Date();
        var currentTime = _startTime.getTime();
        if (currentTime >= AccessTokenExpiryTime) {
            $.ajax({
                url: _keepSessionAliveUrl,
                type: 'POST',
                success: function (data) {
                    accessToken = data;
                }
            })
            LastCookieRefreshTime = new Date().getTime();
            AccessTokenExpiryTime = LastCookieRefreshTime + AccessTokenRefreshDuration;
            
        }
    }
    return {
        CallApiGet: CallApiGet,
        CallApiPost: CallApiPost,
        CallApiPut: CallApiPut,
        CallApiDelete: CallApiDelete,
        CallApiGetAnonymous: CallApiGetAnonymous,
        CallApiPostAnonymous: CallApiPostAnonymous
    }
}]);