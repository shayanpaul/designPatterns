﻿myAppangular.factory('PromoCodeService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    // GET
    //function GetPersonDetails(childId) {
    //    var apiUrl = '/members/' + childId;

    //    if (childId && childId != 0) {
    //        return FactoryHelper.CallApiGet(apiUrl);
    //    }
    //}

    //function GetQuotes(personId, childId) {
    //    var apiUrl = '/productonboarding/person/' + personId + '/child/' + childId + '/quotes';

    //    return FactoryHelper.CallApiGet(apiUrl, {
    //        parentid: personId,
    //        childid: childId
    //    });

    //}

    //function GetGenericProductInformation() {
    //    var apiUrl = '/productonboarding/productgenericinformation';

    //    return FactoryHelper.CallApiGet(apiUrl);
    //}

    function GetPromocodeInformation(promoCodeRequest) {
        var apiUrl = '/productonboarding/promocode';

        return FactoryHelper.CallApiPostAnonymous(apiUrl, promoCodeRequest);
    }

    //function GetSubscriptionQuestions() {
    //    var apiUrl = '/productonboarding/subscriptionquestion';

    //    return FactoryHelper.CallApiGet(apiUrl);
    //}

    //function GetEmptyQuoteDetails() {
    //    var apiUrl = '/productonboarding/quotedetails/empty';

    //    return FactoryHelper.CallApiGet(apiUrl);
    //}

    //function GetEmptyProspectIdentification() {
    //    var apiUrl = '/productonboarding/prospectidentification/empty';

    //    return FactoryHelper.CallApiGet(apiUrl);
    //}

    //function GetProductsByAnswers(answers) {
    //    var apiUrl = '/productonboarding/productgenericinformation/filtered';

    //    return FactoryHelper.CallApiGet(apiUrl, answers);
    //}

    function GetPartnerDetails(promoCode) {
        var apiUrl = '/productonboarding/promocode/' + promoCode + '/partnerdetails';

        return FactoryHelper.CallApiGetAnonymous(apiUrl);
    }

    //POST

    //function OrderService(quoteDetail) {
    //    var apiUrl = '/productonboarding/orderservice';

    //    return FactoryHelper.CallApiPost(apiUrl, quoteDetail);
    //}

    function CreateSignature(documentModel) {
        var apiUrl = '/connective';

        return FactoryHelper.CallApiPost(apiUrl, documentModel);
    }

    //function UpdateProspectData(quote) {
    //    var apiUrl = '/productonboarding/quote';

    //    return FactoryHelper.CallApiPost(apiUrl, quote);
    //}

    return {
        //GetPersonDetails: GetPersonDetails,
        //GetQuotes: GetQuotes,
        //GetGenericProductInformation: GetGenericProductInformation,
        //GetSubscriptionQuestions: GetSubscriptionQuestions,
        //GetEmptyQuoteDetails: GetEmptyQuoteDetails,
        //GetEmptyProspectIdentification: GetEmptyProspectIdentification,
        //GetProductsByAnswers : GetProductsByAnswers,
        //OrderService: OrderService,
        CreateSignature: CreateSignature,
        //UpdateProspectData: UpdateProspectData,
        GetPromocodeInformation: GetPromocodeInformation,
        GetPartnerDetails: GetPartnerDetails
    }
}]);