﻿myAppangular.factory('paymentService', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    var url;
    /* Add to Basket*/
    function addToBasket(addToBasketData) {
        var apiUrl = '/payment/basket/draftcontribution';
        return FactoryHelper.CallApiPost(apiUrl, addToBasketData);
        //url = baseUrl + apiUrl;
        //request = $http({
        //    method: 'POST',
        //    url: url,
        //    data: addToBasketData
        //});
        //return request;
    };

    function addRecurrentPayment(recurrentPayment) {
        var apiUrl = '/payment/recurrent';
        return FactoryHelper.CallApiPost(apiUrl, recurrentPayment);

        //url = baseUrl + apiUrl;
        //request = $http({
        //    method: 'POST',
        //    url: url,
        //    data: recurrentPayment
        //});
        //return request;
    };

    /* Add to Basket*/
    function payOneShotPayment(oneShotPayment) {
        var apiUrl = '/payment/oneshot';
        return FactoryHelper.CallApiPost(apiUrl, oneShotPayment);

        //url = baseUrl + apiUrl;
        //request = $http({
        //    method: 'POST',
        //    url: url,
        //    data: oneShotPayment
        //});
        //return request;
    };

    // Get list of contribution for a person
    function getListOfContributionForAPerson(parentId) {
        var apiUrl = '/payment/person/' + parentId + '/contributions';
        return FactoryHelper.CallApiGet(apiUrl);
        //url = baseUrl + apiUrl;
        //request = $http({
        //    method: 'GET',
        //    url: url
        //});
        //return request;
    };
    //Get contribution details
    function getContributionDetails() {
        var apiUrl = '/payment/listofcontributionforaperson/' + parentId;
        return FactoryHelper.CallApiGet(apiUrl);
        //url = baseUrl + apiUrl;
        //request = $http({
        //    method: 'GET',
        //    url: url
        //});
        //return request;
    };
    //Delete contribution details
    function deleteContributionDetails(contribution) {
        var basketId = contribution.BasketId;
        var contributionId = contribution.ContributionId;
        var apiUrl = '/payment/basket/' + basketId + '/contributions/' + contributionId;

        return FactoryHelper.CallApiDelete(apiUrl);
    };

    function getRecurrentPaymentStatus(paymentDetail) {
        var apiUrl = '/payment/updaterecurrentdetailsstatus';
        return FactoryHelper.CallApiPost(apiUrl, paymentDetail);
    };

    //Pay All At Once
    function payAll(paymentDetail) {
        var cultureCode;
        if ($.cookie("language") == "en") {
            cultureCode = 0;
        }
        if ($.cookie("language") == "fr") {
            cultureCode = 1;
        }
        if ($.cookie("language") == "nl") {
            cultureCode = 2;
        }
        paymentDetail.CultureCode = cultureCode;

        var apiUrl = '/payment/submitallcontributions/';
        return FactoryHelper.CallApiPost(apiUrl, paymentDetail);
    };
    // call payment gateway
    function paymentGateway(postData) {
        var apiUrl = '/payments/';
        return FactoryHelper.CallApiPostAnonymous(apiUrl, postData);
        //url = baseUrl + apiUrl;
        //request = $http({
        //    method: 'POST',
        //    url: url,
        //    data: postData
        //});
        //return request;
    };

    function updateTransactionStatus(paymentTransactionId, status) {
        var apiUrl = '/payment/paymentReferenceNumber/' + paymentTransactionId + '/status/' + status + '/updatecontributionandbasketstatus/';
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetAmountOnRetry(paymentTransactionId, newPaymentTransactionId) {
        var apiUrl = '/payment/paymenttransaction/' + paymentTransactionId + '/newpaymenttransaction/' + newPaymentTransactionId + '/getamountonretry';
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function getTransactionStatus(paymentTransactionId, status) {
        var apiUrl = '/payment/paymentReferenceNumber/' + paymentTransactionId + '/status/' + status + '/basketdetails';
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function getFirstChildIdByParent(personId) {
        var apiUrl = '/payment/' + personId + '/firstchildid';
        return FactoryHelper.CallApiGet(apiUrl);
    };
    function getBasketCount() {
        var apiUrl = "/members/" + +$.cookie("personId") + "/basket";
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetContributionDetailOnTimeline(id, source) {
        var apiUrl = "/payment/contribution/" + id + "/receiver/" + $.cookie("personId") + "/source/" + source + "/contributiondetails";
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function GetThankYouDetail(id) {
        var culturecode;

        var apiUrl = "/payment/contribution/" + id + "/receiver/" + $.cookie("personId") + "/thankyoudetails";
        return FactoryHelper.CallApiGet(apiUrl);
    };
    function getPaymentIntiatingDetail(personId, childId, entryPoint) {
        var apiUrl = "/childsaving/person/" + personId + "/child/" + childId + "/context/" + entryPoint + "/initiatepayment";
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function getChildrenDetail(personId, childId) {
        var apiUrl = "/contibution/person/" + personId + "/" + childId + "/children/all";
        return FactoryHelper.CallApiGet(apiUrl);
    };

    return {
        GetAmountOnRetry: GetAmountOnRetry,
        addToBasket: addToBasket,
        addRecurrentPayment: addRecurrentPayment,
        payOneShotPayment: payOneShotPayment,
        getListOfContributionForAPerson: getListOfContributionForAPerson,
        getContributionDetails: getContributionDetails,
        getRecurrentPaymentStatus: getRecurrentPaymentStatus,
        deleteContributionDetails: deleteContributionDetails,
        payAll: payAll,
        paymentGateway: paymentGateway,
        updateTransactionStatus: updateTransactionStatus,
        getFirstChildIdByParent: getFirstChildIdByParent,
        getBasketCount: getBasketCount,
        getTransactionStatus: getTransactionStatus,
        //updatePaymentReferenceOnRetry: updatePaymentReferenceOnRetry,
        GetContributionDetailOnTimeline: GetContributionDetailOnTimeline,
        GetThankYouDetail: GetThankYouDetail,
        getPaymentIntiatingDetail: getPaymentIntiatingDetail,
        getChildrenDetail: getChildrenDetail
    };
}]);