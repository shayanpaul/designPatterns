﻿myAppangular.factory('HeaderServices', ['$http', 'FactoryHelper', function ($http, FactoryHelper) {
    //Get contribution details
    function getNotifications(personId, notificationPageNumber, notificationPageSize) {
        var apiUrl = "/members/" + personId + "/notification?pageNumber=" + notificationPageNumber + "&pageSize=" + notificationPageSize;
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function acceptRejectSupporterInvite(timlineID,isApprove) {
        var apiUrl = "/invitations/approveinvitationbyparent/" + timlineID + "/" + isApprove;
        return FactoryHelper.CallApiPost(apiUrl);
    };

    function getHeaderCount(personId) {
        var apiUrl = "/members/" + personId + "/headerdata";
        return FactoryHelper.CallApiGet(apiUrl);
    };

    function markNotificationRead(notificationId) {
        var apiUrl = "/notification/" + notificationId + "/read";
        return FactoryHelper.CallApiPut(apiUrl);
    };

    function markTimelineRead(timelineId) {
        var apiUrl = "/timeline/" + timelineId + "/read";
        return FactoryHelper.CallApiPut(apiUrl);
    };

    function skipNotification(notificationId) {
        var apiUrl = "/notification/" + notificationId + "/skip";
        return FactoryHelper.CallApiPut(apiUrl);
    };

    function SendThankYou(responseData) {
        var apiUrl = '/members/thankyou';
        return FactoryHelper.CallApiPost(apiUrl, responseData);
    }
    var acceptRejectSupporterEvent = function (eventID, isapprove) {
        var apiUrl = "/events/notification/" + eventID + "/" + isapprove;
        return FactoryHelper.CallApiPost(apiUrl);
    }
   
    return {
        getNotifications: getNotifications,
        getHeaderCount: getHeaderCount,
        markNotificationRead: markNotificationRead,
        markTimelineRead: markTimelineRead,
        skipNotification: skipNotification,
        SendThankYou: SendThankYou,
        acceptRejectSupporterInvite: acceptRejectSupporterInvite,
        acceptRejectSupporterEvent: acceptRejectSupporterEvent
    };
}]);