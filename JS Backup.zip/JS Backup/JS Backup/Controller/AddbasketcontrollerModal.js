﻿myAppangular.controller("addtoBasketController", ["$scope", "$filter", "WebApiService", "paymentService", "$window", "FormSubmitter", "$rootScope", function ($scope, $filter, WebApiService, paymentService, $window, FormSubmitter, $rootScope) {
    $rootScope.$on('addToBasketModal-started', function (event, args) {
        $scope.SelectedChildFirstName = args.any.name;
        //$scope.delfirstName = args.any.firstName;
        $("#addToBasketModal1").modal("show");
    });
    $scope.addAnotherChild = function () {
        $rootScope.$broadcast('addAnotherChild-payment');
    }
    $scope.seeChildOverview = function () {
        $rootScope.$broadcast('seeChildOverview-payment');
    }
}]);