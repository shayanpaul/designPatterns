﻿myAppangular.controller("projectController", ["$scope", "$rootScope", "$state", "$filter", "savingSchoolService", function ($scope, $rootScope, $state, $filter, savingSchoolService) {
    $scope.createFlag = false;
    $scope.projectImage = '';
    $scope.validOnlyWholeNumber = true;

   
    $scope.focusAmountField = function (amountField, index) {

        if (amountField == "projectAmount") {
            $('#inputAmountSS').inputmask('AmountNumber');
            if ($scope.projectAmount) {
                $scope.projectAmount = returnANumberWithoutFormating($scope.projectAmount, $scope.languageid);
                $scope.oldProjectAmount = Number($scope.projectAmount);
                $("#inputAmountSS").val($scope.projectAmount);
            }
        } 
    }

    $scope.blurAmountField = function (amountField, index, customEvent) {

        if (amountField == "projectAmount") {
            $('#inputAmountSS').inputmask('remove');
            if ($scope.projectAmount != undefined) {
                var amount = Number($("#inputAmountSS").val());
                amount = formatAmountField(amount, $scope.languageid);
                $scope.projectAmount = amount;
                $("#inputAmountSS").val(amount);
                customEvent.stopImmediatePropagation();
            }
        }
    }

    $scope.projectAmountMethod = function () {

        var projectAmount = $("#inputAmountSS").val().replace(/[^0-9]/, "");
        $("#inputAmountSS").val(projectAmount);
        if (Number(projectAmount) > 9999) {
            $scope.projectAmount = $scope.oldProjectAmount;
        } else {
            $scope.projectAmount = projectAmount;
            $scope.oldProjectAmount = $scope.projectAmount;
        }
    };


    $scope.saveProjectDetails = function () {
        if (!$('#WishOrProjectCreation').valid()) {
            $('#WishOrProjectCreation').valid()
        }
        else {
        serviceProjectSaveCalled = true;
        $scope.shortTermProjectData = {};
        $scope.shortTermProjectData.ProjectCurrentValue = 0;

            if ($scope.createFlag) {
              $scope.shortTermProjectData.ProjectImage = $scope.projectImage.split(",")[1];
              $scope.shortTermProjectData.ProjectPriority = 0;
              $scope.shortTermProjectData.ProjectTargetAmount = returnANumberWithoutFormating($scope.projectAmount, $scope.languageid);
                $scope.shortTermProjectData.ProjectTitle = angular.element("#inputProjectNameSS").val();
                $scope.shortTermProjectData.CreatorId = $.cookie("personId");
            $scope.shortTermProjectData.IsPriorityChanged = false;
            if ($scope.isProject) {
                $scope.shortTermProjectData.ProjectCategory = 0;
            } else {
                $scope.shortTermProjectData.ProjectCategory = 1;
            }
            $scope.shortTermProjectData.Assignee = $scope.childId;
                $scope.shortTermProjectData.ProjectDescription = $scope.projectDescription;
            $scope.shortTermProjectData.ProjectStatus = "Active";
            $scope.shortTermProjectData.ProjectId = 0;

            }
            else {
                $scope.shortTermProjectData.ProjectImage =($scope.projectImage ? $scope.projectImage.split(",")[1]: "");

            if ($scope.edit && $scope.edit.projectPriority) {
                $scope.shortTermProjectData.ProjectPriority = $scope.edit.projectPriority;
            }
                $scope.shortTermProjectData.ProjectTargetAmount = returnANumberWithoutFormating($scope.projectAmount, $scope.languageid);
                $scope.shortTermProjectData.ProjectTitle = angular.element("#inputProjectNameSS").val();
            $scope.shortTermProjectData.CreatorId = $scope.personId;
            $scope.shortTermProjectData.IsPriorityChanged = false;
            $scope.shortTermProjectData.ProjectCategory = $scope.edit.projectCategory;
            $scope.shortTermProjectData.Assignee = $scope.childId;
                $scope.shortTermProjectData.ProjectDescription = $scope.projectDescription;
            $scope.shortTermProjectData.ProjectStatus = $scope.edit.projectStatus;
            $scope.shortTermProjectData.ProjectId = $scope.edit.projectId;
        }

            savingSchoolService.saveProjectDetails($scope.shortTermProjectData).then(
                function (data) {
            serviceProjectSaveCalled = false;
                $("#createProjectModal").modal('hide');
                if ($scope.entryPoint == "childplan") {
                    savingSchoolService.setSavingSchoolData("");
                    $state.go('child.detail.savingschool', { routingEntry: 'cp', childFirstName: $scope.childName});
                }
                else {
            $rootScope.$broadcast('projectModal-saving');
                }
            
                if (!$.isEmptyObject(data.data)) {
                if (data.data.ProjectCategory == 0) //for projects
                {
                            genericSuccessMessageDisplay(Resources.SaveProjectDetails_Success);
                } else if (data.data.ProjectCategory == 1) {
                            genericSuccessMessageDisplay(Resources.SaveWishDetails_Success);
                    }
                    }
                },
                function (error) {
                serviceProjectSaveCalled = false;
                    genericModalErrorDisplayMessage(Resources.EditWishOrProject_Failed, "create-project-failure-msg");
                });
                    }
    }
    $rootScope.$on('projectModal-started', function (event, args) {
        $scope.languageid = args.any.language;
        $scope.languageCulture = args.any.language;
        $scope.edit = args.any.edit;
        $scope.childId = args.any.childId;
        var isProject = args.any.isProject;
        $scope.isProject = args.any.isProject;
        $scope.entryPoint = args.any.entryLocation;
        var showChildName = false;
        if (!$rootScope.isChild) { showChildName = true; }
        if (args.any.childFirstName) {
            $scope.childName=args.any.childFirstName;
        }
        if (args.any.isEdit) {
            var editData = args.any.editData;            
            $scope.languageid = args.any.language;
            var projectHeaderText;
            $scope.projectTitle = editData.projectTitle;
            $scope.projectAmount = editData.projectAmount;
            $scope.projectDescription = editData.projectDescription;
            if ($scope.projectDescription) {
                var fillUpLength = $scope.projectDescription.length;
                var charLeft = Number(500 - fillUpLength);
                $("#descCount").text(charLeft);
            }
            else{
                var charLeft = Number(500);
                $("#descCount").text(charLeft);
            }
            if ($scope.projectDescription != null) {
                var charCount = $scope.projectDescription.length;
                $scope.Charleft = 500 - charCount;
            }

            $scope.projectImage = editData.projectImage;
            $scope.createFlag = false;
            $scope.isProject = isProject;
            if (isProject) {
                projectHeaderText = Resources.Header_EditProject;
                } else {
                projectHeaderText = Resources.Header_EditWish;
            }
            if (showChildName) {
                projectHeaderText = $rootScope.childName + " - " + projectHeaderText;
            }
            $("#createProjectModal_label").text(projectHeaderText);
            $('#inputProjectNameSS').val(args.any.editData.projectTitle);
            $("#createProjectModal").modal('show');
        }

        else {
            if (window.innerWidth < 768) {
                $("#moreOptionModal").modal('hide');
                $('#moreOptionModal').on('hidden.bs.modal', function () {
                    $("body").addClass('modal-open');
                });               
            }
           
            $scope.modalformSavingschool.$setPristine();
            $scope.modalformSavingschool.$setUntouched();
            var projectHeaderText;
            $scope.projectTitle = null;
            $scope.projectAmount = null;
            $scope.projectDescription = null;
            $scope.Charleft = 500;
            $scope.projectImage = '';
            $scope.createFlag = true;
            $scope.isProject = isProject;
            if (isProject) {
                projectHeaderText = Resources.Header_CreateProject;
                } else {
                projectHeaderText = Resources.Header_CreateWish;
            }
            if (showChildName) {
                projectHeaderText = $rootScope.childName + " - " + projectHeaderText;
            }
            $("#createProjectModal_label").text(projectHeaderText);
            $("#createProjectModal").modal('show');
            $('#inputProjectNameSS').val("");
            $("#projectOrWishEvent").val("createProjectEvent");
        }
    });
    $("#createProjectModal").on('shown.bs.modal', function (e) {
        angular.element('#inputProjectNameSS').focus();
    });
    $scope.wishCancelled = function () {
        $rootScope.$broadcast("wish-cancelled-without-saving");
    }
    angular.element("#createProjectModal .close").click(function () {
        $scope.wishCancelled();
    });
}]);
