﻿myAppangular.controller("TransactionDetailsModalController", ["$scope", "$rootScope",  function ($scope, $rootScope) {


    $rootScope.$on('transactionDetailModal-started', function (event, arg) {

        if (arg.any && arg.any.data) {
            $scope.TimelineInfo = arg.any.data;
            $scope.IsPromoCodeMessage = false;
            $("#transactionDetailModal").modal("show");
            $("#transactionDetailModal_label").text($scope.TimelineInfo.HeaderName);
            if ($scope.TimelineInfo.promocodeModal) {
                $scope.IsPromoCodeMessage = true;
            }
         }
        });
    

}]);
