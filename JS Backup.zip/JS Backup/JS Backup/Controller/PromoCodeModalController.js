﻿myAppangular.controller("PromoCodeModalController", ["$scope", "$rootScope", "PromoCodeService", "$stateParams","subscriptionFactory", function ($scope, $rootScope, PromoCodeService, $stateParams,subscriptionFactory) {
    $scope.languageCulture = currentLanguage;
    $scope.personId = $.cookie("personId");
    var subDetails = subscriptionFactory.wholeSubDetails();
    if (subDetails && subDetails.childDetails) {

    }


    $scope.$watch("promoCode", function (newValue, oldValue) {
        if ($('#promoCodeTextPlaceholder').parent().hasClass('error')) {
            $('#promoCodeTextPlaceholder').parent().removeClass('error');
        }
    });
    //setTimeout(function () {
    //    $('#promoCodeTextPlaceholder').change(function () {
    //        if ($('#promoCodeTextPlaceholder').parent().hasClass('error')) {
    //            $('#promoCodeTextPlaceholder').parent().removeClass('error');
    //        }
    //    });
    //}, 100);
    $scope.hideCrossButton = hideCrossButton;
    $rootScope.$on('deleteCross', function (event, args) {

        setTimeout(function () { $scope.hideCrossButton = true; }, 20);

    });
    //$scope.childId = $stateParams.childId;
    $scope.childLastName = $("#inputChildLastName").val();
    $scope.childFirstName = $("#inputChildFirstName").val();
    $scope.promoCodeDetails = {};
    $(document).bind("promocodeDataSubscription", function (e, args) {
        $scope.promoCodeDetails = args;
    });

    $scope.checkPromoCode = function () {
        var promoCodeRequest = $scope.populatePromoCodeRequest();
        if (promoCodeRequest.Code) {
            PromoCodeService.GetPromocodeInformation(promoCodeRequest).then(
                function (data) {
                    $scope.promoCodeDetails = data.data.Result;
                    if ($scope.promoCodeDetails) {
                        $rootScope.$broadcast('PartnerShip', { any: { "partnershipId": data.data.Result.PartnerId } });
                        if ($scope.promoCodeDetails.PromoCode.length > 0) {
                            $.cookie("promoCode", $scope.promoCodeDetails.PromoCode, {
                                path: "/"
                            });
                            $scope.promoCode = $scope.promoCodeDetails.PromoCode;

                        }
                        if ($scope.promoCodeDetails.PartnerImageUrl) {
                            $scope.promoCodeDetails.PartnerImage = $scope.promoCodeDetails.PartnerImageUrl;
                        }
                        $("#applyPromoCode").css("z-index", "96");
                        $scope.hideDisplay();
                        $('#applyPromoCodeSucessful').modal('show');
                        $rootScope.$broadcast('promoComplete', { any: { "promocodedetails": $scope.promoCodeDetails } });
                    }
                },
                function (error) {
                    $(".promoCode-failure-notification").css("display", "block");
                    $(".promoCode-entry-texbox").addClass("error");
                }
            );
        }
    }
    $scope.hideDisplay = function() {
        $(".promoCode-failure-notification").css("display", "none");
        $(".promoCode-entry-texbox").removeClass("error");
    }

    $scope.hidePromoDetails = function () {
        $('#applyPromoCode').modal('hide');
        $("#applyPromoCode").css("z-index", "1050");
        $('#applyPromoCodeSucessful').modal('hide');
        $('#pageLoader').removeClass('show');
        $('html').removeClass('no-scroll');
       unfreezeBackground();
    }

    $scope.cancelPromoCode = function () {
        $scope.hideDisplay();
        $.cookie("promoCode", "", { path: "/" });
        globalFlagForPromoApplied = "";
        $scope.promoCode = "";
        $rootScope.$broadcast('promoCanceled');
        subscriptionFactory.setpartnershipIdForOther(0);
        //if ($.cookie("promoCode"))
        //    $scope.promoCode = $.cookie("promoCode");
        //else {
        //    $scope.promoCode = "";
        //}
        $scope.hidePromoDetails();
    }

    $scope.closePromoPopUp = function () {
        $scope.hidePromoDetails();
    }

    $scope.clearPromoCode = function () {
        $("#applyPromoCode").css("z-index", "1050");
        $('#applyPromoCodeSucessful').modal('hide');
        $scope.promoCode = "";
        $('#applyPromoCode').modal('show');
        $.cookie("promoCode", "", { path: "/" });
        $scope.promoCodeDetails.IsApplied = false;
    }

    $scope.populatePromoCodeRequest = function () {
        if (!$scope.personId)
            $scope.personId = 0;
        //if (!$scope.childId)
        //    $scope.childId = 0;
        var subDetails = subscriptionFactory.wholeSubDetails();
        if (subDetails && subDetails.childDetails && subDetails.childDetails.childDetails && subDetails.childDetails.childDetails.PersonId) {
            $scope.childId = subDetails.childDetails.childDetails.PersonId;
        }
        else {
            $scope.childId = 0;
        }
        if (!$scope.childFirstName)
            $scope.childFirstName = "";
        if (!$scope.childLastName)
            $scope.childLastName = "";
        $scope.promoCode = $("#promoCodeTextPlaceholder").val();

        var promoCodeRequest = {
            PersonId: $scope.personId,
            ChildId: $scope.childId,
            FirstName: $scope.childFirstName,
            LastName: $scope.childLastName,
            Code: $scope.promoCode
        };
        return promoCodeRequest;
    }
    $scope.$on('code-in-cookie-present', function (event, args) {
        if ($.cookie("promoCode")) {
            $("#promoCodeTextPlaceholder").val($.cookie("promoCode"));
        }
        else {
            $("#promoCodeTextPlaceholder").val(subscriptionFactory.getPromoCode);
        }
        
        $scope.checkPromoCode();
    });
}]);