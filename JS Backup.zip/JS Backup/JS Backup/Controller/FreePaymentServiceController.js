﻿/*global $, angular, jQuery, alert, window*/
/*jslint browser: true*/
/*jslint this:true */
/*jslint white:true, for:true */
/*jslint  devel: true */
myAppangular.controller("freePaymentServiceController", ["$scope", "$filter", "$state", "$stateParams", "$window", "FormSubmitter", "AnonymousUserService", "$rootScope", function ($scope, $filter, $state, $stateParams, $window, FormSubmitter, AnonymousUserService, $rootScope) {
    $scope.paymentSucess = true;
    $scope.paymentError = true;
    $scope.paymentLongType;
    $scope.paymentShortType;
    $scope.LongTermPlanPresent = false;
    $scope.ShortTermPlanPresent = false;

    $scope.paymentReference;
    $scope.paymentDetail = {};
    $scope.init = function () {
        var valuetocheck = $.cookie("PaymentStatus");

        if (valuetocheck !== "" && valuetocheck !== null && valuetocheck !== undefined && valuetocheck !== "null") {
            if ($.cookie("PaymentTransactionId"))/* for free contributor*/ {
                $scope.paymentTransactionId = $.cookie("PaymentTransactionId");
            }

            if (valuetocheck === PaymentAccepted) {
                $scope.paymentSucess = false;
                $scope.paymentError = true;
                if ($scope.paymentTransactionId !== "" || $scope.paymentTransactionId !== null || $scope.paymentTransactionId !== undefined) {
                    $scope.updateTransactionStatus(true);
                    $scope.getTransactionStatus(true);
                }
            } else {
                $scope.paymentSucess = true;
                $scope.paymentError = false;
                if ($scope.paymentTransactionId !== "" || $scope.paymentTransactionId !== null || $scope.paymentTransactionId !== undefined) {
                    $scope.updateTransactionStatus(false);
                    $scope.getTransactionStatus(false);
                }
            }
        }
    };

    $scope.updateTransactionStatus = function (status) {
        $scope.paymentDetail.PaymentReferenceNumber = $scope.paymentTransactionId;
        $scope.paymentDetail.Status = status;
        var res = AnonymousUserService.updateTransactionStatus($scope.paymentTransactionId, $scope.paymentDetail.Status)//.success(function (data, status) {
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (d) {
            }, function (error) {
            });
        }
    };

    $scope.getTransactionStatus = function (status) {
        $scope.paymentDetail.Status = status;

        var res = AnonymousUserService.GetPaymentDetailForFreeContribution($scope.paymentTransactionId);
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (data) {
                $scope.paymentDate = $.cookie("TransactionDate");
                $scope.transactionId = $.cookie("PaymentTransactionId");
                $scope.transChildInfo = {};
                $scope.confirmTransactionDetails = [];

                $scope.paymentReference = data.PaymentReference;

                if (data.TotalLongTermAmount > 0) {
                    $scope.transChildInfo.childNameInPayment = data.ChildName;
                    $scope.transChildInfo.totalAmount = data.TotalLongTermAmount;
                    $scope.transChildInfo.childPlanName = longTermPlan;
                    $scope.confirmTransactionDetails.push($scope.transChildInfo);
                    $scope.transChildInfo = {};
                }
                if (data.TotalShortTermAmount > 0) {
                    $scope.transChildInfo.childNameInPayment = data.ChildName;
                    $scope.transChildInfo.totalAmount = data.TotalShortTermAmount;
                    $scope.transChildInfo.childPlanName = shortTermPlan;
                    $scope.confirmTransactionDetails.push($scope.transChildInfo);
                    $scope.transChildInfo = {};
                }
            }, function (error) {
            });
        }
    }

    $scope.goToAaGje = function () {
        window.location.href = "/"
    }

}]);