﻿myAppangular.controller("savingSchoolController", ["$scope", "$rootScope", "$filter", "$state", "$stateParams", "savingSchoolService", "$timeout", "parentalsettingsService", "EditProfileService", function ($scope, $rootScope, $filter, $state, $stateParams, savingSchoolService, $timeout, parentalsettingsService, EditProfileService) {



    var currentStateName = $rootScope.$state.current.name;

    $scope.nameRegexp = nameRegex;
    $scope.amountRegexp = amountRegex;
    $scope.OtherResources = [];
    var serviceProjectSaveCalled = false;
    $scope.Charleft = 500;
    $scope.projectAmountForvalidation = false;
    $scope.saveotherResourcesFlag = true;
    $scope.deletedBlockSource = [];
    $scope.moreOptionsVisible = false;
    $scope.backBtnShowOnSavingSchool = false;
    $scope.isNon_EligbleForMoneyOut = $stateParams.isNon_EligibleForMoneyOut;
    var totalOtherResourcesAmount = 0;
    angular.element("#changeChild-image-web .demoImg").attr('src', $stateParams.childImage);
    angular.element("#changeChild-image-mobile .demoImg").attr('src', $stateParams.childImage);

    $scope.valuePerSource = {
        "Id": "",
        "Label": "",
        "Amount": "",
        "Category": customAmountCategory.MyOtherSource,
        "Status": Status.Active,
        "Creator": $scope.personId,
        "Owner": $scope.childId,
        "requiredAmount": false,
        "requiredSource": false

    };
    var initialOtherSources = [{
        "Id": "",
        "Label": "",
        "Amount": "",
        "Category": customAmountCategory.MyOtherSource,
        "Status": Status.Active,
        "Creator": $scope.personId,
        "Owner": $scope.childId,
        "requiredAmount": false,
        "requiredSource": false

    }];
    $scope.totalamount = 0, 00;

    $scope.itemsforSources = [];
    $scope.itemsforReserve = {};
    $scope.totalamount = 0, 00;
    $scope.itemsforSources.push($scope.valuePerSource);
    $scope.editOtherResouce = true;

    $scope.clickSavingSchoolLink = function (selChildId) {
        localStorage.setItem("clickSS", true);
        if (selChildId == undefined) {
            selChildId = $.cookie("personId");
        }
        $state.go("child.detail.savingschool", {
            'childId': selChildId,
            'routingEntry': 'cp',
            childEntry: true
        });

    }
    $scope.clickMyPlanLink = function (selChildId) {
        if (selChildId == undefined) {
            selChildId = $.cookie("personId");
        }
        localStorage.setItem("planOverviewChildLoggedIn", "true");
        $state.go("child.detail.plan", {
            childId: selChildId,
            childEntry: true
        });
    }

    $scope.$on('getSavingSchoolInfoForChild', function () {
        $scope.getSavingSchoolInformation();
    });
    var parentalControlObj = {};
    $scope.init = function () {
        $(".csm-menu-list").removeClass("csm-active-list");
        $("#savingSchool").parent().addClass("csm-active-list");
        $(".csm-sub-menu-list").removeClass("active-sub-menu");
        if (window.innerWidth > 991) {
            $(".csm-first-menu").removeClass("csm-expanded-menu");
        }
        $scope.childId = $stateParams.childId;
        $scope.personId = $.cookie("personId");
        $scope.language = $stateParams.language
        $scope.currency = "EUR";
        $scope.wishInfoList = [];
        $scope.savingSchoolDetail = {};
        $scope.activeProjects = [];
        $scope.completedProjects = [];
        $scope.pendingProjects = [];
        $scope.showWishList = false;
        $scope.showEmptyWishList = false;
        $scope.hideActiveProjectsVideoBlock = true;
        $scope.hideReserveAmountDelete = true;
        $scope.otherReserveAmountModel = "";
        $scope.Level = {};
        $scope.showProjectDetails = false;
        $scope.hideWishlistBlock = false;
        $scope.hideActiveProjectBlock = false;
        $scope.moreOption = false;
        $scope.showActivateLevel2 = false;
        $scope.shortTermProjects = [];
        $scope.OtherResources = [];
        $scope.AllOtherResources = [];
        $scope.hideCreateProjectMenutext = true;
        $scope.isParentOrAdmin = true;
        $scope.showMoveToProject = true;
        $scope.showDelete = true;
        $scope.showFirstButtonSet = false;
        $scope.showSecondButtonSet = false;
        $scope.showThirdButtonSet = false;
        $scope.busySS = false;
        $scope.lastLoadedId = 2;
        $scope.amount;
        $scope.createFlag;
        $scope.isProject;
        $scope.oldProjectAmount = "";
        $scope.getSavingSchoolInformation();
        $scope.valuePerSource = {
            "Id": "",
            "Label": "",
            "Amount": "",
            "Category": customAmountCategory.MyOtherSource,
            "Status": Status.Active,
            "Creator": $scope.personId,
            "Owner": $scope.childId,
            "requiredAmount": false,
            "requiredSource": false

        };
        $scope.itemsforSources = [];
        $scope.$parent.hideSavingSchoolWishButton = true;
        $scope.itemsforSources.push($scope.valuePerSource);

        if (currentStateName == "child.detail.savingschool") {

            parentalControlObj = parentalsettingsService.getData('Dataname');
            if (!parentalControlObj) {
                var childId = $stateParams.childId;
                EditProfileService.GetParentalInformationBasedonParentID($.cookie("personId"), childId).then(
                    function (data) {
                        if (data) {

                            parentalControlObj = {
                                longTermAnswer: data.LTSP,
                                currentAmountAnswer: data.AmountonShortTermplan,
                                inviteContributor: data.InviteContributors,
                                createEvent: data.ManageEvents,
                                editPersonalData: data.EditPersonalData,
                                editProfilePicture: data.EditProfilePicture,
                                createProject: data.CreateProject,
                                levelActivate: data.ActivateSavingSchoolLevel2
                            };

                            EditProfileService.setParentalControl(parentalControlObj);
                        }
                    }
                );
            }
            $scope.getWishDetails($stateParams.childId);

        }

    }

    $scope.openMyReserveModal = function () {
        $("#myReserveModal").find(".errornew").removeClass("errornew");
        if (window.innerWidth < 768) {
            $scope.moreOptionsVisible = false;
        }
        $scope.itemsforReserve.Amount = $scope.ReserveAmount;
        $("#itemsforReserveAmount").val(formatAmountField($scope.ReserveAmount, $scope.language));
        $scope.myReserveForm.$setPristine();

        unfreezeBackground();
    };
    $scope.$on("isChildEvent", function () {
        if ($rootScope.isChild) {
            if (localStorage.getItem("isSavingSchool") && !JSON.parse(localStorage.getItem("isSavingSchool"))) {
                var childId = $.cookie("personId");
                var personId = $.cookie("personId");
                $scope.getSavingSchoolDetail(personId, childId);
            }
        }

    });
    //<Start of add other source modal>
    $scope.callMyOtherSourceModal = function () {

        if (window.innerWidth < 768) {

            $scope.moreOptionsVisible = false;
        }

        $scope.editOtherResouce = true;
        $scope.myReserveForm.$setPristine();
        unfreezeBackground();
        $scope.itemsforSources = angular.copy(initialOtherSources);
        $scope.SummationOfOtherSourcesAmountAndValidateSelf();
        $scope.saveotherResourcesFlag = $scope.validateOtherResource();
        $("#myOtherSourcesModal").on('shown.bs.modal', function () {
            for (i = 0; i < $scope.itemsforSources.length; i++) {
                $('#otherReserveAmountModelId' + i).val(formatAmountField($scope.itemsforSources[i].Amount, $scope.language));
            }
        });
    }
    $scope.addSourceBlock = function (index) {
        $scope.itemsforSources.push({
            "Id": "",
            "Label": "",
            "Amount": "",
            "Category": customAmountCategory.MyOtherSource,
            "Status": Status.Active,
            "Creator": $scope.personId,
            "Owner": $scope.childId,
            "requiredAmount": false,
            "requiredSource": false
        });
        $scope.saveotherResourcesFlag = true;
        //var numberOfAmountField = $scope.itemsforSources.length - 1;

    }
    $scope.removeSourceBlock = function (index) {
        totalOtherResourcesAmount = 0;
        var id = $scope.itemsforSources[index].Id;
        if (id && id > 0) {
            $scope.itemsforSources[index].Status = Status.Cancelled;
        } else {
            $scope.itemsforSources.splice(index, 1);
        }
        $scope.SummationOfOtherSourcesAmountAndValidateSelf();

    }
    var oldResourceAmount = 0;
    $scope.SummationOfOtherSourcesAmountAndValidateSelf = function (index) {
        if (index != null && index != undefined) {
            var thisElement = $("#otherReserveAmountModelId" + index);
            var position = thisElement[0].selectionStart;
            var resourceAmount = thisElement.val().toString().replace(/[^0-;9]/, "");
            if (/[^0-;9]/.test(thisElement.val().toString())) {
                position = position - 1;
            }

            if (Number(resourceAmount) > 99999) {
                $scope.itemsforSources[index].Amount = oldResourceAmount;
                position = position - 1;
            } else {
                $scope.itemsforSources[index].Amount = resourceAmount;
                oldResourceAmount = resourceAmount;
            }
            thisElement[0].selectionEnd = position;

            if (!$scope.itemsforSources[index].Amount) {
                $scope.itemsforSources[index].requiredAmount = true;
            }
            else {
                $scope.itemsforSources[index].requiredAmount = false;
            }
        }
        totalOtherResourcesAmount = 0;
        var count = 0;
        $.each($scope.itemsforSources, function () {
            if (this.Status == Status.Active) {
                totalOtherResourcesAmount += Number(this.Amount);
                count++;
            }
        });

        $scope.formatedTotalAmount = formatAmountField(totalOtherResourcesAmount, $scope.language);
        $scope.saveotherResourcesFlag = $scope.validateOtherResource();
        if (count == 0) {
            $scope.saveotherResourcesFlag = true;
        }
    }
    $scope.returnAmountInNumberFormat = function (event) {
        var fieldId = event.currentTarget.id;
        var amtInNumber = returnANumberWithoutFormating(angular.element('#' + fieldId).val(), $scope.language);
        if (amtInNumber) {
            angular.element('#' + fieldId).val(amtInNumber);
        } else {
            angular.element('#' + fieldId).val('');
        }
        $scope.saveotherResourcesFlag = $scope.validateOtherResource();
    }

    $scope.returnFormattedAmount = function (event) {
        var fieldId = event.currentTarget.id;
        angular.element('#' + fieldId).val(formatAmountField(angular.element('#' + fieldId).val(), $scope.language));
        $scope.saveotherResourcesFlag = $scope.validateOtherResource();
    }
    $scope.validateOtherResource = function () {
        if (angular.equals($scope.itemsforSources, initialOtherSources)) {
            return true;
        }
        else {
            var flag = false;
            $.each($scope.itemsforSources, function () {
                if (this.Status == Status.Active && (!Number(this.Amount) || !this.Label)) {
                    flag = true;
                    return false;
                }
            });
            return flag;
        }
    }

    $scope.validateSourceName = function (index) {
        if (!$scope.itemsforSources[index].Label) {
            $scope.itemsforSources[index].requiredSource = true;
        }
        else {
            $scope.itemsforSources[index].requiredSource = false;
        }
        $scope.saveotherResourcesFlag = $scope.validateOtherResource();
    }

    $scope.saveOtherResources = function () {
        $scope.AllOtherResources = angular.copy($scope.itemsforSources);

        $scope.saveCustomAmount();
    }


    $scope.getSavingSchoolInformation = function () {
        $rootScope.$broadcast("isSavingSchool");
        $scope.$parent.hideSavingSchoolProjectButton = true;
        $scope.$parent.hideSavingSchoolContributeButton = true;
        localStorage.setItem("shortTermObj", true);
        $scope.getSavingSchoolDetail($scope.personId, $scope.childId);
    }
    $scope.savingSchoolProjectsBindingForChild = function (savingSchoolDetail, shortTermPlanValidationType) {
        if (localStorage.getItem("isSavingSchool") && !JSON.parse(localStorage.getItem("isSavingSchool"))) {
            localStorage.isShortTermChildPage = true;
            $scope.showSsLink = true;
            if (savingSchoolDetail.ValidationType === shortTermPlanValidationType) {
                localStorage.isShortTermChildPage = false;
                $scope.showSsLink = false;
            }
        }
        if (savingSchoolDetail.ShortTermProjects != null) {
            if (savingSchoolDetail.ShortTermProjects.length > 0) {
                var activeProjectCount = 0;
                $scope.shortTermProjects = [];
                $.each(savingSchoolDetail.ShortTermProjects, function (index) {
                    if ($scope.shortTermProjects.length < 3) {
                        if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active" || savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Inactive") {
                            var shortTermProjectInfo = {
                            };
                            shortTermProjectInfo.projectCurrentAmount = 0;
                            shortTermProjectInfo.projectOtherAmount = 0;
                            shortTermProjectInfo.planId = savingSchoolDetail.ShortTermProjects[index].PlanId;
                            shortTermProjectInfo.projectTitle = savingSchoolDetail.ShortTermProjects[index].ProjectTitle;
                            shortTermProjectInfo.projectPriority = savingSchoolDetail.ShortTermProjects[index].ProjectPriority;
                            shortTermProjectInfo.projectId = savingSchoolDetail.ShortTermProjects[index].ProjectId;
                            shortTermProjectInfo.projectStatus = savingSchoolDetail.ShortTermProjects[index].ProjectStatus;
                            shortTermProjectInfo.projectDescription = savingSchoolDetail.ShortTermProjects[index].ProjectDescription;
                            shortTermProjectInfo.projectCategory = savingSchoolDetail.ShortTermProjects[index].ProjectCategory;
                            shortTermProjectInfo.projectImage = savingSchoolDetail.ShortTermProjects[index].ProjectImageUrl;
                            if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active") {
                                activeProjectCount++;
                            }

                            shortTermProjectInfo.targetProjectAmount = formatAmountField((Number(savingSchoolDetail.ShortTermProjects[index].ProjectTargetAmount)), $scope.language);


                            if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active") {

                                shortTermProjectInfo.projectCurrentAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectCurrentValue, $scope.language);
                                shortTermProjectInfo.projectTotalAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectTotalAmount, $scope.language);


                                if (savingSchoolDetail.Level == SavingSchoolLevel.Level2) {

                                    shortTermProjectInfo.projectOtherAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectOtherAmount, $scope.language);

                                }

                            }
                            var graphDetails = $scope.graphCalculator(Number(savingSchoolDetail.ShortTermProjects[index].ProjectTargetAmount), Number(savingSchoolDetail.ShortTermProjects[index].ProjectCurrentValue), Number(savingSchoolDetail.ShortTermProjects[index].ProjectOtherAmount));
                            shortTermProjectInfo.offset1 = graphDetails.offset1;
                            shortTermProjectInfo.offset2 = graphDetails.offset2;

                            $scope.shortTermProjects.push(shortTermProjectInfo);


                            $scope.EmptyCount = $scope.EmptyCount + 1;
                        }
                        else {
                            return false;
                        }
                    }
                });
            } else {
                $scope.shortTermProjects = [];
            }
        } else {
            $scope.shortTermProjects = [];
        }

    }
    $scope.savingSchoolProjectsBinding = function (savingSchoolDetail, shortTermPlanValidationType) {
        var completedProjectList = [];
        if (savingSchoolDetail != null) {
            if (savingSchoolDetail.Level) {
                $scope.Level = savingSchoolDetail.Level;
            }
            if ($rootScope.isChild && !savingSchoolDetail.IsSubscribingParent) { //defect 6895 fix
                $scope.$parent.hideSavingSchoolWishButton = false;
                $scope.isParentOrAdmin = false;
                $scope.$parent.hideSavingSchoolContributeButton = true;
            }
            else {// Don't Display Create Project button in Saving School , if there is no Shrt Term Plan  and login as Admin 
                if (savingSchoolDetail.ValidationType === shortTermPlanValidationType && Number(localStorage.getItem(personRole)) === roles.admin)
                    $scope.$parent.hideSavingSchoolProjectButton = true;
                else
                    $scope.$parent.hideSavingSchoolProjectButton = false;
                $scope.$parent.hideSavingSchoolContributeButton = false;
            }
            if (localStorage.getItem("isSavingSchool") && !JSON.parse(localStorage.getItem("isSavingSchool"))) {
                localStorage.isShortTermChildPage = true;
                $scope.showSsLink = true;
                if (savingSchoolDetail.ValidationType === shortTermPlanValidationType) {
                    localStorage.isShortTermChildPage = false;
                    $scope.showSsLink = false;
                }
            }

            if (savingSchoolDetail.Level == SavingSchoolLevel.Level2) {
                $scope.ReserveAmount = formatAmountField(savingSchoolDetail.ReserveAmount, $scope.language);
                $scope.OtherResourcesAmount = savingSchoolDetail.OtherResourcesAmount;
                $scope.OtherResourcesAmount = formatAmountField($scope.OtherResourcesAmount, $scope.language);


                if (savingSchoolDetail.MyReserve != null && savingSchoolDetail.MyReserve.length > 0) {
                    $scope.itemsforReserve = savingSchoolDetail.MyReserve[0];
                }

                $scope.ShortTermContractAmount = savingSchoolDetail.ShortTermContractAmount;
                $scope.ShortTermContractAmt = savingSchoolDetail.ShortTermContractAmount;
                $scope.ShortTermContractAmount = formatAmountField($scope.ShortTermContractAmount, $scope.language);
                $scope.OtherResources = savingSchoolDetail.OtherResources ? savingSchoolDetail.OtherResources : [];
                if (!$scope.OtherResources || $scope.OtherResources.length === 0) {
                    $scope.OtherResources.push($scope.valuePerSource);
                }
                initialOtherSources = savingSchoolDetail.OtherResources ? savingSchoolDetail.OtherResources : initialOtherSources;
                $scope.itemsforSources = $scope.OtherResources;
                for (var i = 0; i < $scope.itemsforSources.length; i++) {
                    $scope.itemsforSources[i].requiredAmount = false;
                    $scope.itemsforSources[i].requiredSource = false;
                }
                $scope.saveotherResourcesFlag = true;
                $scope.deletedBlockSource = [];
            }
            $scope.EmptyCount = 0;
            if (savingSchoolDetail.ShortTermProjects != null) {
                if (savingSchoolDetail.ShortTermProjects.length > 0) {
                    var activeProjectCount = 0;
                    $scope.shortTermProjects = [];
                    $.each(savingSchoolDetail.ShortTermProjects, function (index) {
                        if ($scope.shortTermProjects.length < 3) {
                            if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active" || savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Pending") {
                                var shortTermProjectInfo = {
                                };
                                shortTermProjectInfo.projectCurrentAmount = 0;
                                shortTermProjectInfo.projectOtherAmount = 0;
                                shortTermProjectInfo.planId = savingSchoolDetail.ShortTermProjects[index].PlanId;
                                shortTermProjectInfo.projectTitle = savingSchoolDetail.ShortTermProjects[index].ProjectTitle;
                                shortTermProjectInfo.projectPriority = savingSchoolDetail.ShortTermProjects[index].ProjectPriority;
                                shortTermProjectInfo.projectId = savingSchoolDetail.ShortTermProjects[index].ProjectId;
                                shortTermProjectInfo.projectStatus = savingSchoolDetail.ShortTermProjects[index].ProjectStatus;
                                shortTermProjectInfo.projectDescription = savingSchoolDetail.ShortTermProjects[index].ProjectDescription;
                                shortTermProjectInfo.projectCategory = savingSchoolDetail.ShortTermProjects[index].ProjectCategory;
                                shortTermProjectInfo.projectImage = savingSchoolDetail.ShortTermProjects[index].ProjectImageUrl;
                                if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active") {
                                    activeProjectCount++;
                                }

                                shortTermProjectInfo.targetProjectAmount = formatAmountField((Number(savingSchoolDetail.ShortTermProjects[index].ProjectTargetAmount)), $scope.language);


                                if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active") {

                                    shortTermProjectInfo.projectCurrentAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectCurrentValue, $scope.language);
                                    shortTermProjectInfo.projectTotalAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectTotalAmount, $scope.language);


                                    if (savingSchoolDetail.Level == SavingSchoolLevel.Level2) {

                                        shortTermProjectInfo.projectOtherAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectOtherAmount, $scope.language);

                                    }

                                }
                                var graphDetails = $scope.graphCalculator(Number(savingSchoolDetail.ShortTermProjects[index].ProjectTargetAmount), Number(savingSchoolDetail.ShortTermProjects[index].ProjectCurrentValue), Number(savingSchoolDetail.ShortTermProjects[index].ProjectOtherAmount));
                                shortTermProjectInfo.offset1 = graphDetails.offset1;
                                shortTermProjectInfo.offset2 = graphDetails.offset2;

                                $scope.shortTermProjects.push(shortTermProjectInfo);


                                $scope.EmptyCount = $scope.EmptyCount + 1;

                            }

                        }
                        if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Inactive") {
                            completedProjectList.push(savingSchoolDetail.ShortTermProjects[index]);
                        }
                        index++;

                    });


                    $(".ss-back-to-projects").click(function () {
                        $(".draggable-project-section").css("display", "none");
                        $(".ss-first-level-projects").css("display", "block");
                        $("#columns").sortable('cancel');
                    });


                    if ($scope.shortTermProjects.length > 2) {
                        $("#ssCreateProjBtn").addClass("disabled").prop("disabled", true);
                    } else {
                        $("#ssCreateProjBtn").removeClass("disabled").prop("disabled", false);
                    }
                    $scope.activeProjectsNumber = activeProjectCount;
                } else {
                    $scope.shortTermProjects = [];
                }
            } else {
                $scope.shortTermProjects = [];
            }
            $scope.emptyProject = 3 - $scope.EmptyCount;
            $scope.emptyProjectArr = [];
            for (i = 0; i < $scope.emptyProject; i++) {
                $scope.emptyProjectArr.push(i);
            }
            if (completedProjectList != null) {
                if (completedProjectList.length > 0) {
                    $scope.completedProjects = [];
                    $scope.hideNoCompletedProject = true;
                    $.each(completedProjectList, function (index) {
                        var completedProjectInfo = {
                        };
                        completedProjectInfo.projectTitle = completedProjectList[index].ProjectTitle;
                        if (completedProjectList[index].ProjectImageUrl) {
                            completedProjectInfo.projectImage = completedProjectList[index].ProjectImageUrl;
                        }
                        $scope.completedProjects.push(completedProjectInfo);
                    });
                } else {
                    $scope.hideNoCompletedProject = false;
                    $scope.completedProjects = []
                }
            }
            else {
                $scope.completedProjects = [];
            }
        }
        $scope.childCanCreateProject = savingSchoolDetail.CanCreateProject;
        $scope.isSubscribingParent = savingSchoolDetail.IsSubscribingParent;
        $scope.isAdultChild = savingSchoolDetail.IsAdultChild;
        $scope.moreOption = ($scope.shortTermProjects.length > 0 || $scope.completedProjects.length > 0 || $scope.wishInfoList.length > 0);
        $scope.showActivateLevel2 = ($scope.Level == '1' && ($scope.isParentOrAdmin || $scope.isAdultChild));

        if ($scope.childCanCreateProject === true && localStorage.getItem("isChild") === "true") {
            $scope.hideCreateProjectMenutext = false;

        } else {
            $scope.hideCreateProjectMenutext = true;
        }
        try {
            $scope.firstLevelProjectsCount = Number($scope.activeProjects.length + $scope.pendingProjects.length);
        } catch (e) {
            $scope.firstLevelProjectsCount = Number($scope.activeProjects.length);
        }

    }

    $scope.sortProject = function () {
        $scope.sortableProjects = [];
        if (window.innerWidth > 767) {
            $(this).parent().slideUp();
        } else {
            $scope.moreOptionsVisible = false;
        }
        $scope.sortableProjects = $scope.shortTermProjects;
        $(".ss-first-level-projects").css("display", "none");
        $(".draggable-project-section").css("display", "block");
        $(".ss-first-level-projects").css("display", "none");
        $(".ss-save-priority").prop("disabled", true).addClass("disabled");
    }
    $scope.getSavingSchoolDetail = function (personId, childId) {
        $scope.activeProjectsNumber = 0;
        var shortTermPlanValidationType = 1;
        localStorage.setItem("currentSection", "savingSchool");
        $scope.$parent.hideSavingSchoolProjectButton = true;
        if (!savingSchoolService.getSavingSchoolData()) {
            if (childId && personId) {
                savingSchoolService.getSavingSchoolDetail(personId, childId).then(
                        function (data) {
                            var savingSchoolDetail = data;
                            $scope.ssChildId = savingSchoolDetail.PersonId;
                            savingSchoolService.setSavingSchoolData(savingSchoolDetail);
                            if (currentStateName == "child.detail.savingschool") {
                                $scope.savingSchoolProjectsBinding(savingSchoolDetail, shortTermPlanValidationType);
                            }
                            else {
                                $scope.savingSchoolProjectsBindingForChild(savingSchoolDetail, shortTermPlanValidationType);
                            }
                            localStorage.setItem("isSavingSchool", false);
                        },
                    function (error) {
                        localStorage.setItem("isSavingSchool", false);
                        genericErrorMessageDisplay(Resources.SavingSchoolDetails_Failed);
                    });
            }
        }
        else {
            $scope.shortTermProjects = [];
            var savingSchoolDetail = savingSchoolService.getSavingSchoolData();
            $scope.$evalAsync(function ($scope) {
                if (currentStateName == "child.detail.savingschool") {
                    $scope.savingSchoolProjectsBinding(savingSchoolDetail, shortTermPlanValidationType);
                }
                else {
                    $scope.savingSchoolProjectsBindingForChild(savingSchoolDetail, shortTermPlanValidationType);
                }
            });
            localStorage.setItem("isSavingSchool", false);
        }

    }

    $scope.deleteCustomAmount = function () {
        savingSchoolService.saveCustomAmount($scope.AllOtherResources).then(
            function (data) {
                $scope.calAmount();
            },
            function (error) {
                $scope.calAmount();
                genericErrorMessageDisplay(Resources.CustomAmount_Failed);
            }
        );
    }

    $scope.saveCustomAmount = function () {
        savingSchoolService.saveCustomAmount($scope.AllOtherResources).then(
            function (data) {

                if (data.data && data.data.length) {
                    if (data.data[0].Category == customAmountCategory.MyReserve) {
                        $scope.itemsforReserve = data.data[0];
                        $scope.ReserveAmount = data.data[0].Amount;
                    } else {
                        $scope.itemsforSources = data.data;
                        $scope.SummationOfOtherSourcesAmountAndValidateSelf();
                    }

                    savingSchoolService.setSavingSchoolData('');
                    $scope.getSavingSchoolInformation();
                }
            },
            function (error) {
                $scope.SummationOfOtherSourcesAmountAndValidateSelf()
                genericErrorMessageDisplay(Resources.CustomAmount_Failed);
            }
        );
    }

    $scope.activateLevel2 = function () {
        if (parentalControlObj.currentAmountAnswer) {
            savingSchoolService.activateLevel2($scope.personId, $scope.childId).then(
                        function (data) {
                            savingSchoolService.getSavingSchoolData().Level = SavingSchoolLevel.Level2;
                            $scope.getSavingSchoolInformation();
                        },
                function (error) {
                    genericErrorMessageDisplay(Resources.SavingSchoolDetails_Failed);
                }
            );

            if (window.innerWidth < 768) {

                $scope.moreOptionsVisible = false;
            }
        }
        else {
            $rootScope.$broadcast("parental-setting-change-triggered", {
                childFirstName: $stateParams.childFirstName, showBtnsFromSavingsAcademy: true
            });
            $("#parentalSettingChangeModal").modal("show");
        }
    }
    $rootScope.$on("implement-setting-for-level-two", function () {
        savingSchoolService.activateLevel2($scope.personId, $stateParams.childId).then(
                function (data) {
                    savingSchoolService.getSavingSchoolData().Level = SavingSchoolLevel.Level2;
                    $scope.getSavingSchoolInformation();
                },
                function (error) {
                    genericErrorMessageDisplay(Resources.SavingSchoolDetails_Failed);
                }
            );

        if (window.innerWidth < 768) {

            $scope.moreOptionsVisible = false;
        }
    });
    $scope.changePriority = function (event) {
        $scope.priorityArray = new Array();
        angular.forEach(angular.element(".ss-prject-prority-card"), function (value, key) {
            var elem = angular.element(value);
            var elemObj = {
                "ProjectId": elem.attr("projectid"),
                "ProjectPriority": Number(elem.index() + 1)
            }
            $scope.priorityArray.push(elemObj);
        });
        $scope.newArray = {
        };
        $scope.newArray = $scope.priorityArray;
        savingSchoolService.saveActiveProjectByPriority($scope.newArray).then(
            function (data) {
                savingSchoolService.setSavingSchoolData("");
                $scope.getSavingSchoolInformation();
                $(".draggable-project-section").css("display", "none");
                $(".ss-first-level-projects").css("display", "block");
            },
            function (error) {
                genericErrorMessageDisplay(Resources.SavingSchoolDetails_Failed);
            }
        );
    }

    $scope.graphCalculator = function (totalVal, graphOne, graphTwo) {
        var totalGraphValue = totalVal;
        var primaryVal = graphOne;
        var secondaryVal = graphTwo;
        var primaryValPercentage = Number(primaryVal / totalGraphValue * 100);
        var secondaryValPercentage = Number(secondaryVal / totalGraphValue * 100);
        // code for putting values in graph
        var graphCircumference = 220; //constant value for the radius used in the circular graph
        var primaryValGraph = Number(primaryValPercentage / 100 * graphCircumference);
        var secondaryValGraph = Number(secondaryValPercentage / 100 * graphCircumference);
        var primaryOffset = graphCircumference - primaryValGraph;
        var secondaryOffset = graphCircumference - (primaryValGraph + secondaryValGraph);
        var secondGraphPath = graphCircumference - primaryValGraph;
        return {
            "offset1": primaryOffset,
            "offset2": primaryOffset != 220 ? secondaryOffset + 2 : secondaryOffset
        };
    };


    $scope.$on('projectModal-saving', function (event, args) {
        savingSchoolService.setSavingSchoolData("");
        savingSchoolService.setWishData("");
        $scope.backToSavingSchool();
    });


    $scope.getProjectDetails = function (projectId) {
        $scope.backBtnShowOnSavingSchool = true;
        $scope.edit = null;

        if ($rootScope.isChild && !$scope.isAdultChild && !$scope.childCanCreateProject) {
            $scope.showSecondButtonSet = false;
            $scope.showDelete = false;
        } else {
            $scope.showDelete = true;
        }
        $.each($scope.shortTermProjects, function (index) {

            if ($scope.shortTermProjects[index].projectId === projectId) {
                $scope.wishListFlag = false;
                $scope.edit = $scope.shortTermProjects[index];

                $scope.edit.projectId = projectId;

                if ($scope.edit.projectStatus === "Active") {
                    $scope.showFirstButtonSet = true;
                    $scope.showSecondButtonSet = false;
                    $scope.showThirdButtonSet = false;
                    $scope.edit.projectAmount = $scope.edit.targetProjectAmount;
                    $scope.amount = $scope.edit.projectAmount;
                } else {
                    $scope.edit.projectAmount = $scope.edit.targetProjectAmount;
                    $scope.amount = $scope.edit.projectAmount;
                    if ($rootScope.isChild && !$scope.isAdultChild && !$scope.childCanCreateProject) {
                        $scope.showThirdButtonSet = true;
                        $scope.showSecondButtonSet = false;
                        $scope.showDelete = false;
                        $scope.showFirstButtonSet = false;
                    } else {
                        $scope.showSecondButtonSet = true;
                        $scope.showFirstButtonSet = false;
                        $scope.showThirdButtonSet = false;
                    }

                    if ($rootScope.isChild && !$scope.isAdultChild && $scope.childCanCreateProject === true) {
                        $scope.showThirdButtonSet = true;
                        $scope.showSecondButtonSet = false;
                        $scope.showFirstButtonSet = false;
                    }
                }
            }
        });
        $(".ss-container-left").animate({
            'left': '-130%'
        }).css("position", "absolute");
        $(".ss-container-right").animate({
            'left': '0'
        }).css("position", "relative");
    }


    $scope.getWishDetailsForChild = function (projectId) {
        $scope.backBtnShowOnSavingSchool = true;
        $scope.edit = null;
        $scope.showFirstButtonSet = true;
        $scope.showSecondButtonSet = false;
        $scope.showThirdButtonSet = false;
        if ($rootScope.isChild) {
            $scope.showDelete = true;
        } else {
            $scope.showDelete = false;
        }
        $.each($scope.wishInfoList, function (index) {
            if ($scope.wishInfoList[index].projectId === projectId) {
                $scope.wishListFlag = true;
                $scope.edit = $scope.wishInfoList[index];
                $scope.edit.projectId = projectId;
                $scope.amount = $scope.edit.projectAmount;
            }
        });
        $(window).scrollTop(0);
        $(".ss-container-left").animate({
            'left': '-130%'
        }).css("position", "absolute");
        $(".ss-container-right").animate({
            'left': '0'
        }).css("position", "relative");
    }


    $scope.moveToProject = function (projectId, projectCategory, projectPriority, planId) {
        $scope.projectDetail = {
        };
        $scope.projectDetail.projectId = projectId;
        $scope.projectDetail.projectCategory = projectCategory;
        $scope.projectDetail.projectPriority = projectPriority;
        $scope.projectDetail.planId = planId;

        if ($scope.isParentOrAdmin || $scope.isAdultChild || (($rootScope.isChild && $scope.childCanCreateProject))) {
            $scope.projectDetail.isParentOrAdmin = true;
        }
        else {
            $scope.projectDetail.isParentOrAdmin = false;
        }

        savingSchoolService.updateProjectStatus($scope.projectDetail, $scope.personId, $scope.childId).then(
            function (data) {
                savingSchoolService.setWishData("");
                savingSchoolService.setSavingSchoolData("");
                $scope.getWishDetails($stateParams.childId);
                $scope.getSavingSchoolInformation();
                $(window).scrollTop(0);
                $(".ss-container-left").animate({
                    'left': '0'
                }, function () {
                    $(this).css("position", "relative")
                });
                $(".ss-container-right").animate({
                    'left': '130%'
                }, 300, "linear", function () {
                    $(this).css("position", "absolute");
                });

                if ((projectCategory === 1) && ($scope.isParentOrAdmin || $scope.isAdultChild || (($rootScope.isChild && $scope.childCanCreateProject)))) {
                    genericSuccessMessageDisplay(Resources.MoveToProject_Success);
                } else {
                    //If Child moves Wish to Project :
                    if ((projectCategory === 1) && ($rootScope.isChild && !$scope.isAdultChild && !$scope.childCanCreateProject)) {
                        genericSuccessMessageDisplay(Resources.MoveToProjectForChild_Success);
                    } else {
                        genericSuccessMessageDisplay(Resources.MoveToWish_Success);
                    }
                }
            },
            function (error) {
                if (projectCategory === 1) {
                    genericErrorMessageDisplay(Resources.MoveToProject_Failed);
                } else {
                    genericErrorMessageDisplay(Resources.MoveToWish_Failed);
                }
            }
        );
    }

    $scope.deleteProject = function (projectData) {
        $scope.projectDetail = {
        };
        $scope.projectDetail.projectId = projectData.projectId;
        $scope.projectDetail.planId = projectData.planId;
        $scope.projectDetail.projectPriority = projectData.projectPriority;
        savingSchoolService.deleteProject($scope.projectDetail).then(
            function (data) {
                $("#deleteProjectModal").modal("hide");
                savingSchoolService.setWishData("");
                savingSchoolService.setSavingSchoolData("");
                $scope.getSavingSchoolInformation();
                $scope.getWishDetails($stateParams.childId);
                $('#deleteProjectModal').on('hidden.bs.modal', function () {
                    $(window).scrollTop(0);
                    $(".ss-container-left").animate({
                        'left': '0'
                    }, function () {
                        $(this).css("position", "relative")
                    });
                    $(".ss-container-right").animate({
                        'left': '130%'
                    }, 300, "linear", function () {
                        $(this).css("position", "absolute");
                    });
                })

                var message = Resources.DeleteProject_Success.replace("{0}", projectData.projectTitle);
                genericSuccessMessageDisplay(message);

            },
            function (error) {
                $("#deleteProjectModal").modal("hide");
                var message = Resources.DeleteProject_Failed.replace("{0}", projectData.projectTitle);
                genericErrorMessageDisplay(message);
            }
        );
    }

    $scope.completeProject = function (projectId, projectPriority) {

        localStorage.setItem("isSavingSchool", true);
        var completeProjectObj = {
            'stProjectId': projectId,
            'stProjectPriority': projectPriority
        }
        $state.go('moneyout', {
            childId: $stateParams.childId,
            obj: completeProjectObj
        });

    }

    $scope.updatePendingProject = function (projectId, planId, isApprove) {
        $scope.projectDetail = {};
        $scope.projectDetail.projectId = projectId;
        $scope.projectDetail.planId = planId;
        $scope.projectDetail.isParentOrAdmin = $scope.isParentOrAdmin;
        savingSchoolService.updatePendingProjectStatus($scope.projectDetail, $scope.personId, $scope.childId, isApprove, false).then(
            function (data) {
                $(window).scrollTop(0);
                savingSchoolService.setSavingSchoolData("");
                savingSchoolService.setWishData("");
                $scope.backToSavingSchool();

                if (isApprove) {
                    genericSuccessMessageDisplay(Resources.MoveToProject_Success);
                } else {
                    genericSuccessMessageDisplay(Resources.MoveToProject_Disapproved);
                }
            },
            function (error) {
            }
        );
    }

    $scope.saveReserveDetails = function () {
        $scope.AllOtherResources = [];
        $scope.itemsforReserve.Amount = Number(returnANumberWithoutFormating($scope.itemsforReserve.Amount, $scope.language));
        $scope.AllOtherResources.push($scope.itemsforReserve);
        $scope.saveCustomAmount();
    }

    $scope.$watch("itemsforReserve.Amount", function (current, previous) {
        var enteredVal = Number(current);
        if (!Number(current) && Number(current) != 0) {
            enteredVal = Number(previous)  //TODO: need to look into it properly.
        }
        var ShortTermContractAmountnumber = Number(returnANumberWithoutFormating($scope.ShortTermContractAmount, $scope.language));
        if (enteredVal <= ShortTermContractAmountnumber) {
            $scope.projectAmountForvalidation = false;
        } else {
            $scope.projectAmountForvalidation = true;

        }
    });


    $scope.updatePendingProjectForInfantChild = function (projectId, isApprove) {
        $scope.projectDetail = {
        };
        $scope.projectDetail.projectId = projectId;
        savingSchoolService.updatePendingProjectStatus($scope.projectDetail, $scope.personId, $scope.childId, isApprove, true).then(
            function (data) {
                if (!isApprove) {
                    savingSchoolService.setWishData("");
                    savingSchoolService.setSavingSchoolData("");
                    $scope.getWishDetails($stateParams.childId);
                    $scope.getSavingSchoolInformation();
                    $("#deletePendingProjectModal").modal("hide");
                    $('#deletePendingProjectModal').on('hidden.bs.modal', function () {
                        $(window).scrollTop(0);
                        $(".ss-container-left").animate({
                            'left': '0'
                        }, function () {
                            $(this).css("position", "relative")
                        });
                        $(".ss-container-right").animate({
                            'left': '130%'
                        }, 300, "linear", function () {
                            $(this).css("position", "absolute");
                        });
                    })
                } else {
                    savingSchoolService.setWishData("");
                    savingSchoolService.setSavingSchoolData("");
                    $scope.getWishDetails($stateParams.childId);
                    $scope.getSavingSchoolInformation();
                    $(window).scrollTop(0);
                    $(".ss-container-left").animate({
                        'left': '0'
                    }, function () {
                        $(this).css("position", "relative")
                    });
                    $(".ss-container-right").animate({
                        'left': '130%'
                    }, 300, "linear", function () {
                        $(this).css("position", "absolute");
                    });
                }
                genericSuccessMessageDisplay(Resources.MoveToWish_Success);
            },
            function (error) {
                if (!isApprove) {
                    $("#deletePendingProjectModal").modal("hide");
                }
                genericErrorMessageDisplay(Resources.MoveToWish_Failed);
            }
        );
    }

    $scope.backToSavingSchool = function () {
        savingSchoolService.setSavingSchoolData("");
        $scope.getSavingSchoolInformation();
        $scope.getWishDetails($stateParams.childId);
        $(".ss-container-left").animate({
            'left': '0'
        }).css("position", "relative");
        $(".ss-container-right").animate({
            'left': '115%'
        }).css("position", "absolute");

    }

    $scope.backButtonClick = function () {
        $scope.backBtnShowOnSavingSchool = false;
        $(".ss-container-left").animate({
            'left': '0'
        }).css("position", "relative");
        $(".ss-container-right").animate({
            'left': '115%'
        }).css("position", "absolute");
    }

    function setWishListDetails(wishInfoList) {
        $scope.wishInfoList = [];
        if (wishInfoList.length) {
            $.each(wishInfoList, function (index) {
                var wishInfo = {
                };

                wishInfo.projectId = wishInfoList[index].ProjectId;
                wishInfo.planId = wishInfoList[index].PlanId;
                wishInfo.projectTitle = wishInfoList[index].ProjectTitle;
                wishInfo.projectPriority = wishInfoList[index].ProjectPriority;
                wishInfo.projectDescription = wishInfoList[index].ProjectDescription;
                wishInfo.projectCategory = wishInfoList[index].ProjectCategory;
                wishInfo.projectStatus = wishInfoList[index].ProjectStatus;
                wishInfo.projectImage = wishInfoList[index].ProjectImageUrl;
                wishInfo.projectAmount = formatAmountField(wishInfoList[index].ProjectTargetAmount, $scope.language);
                $scope.wishInfoList.push(wishInfo);
            });
        } else {
            $scope.wishInfoList = [];
        }

    }
    $scope.getWishDetails = function (childId) {
        if (!savingSchoolService.getWishData.length) {
            savingSchoolService.getWishList(childId).then(function (data) {
                var wishes = data;
                savingSchoolService.getWishData(wishes);
                setWishListDetails(wishes);

            });

        } else {
            setWishListDetails(savingSchoolService.WishDetails);
        }
    }
    $scope.$parent.createProjectForSavingSchool = function (isProject) {

        $rootScope.$broadcast('projectModal-started', {
            any: {
                "isEdit": false, "editData": "", "isProject": isProject, "language": $scope.language, "edit": $scope.edit, "childId": $stateParams.childId, "entryLocation": "savingSchool", "childFirstName": $rootScope.childFirstName
            }
        });

        $scope.isProject = isProject;
    }

    $scope.editProjectForSavingSchool = function (editData, isProject) {
        $rootScope.$broadcast('projectModal-started', {
            any: {
                "isEdit": true, "editData": editData, "isProject": isProject, "language": $scope.language, "edit": $scope.edit, "childId": $stateParams.childId, "childFirstName": $rootScope.childFirstName
            }
        });
        $scope.isProject = isProject;
    }



    $scope.projectAmountMethod = function () {

        var projectAmount = $("#inputAmountSS").val().replace(/[^0-9]/, "");
        $("#inputAmountSS").val("$" + projectAmount);
        if (Number(projectAmount) > 9999) {
            $scope.projectAmount = $scope.oldProjectAmount;
        } else {
            $scope.projectAmount = projectAmount;
            $scope.oldProjectAmount = $scope.projectAmount;
        }
    };
    $scope.enteAnAmountReserveMethod = function () {
        var position = document.getElementById("itemsforReserveAmount").selectionStart
        var projectAmount = $("#itemsforReserveAmount").val().toString().replace(/[^0-;9]/, ""); //$scope.itemsforReserve.Amount.toString();
        if (/[^0-;9]/.test($("#itemsforReserveAmount").val().toString())) {
            position = position - 1;
        }
        if (Number(projectAmount) > 99999) {
            $scope.itemsforReserve.Amount = $scope.oldProjectAmount;
            position = position - 1;
        } else {
            $scope.itemsforReserve.Amount = projectAmount;
            $scope.oldProjectAmount = projectAmount;
            $("#itemsforReserveAmount").val(projectAmount);
        }
        document.getElementById("itemsforReserveAmount").selectionEnd = position;

    }





    $scope.goToSavingSchoolSection = function () {
        setTimeout(function () {
            $("#savingSchool").trigger('click');
        }, 500)
    };


    if ($stateParams.routingEntry == "cp") {
        $scope.getSavingSchoolDetail($.cookie("personId"), $scope.childId);
    }
    $scope.checkPendingProject = function (projectId) {
        if ($stateParams.isTimeline) {
            if ($stateParams.projectId == projectId) {
                $scope.getProjectDetails($stateParams.projectId);
            }
        }
    }
    $scope.checkIfNavigatedFromDashboard = function (wishId) {
        if ($stateParams.isTimeline) {
            if ($stateParams.projectId == wishId) {
                $scope.getWishDetailsForChild($stateParams.projectId);
            }
        }
    }
    $scope.$on('child-is-supporter', function (event, data) {
        $scope.$parent.hideSavingSchoolContributeButton = false;
    });
    $scope.$on("wish-cancelled-without-saving", function () {
        if ($scope.wishInfoList.length == 0 && $rootScope.isChild && $stateParams.wishFlag) {
            $state.go("dashboard");
        }
    });

    if ($rootScope.isChild && $stateParams.wishFlag) {
        $scope.$parent.createProjectForSavingSchool(false);
    }
}]);
$(document).ready(function () {

    $(document).on("click", ".ss-show-completed-projects", function () {
        $(".wishlist-project-list").animate({ 'left': '-110%' });
        $(".wishlist-project-list").css("position", "absolute");
        $(".completed-project-list").animate({
            'left': '0'
        },
        {
            complete: function () {
                $(".completed-project-list").css("position", "relative");
                $(".wishlist-project-list").css("position", "absolute");
            }
        });

    });
    $(document).on("click", ".ss-show-wishlist-projects", function () {
        $(".wishlist-project-list").animate({
            'left': '0'
        });
        $(".wishlist-project-list").css("position", "relative");
        $(".completed-project-list").animate({
            'left': '110%'
        },
        {
            complete: function () {
                $(".completed-project-list").css("position", "absolute");
                $(".wishlist-project-list").css("position", "relative");
            }
        });
        $(".completed-project-list").css("position", "absolute");
    });
    $(document).on("click", ".ss-project-tab", function () {
        $(".ss-project-tab").removeClass("menu-selected-item ss-active-tab").addClass("ss-inactive-tab");
        $(this).addClass("menu-selected-item ss-active-tab").removeClass("ss-inactive-tabs");
        if ($(this).parent().index() == 1) {
            $(".ss-web-wishlist-projects").animate({
                'left': '-110%'
            },
            {
                complete: function () {
                    $(".ss-web-wishlist-projects").css("position", "absolute");
                }
            });
            $(".ss-web-completed-projects").animate({
                'left': '0'
            },
            {
                complete: function () {
                    $(".ss-web-completed-projects").css("position", "relative");
                }
            });


        } else if ($(this).parent().index() == 0) {
            $(".ss-web-wishlist-projects").animate({
                'left': '0'
            },
        {
            complete: function () {
                $(".ss-web-wishlist-projects").css("position", "relative");
            }
        });
            $(".ss-web-completed-projects").animate({
                'left': '110%'
            },
        {
            complete: function () {
                $(".ss-web-completed-projects").css("position", "absolute");
            }
        });
        }
    });
    $(document).on("click", "#optionDropDown", function () {
        $("#longOptionDropDownDetail, #shortOptionDropDownDetail").slideToggle();
    });
    $(document).click(function (e) {
        if (e.target.id != 'optionDropDown') {
            $("#longOptionDropDownDetail, #shortOptionDropDownDetail").hide();
        }
    });
    $(document).on("click", ".ss-priority-change", function () {
        if (window.innerWidth > 767) {
            $(this).parent().slideUp();
        } else {
            $("#moreOptionModal").modal("hide");
            $('#moreOptionModal').on('hidden.bs.modal', function () {
                $("body").removeClass('modal-open');
            });
        }
        $(".ss-first-level-projects").css("display", "none");
        $(".draggable-project-section").css("display", "block");
        $("#columns").sortable({
            stop: function (event, ui) {
                $(".ss-save-priority").prop("disabled", false).removeClass("disabled");
            }
        });
        $(".ss-first-level-projects").css("display", "none");
        $(".ss-save-priority").prop("disabled", true).addClass("disabled");
    });
    $(document).on("click", ".ss-back-to-projects", function () {
        $(".draggable-project-section").css("display", "none");
        $(".ss-first-level-projects").css("display", "block");
        $("#columns").sortable('cancel');
    });

    $(document).on('mouseenter', '.ss-first-level-projects .ss-purple-circle,.shortterm-graph .ss-purple-circle, #messageInfoId .ss-purple-circle', function () {
        $(this).parent().parent().find(".ss-purple-overlay").css("display", "block");
        $(this).parent().parent().find(".ss-blue-overlay").css("display", "none");
    });
    $("document").on('mouseleave', '.ss-first-level-projects .ss-purple-circle,.shortterm-graph .ss-purple-circle, #messageInfoId .ss-purple-circle', function () {
        $(this).parent().parent().find(".ss-purple-overlay").css("display", "none");
        $(this).parent().parent().find(".ss-blue-overlay").css("display", "none");
    });
    $(document).on('mouseenter', '.ss-first-level-projects .ss-blue-circle,.shortterm-graph .ss-blue-circle, #messageInfoId .ss-blue-circle', function () {
        $(this).parent().parent().find(".ss-blue-overlay").css("display", "block");
        $(this).parent().parent().find(".ss-purple-overlay").css("display", "none");
    });
    $(document).on('mouseleave', '.ss-first-level-projects .ss-blue-circle,.shortterm-graph .ss-blue-circle, #messageInfoId .ss-blue-circle', function () {
        $(this).parent().parent().find(".ss-blue-overlay").css("display", "none");
        $(this).parent().parent().find(".ss-purple-overlay").css("display", "none");
    });
    $(document).on('mouseleave', '.ss-active-project-wrapper', function () {
        $(this).find('.ss-blue-overlay').css('display', 'none');
        $(this).find('.ss-purple-overlay').css('display', 'none');
    });
    $(document).on('mouseenter', '.ss-blue-overlay,.ss-purple-overlay', function () {
        $(this).css('display', 'none');
    });
    $('#myOtherSourcesModal,#myReserveModal,#createProjectModal').on('hidden.bs.modal', function () {
        $("body").css('padding', '0');
    });
    $(document).on("click", "#moreOptionModal .modal-close-link", function () {
        $('#moreOptionModal').on('hidden.bs.modal', function () {
            $("body").removeClass('modal-open');
        });
    })


    $("#childEventDetails").animate({
        "right": "-1053px"
    });
    $(".scroll").mCustomScrollbar({
        axis: "y",
        scrollbarPosition: "outside"
    });
    $(document).on("keydown keypress", "#inputDescriptionFieldSS", function (e) {
        setTimeout(function () {
            var fillUpLength = $("#inputDescriptionFieldSS").val().length;
            var charLeft = Number(500 - fillUpLength);
            $("#descCount").text(charLeft);



            if (e.which == 08 || e.which == 127) {

                fillUpLength = $("#inputDescriptionFieldSS").val().length;
                charLeft = Number(500 - fillUpLength);
                $("#descCount").text(charLeft);

            }

        }, 50);
        if ($("#inputDescriptionFieldSS").val().length > 499 && e.which != 08 && e.which != 127) {
            e.preventDefault();
        }
    });
    $("#inputDescriptionFieldSS").bind("paste cut", function (e) {
        var fillUpLength = 0;
        setTimeout(function (e) {
            if ($("#inputDescriptionFieldSS").val().length > 500) {
                $("#inputDescriptionFieldSS").val($("#inputDescriptionFieldSS").val().slice(0, 500));
            }
            fillUpLength = $("#inputDescriptionFieldSS").val().length;
            var charLeft = Number(500 - fillUpLength);
            $("#descCount").text(charLeft);
        }, 100);


    });

});


