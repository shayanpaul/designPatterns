﻿childPage.controller("remindSupporterController", ["$scope", "$rootScope", "$stateParams", "$state", "WebApiService", "DisplaySupportersService", function ($scope, $rootScope, $stateParams, $state, WebApiService, DisplaySupportersService) {
    $scope.$on('remindTheSupporter', function (event, args) {
        DisplaySupportersService.GetDefaultInviterDetails().then(
            function (data) {
                $scope.relationships = data.Relationship;
                $scope.modalChildRelation = $scope.relationships[args.any.supporterData.Relationship].Code;
            },
            function (error) {
            }
        );
        $scope.modalData = args.any.supporterData;
        $scope.modalChildImage = args.any.childImage;
        $scope.modalChildChildName = args.any.childName;
        if (!$scope.modalData.PersonImageUrl) {
            $scope.modalData.PersonImageUrl = images.defaultPersonImage;
        }
        var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
        var firstDate = new Date(args.any.supporterData.InvitationDate);
        var secondDate = new Date();

        $scope.daysAfterInvitation = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime()) / (oneDay)));
    });
    
    $scope.sendMailToSupporter = function (mailCode) {
        var mailUrl = "/invitations/"+mailCode+"/supporterinvitationreminder";
        WebApiService.sendMailToSupporter(mailUrl).then(function (data) {
            //console.log(data);
            $("#SupporterReminderModal").modal('hide');
            genericSuccessMessageDisplay(Resources.supporterReminderSent);
        })
    }
}])