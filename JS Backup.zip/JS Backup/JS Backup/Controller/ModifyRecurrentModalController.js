﻿myAppangular.controller("modifyRecurrentController", ["$scope", "$filter", "WebApiService", "paymentService", "$window", "FormSubmitter", "$rootScope", "$state", function ($scope, $filter, WebApiService, paymentService, $window, FormSubmitter, $rootScope, $state) {
    var ProofOfIdentity = [{
        "Barcode": "",
        "ChildId": 0,
        "ExpiryDate": "",
        "IdentityProofNumber": "",
        "Image": "",
        "ImageBase64": [],
        "ImageBase64ForSingleImage": "",
        "ImageForSingleImage": "",
        "ImageName": "BackImage",
        "ImageTypeCode": 2,
        "ImageUri": "",
        "IsUserSettings": "",
        "PersonId": parentID
    }, {
        "Barcode": "",
        "ChildId": 0,
        "ExpiryDate": "",
        "IdentityProofNumber": "",
        "Image": "",
        "ImageBase64": [],
        "ImageBase64ForSingleImage": "",
        "ImageForSingleImage": "",
        "ImageName": "FrontID",
        "ImageTypeCode": 3,
        "ImageUri": "",
        "IsUserSettings": "",
        "PersonId": parentID
    }];

    $scope.Eid = {
        "front": "",
        "back": ""
    };
    $scope.locationCalledFrom = null;
    $scope.$on('updateRecurrentModal-started', function (event, args) {
        $scope.modifyRecurrentData = args.any.recurrentData;
        $scope.locationCalledFrom = args.any.locationCalledFrom;
        if (localStorage.getItem("isContributionUpdate") == "true") {
            $scope.showModifySection = true;
            $scope.showDeleteSection = false;
            $scope.modifyLTAmount = true;
            $scope.modifySTAmount = true;
        }
        $scope.showModifiedShortTerm = false;
        $scope.showModifiedLongTerm = false;
        $scope.showDeleteShortTerm = false;
        $scope.showDeleteLongTerm = false;
        var longTermAmount = '';
        var shortTermAmount = '';
        var oldLongTermAmount = '';
        var oldShortTermAmount = '';
        if (args.any.recurrentData != null) {
            if (args.any.recurrentData.RecurrentPaymentView.LongTermPlanView != null && args.any.recurrentData.RecurrentPaymentView.ShortTermPlanView != null) {
                longTermAmount = args.any.recurrentData.RecurrentPaymentView.LongTermPlanView.NewAmount;
                shortTermAmount = args.any.recurrentData.RecurrentPaymentView.ShortTermPlanView.NewAmount;
                oldLongTermAmount = returnANumberWithoutFormating(args.any.recurrentData.RecurrentPaymentView.LongTermPlanView.OldAmount, currentLanguage);
                oldShortTermAmount = returnANumberWithoutFormating(args.any.recurrentData.RecurrentPaymentView.ShortTermPlanView.OldAmount, currentLanguage);
            } else if (args.any.recurrentData.RecurrentPaymentView.ShortTermPlanView != null) {
                shortTermAmount = args.any.recurrentData.RecurrentPaymentView.ShortTermPlanView.NewAmount;
                oldShortTermAmount = returnANumberWithoutFormating(args.any.recurrentData.RecurrentPaymentView.ShortTermPlanView.OldAmount, currentLanguage);
            } else if (args.any.recurrentData.RecurrentPaymentView.LongTermPlanView != null) {
                longTermAmount = args.any.recurrentData.RecurrentPaymentView.LongTermPlanView.NewAmount;
                oldLongTermAmount = returnANumberWithoutFormating(args.any.recurrentData.RecurrentPaymentView.LongTermPlanView.OldAmount, currentLanguage);
            }
            if (!isEmptyOrUndefinedOrNull(longTermAmount)) {
                $scope.longTermAmount = formatAmountField(longTermAmount, currentLanguage);
                if (longTermAmount === oldLongTermAmount) {
                    $scope.showModifiedLongTerm = true;
                    $scope.showDeleteLongTerm = false;
                } else if (longTermAmount == 0) {
                    $scope.showModifiedLongTerm = false;
                    $scope.showDeleteLongTerm = true;
                }
                else {
                    $scope.showModifiedLongTerm = true;
                    $scope.showDeleteLongTerm = false;
                }
            } else {
                $scope.showModifiedLongTerm = false;
                $scope.showDeleteLongTerm = false;
            }
            if (!isEmptyOrUndefinedOrNull(shortTermAmount)) {
                $scope.shortTermAmount = formatAmountField(shortTermAmount, currentLanguage);
                if (shortTermAmount === oldShortTermAmount) {
                    $scope.showModifiedShortTerm = true;
                    $scope.showDeleteShortTerm = false;
                } else if (shortTermAmount == 0) {
                    $scope.showModifiedShortTerm = false;
                    $scope.showDeleteShortTerm = true;
                }
                else
                {
                    $scope.showModifiedShortTerm = true;
                    $scope.showDeleteShortTerm = false;
                }
            } else {
                $scope.showModifiedShortTerm = false;
                $scope.showDeleteShortTerm = false;
            }
            $scope.recurrentId = args.any.recurrentData.RecurrentPaymentView.RecurrentPaymentId;
            $scope.contributorId = args.any.recurrentData.ContributorViewModel.PersonId;
            $scope.accountHolderIbanNumber = args.any.recurrentData.RecurrentPaymentView.IbanAccountNumber;
            $scope.accountHolderFirstName = args.any.recurrentData.RecurrentPaymentView.AccountHolderFirstName;
            $scope.accountHolderLastName = args.any.recurrentData.RecurrentPaymentView.AccountHolderLastName;
            $scope.userMessage = args.any.recurrentData.RecurrentPaymentView.Message;
            $scope.bicNumber = args.any.recurrentData.RecurrentPaymentView.Swift;
            $scope.value = args.any.recurrentData.RecurrentPaymentView.Frequency;
            $scope.isDelete = args.any.recurrentData.RecurrentPaymentView.IsRecurrentDelete;
        }
        $scope.childName = args.any.name;

        $("#paymentOverviewModal").modal("show");
    });
   
    $scope.modifyRecurrentPayment = function (longTermAmount, shortTermAmount, userMessage, value, accountHolderLastName, bicNumber, accountHolderIbanNumber, accountHolderFirstName, callType, refType, recurrentId, isDelete) {
        localStorage.setItem("recurrentRedirect", true);
        $scope.saveRecurrentPayment($scope.modifyRecurrentData.RecurrentPaymentView, longTermAmount, shortTermAmount, userMessage, value, accountHolderLastName, bicNumber, accountHolderIbanNumber, accountHolderFirstName, callType, refType, recurrentId);
    }
    $scope.saveRecurrentPayment = function (modifyRecurrentData, longTermAmount, shortTermAmount, userMessage, value, accountHolderLastName, bicNumber, accountHolderIbanNumber, accountHolderFirstName, callType, ReferencedFrom, recurrentId) {
        if (!$('#contributeForm').valid()) {
            $('#contributeForm').valid();
            return;
        }
        var paymentDetail = {};
        paymentDetail.RecurrentPaymentView = modifyRecurrentData;//need to initialize when creating new recurrent TODO:
        $scope.modifiedChildId = modifyRecurrentData.ChildView.PersonId;
        paymentDetail.ContributorViewModel = {};

        paymentDetail.isContributionUpdate = isTrue(localStorage.getItem("isContributionUpdate"));
        if (isTrue(localStorage.getItem("deleteRec"))) {
            paymentDetail.RecurrentPaymentView.IsRecurrentDelete = true;
        } else {
            paymentDetail.RecurrentPaymentView.IsRecurrentDelete = false;
        }

        //

        if (ProofOfIdentity[0].ImageTypeCode == 2) {
            if (ProofOfIdentity[0].ImageBase64[0]) {
                ProofOfIdentity[0].ImageBase64[0] = $scope.Eid.front;
            }
            else {
                ProofOfIdentity[0].ImageBase64.push($scope.Eid.front);
            }
        }
        else {
            if (ProofOfIdentity[0].ImageBase64[0]) {
                ProofOfIdentity[0].ImageBase64[0] = $scope.Eid.back;
            }
            else {
                ProofOfIdentity[0].ImageBase64.push($scope.Eid.back);
            }
        }
        if (ProofOfIdentity[1].ImageTypeCode == 2) {
            if (ProofOfIdentity[1].ImageBase64[0]) {
                ProofOfIdentity[1].ImageBase64[0] = $scope.Eid.front;
            }
            else {
                ProofOfIdentity[1].ImageBase64.push($scope.Eid.front);
            }
        }
        else {
            if (ProofOfIdentity[1].ImageBase64[0]) {
                ProofOfIdentity[1].ImageBase64[0] = $scope.Eid.back;;
            }
            else {
                ProofOfIdentity[1].ImageBase64.push($scope.Eid.back);
            }
        }

        ProofOfIdentity[0].IdentityId = 1;
        ProofOfIdentity[1].IdentityId = 2;
        ProofOfIdentity[0].IdentityProofNumber = $scope.nationalNumber;
        ProofOfIdentity[1].IdentityProofNumber = $scope.nationalNumber;
        ProofOfIdentity[0].ExpiryDate = $scope.tinExpDate;
        ProofOfIdentity[1].ExpiryDate = $scope.tinExpDate;

        

        for (var i = 0; i < ProofOfIdentity.length; i++) {
            if (!isEmptyOrUndefinedOrNull(ProofOfIdentity[i].ImageBase64[0])) {
                if (ProofOfIdentity[i].ImageBase64[0].substring(0, 4) == 'data') {
                    var array = ProofOfIdentity[i].ImageBase64[0].split(",");
                    ProofOfIdentity[i].ImageBase64[0] = array[1];
                } else {
                    ProofOfIdentity[i].ImageBase64[0] = null;
                }
            } else {
                ProofOfIdentity[i].ImageBase64[0] = null;
            }
        }


        paymentDetail.RecurrentPaymentView.ProofOfIdentityViewModel = ProofOfIdentity;
        paymentDetail.RecurrentPaymentView.RecurrentPaymentId = recurrentId;
        paymentDetail.ContributorViewModel.PersonId = $scope.contributorId;
        paymentDetail.RecurrentPaymentView.IbanAccountNumber = accountHolderIbanNumber;
        paymentDetail.RecurrentPaymentView.AccountHolderFirstName = accountHolderFirstName;
        paymentDetail.RecurrentPaymentView.AccountHolderLastName = accountHolderLastName;
        paymentDetail.RecurrentPaymentView.Message = userMessage;
        paymentDetail.RecurrentPaymentView.Swift = bicNumber;
        paymentDetail.RecurrentPaymentView.Frequency = value;
        paymentDetail.RecurrentPaymentView.StartDate = $("#contributeStartDate").val();
        paymentDetail.RecurrentPaymentView.EndDate = $("#contributeEndDate").val();
        paymentDetail.RecurrentPaymentView.CallType = callType;
        paymentDetail.RecurrentPaymentView.ReferencedFrom = ReferencedFrom;
        paymentDetail.RecurrentPaymentView.RedirectUrl = baseFrontEndUrl + "/connective/ConfirmSign";
        if (paymentDetail.RecurrentPaymentView.LongTermPlanView != null) {
            paymentDetail.RecurrentPaymentView.LongTermPlanView.NewAmount = returnANumberWithoutFormating(longTermAmount, currentLanguage);
        }
        if (paymentDetail.RecurrentPaymentView.ShortTermPlanView != null) {
            paymentDetail.RecurrentPaymentView.ShortTermPlanView.NewAmount = returnANumberWithoutFormating(shortTermAmount, currentLanguage);
        }
        paymentDetail.OneShotPaymentView = {};
        if (paymentDetail.RecurrentPaymentView.IsUploadIdExists == true) {
            paymentDetail.RecurrentPaymentView.ProofOfIdentityViewModel = {};
        }
        paymentService.addRecurrentPayment(paymentDetail).success(function (data, status) {

            if (data.PaymentType = "RecurrentPayment") {
                if (data.Url != null) {
                    $window.location.href = data.Url;
                }
            }

            if (isTrue(localStorage.getItem("isContributionUpdate"))) {
                localStorage.setItem("isContributionUpdate", "false");
                localStorage.setItem("deleteRec", false);
                if (data.Url != null) {
                    $window.location.href = data.Url;
                }
                else {
                    //$scope.locationCalledFrom = 'updateViaBasket';
                    $scope.goToChild($scope.modifiedChildId, $scope.contributorId, true);
                }
            } else {
                if (paymentDetail.RecurrentPaymentView.ChildView.PersonId != null || paymentDetail.RecurrentPaymentView.ChildView.PersonId != "") {
                    $scope.childId = paymentDetail.RecurrentPaymentView.ChildView.PersonId;
                } else {
                    $scope.childId = paymentDetail.SelectedChildId;
                }
                $scope.goToChild($scope.modifiedChildId, $scope.contributorId, false);
            }
        })
            .error(function (data, status) {
                genericErrorMessageDisplay(Resources.CreateRecurrentPayment_Failed);
            });
    }
    $scope.goToChild = function (SelectedChild, contributorId, isUpdate) {
        localStorage.setItem("isContributionUpdate", "false");
        localStorage.setItem("sameNavigationHistory", "true");
        if ($scope.entryPoint == 6 || $scope.entryPoint == 7) // for free contributor
        {
            $window.history.back();
        } else {
            if (isUpdate) {
                if ($scope.locationCalledFrom === 'updateViaChildView') {
                    $state.go("child.detail.plan", {
                        childId: SelectedChild
                    });
                } else if (($scope.locationCalledFrom === 'updateViaBasket') || ($scope.locationCalledFrom === 'updateViaBasketToPayment')) {
                    $state.go("contribute.basket");
                }
            } else {
                $state.go("child.detail.recurrentpayment", {
                    childId: SelectedChild
                });
            }
        }
    }
}]);