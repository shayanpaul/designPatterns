﻿myAppangular.filter('default', function () {
    return function (value, def) {
        return (value === undefined || value === null ? def : value);
    };
});

myAppangular.controller("UserProfileController", ["$scope", "EditProfileService", "$rootScope", function ($scope, EditProfileService, $rootScope) {

    $scope.personImage = '';
    $scope.allCountryList = [];
    $scope.hasManateDocument = false;
    $scope.hasNoRecurrentPayement = false;
    localStorage.setItem("isSubscriptionFlow", false);
     $scope.init = function () {
        $scope.getUserProfileDetails();
        $scope.getAllCountriesList();

        
    }

    $scope.getUserProfileDetails = function () {
        var personId = $.cookie('personId');

        EditProfileService.GetUserProfile(personId).then(
            function (data) {
                if (data.profilePictureUrl != null) {
                    $scope.personImage = data.profilePictureUrl;
                }
                if (data.dateOfBirth == '0001-01-01T00:00:00') { data.dateOfBirth = null; }
                
                data.countryCodeId = data.countryCodeId.toString();
                data.cityCodeId = data.cityZipCodeId.toString();

                $scope.userProfileDetails = data;
                $rootScope.personPhone = data.phoneNumber;
                if (!data.canEditProfilePicture) {
                    angular.element('#editPersonImage button').css('display', 'none');
                }
            },
            function (error) {
                genericErrorMessageDisplay();
            }
        );
    }

    $scope.ShowEditPopup = function () {
        $rootScope.$broadcast('userModal-started', {
            any: {
                "userProfileDetails": angular.copy($scope.userProfileDetails),
                "countryList": $scope.allCountryList,
                "isChildProfile": false,
            }
        });
    }

    $scope.GetParentalSettingsToUploadPicture = function () {
        var personId = $.cookie("personId");

        EditProfileService.GetParentalInformationForImage(personId).then(
            function (data) {
                if (data == true) {
                    $("#preview").removeAttr("disabled").removeClass("disabled");
                    $("#my-dropzone-form").removeAttr("disabled").removeClass("disabled");
                    $("#button-edit").show();
                    $("#my-dropzone-form").show();
                    $("#my-dropzone-form-image").show();
                } else {
                    $("#preview").attr("disabled", "disabled").addClass("disabled");
                    $("#my-dropzone-form").attr("disabled", "disabled").addClass("disabled");
                    $("#my-dropzone-form").hide();
                    $("#my-dropzone-form-image").hide();
                    $("#button-edit").hide();
                }
            },
            function (error) {
                genericErrorMessageDisplay();
            }
        );
    }

    $rootScope.$on('userModal-update', function (event, args) {
        $scope.userProfileDetailsForEdit = args.userProfileDetailsForEdit;
        $scope.updateSettingData();
    });

    $scope.updateSettingData = function () {
        EditProfileService.UpdateUserProfile($scope.userProfileDetailsForEdit).then(
            function (data) {
                $("#editProfileModal").modal("hide");
                $scope.getUserProfileDetails();
                genericSuccessMessageDisplay(Resources.SuccessfulYourPersonalDetailsAreSaved);
            },
            function (error) {
                genericModalErrorDisplayMessage(Resources.EditChildProfile_Failed, "edit-profile-failure-msg");
            }
        );
        $scope.userProfileDetailsForEdit = '';
    }

    $scope.updateUserPicture = function () {
        $scope.personImage = $('#editPersonImage').find('.demoImg').attr('src');
        var request = {            
            profilePictureData: $scope.personImage,
        };

        EditProfileService.UpdateUserPicture(request).then(
            function (data) {
                $("#personImageHeader").attr("src", $scope.personImage);
                $scope.personImage = $scope.personImage;

                genericSuccessMessageDisplay(Resources.SuccessfulYourPersonalDetailsAreSaved);
            },
            function (error) {
               // genericErrorMessageDisplay();
            }
        );
    }

    //$scope.deleteUserPicture = function () {
    //    $scope.personImage = images.defaultPersonImage;

    //    var personId = $.cookie("personId");
    //    var childId = $.cookie("childId");

    //    var request = {
    //        PersonId: personId,
    //        ChildId: childId,
    //        IsUserSettings: $scope.getUserSettingsEntryPoint()
    //    };

    //    EditProfileService.DeleteUserPicture(request).then(
    //        function (data) {
    //            genericSuccessMessageDisplay();
    //        },
    //        function (error) {
    //            genericErrorMessageDisplay();
    //        }
    //    );
    //}

   
    $scope.GetLanguagePreference = function () {
        var personId = $.cookie("personId");

        EditProfileService.GetLanguagePreference(personId).then(
            function (data) {
                if (data != null) {
                    $scope.selectedLanguage = data;
                } else {
                    $scope.selectedLanguage = currentLanguage;
                }
            },
            function (error) {
                genericErrorMessageDisplay();
            }
        );
    }

    //Directive is not updating the scope variable hence setting the value manually
    $scope.updateLanguage = function () {
        $scope.selectedLanguage = angular.element("#selCountry").selectpicker('val');
    }

    $scope.SaveLanguagePreference = function () {
        var personId = $.cookie("personId");
        var language = $scope.selectedLanguage;

        EditProfileService.SaveLanguagePreference(personId, language).then(
            function (data) {
                $.cookie("language", $scope.selectedLanguage, { path: "/" });
                var url = window.location.toString();
                window.location = url.replace(/en|fr|nl/, $scope.selectedLanguage);
            },
            function (error) {
                genericErrorMessageDisplay();
            }
        );
    }

    $scope.GetAllDocuments = function () {
        var personId = $.cookie("personId");
        $scope.docInfo = [];
        EditProfileService.GetMandateDocument(personId).then(
            function (data) {
                if (data != null && data.length > 0) {
                    $scope.hasManateDocument = true;
                }
            },
            function (error) {
               
                if (error.status == 404) {
                    $scope.hasNoRecurrentPayement = true;
                }
                else {
                    genericErrorMessageDisplay();
                }
            }
        );
    }

    $scope.downloadDoc = function (document) {
        var personId = $.cookie("personId");
        var webApiResponse = EditProfileService.DownloadMandateDocument(personId).then(
            function (data) {                    
                    if (data != undefined) {
                        window.open(data);
                    }
                 },
                function (error) {
                    genericErrorMessageDisplay();
            });
    }

    $scope.getAllCountriesList = function () {
        EditProfileService.GetAllCountries().then(
            function (data) {
                var countryArray = [];
                $scope.allCountryList = [];
                for (i = 0; i < data.Result.length; i++) {
                    $scope.allCountryList.push(data.Result[i]);
                }

            },
            function (error) {
            }
        );
    };
}]);