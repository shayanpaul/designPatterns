﻿childPage.controller("addParentController", ["$scope", "$rootScope", "$filter", "EditProfileService", "InvitationService", "ChildProfileService", "WebApiService", "savingSchoolService", "DisplaySupportersService", "$window", "ModalFactory", "utilityFactory", function ($scope, $rootScope, $filter, EditProfileService, InvitationService, ChildProfileService, WebApiService, savingSchoolService, DisplaySupportersService, $window, ModalFactory, utilityFactory) {
    $scope.newNameregex = newnameRegex;
    $scope.isAValidEmailID = false;
    $scope.iConfirmParent = true;

    $rootScope.$on('deleteParent-started', function (event, args) {
        $scope.adminNickName = args.any.adminNickName;
        $scope.delfirstName = args.any.firstName;
        $("#deleteParentConfirmModal").modal("show");
    });
    $scope.DeleteAdmin = function () {
        $rootScope.$broadcast('deleteParent-confirm');
    };

    $scope.validEmail = function () {
        var resultEmailval = utilityFactory.validEmail($scope.email);
        $scope.inputAdminEmail = resultEmailval[0];
        $scope.isAValidEmailID = resultEmailval[1];

    }
    $scope.removeErrorStyle = function () {
        $scope.isAValidEmailID = false;
        $scope.inputAdminEmail = {
            "required": false,
            "pattern": false
        };
    }
    $scope.SaveAdminForChild = function (firstName, lastName, nickName, adminEmail) {
        var callService = true;
        
        if (callService) {
            var invitationMessageViewModel = {
                invitedFirstName: firstName,
                invitedLastName: lastName,
                invitedNickName: nickName,
                inviterEmail: adminEmail,
            };
            var postData = {
                invitationMessageViewModel: invitationMessageViewModel,
                ParentId: $scope.personId,
                selectedChildId: $.cookie("childId"),
                invitationId: 0,
                cultureCode: $scope.language,
            }
            $("#saveAsParent").attr("disabled", "disabled");
            $("#saveAsParent").addClass("disabled");
            InvitationService.PostInvitedAdminDetail(postData).then(
                function (data) {
                    $("#addParentModal").modal("hide");
                    $scope.ResetAdminForChild();
                    $rootScope.$broadcast('addParent-confirm');
                },
                function (error) {
                    if ($scope.languageCulture.toUpperCase() === languages.languageFR) {
                        genericModalErrorDisplayMessage(failedAdminInvitation_fr, "add-admin-failure-msg");
                    }
                    if ($scope.languageCulture.toUpperCase() === languages.languageNL) {
                        genericModalErrorDisplayMessage(failedAdminInvitation_nl, "add-admin-failure-msg");
                    }
                    if ($scope.languageCulture.toUpperCase() === languages.languageEN) {
                        genericModalErrorDisplayMessage(failedAdminInvitation_en, "add-admin-failure-msg");
                    }
                }
            );
        }
    };
    $scope.ResetAdminForChild = function (firstName, lastName, nickName, adminEmail) {
        $scope.iConfirmParent = true;
        $("#inputAdminFirstName").val("");
        $("#inputAdminLastname").val("");
        $("#inputAdminNickName").val("");
        $("#inputAdminEmail").val("");
        $scope.firstName = "", $scope.lastName = "", $scope.nickName = "", $scope.adminEmail = "";
        $scope.addParentform.$setPristine();
        $scope.addParentform.$setUntouched()
        $("#emailFieldAdmin").removeClass("error");
        $("#firstNameAdmin").removeClass("error");
        $("#lastNameAdmin").removeClass("error");
        $("#nickNameAdmin").removeClass("error");
        $("#emailFieldAdmin").removeClass("errornew");
        $("#firstNameAdmin").removeClass("errornew");
        $("#lastNameAdmin").removeClass("errornew");
        $("#nickNameAdmin").removeClass("errornew");
        $("#iConfirmParent").prop("checked", false);
    };
    $("#iConfirmParent").change(function () {
        //ValidateEditProfileAdminUserFields();
        if ($("#iConfirmParent").is(":checked")) {
            $scope.iConfirmParent = false;
        }
        else {
            $scope.iConfirmParent = true;
        }
        $scope.$apply();
    });
}]);