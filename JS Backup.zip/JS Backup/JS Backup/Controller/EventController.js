﻿//var eventmodelModule = angular.module("eventmodelModule", ["formsModule"]);

eventmodelModule.controller("eventmodalController", ["$scope","$http", "$rootScope","FactoryHelper", "$stateParams", "ChildProfileService", 'EventService', "WebApiService", function ($scope,$http, $rootScope,FactoryHelper, $stateParams, ChildProfileService, EventService, WebApiService) {
    $scope.eventModalVisible = false;
    $scope.showAddButton = true;
    $scope.showCloseButton = false;
    $scope.nameRegexp = nameRegex;
    $scope.emailRegexp = emailRegex;
    $scope.ifcratechildselected = true;
    $scope.eventImage = "";
    $scope.supporterIdList = [];
    $scope.NonRegSupporterInfoList = [];
    $scope.NonSupporterInfo = {};
    $scope.noSupporterSelected = false;
    //$scope.selectedProjectList = {};
    var imageIdarrayforService = [];
    var images, isEventCreatedByChild;
    $scope.isAValidEmailID = false;
    $scope.inputEventEmail = {
        "required": false,
        "pattern": false
    };
    $('#txtEventDate').inputmask('FilterDate');
    $(document).bind("FileuploadCancelled", function (e, status) {
        $scope.uploadpicSuceess = true;
    });
   
    var isCreatedByChild = $stateParams.childEntry;

    $scope.getAllProjectsByChildAdd = function (childId) {
        $scope.selectedchildidforevent = childId;
        imageIdarrayforService = [];
        
            if (!$scope.$$phase) {
                $scope.$apply();
            }
      
        getChildProjectById(childId);
    };

    $scope.showChildProject = function (id) {
        if (id != "undefined") {
            getChildProjectById(id);
        }               
    };

    $scope.hideChildProject = function (id) {
        $("#displayChildProject" + id).hide();
    };

    function getChildProjectById(id) {
        ChildProfileService.getChildProjectById(id).then(
            function (data) {
                $scope.transInfo = {};
            $scope.transHisData = [];
                if (!$scope.isEditEventPage) {
            $scope.selectedProjectList = [];
                }

                $scope.transHisData = data;

                if($scope.isEditEventPage)
                {
                    if ($scope.selectedProjectList != null) {
                        if ($scope.selectedProjectList.length > 0) {
                            $("#childProject" + data.SelectedChildId).css("display", "block");
                            

                            setTimeout(function () {
                                for (var i = 0; i < $scope.selectedProjectList.length; i++) {
                                    $("#dino" + $scope.selectedProjectList[i]).prop("checked", true);
                                }
                            }, 500);
                        }
            }
            }
                
            },
            function (error) {
    }
        );
    }

    $scope.getImageid = function (event) {
        if ($scope.selectedProjectList.length > 0 && $scope.isEditEventPage) {
            var projId = event.target.id;
            var strchildId = "dino";
            var projectID = parseInt(projId.replace(strchildId, ""));
            if ($.inArray(projectID, $scope.selectedProjectList) != -1) {
                $("#" + projId).prop("checked", false);
                $scope.selectedProjectList.splice($.inArray(projectID, $scope.selectedProjectList), 1);
            } else if ($.inArray(projectID, $scope.selectedProjectList) == -1) {
                $scope.selectedProjectList.push(projectID)
                $("#" + event.target.id).prop("checked", true);
            }

        } else {
            if (imageIdarrayforService.length !== 0 && !$scope.isEditEventPage) {
                var countofId = 0;
                for (var i = 0; i < imageIdarrayforService.length; i++) {
                    if (imageIdarrayforService[i] == event.target.id) {
                        imageIdarrayforService.splice(i, 1);
                        countofId++;
                        break;
                    }
                }
                if (countofId === 0) {
                    $("#" + event.target.id).prop("checked", true);
                }
            } else {
                $("#" + event.target.id).prop("checked", true);
            }
            var projId = event.target.id;
            var strchildId = "dino";
            var projectID = parseInt(projId.replace(strchildId, ""));
            if ($.inArray(projectID, $scope.selectedProjectList) != -1) {
                $("#" + projId).prop("checked", false);
                $scope.selectedProjectList.splice($.inArray(projectID, $scope.selectedProjectList), 1);
            } else if ($.inArray(projectID, $scope.selectedProjectList) == -1) {
                $scope.selectedProjectList.push(projectID)
                $("#" + event.target.id).prop("checked", true);
            }
        }
       
    };

    $scope.EventModalClosed = function () {
        $scope.ifcratechildselected = false;

        if ($scope.isEditEventPage = false) {
            $("#childProject" + $scope.selectedchildidforevent).css("display", "none");
            $("#eventModal input").prop("checked", false);
        }
       
        $scope.dateFiledTextBox = false;
            $("#createevent").show();
            $("#btneventcontribute").show();
            $("#childBlock .child-group").show();
            $("#wrapper #divHideFirst").show();
        }

    $scope.SelectRegSupporter = function (supporterID) {
        if ($("#check" + supporterID).prop("checked") && ($scope.NonRegSupporterInfoList.length > 0 || $scope.supporterIdList.length > 0)) {
            $scope.noSupporterSelected = false;
        } else if (!$("#check" + supporterID).prop("checked") && $scope.NonRegSupporterInfoList.length == 0 && $scope.supporterIdList.length == 0) {
            $scope.noSupporterSelected = true;
        }
    }

    $scope.AddNonRegisteredSupporter = function () {
        $scope.showAddButton = true;
        $scope.showCloseButton = false;
        $scope.noSupporterSelected = false;
        
        $scope.nonregsupporterdisplay = true;
        if ($scope.modelNonUserEmail != $rootScope.PersonEmail)
        {
            if (images != null) {
            $scope.NonSupporterInfo.supporterImage = images.defaultPersonImage;
            }
            $scope.NonSupporterInfo.NonRegSupporterFirstName = $scope.modelNonUserFirstName;
            $scope.NonSupporterInfo.NonRegSupporterLastName = $scope.modelNonUserLastName;
            $scope.NonSupporterInfo.NonRegSupporterNickName = $scope.modelNonUserNickName;
            $scope.NonSupporterInfo.NonRegSupporterUserEmail = $scope.modelNonUserEmail;
            $scope.NonSupporterInfo.SelectedRelation = $scope.relationshipsel;
            $('#invitesomeonelse').hide();

        if (typeof (nonsopporterid) == "undefined")
            nonsopporterid = 1;
        else
            nonsopporterid = nonsopporterid + 1;
        $scope.NonSupporterInfo.supporterID = "N" + nonsopporterid;
        $scope.NonRegSupporterInfoList.push($scope.NonSupporterInfo);

        $scope.NonSupporterInfo = {
        };
        $scope.NonRegSelectedSupporterIdList = [];
        $scope.NonRegSelectedSupporterIdListNew = [];
        var lengthOfNonRegSupporter = $scope.NonRegSupporterInfoList.length;
        for (var i = 0; i < lengthOfNonRegSupporter; i++) {
            var supporterId = $scope.NonRegSupporterInfoList[i].supporterID;
            $scope.NonRegSelectedSupporterIdList.push(supporterId);
            $scope.NonRegSelectedSupporterIdListNew.push(supporterId);
        }
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        $("#invitesomeonelse input").val("");
        $("#drpNonUserRelationship ").selectpicker("val", "");
        $("#invitesomeonelse").hide();
        $(".invite-other").removeClass("invite-other-expand");
    }
        else {
            $("#eventModal").scrollTop(0);
            genericModalErrorDisplayMessage(Resources.SupporterInvitationAsParent_Failed, "event-failure-msg");
        }
}

    $scope.deleteNonSupporterDetails = function (index) {
        var supporter = $scope.NonRegSupporterInfoList[index].supporterID;
        $scope.NonRegSupporterInfoList.splice(index, 1);
        if ($scope.NonRegSupporterInfoList.length == 0 && $scope.supporterIdList.length == 0) {
            $scope.noSupporterSelected = true;
        }
        $.each($scope.NonRegSelectedSupporterIdList, function (i) {
            if ($scope.NonRegSelectedSupporterIdList[i] == supporter) {
                $scope.NonRegSelectedSupporterIdList.splice(i, 1);
            }
        });
        $.each($scope.NonRegSelectedSupporterIdListNew, function (i) {
            if ($scope.NonRegSelectedSupporterIdListNew[i] == supporter) {
                $scope.NonRegSelectedSupporterIdListNew.splice(i, 1);
            }
        });
    }

    $scope.showForParent = true;
    $rootScope.$on('eventModal-started', function (event, args) {
        $("#eventModal input").prop("checked", false);
        $scope.eventSubmit = true;
        $scope.eventApprove = false;
        $scope.isSTExceedLmt = args.any.isSTExceedLmtSendfromChild;
        $scope.ChildFirstName = args.any.childFirstName;
        $scope.shortTermAmount = args.any.shortTermAmount;

        if (args.any.isEventCreatedByChild) {
            $scope.showinviteSupporterModalControllerForParent = false;
        }
        if (args.any.clickEvent) {
            args.any.clickEvent.stopImmediatePropagation();
        }
        if (args.any.editevent) {
            $scope.isEventCreatedByChild = args.any.isEventCreatedByChild;
            $scope.isEditEventPage = true;
            if (args.any.isApprove == true) {
                $scope.selectedchildidforevent = args.any.selectedChildId;
                $scope.isApproveEventPage = true;
                $scope.eventSubmit = false;
                $scope.eventApprove = true;
            }
           // $scope.GroupInfoList = args.any.groupinfoList;
            $scope.SupporterInfoList = args.any.SupporterInfoList;
            images = args.any.images;
            var data = args.any.data;
            $scope.childNameForEvent = data.ChildName;
            $("#eventModal").find(".error").removeClass("error");
            $("#eventModal").find(".errornew").removeClass("errornew");
            $scope.eventForm.$setPristine();
            $scope.eventForm.$setUntouched();
            $("#eventModal div").removeClass("error");
            $("#eventModal div").removeClass("errornew");
            var text = $("#childBlock .child-main .child-name-div").text();
            var anyeventimage = {
                selector: "eventUploadPicture"
            }
            $scope.ifcratechildselected = true;

            if ($scope.isApproveEventPage == true) {
                $scope.eventactiontype = "APPROVEEVENT";
                $("#eventModal .modal-title").text($scope.childNameForEvent + "-" + Resources.ApproveRejectInvitationForAnEvent);
            }
            else {
            $scope.eventactiontype = "EDITEVENT";
                $("#eventModal .modal-title").text($scope.childNameForEvent + " - " + Resources.EditInvitationForAnEvent);
            }
            $("#invitesomeonelse").hide();
            $(".invite-other").removeClass("invite-other-expand");

            $scope.eventId = data.EventId;
            $scope.eventModalVisible = true;
            $scope.existingEventData = data;
            $scope.eventMessage = data.EventMessage;
            $scope.eventTitle = data.EventName;
            $scope.supporterIdList = data.SelectedSupportedList;
            $scope.NonRegSupporterInfoList = data.NonSupporterUser;
            if ($scope.NonRegSupporterInfoList.length>0)
            {
                $scope.nonregsupporterdisplay = true;
            }
            $scope.selectedchildidforevent = data.SelectedChildId;
            $scope.NonRegSelectedSupporterIdList = [];
            $scope.NonRegSelectedSupporterIdListNew = [];

            for (var item = 0; item < data.NonSupporterUser.length; item++) {
                $scope.NonRegSupporterInfoList[item].supporterImage = images.defaultPersonImage;
                $scope.NonRegSupporterInfoList[item].supporterID = "N" + item
                $scope.NonRegSelectedSupporterIdList.push("N" + item);
                $scope.NonRegSelectedSupporterIdListNew.push("N" + item);
            }

            if ($scope.NonRegSupporterInfoList.length > 0)
                $scope.nonregsupporterdisplay = true;
            else
                $scope.nonregsupporterdisplay = false;

            $scope.eventPlace = data.EventPlace;
            $scope.selectedEventDate = new Date(data.EventDate);
            $scope.selectedProjectList = data.SelectedProjectList;
            if ($scope.selectedProjectList == null) {
                $scope.selectedProjectList = [];
            }
                   
            $scope.getAllProjectsByChildAdd($scope.selectedchildidforevent);
            $scope.eventImage = data.EventPictureUrl;
            $("#eventModal").find(".error").removeClass("error");
            $("#eventModal").find(".errornew").removeClass("errornew");
            $scope.eventForm.$setPristine();
            $scope.eventForm.$setUntouched();
            $("#eventModal div").removeClass("error");
            $("#eventModal div").removeClass("errornew");
            $scope.dateFiledTextBox = false;
            $scope.ifcratechildselected = false;
        }
        else {
            $scope.childFirstName = args.any.childFirstName;
            $scope.isEventCreatedByChild = args.any.isEventCreatedByChild;
          //  $scope.GroupInfoList = args.any.groupinfoList;
            $scope.SupporterInfoList = args.any.SupporterInfoList;
            images = args.any.images;
            if($scope.isEventCreatedByChild){
                $scope.ifcratechildselected = false;
            } else {
            $scope.ifcratechildselected = true;
            }
            
            $scope.isEditEventPage = false;
            $scope.nonregsupporterdisplay = false;
            $scope.eventactiontype = "CREATEEVENT";

            $scope.modelNonUserFirstName
            $scope.modelNonUserLastName = "";
            $scope.modelNonUserNickName = "";
            $scope.modelNonUserEmail = "";
            $scope.relationshipsel = "";
            //$("#drpNonUserRelationship").val("select");
            if (!$scope.isEventCreatedByChild) {
                $("#eventModal .modal-title").text($scope.childFirstName + " - " + Resources.InvitationForAnEvent);
            }
            $scope.eventTitle = "";
            $scope.eventMessage = "";
            $scope.eventPlace = "";
            $scope.selectedEventDate = null;
            $scope.NonRegSupporterInfoList.length = 0;
            $scope.NonRegSelectedSupporterIdList = [];
            $scope.NonRegSelectedSupporterIdListNew = [];
            $scope.eventImage = null;
            $scope.supporterIdList.length = 0;
            $scope.selectedchildidforevent = 0; //$.cookie("childId"); //$scope.id;
            $("#invitesomeonelse").hide();
            $(".invite-other").removeClass("invite-other-expand");
           
            if ($('html').hasClass('touch')) {
                $("#btneventcontribute").hide();
                $("#childBlock .child-group").hide();
                $("#wrapper .child-dropdown-button").attr("style", "display: none !important");
                $("#wrapper #divHideFirst").hide();
            }
            else {
                $("#btneventcontribute").show();
                $("#childBlock .child-group").show();
                // $("#wrapper .child-dropdown-button").attr("style", "display: block !important");
                $("#wrapper #divHideFirst").show();
            }

            $("#eventModal div").removeClass("error");
            $("#eventModal div").removeClass("errornew");
            $("#eventModal").find(".error").removeClass("error");
            $("#eventModal").find(".errornew").removeClass("errornew");
            $scope.dateFiledTextBox = false;
            $scope.eventModalVisible = true;
            setTimeout(function () { 
                $("#eventModal input").prop("checked", false);
                $scope.eventImage = null;

                $scope.selectedchildidforevent = $stateParams.childId;
                $scope.getAllProjectsByChildAdd($stateParams.childId);
            }, 500);

            $('#eventModal').modal('show');

        }

        setTimeout(function () {
            $(".event-project-select").each(function () {

                var timeout;
                var element = $("#" + $(this).attr("for"));

                $(this).on("click", function () {
                    timeout = setTimeout(function () {
                        element.click();
                    }, 100);
                });

                element.on("click", function () {
                    clearTimeout(timeout);
                });

            });
        }, 1000); 
    });

    $scope.openInviteOtherBlock = function () {
        if ($scope.showAddButton == false && $scope.showCloseButton == true) {
            $scope.showAddButton = true;
            $scope.showCloseButton = false;
        } else {
            $scope.showAddButton = false;
            $scope.showCloseButton = true;
        }        
        $scope.DefaultRelationship();
        $scope.modelNonUserFirstName = "";
        $scope.modelNonUserLastName = "";
        $scope.modelNonUserNickName = "";
        $scope.modelNonUserEmail = "";
        $scope.relationshipsel = "";
     
        $(this).parent().toggleClass("invite-other-expand");        
    };
    $scope.cancelNonRegisteredSupporter = function () {
        $scope.showAddButton = true;
        $scope.showCloseButton = false;
    }

    $(".evnt-timeline-home").click(function () {
        $("#childEventDetails").animate({
            "right": "-1053px"
        });
        $("#childEventHomePage").show();
    });
    $scope.DefaultRelationship = function () {
        ChildProfileService.DefaultRelationship().then(
            function (data) {
            var result = [];
            for (var i in data)
                result.push({
                    id: i,
                    name: data[i]
                });
            $scope.defaultRelationship = result;
            },
            function (error) {
            }
        );
    }

    $scope.sendEventInvitation = function (supporterIdList, selectedchildidforevent, childProject, selectProjectList, eventId) {
        if (!$('#eventForm').valid()) {
            $('#eventForm').valid();
            return;
        } else if (supporterIdList.length == 0 && $scope.NonRegSelectedSupporterIdList.length == 0) {
            $scope.noSupporterSelected = true;
            return false;
        } else if ($("#invitesomeonelse").is(":visible")) {
            $("#addnonregsupporter").trigger("click");
        }
        else {
        //eventPicture = uploadEventPicture();
        var NonRegSelectedSupporterInfoList = [];
        
        for (var index = 0; index < $scope.NonRegSupporterInfoList.length; index++) {
            var selectedindex = jQuery.inArray($scope.NonRegSupporterInfoList[index].supporterID, $scope.NonRegSelectedSupporterIdList);
            if (selectedindex > -1) {
                NonRegSelectedSupporterInfoList.push($scope.NonRegSupporterInfoList[index]);
            }
        }

        var NonSupporterUser = $scope.NonRegSupporterInfoList;
        var selectedProjectList = [];
        
        selectedProjectList = imageIdarrayforService;
        if (selectProjectList != null && selectProjectList.length > 0) {
            selectedProjectList = selectProjectList;
            childProject = true;
        }

        var eventInfo = {};
        if ($scope.eventactiontype == "CREATEEVENT") {
            eventInfo = {};
            eventInfo.IsUpdate = false;
        } else {
            eventInfo = $scope.existingEventData;
            eventInfo.IsUpdate = true;
        }
        //eventInfo.EventName = eventName;
        eventInfo.EventName = $scope.eventTitle;
        eventInfo.DateOfEvent = FormatDate($scope.selectedEventDate);
        eventInfo.EventDate = $scope.selectedEventDate;
        //eventInfo.EventPicture = eventPicture;
        eventInfo.EventPicture = $scope.eventImage;
        if (eventInfo.EventPicture != null) {
            if (eventInfo.EventPicture.substring(0, 4) == 'data') {
                var array = eventInfo.EventPicture.split(",");
                eventInfo.EventPicture = array[1];
            }
        }
        eventInfo.EventPlace = $scope.eventPlace;
        eventInfo.EventMessage = $scope.eventMessage;
        eventInfo.SelectedSupportedList = supporterIdList;
        eventInfo.SelectedChildId = selectedchildidforevent;
        eventInfo.ParentId = $.cookie("personId");
        eventInfo.ShowProject = childProject;
        eventInfo.NonSupporterUser = NonRegSelectedSupporterInfoList;
        eventInfo.SelectedProjectList = selectedProjectList;
        eventInfo.IsCreatedByChild = $scope.isEventCreatedByChild;
        if ($scope.eventactiontype == "APPROVEEVENT") {
            eventInfo.EventId = $scope.eventId;
            EventService.ApproveEventInvitation(eventInfo).then(
                function (data) {
                    $scope.eventModalVisible = false;
                    genericSuccessMessageDisplay(Resources.CreateEvent_Success);
                    $rootScope.$broadcast('refresh-timeline', {});
                    $scope.EventInvitationResponse = data;
                 //   $scope.RefreshEventDetails();
                    $rootScope.$broadcast('onEventSuccess');
                },
                function (error) {
                    var eventModalState = $("#createOrEditEvent").val();
                    if (eventModalState == "createEvent") {
                        genericModalErrorDisplayMessage(Resources.CreateEvent_Failed, "event-failure-msg");
                    }
                    if (eventModalState == "editEvent") {
                        genericModalErrorDisplayMessage(Resources.EditEvent_Failed, "event-failure-msg");
                    }
                }
            );
        }
        else {
        //eventInfo.NowProjectViewModel = selectedProjectList;
        EventService.SendEventInvitation(eventInfo).then(
            function (data) {
                $scope.eventModalVisible = false;
                genericSuccessMessageDisplay(Resources.CreateEvent_Success);
                $scope.EventInvitationResponse = data;
              //  $scope.RefreshEventDetails();
                    $rootScope.$broadcast('onEventSuccess');
            },
            function (error) {
                var eventModalState = $("#createOrEditEvent").val();
                if (eventModalState == "createEvent") {
                    genericModalErrorDisplayMessage(Resources.CreateEvent_Failed, "event-failure-msg");
                }
                if (eventModalState == "editEvent") {
                    genericModalErrorDisplayMessage(Resources.EditEvent_Failed, "event-failure-msg");
                }
            }
        );
        }

        if ($('html').hasClass('touch')) {
            $("#createevent").show();
            $("#btneventcontribute").show();
            $("#childBlock .child-group").show();
            $("#wrapper #divHideFirst").show();
        }
        else {
            $("#createevent").show();
            $("#btneventcontribute").show();
            $("#childBlock .child-group").show();
            $("#wrapper #divHideFirst").show();
        }
    }
}

    $scope.rejectInvitation = function (selectedchildidforevent, eventId) {
        var url = "/parent/" + $.cookie("personId") + "/events/" + eventId + "/child/" + selectedchildidforevent;
      //  var eventUrl = baseUrl + url;

        FactoryHelper.CallApiPost(url).then(
            function (data) {
                $rootScope.$broadcast('refresh-timeline', {});
            },
            function (error) {
            }
        );
    }

    
    angular.element("#eventModal").on("hidden.bs.modal", function () {
        $scope.showAddButton = true;
        $scope.showCloseButton = false;
    });

}]);