﻿/*global $, jQuery, alert, window*/
/*jslint browser: true*/
/*jslint white:true, for:true */
//myAppangular.filter("sumOfValue", function () {
//    return function (data, key) {
//        if (angular.isUndefined(data) && angular.isUndefined(key)) {
//            return 0;
//        }
//        var sum = 0;
//        angular.forEach(data, function (value) {
//            sum = sum + parseInt(value[key]);
//        });
//        return sum;
//    };
//});

myAppangular.controller("paymentController", ["$scope", "$filter", "$state", "$stateParams", "WebApiService", "paymentService", "$window", "FormSubmitter", "$rootScope", "ChildProfileService", "gemaltoFactory", "EditProfileService", function ($scope, $filter, $state, $stateParams, WebApiService, paymentService, $window, FormSubmitter, $rootScope, ChildProfileService, gemaltoFactory, EditProfileService) {
    $scope.childId = $.cookie("childId");
    if (eidSwitch == true) {
        $scope.eidSwitch = true;
    }
    if ($stateParams.obj) {
        $scope.contributeCond = $stateParams.obj.hideContributeView;
    }
    $scope.$watch("Eid.front", function () {
        if ($scope.reader == "picture" && $scope.Eid.front != "" && $scope.Eid.back !== "") {
            $scope.noPictureUploaded = false;
        } else {
            $scope.noPictureUploaded = true;
        }
    });

    $scope.$watch("Eid.back", function () {
        if ($scope.reader == "picture" && $scope.Eid.front != "" && $scope.Eid.back !== "") {
            $scope.noPictureUploaded = false;
        } else {
            $scope.noPictureUploaded = true;
        }
    });

    var ProofOfIdentity = [{
        "Barcode": "",
        "ChildId": 0,
        "ExpiryDate": "",
        "IdentityProofNumber": "",
        "Image": "",
        "ImageBase64": [],
        "ImageBase64ForSingleImage": "",
        "ImageForSingleImage": "",
        "ImageName": "BackImage",
        "ImageTypeCode": 2,
        "ImageUri": "",
        "IsUserSettings": "",
        "PersonId": parentID,
        "PersonDateOfBirth": ""
    }, {
        "Barcode": "",
        "ChildId": 0,
        "ExpiryDate": "",
        "IdentityProofNumber": "",
        "Image": "",
        "ImageBase64": [],
        "ImageBase64ForSingleImage": "",
        "ImageForSingleImage": "",
        "ImageName": "FrontID",
        "ImageTypeCode": 3,
        "ImageUri": "",
        "IsUserSettings": "",
        "PersonId": parentID,
        "PersonDateOfBirth": ""
    }];

    $scope.Eid = {
        "front": "",
        "back": ""
    };

    $scope.allCountryList = [];

    $scope.getAllCountriesList = function () {
        EditProfileService.GetAllCountries().then(
            function (data) {
                var countryArray = [];
                $scope.allCountryList = [];
                for (i = 0; i < data.Result.length; i++) {
                    $scope.allCountryList.push(data.Result[i]);
                }
            });
    };

    $scope.cityDropDownChange = function (CityZipCode) {
        if (CityZipCode) {

            var cityList = $scope.cityListToDisplay;
            $.each(cityList, function () {
                if (this.Id == CityZipCode) {
                    $scope.accountHolderCity = this.Name;
                    $scope.accountHolderZipCodeId = CityZipCode;
                }
            });
        }
    };

    $scope.getCitybyZip = function (zip) {
        if (zip) {
            EditProfileService.GetCityZipCode(zip).then(
                            function (data) {
                                if (!data || !data.Result || !data.Result.City || data.Result.City.length > 0) {
                                    $scope.accountHolderZipCode = data.Result.ZipCode;
                                    $scope.accountHolderCity = '';
                                }
                                $scope.cityListToDisplay = data.Result.City;

                                if ($scope.cityListToDisplay.length > 1) {
                                    $scope.cityDropDown = true;
                                    for (var i = 0; i < $scope.cityListToDisplay.length; i++) {
                                        $scope.cityListToDisplay[i].Id = $scope.cityListToDisplay[i].Id.toString();
                                        if ($scope.cityListToDisplay[i].Id.toString() === $scope.accountHolderZipCodeId.toString()) {
                                            $scope.accountHolderCity = $scope.cityListToDisplay[i].Name;
                                            if (!$scope.$$phase) {
                                                $scope.$apply();
                                            }
                                        }
                                    }
                                } else {
                                    $scope.cityDropDown = false;
                                    if ($scope.cityListToDisplay[0]) {
                                        $scope.accountHolderCity = $scope.cityListToDisplay[0].Name;
                                        $scope.accountHolderZipCodeId = $scope.cityListToDisplay[0].Id;
                                    }
                                }
                            },
                            function (error) {
                                $scope.accountHolderZipCode = '';
                                $scope.accountHolderZipCodeId = '';
                                $scope.accountHolderCity = '';
                            }
            );
        }
    };

    $scope.basketToPaymentOneShot = function (contributionData) {
        $scope.contributeCond = false;
        $scope.contributionObj = contributionData;//data.any.contributionData;
        $scope.checkPaymentDetail(OneShot, null, $scope.contributionObj);

        $scope.updateOne = true;
        $scope.showRecPrem = false;
        $scope.hideModifyPayment = false;
        $scope.showMakePayment = false;
        $scope.showNextDueDate = false;

        $scope.childNameOnModify = false;
        $scope.childDropdown = false;
        $scope.showChooseYourChild = false;
        $("#isUpdate").val("true");
        $("#proceedToPayment").hide();
        var saveToBasketText = $("#saveToBasketText").val();
        $("#addToBasket").text(saveToBasketText);

        $scope.enableAddtobasket = true;
        //$("#select-option-groups").selectpicker("val", contributionData.ChildView.PersonId);

        $scope.modifiedChildId = contributionData.ChildView.PersonId;
        $scope.SelectedChildName = contributionData.ChildView.PersonFirstName;
        if (contributionData.ChildView.PersonImageUrl != null) {
            $scope.IndInfo.imagePath = contributionData.ChildView.PersonImageUrl;
        }
        else {
            $scope.IndInfo.imagePath = images.defaultPersonImage;
        }
        $scope.modifiedChildId = contributionData.ChildView.PersonId;

        $scope.SelectedChildFirstName = contributionData.ChildView.PersonFirstName;
        if (contributionData.LongTermPlanView != null) {
            $scope.maxValueLT = contributionData.LongTermPlanView.MaxValue;
            $scope.minValueLT = contributionData.LongTermPlanView.MinValue;
            $scope.planId = contributionData.LongTermPlanView.PlanId;
            $scope.longTermPlanId = contributionData.LongTermPlanView.PlanId;
            $scope.longTermPlanType = contributionData.LongTermPlanView.PlanType;
            $scope.longOldAmount = contributionData.LongTermPlanView.OldAmount;
        }
        else {
            $scope.maxValueLT = 9999;
            $scope.minValueLT = 10;
        }
        if (contributionData.ShortTermPlanView != null) {
            $scope.maxValueST = contributionData.ShortTermPlanView.MaxValue;
            $scope.minValueST = contributionData.ShortTermPlanView.MinValue;
            $scope.planId = contributionData.ShortTermPlanView.PlanId;

            $scope.shortTermPlanId = contributionData.ShortTermPlanView.PlanId;
            $scope.shortTermPlanType = contributionData.ShortTermPlanView.PlanType;
            $scope.shortOldAmount = contributionData.ShortTermPlanView.OldAmount;
        }
        else {
            $scope.maxValueST = 2500;
            $scope.minValueST = 10;
        }
        if (contributionData.LongTermPlanView) {
            //for updating one shot

            $scope.hideLongTerm = false;

            $scope.longTermAmount = returnANumberWithoutFormating(contributionData.LongTermPlanView.OldAmount, currentLanguage);
        } else {
            $scope.hideLongTerm = true;
        }

        if (contributionData.ShortTermPlanView) {
            //for updating one shot
            $scope.hideShortTerm = false;
            $scope.shortTermAmount = returnANumberWithoutFormating(contributionData.ShortTermPlanView.OldAmount, currentLanguage);
        } else {
            $scope.hideShortTerm = true;
        }
        $scope.userMessage = contributionData.Message;
        $scope.isUpdate = true;
        $scope.contributionId = contributionData.ContributionId;
        $scope.SelectedChild = contributionData.ChildView.PersonId;
        $scope.oneShotSelected = true;
    }
    $scope.recurrentPicUpload = function () {
        $scope.disabledProceedToPayment = false;
        $scope.disabledAddToBasket = false;
        $scope.proofOfIdentityUploadOption = true;
        $('#nationalNumber').inputmask('TINNumber');
        $("#expDateId").aagjeDatePicker("remove");
        $("#expDateId").aagjeDatePicker({ minViewMode: 0 });
        initializeFormValidation($("#recurrentIdentificationForm"));
    }
    $scope.basketToPayment = function (recurrentData) {
        recurrent = recurrentData;//data.any.recurrentData;
        $scope.modifyRecurrentData = recurrentData;
        localStorage.setItem("contributeCond", false);
        localStorage.setItem("isContributionUpdate", true);
        $scope.PaymentMode = "RecurrentPayment";
        $scope.recurrentSelected = true;
        $scope.contributeCond = false;
        $scope.checkPaymentDetail(RecurrentPremium, recurrent, null);
        $scope.contributionObj = recurrent
        $scope.showNextDueDate = true;
        $scope.showRecPrem = true;
        $scope.showOneShot = false;
        $scope.childNameOnModify = false;
        $scope.childDropdown = false;
        $scope.hidePlanDetails = false;
        //$scope.confirmButton = true; //for modify confirm button will be visible
        $scope.hideIdentityDetails = true;//to hide upload identity for modify as per US
        $scope.hideContinueButton = true;
        $scope.hidePlanWhenShowingIdentityDetails = false;
        //$scope.hideRecButtons = false;
        $scope.recDeleteLT = true;
        $scope.recDeleteST = true;
        $scope.hideModifyPayment = false;
        $scope.showMakePayment = false;
        $scope.IndInfo.imagePath = images.defaultPersonImage;

        //
        $scope.maxValueLT = LONG_TERM.MAX_AMOUNT;
        $scope.minValueLT = LONG_TERM.MIN_AMOUNT;
        $scope.planId = VALUE.EMPTY;
        $scope.longTermPlanId = VALUE.EMPTY;
        $scope.longTermPlanType = VALUE.EMPTY;
        $scope.longOldAmount = VALUE.EMPTY;

        //
        $scope.maxValueST = SHORT_TERM.MAX_AMOUNT;
        $scope.minValueST = SHORT_TERM.MIN_AMOUNT;
        $scope.planId = VALUE.EMPTY;
        $scope.shortTermPlanId = VALUE.EMPTY;
        $scope.shortTermPlanType = VALUE.EMPTY;
        $scope.shortOldAmount = VALUE.EMPTY;
        $scope.recPhone = recurrent.PhoneNumber;
        if ($scope.recPhone) {
            angular.element("#mobilePhone").prop("disabled", true);
        }
        else {
            angular.element("#mobilePhone").prop("disabled", false);
        }
        // $("[id = 'contributeStartDate'], [id = 'contributeEndDate']").aagjeDatePicker('remove');

        if (!isEmptyOrUndefinedOrNull(recurrent)) {
            $scope.recurrentSelected = true;
            if (!isEmptyOrUndefinedOrNull(recurrent.ChildView.PersonImageUrl)) {
                $scope.IndInfo.imagePath = recurrent.ChildView.PersonImageUrl;
            }
            $scope.modifiedChildId = recurrent.ChildView.PersonId;
            $scope.SelectedChildName = recurrent.ChildView.PersonFirstName;
            $scope.recurrentId = recurrent.RecurrentPaymentId;

            $scope.accountHolderIbanNumber = recurrent.IbanAccountNumber;
            $scope.ContractEndDate = getDateInString(new Date(recurrent.ContractEndDate), DATE_FORMAT.DDMMYYYY, currentLanguage);
            if (!isEmptyOrUndefinedOrNull(recurrent.LongTermPlanView)) {
                $scope.maxValueLT = recurrent.LongTermPlanView.MaxValue;
                $scope.minValueLT = recurrent.LongTermPlanView.MinValue;
                $scope.planId = recurrent.LongTermPlanView.PlanId;
                $scope.longTermPlanId = recurrent.LongTermPlanView.PlanId;
                $scope.longTermPlanType = recurrent.LongTermPlanView.PlanType;
                $scope.longOldAmount = recurrent.LongTermPlanView.NewAmount;
            }
            if (!isEmptyOrUndefinedOrNull(recurrent.ShortTermPlanView)) {
                $scope.maxValueST = recurrent.ShortTermPlanView.MaxValue;
                $scope.minValueST = recurrent.ShortTermPlanView.MinValue;
                $scope.planId = recurrent.ShortTermPlanView.PlanId;

                $scope.shortTermPlanId = recurrent.ShortTermPlanView.PlanId;
                $scope.shortTermPlanType = recurrent.ShortTermPlanView.PlanType;
                $scope.shortOldAmount = recurrent.ShortTermPlanView.NewAmount;
            }
            $scope.hideLongTerm = BOOLEAN.FALSE;
            if (!isEmptyOrUndefinedOrNull(recurrent.LongTermPlanView) && recurrent.LongTermPlanExist) {
                var longTermAmount = parseInt(returnANumberWithoutFormating(recurrent.LongTermPlanView.NewAmount, currentLanguage)); //TODO Verify
                //$scope.hideLongTerm = BOOLEAN.TRUE;
                if (longTermAmount !== 0) {
                    //$scope.hideLongTerm = BOOLEAN.FALSE;
                    $scope.longTermAmount = longTermAmount;
                    $("#longTermAmount").val(longTermAmount);
                }
            }
            else {
                $scope.hideLongTerm = BOOLEAN.TRUE;
            }
            $scope.hideShortTerm = BOOLEAN.FALSE;
            if (!isEmptyOrUndefinedOrNull(recurrent.ShortTermPlanView) && recurrent.ShortTermPlanExist) {
                var shortTermAmount = parseInt(returnANumberWithoutFormating(recurrent.ShortTermPlanView.NewAmount, currentLanguage)); //TODO Verify
                //$scope.hideShortTerm = BOOLEAN.TRUE;
                if (shortTermAmount !== 0) {
                    //$scope.hideShortTerm = BOOLEAN.FALSE;
                    $scope.shortTermAmount = shortTermAmount;
                    $("#shortTermValue").val(shortTermAmount);
                }
            } else {
                $scope.hideShortTerm = BOOLEAN.TRUE;
            }

            $scope.userMessage = recurrent.Message;
            $scope.isUpdate = true;
            //  $scope.contributionId = recurrent.ContributionId;
            $scope.SelectedChild = recurrent.ChildView.PersonId;
            $scope.accountHolderFirstName = recurrent.AccountHolderFirstName;
            $scope.accountHolderLastName = recurrent.AccountHolderLastName;
            $scope.accountHolderIbanNumber = recurrent.IbanAccountNumber;

            var uniqueFrequency = [];
            $.each(recurrent.FrequencyView, function (index, value) {
                if (value.Id != 0) {
                    uniqueFrequency.push(value);
                }
            });

            $scope.accountNewFrequency = uniqueFrequency;
            $scope.value = recurrent.Frequency.toString();
            $scope.NextDueDate = recurrent.StartDate;
        }
        $scope.RecurrentPaymentViewMethod(recurrent, BOOLEAN.FALSE);
    } // End of Basket Method
    //codes for new child selection in contribution
    //$scope.childExpandedSectionLink = false;
    $scope.enableAddtobasket = true;
    $scope.recurrenttimesoption = "";
    $scope.enableProceedtoPayment = true;
    $scope.contributorId = $.cookie("personId");
    $scope.paymentDetail = {};
    $scope.showPaymentType = true;
    $scope.hideLongTerm = true;
    $scope.hideShortTerm = true;
    $scope.showOneShot = true;
    $scope.showRecPrem = true;
    $scope.hidePlanDetails = true;
    $scope.hidePaymentDetails = true;
    $scope.hideIdentityDetails = true;
    $scope.hideContinueButton = true;
    $scope.hideMessage = true;
    $scope.IndInfo.imagePath;
    $scope.hidePaymentStatus = true;
    $scope.hideContribution = true;
    $scope.paymentSucess = true;
    $scope.paymentError = true;
    $scope.SelectedChild;
    $scope.SelectedChildFirstName;
    $scope.hideOneShotButtons = true;
    $scope.hideRecButtons = true; //default true
    $scope.hideOneShotModifyButtons = true;
    $scope.showChooseYourChild = true;
    $scope.dateFiledaccountHolderStartDate = false;
    $scope.dateFiledaccountHolderEndDate = false;
    $scope.dateFiledaccountHolderStartDatevalue = "value";
    $scope.dateFiledaccountHolderEndDatevalue = "";
    $scope.recDeleteLT = false;
    $scope.recDeleteST = false;
    $scope.isDelete = false;
    //$scope.hidePaymentBasket = true;
    $scope.showAddToBasketMobile = true;
    $scope.showAddToBasket = true;
    $scope.hideContributionList = true;
    $scope.hideAddCheck = true;
    $scope.hideBasketDetails = true;
    /// $scope.hideEmptyBasket = true;
    $scope.hideOneShotConfirmation = true;
    $scope.hidePaymentOption = true;
    $scope.hideDeleteRecurrent = true;
    $scope.hideAddToBasketPopUp = true;
    $scope.maxValueLT = 0;
    $scope.minValueLT = 0;
    $scope.maxValueST = 0;
    $scope.minValueST = 0;
    $scope.SelectedChildName;
    $scope.busketCount = 0;
    //For Modification from basket
    $scope.longTermPlanId = 0;
    $scope.longTermPlanType = 0;
    $scope.shortTermPlanId = 0;
    $scope.shortTermPlanType = 0;
    $scope.modifiedChildId;
    $scope.childDropdown = true;
    $scope.showChooseYourChild = true;
    $scope.childNameOnModify = true;
    $scope.showContribution = false;
    $scope.showChooseYourPlan = true;
    $scope.hideFillContribution = true;
    $scope.hideModifyPayment = true;
    $scope.showMakePayment = true;
    $scope.longOldAmount;
    $scope.shortOldAmount;
    $scope.invitationId;
    //$scope.longTermAmount;
    //$scope.shortTermAmount;
    $scope.longTermAmount = null;
    $scope.shortTermAmount = null;
    $("#longTermValue").val(null);
    $("#shortTermValue").val(null);
    $scope.confirmButton = false;
    $scope.signInButton = false;
    $scope.isUpdate = false;
    $scope.IndInfo.cultureCode = $.cookie("language");

    //Recurrent Payment
    $scope.softDelete = false;
    $scope.softDeleteSt = false;
    $scope.recurrentPaymentLongTerm = false;
    $scope.recurrentPaymentShortTerm = false;
    $scope.recurrentPaymentView = null;
    $scope.disableFieldLong = BOOLEAN.FALSE;
    $scope.longTextMessageLong = BOOLEAN.FALSE;
    $scope.shortTextMessageLong = BOOLEAN.FALSE;
    $scope.disableFieldShort = BOOLEAN.FALSE;
    $scope.longTextMessageShort = BOOLEAN.FALSE;
    $scope.shortTextMessageShort = BOOLEAN.FALSE;
    $("#longTermValue").val("");
    $("#shortTermValue").val("");
    $scope.userMessage = "";
    $scope.accountHolderFirstName = "";
    $scope.accountHolderLastName = "";
    $scope.accountHolderIbanNumber = "";
    $scope.bicNumber = "";
    $scope.value = "1";
    $scope.startDates = "";
    $scope.endDates = "";
    $scope.dateFiledaccountHolderStartDate = false;
    $scope.dateFiledaccountHolderEndDate = false;
    $scope.dateFiledaccountHolderStartDatevalue = "";
    $scope.dateFiledaccountHolderEndDatevalue = "";
    // $("#contributeEndDate").val("");
    $scope.recPhone = "";
    $scope.showRecPhone = false;
    $scope.hidePlanWhenShowingIdentityDetails = false;
    $scope.optionSelected = -1;
    $scope.disabledProceedToPayment = false;
    $scope.disabledAddToBasket = false;
    $scope.disableField = function (id) {
        if (id === 'longTermValue') {
            $('.long-term-div>div.contribute-spinner-btn>button#btnLongDown').attr("disabled", "disabled");
            $('.long-term-div>div.contribute-spinner-btn>button#btnLongUp').attr("disabled", "disabled");
        } else if (id === 'shortTermValue') {
            $('.short-term-div>div.contribute-spinner-btn>button#btnShortDown').attr("disabled", "disabled");
            $('.short-term-div>div.contribute-spinner-btn>button#btnShortUp').attr("disabled", "disabled");
        }
        $('#' + id).attr("disabled", "disabled");
        $("#" + id).addClass("ignoreValidation");
    }
    $scope.enableField = function (id) {
        if (id === 'longTermValue') {
            $('.long-term-div>div.contribute-spinner-btn>button#btnLongDown').removeAttr("disabled", "disabled");
            $('.long-term-div>div.contribute-spinner-btn>button#btnLongUp').removeAttr("disabled", "disabled");
        } else if (id === 'shortTermValue') {
            $('.short-term-div>div.contribute-spinner-btn>button#btnShortDown').removeAttr("disabled", "disabled");
            $('.short-term-div>div.contribute-spinner-btn>button#btnShortUp').removeAttr("disabled", "disabled");
        }
        //angular.element(evt.target).closest(".long-term-details").find(".contribute-spinner-btn .btn").removeAttr("disabled", "disabled");
        $('#' + id).removeAttr("disabled", "disabled");
        $("#" + id).removeClass("ignoreValidation");
    }
    $scope.disableFieldLong = BOOLEAN.FALSE;
    $scope.longTextMessageLong = BOOLEAN.FALSE;
    $scope.shortTextMessageLong = BOOLEAN.FALSE;
    $scope.disableFieldShort = BOOLEAN.FALSE;
    $scope.longTextMessageShort = BOOLEAN.FALSE;
    $scope.shortTextMessageShort = BOOLEAN.FALSE;

    $scope.enableField('longTermValue');
    $scope.enableField('shortTermValue');
    // $scope.showNextDueDate = true;
    $scope.longTermPlanId = 0;
    $scope.longTermPlanType = 0;
    $scope.shortTermPlanId = 0;
    $scope.shortTermPlanType = 0;

    $scope.accountHolderStreet = "";
    $scope.accountHolderHouseNumber = "";
    $scope.accountHolderZipCode = 0;
    $scope.accountHolderCity = "";
    $scope.accountHolderCountry = "";
    $scope.accountHolderZipCodeId = "";
    $scope.accountHolderCountryCodeId = "";
    // initiate payment
    $scope.hideLongTermIsShortTermPreBirth = false;

    if (isTrue(localStorage.getItem("isContributionUpdate"))) {
        $scope.hidePaymentDetails = false;
        $scope.hideOneShotButtons = true; //not needed re-initialized
        $scope.hideRecButtons = false; // when contibution is true
        $scope.hidePlanDetails = false;
        $scope.hideMessage = false;
        $scope.$parent.updateRecurrent = true;
        $scope.childDropdown = false;
        $scope.childNameOnModify = false;
        $scope.showChooseYourChild = true;
        $scope.showOneShot = false;
        $scope.hideModifyPayment = false;
        $scope.showMakePayment = false;
        $scope.showChooseYourChild = false;
        $scope.showNextDueDate = true;
    } else { // if (localStorage.getItem("isContributionUpdate") == "false") {
        $scope.hideModifyPayment = true;
        $scope.showMakePayment = true;
        $scope.showNextDueDate = false;
    }

    if (isTrue(localStorage.getItem("fromTimeline")) || isTrue(localStorage.getItem("fromNotification"))) {
        // $scope.childDropdown = false;
        if (!isEmptyOrUndefinedOrNull(localStorage.getItem("childId"))) {
            $scope.childId = localStorage.getItem("childId");
        }
        $scope.showContribution = false;
        $scope.childDropdown = false;
        $scope.childNameOnModify = false;
        $scope.showChooseYourChild = false;
    }

    $scope.uploadedIdNowContinue = function () {
        if (!$('#recurrentIdentificationForm').valid()) {
            $('#recurrentIdentificationForm').valid();
            return;
        }
        if (!$scope.Eid.front || !$scope.Eid.back) {
            return false;
        }
        $scope.hideIdentityDetails = true;
        $scope.hideContinueButton = true;
        $scope.hideMessage = false;
        $scope.hidePlanWhenShowingIdentityDetails = false;
        if (isTrue($scope.hideLongTerm) && isTrue($scope.hideShortTerm)) {
            $scope.hidePlanDetails = true;
            $scope.hideMessage = true;
        }
        if (ProofOfIdentity[0].ImageTypeCode == 2) {
            if (ProofOfIdentity[0].ImageBase64[0]) {
                ProofOfIdentity[0].ImageBase64[0] = $scope.Eid.front;
            }
            else {
                ProofOfIdentity[0].ImageBase64.push($scope.Eid.front);
            }
        }
        else {
            if (ProofOfIdentity[0].ImageBase64[0]) {
                ProofOfIdentity[0].ImageBase64[0] = $scope.Eid.back;
            }
            else {
                ProofOfIdentity[0].ImageBase64.push($scope.Eid.back);
            }
        }
        if (ProofOfIdentity[1].ImageTypeCode == 2) {
            if (ProofOfIdentity[1].ImageBase64[0]) {
                ProofOfIdentity[1].ImageBase64[0] = $scope.Eid.front;
            }
            else {
                ProofOfIdentity[1].ImageBase64.push($scope.Eid.front);
            }
        }
        else {
            if (ProofOfIdentity[1].ImageBase64[0]) {
                ProofOfIdentity[1].ImageBase64[0] = $scope.Eid.back;;
            }
            else {
                ProofOfIdentity[1].ImageBase64.push($scope.Eid.back);
            }
        }

        ProofOfIdentity[0].IdentityId = 1;
        ProofOfIdentity[1].IdentityId = 2;
        ProofOfIdentity[0].IdentityProofNumber = $scope.nationalNumber;
        ProofOfIdentity[1].IdentityProofNumber = $scope.nationalNumber;
        ProofOfIdentity[0].ExpiryDate = $scope.tinExpDate;
        ProofOfIdentity[1].ExpiryDate = $scope.tinExpDate;
        var DOBArray = [];
        DOBArray = $scope.nationalNumber.substring(0, 6).match(/.{2}/g);
        var personDOB = DOBArray[2] + "/" + DOBArray[1] + "/" + DOBArray[0];

        ProofOfIdentity[0].PersonDateOfBirth = personDOB;
        ProofOfIdentity[1].PersonDateOfBirth = personDOB;


        for (var i = 0; i < ProofOfIdentity.length; i++) {
            if (!isEmptyOrUndefinedOrNull(ProofOfIdentity[i].ImageBase64[0])) {
                if (ProofOfIdentity[i].ImageBase64[0].substring(0, 4) == 'data') {
                    var array = ProofOfIdentity[i].ImageBase64[0].split(",");
                    ProofOfIdentity[i].ImageBase64[0] = array[1];
                } else {
                    ProofOfIdentity[i].ImageBase64[0] = null;
                }
            } else {
                ProofOfIdentity[i].ImageBase64[0] = null;
            }
        }


        paymentDetail.RecurrentPaymentView.ProofOfIdentityViewModel = ProofOfIdentity;
        paymentDetail.ProofOfIdentityViewModel = ProofOfIdentity;
        $scope.paymentDetail.ProofOfIdentityViewModel = ProofOfIdentity;
        // var res = paymentService.addRecurrentPayment(paymentDetail);
    }

    $scope.init = function (entryPointForContribution) {
        // $('#contributeStartDate').inputmask('ContributionDate');
        // $('#contributeEndDate').inputmask('ContributionDate');
        $scope.recurrentId = 0;
        if ($.cookie("entryPoint")) {// for free contributor
            $scope.entryPoint = $.cookie("entryPoint");
            $scope.showAddToBasketMobile = false;
            $scope.showAddToBasket = false;
            $scope.showContribution = true;
            $scope.invitationId = $.cookie("invitationId");
        } else {// for registered supporter
            $scope.entryPoint = entryPointForContribution;
            $scope.showAddToBasketMobile = true;
            $scope.showAddToBasket = true;
            if ((isTrue(localStorage.getItem("fromTimeline"))) || (isTrue(localStorage.getItem("fromNotification")))) {
                $scope.childId = localStorage.getItem("childId");
            }
        }

        $scope.recurrentData = $stateParams.recurrentData;
        var locationCalledFrom = $stateParams.locationCalledFrom;
        if (isEmptyOrUndefinedOrNull(locationCalledFrom)) {
            locationCalledFrom = localStorage.getItem("locationCalledFrom");
        }
        $scope.locationCalledFrom = locationCalledFrom;
        localStorage.setItem("locationCalledFrom", '');
        var childParamId = $stateParams.childId;
        if (!isEmptyOrUndefinedOrNull(childParamId)) {
            $scope.childId = childParamId;
        }

        if (locationCalledFrom === 'updateViaBasket') {
            if (!isEmptyOrUndefinedOrNull($scope.recurrentData)) {
                $scope.modifyRecurrentData = $scope.recurrentData;
                $scope.basketToPayment($scope.recurrentData);
            }
        } else if (locationCalledFrom === 'childDetailsViaRecurrentpayment') {
            if (!isEmptyOrUndefinedOrNull($scope.contributorId)) {
                if (!isEmptyOrUndefinedOrNull($scope.entryPoint)) {
                    if (isEmptyOrUndefinedOrNull($scope.childId)) {
                        $scope.initializeChildId($scope.contributorId);
                    }
                    $scope.getPaymentIntiatingDetail($scope.childId);
                } else {
                    $scope.recurrenttimesoption = "error";
                }
            } else {
                $scope.recurrenttimesoption = "error";
            }
        } else if (locationCalledFrom === 'updateViaChildView') {
            $scope.basketToPayment($scope.recurrentData);
        } else if (locationCalledFrom === 'goToContributeViaBasket' || locationCalledFrom === 'goToContribute' || locationCalledFrom === 'updateViaPaymentConfirmationPage') {
            if (!isEmptyOrUndefinedOrNull($scope.contributorId)) {
                if (!isEmptyOrUndefinedOrNull($scope.entryPoint)) {
                    if (isEmptyOrUndefinedOrNull($scope.childId)) {
                        $scope.initializeChildId($scope.contributorId);
                    }
                    $scope.getChildrenDetail($scope.childId);
                    $scope.getAllCountriesList();
                } else {
                    $scope.recurrenttimesoption = "error";
                }
            } else {
                $scope.recurrenttimesoption = "error";
            }
        } else if (locationCalledFrom === 'updateViaBasketToPayment') {
            $scope.getPaymentIntiatingDetail($scope.childId);
            // $scope.basketToPaymentOneShot($scope.recurrentData);
            // $scope.getChildrenDetail($scope.recurrentData.ChildView.PersonId);
        } else if (locationCalledFrom === 'updateViaPaymentConfirmationPageOnRetry') {
            $scope.getPaymentIntiatingDetail($scope.childId);
            //$scope.OneShotOnRetry();
        } else if (locationCalledFrom === 'updateViaNotificationView') {
            $("#invitationEmailModal").modal('hide');
            $scope.getChildrenDetail($scope.childId);
            // $scope.getPaymentIntiatingDetail();
            // $scope.basketToPaymentOneShot($scope.recurrentData);
            // $scope.getChildrenDetail($scope.recurrentData.ChildView.PersonId);
        }

        $scope.hideContribution = false;
    };

    $scope.updateTransactionStatus = function () {
        $scope.paymentDetail.PaymentReferenceNumber = $scope.paymentTransactionId;

        var res = paymentService.updateTransactionStatus($scope.paymentDetail);//.success(function (data, status) {
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (d) {
            }
            , function (error) {
            });
        }

    };

    $scope.RecurrentPaymentViewMethod = function (recurrentDataView, isNew) {
        $scope.showError = false;
        $scope.showModifyError = false;
        $scope.confirmButton = false;
        $scope.signInButton = false;
        $scope.modifyRecButton = false;
        $scope.showRecPhone = true;
        if (isTrue(recurrentDataView.NoRecurrent)) {
            if (isTrue(recurrentDataView.IsMandateExists)) {//if contract date has n't passed but mandate exist
                $scope.confirmButton = true;
                $scope.modifyRecButton = false;
            } else {//if contract date has n't passed but mandate does n't exist. This will create Only Mandate
                $scope.signInButton = true;
            }
            //for modify payment
            if (isTrue(localStorage.getItem("isContributionUpdate"))) {
                $scope.confirmButton = false;
                $scope.modifyRecButton = true;
            }
        }
        else {   //if contract date has passed.
            if (isTrue(localStorage.getItem("isContributionUpdate"))) {
                //for modify
                $scope.showModifyError = true;
            }
            else {//for create
                $scope.showError = true;
            }
        }

        if (!isEmptyOrUndefinedOrNull(recurrentDataView.IbanAccountNumber)) {
            $scope.longTermAmount = null;
            $scope.shortTermAmount = null;

            if (!isEmptyOrUndefinedOrNull(recurrentDataView.LongTermPlanView)) {
                var longTermAmount = parseInt(returnANumberWithoutFormating(recurrentDataView.LongTermPlanView.NewAmount, currentLanguage)); //TODO Verify

                if (longTermAmount != 0) {
                    $scope.hideLongTerm = BOOLEAN.FALSE;
                    $scope.longTermAmount = longTermAmount;
                    if (isNew) {
                        $scope.disableFieldLong = BOOLEAN.TRUE;
                        $scope.longTextMessageLong = BOOLEAN.FALSE;
                        $scope.shortTextMessageLong = BOOLEAN.TRUE;
                        $scope.disableField('longTermValue');
                    } else {
                        $scope.disableFieldLong = BOOLEAN.FALSE;
                        $scope.longTextMessageLong = BOOLEAN.FALSE;
                        $scope.shortTextMessageLong = BOOLEAN.FALSE;
                        $scope.enableField('longTermValue');
                    }
                } else {
                    $scope.hideLongTerm = BOOLEAN.FALSE;
                    if (isNew) {
                        $scope.disableFieldLong = BOOLEAN.FALSE;
                        $scope.longTextMessageLong = BOOLEAN.FALSE;
                        $scope.shortTextMessageLong = BOOLEAN.FALSE;
                        $scope.enableField('longTermValue');
                    } else {
                        $scope.disableFieldLong = BOOLEAN.TRUE;
                        $scope.longTextMessageLong = BOOLEAN.TRUE;
                        $scope.shortTextMessageLong = BOOLEAN.FALSE;
                        $scope.disableField('longTermValue');
                        $scope.recDeleteLT = false;
                    }
                }
                $scope.planId = recurrentDataView.LongTermPlanView.PlanId;
            }
            if (!isEmptyOrUndefinedOrNull(recurrentDataView.ShortTermPlanView)) {
                var shortTermAmount = parseInt(returnANumberWithoutFormating(recurrentDataView.ShortTermPlanView.NewAmount, currentLanguage)); //TODO Verify

                if (shortTermAmount != 0) {
                    //$scope.hideShortTerm = BOOLEAN.FALSE;
                    $scope.shortTermAmount = shortTermAmount;
                    $("#shortTermValue").val(shortTermAmount);
                    if (isNew) {
                        $scope.disableFieldShort = BOOLEAN.TRUE;
                        $scope.longTextMessageShort = BOOLEAN.FALSE;
                        $scope.shortTextMessageShort = BOOLEAN.TRUE;
                        $scope.disableField('shortTermValue');
                    } else {
                        $scope.disableFieldShort = BOOLEAN.FALSE;
                        $scope.longTextMessageShort = BOOLEAN.FALSE;
                        $scope.shortTextMessageShort = BOOLEAN.FALSE;
                        //$scope.enableField('shortTermValue');
                    }
                } else {
                    //$scope.hideShortTerm = BOOLEAN.FALSE;
                    if (isNew) {
                        $scope.disableFieldShort = BOOLEAN.FALSE;
                        $scope.longTextMessageShort = BOOLEAN.FALSE;
                        $scope.shortTextMessageShort = BOOLEAN.FALSE;
                        //$scope.enableField('shortTermValue');
                    } else {
                        $scope.disableFieldShort = BOOLEAN.TRUE;
                        $scope.longTextMessageShort = BOOLEAN.TRUE;
                        $scope.shortTextMessageShort = BOOLEAN.FALSE;
                        $scope.disableField('shortTermValue');
                        $scope.recDeleteST = false;
                    }
                }
                $scope.planId = recurrentDataView.ShortTermPlanView.PlanId;
            }
            $scope.recurrentId = recurrentDataView.RecurrentPaymentId;
            $scope.accountHolderFirstName = recurrentDataView.AccountHolderFirstName;
            $scope.accountHolderLastName = recurrentDataView.AccountHolderLastName;
            $scope.accountHolderIbanNumber = recurrentDataView.IbanAccountNumber;
            $scope.recPhone = recurrentDataView.PhoneNumber;
            if (recurrentDataView.MandateId != 0) {
                if (!isNew) {
                    $scope.accountMessage = recurrentDataView.Message;
                    $scope.accountFrequeny = recurrentDataView.Frequency;
                    //TODO remove below re-initializationa dn keep one name
                    $scope.userMessage = $scope.accountMessage;
                    $scope.value = $scope.accountFrequeny.toString();
                }
                $("#accountHolderFirstName").attr("disabled", "disabled").addClass("disabled");
                $("#accountHolderLastName").attr("disabled", "disabled").addClass("disabled");
                $("#accountHolderIbanNumber").attr("disabled", "disabled").addClass("disabled");
                $("#bicNumber").attr("disabled", "disabled").addClass("disabled");
            } else {
                $("#confirmBtnDeskId").attr("disabled", "disabled").addClass("disabled");
            }

            if ($("#select-defaults-option").is(":disabled")) {
                $("#frequencyDropdown button[data-id='select-defaults-option']").addClass("disabled-state");
            } else {
                $("#frequencyDropdown button[data-id='select-defaults-option']").removeClass("disabled-state");
            }
        }
    }

    $scope.getPaymentIntiatingDetail = function (childId) {
        $scope.$parent.paymentController.new = $scope;
        angular.element(".payment-type-section > .sb-eid-container .image-radio input[type='radio']").prop("checked", false);
        $scope.PaymentMode = "";
        $scope.SelectedChild = childId;
        //codes for new child selection in contribution
        //$scope.childExpandedSectionLink = false;
        //$("#childExpandedSectionShow").slideUp();
        var res = paymentService.getPaymentIntiatingDetail($scope.contributorId, childId, $scope.entryPoint);
        //var url = "/childsaving/person/" + $scope.contributorId + "/child/" + childId + "/context/" + $scope.entryPoint + "/initiatepayment";
        //var res = WebApiService.getWebApiData(url);
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (d) {
                var response = JSON.stringify(d);
                paymentDetail = JSON.parse(response);

                if (!isEmptyOrUndefinedOrNull(paymentDetail)) {
                    $scope.paymentDetail = paymentDetail;
                    $scope.SelectedChildFirstName = paymentDetail.OneShotPaymentView[0].ChildView.PersonFirstName;
                    // $scope.Persons = {};
                    if (paymentDetail.OneShotPaymentView[0].ChildView.PersonImageUrl != null) {
                        $scope.IndInfo.imagePath = paymentDetail.OneShotPaymentView[0].ChildView.PersonImageUrl;
                    }
                    else {
                        $scope.IndInfo.imagePath = images.defaultPersonImage;
                    }
                    $scope.$parent.hideModifyPayment = true;
                    $scope.$parent.showMakePayment = true;
                    $scope.recurrentMessage = false;
                    $scope.hideLongTermIsShortTermPreBirth = false;

                    paymentDetail.isContributionUpdate = BOOLEAN.FALSE;
                    var isContributionUpdateBool = isTrue(localStorage.getItem("isContributionUpdate"));
                    paymentDetail.isContributionUpdate = isContributionUpdateBool;
                    $scope.hideShortTerm = BOOLEAN.FALSE;
                    $scope.hideLongTerm = BOOLEAN.FALSE;
                    if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView)) {
                        if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView.Message)) {
                            $scope.recurrentMessage = true;
                        }
                        $scope.recurrentPaymentView = paymentDetail.RecurrentPaymentView;
                        $scope.modifyRecurrentData = paymentDetail.RecurrentPaymentView;
                    }
                    $scope.oneShotPaymentView = paymentDetail.OneShotPaymentView[0];

                    $("#longTermValue").val("");
                    $("#shortTermValue").val("");
                    $scope.userMessage = "";
                    $scope.accountHolderFirstName = "";
                    $scope.accountHolderLastName = "";
                    $scope.accountHolderIbanNumber = "";
                    $scope.bicNumber = "";
                    $scope.value = "1";
                    $scope.startDates = "";
                    $scope.endDates = "";
                    $scope.dateFiledaccountHolderStartDate = false;
                    $scope.dateFiledaccountHolderEndDate = false;
                    $scope.dateFiledaccountHolderStartDatevalue = "";
                    $scope.dateFiledaccountHolderEndDatevalue = "";
                    // $("#contributeEndDate").val("");
                    $scope.recPhone = paymentDetail.RecurrentPaymentView.PhoneNumber;

                    if (!isEmptyOrUndefinedOrNull($scope.recPhone)) {
                        $('#mobilePhone').attr("disabled", "disabled");
                    } else {
                        $('#mobilePhone').removeAttr("disabled", "disabled");
                    }

                    if (isContributionUpdateBool) {
                        if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView)) {
                            if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView.LongTermPlanView)) {
                                $scope.maxValueLT = paymentDetail.RecurrentPaymentView.LongTermPlanView.MaxValue;
                                $scope.minValueLT = paymentDetail.RecurrentPaymentView.LongTermPlanView.MinValue;
                                $scope.longTermAmount = paymentDetail.RecurrentPaymentView.LongTermPlanView.NewAmount;
                                if (paymentDetail.RecurrentPaymentView.LongTermPlanView.NewAmount != 0) {
                                    $scope.longTermAmount = formatAmountField(paymentDetail.RecurrentPaymentView.LongTermPlanView.NewAmount, currentLanguage);
                                }
                            }
                            if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView.ShortTermPlanView)) {
                                $scope.maxValueST = paymentDetail.RecurrentPaymentView.ShortTermPlanView.MaxValue;
                                $scope.minValueST = paymentDetail.RecurrentPaymentView.ShortTermPlanView.MinValue;
                                $scope.shortTermAmount = paymentDetail.RecurrentPaymentView.ShortTermPlanView.NewAmount;
                                if (paymentDetail.RecurrentPaymentView.ShortTermPlanView.NewAmount != 0) {
                                    $scope.shortTermAmount = formatAmountField(paymentDetail.RecurrentPaymentView.ShortTermPlanView.NewAmount, currentLanguage);
                                }
                            }
                            if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView.Message)) {
                                $scope.recurrentMessage = BOOLEAN.TRUE;
                                $scope.accountMessage = paymentDetail.RecurrentPaymentView.Message;
                            }
                            paymentDetail.RecurrentPaymentView.isContributionUpdate = true;
                            $scope.accountHolderFirstName = paymentDetail.RecurrentPaymentView.AccountHolderFirstName;
                            $scope.accountHolderLastName = paymentDetail.RecurrentPaymentView.AccountHolderLastName;
                            $scope.accountHolderIbanNumber = paymentDetail.RecurrentPaymentView.IbanAccountNumber;
                            $scope.bicNumber = paymentDetail.RecurrentPaymentView.Swift;
                            $scope.startDates = paymentDetail.RecurrentPaymentView.StartDate;
                            $scope.endDates = paymentDetail.RecurrentPaymentView.EndDate;
                            $scope.accountFrequeny = paymentDetail.RecurrentPaymentView.Frequency;
                        }
                        $("#accountHolderFirstName").attr("disabled", "disabled").addClass("disabled");
                        $("#accountHolderLastName").attr("disabled", "disabled").addClass("disabled");
                        $("#accountHolderIbanNumber").attr("disabled", "disabled").addClass("disabled");
                        $("#bicNumber").attr("disabled", "disabled").addClass("disabled");
                        $("#select-defaults-option").removeAttr("disabled").removeClass("disabled");
                        $("#confirmBtnDeskId").attr("disabled", "disabled").addClass("disabled");
                        if ($("#select-defaults-option").is(":disabled")) {
                            $("#frequencyDropdown button[data-id='select-defaults-option']").addClass("disabled-state");
                        } else {
                            $("#frequencyDropdown button[data-id='select-defaults-option']").removeClass("disabled-state");
                        }
                    } else {
                        $scope.enableAddtobasket = true;
                        $scope.enableProceedtoPayment = true;

                        $("#select-defaults-option").removeAttr("disabled").removeClass("disabled");
                        $("#messageForRecurrent").removeAttr("disabled").removeClass("disabled");
                        $("#accountHolderFirstName").removeAttr("disabled").removeClass("disabled");
                        $("#accountHolderLastName").removeAttr("disabled").removeClass("disabled");
                        $("#accountHolderIbanNumber").removeAttr("disabled").removeClass("disabled");

                        $scope.hidePlanDetails = true;
                        $scope.hideMessage = true;
                        $scope.hidePaymentDetails = true;
                        $scope.hideIdentityDetails = true;
                        $scope.hideContinueButton = true;
                        $scope.showRecPhone = false;

                        $scope.hideOneShotButtons = true;
                        $scope.hideRecButtons = true; // initiate payment

                        if (!isEmptyOrUndefinedOrNull(paymentDetail.OneShotPaymentView)) {
                            if (paymentDetail.OneShotPaymentView.length > 0) {
                                if ($scope.entryPoint == 6 || $scope.entryPoint == 7) {
                                    $scope.showPaymentType = false;
                                    $scope.showOneShot = false;
                                    $scope.checkPaymentDetail(1, null, paymentDetail.OneShotPaymentView[0]);
                                    $scope.hideFillContribution = false;
                                    $scope.showChooseYourPlan = false;
                                    if (!isEmptyOrUndefinedOrNull(paymentDetail.OneShotPaymentView[0].LongTermPlanView)) {
                                        $scope.longTermPlanId = paymentDetail.OneShotPaymentView[0].LongTermPlanView.PlanId;
                                        $scope.longTermPlanType = paymentDetail.OneShotPaymentView[0].LongTermPlanView.PlanType;
                                    }
                                    if (!isEmptyOrUndefinedOrNull(paymentDetail.OneShotPaymentView[0].ShortTermPlanView)) {
                                        $scope.shortTermPlanId = paymentDetail.OneShotPaymentView[0].ShortTermPlanView.PlanId;
                                        $scope.shortTermPlanType = paymentDetail.OneShotPaymentView[0].ShortTermPlanView.PlanType;
                                    }
                                } else {
                                    $scope.hideFillContribution = true;
                                    $scope.showChooseYourPlan = true;

                                    $scope.showPaymentType = true;
                                    $scope.showOneShot = true;
                                    $scope.hidePlanDetails == true;
                                    // for updating basket details in case user toggles child option
                                    if (!isEmptyOrUndefinedOrNull(paymentDetail.OneShotPaymentView[0].LongTermPlanView)) {
                                        $scope.longTermPlanId = paymentDetail.OneShotPaymentView[0].LongTermPlanView.PlanId;
                                        $scope.longTermPlanType = paymentDetail.OneShotPaymentView[0].LongTermPlanView.PlanType;
                                    }
                                    if (!isEmptyOrUndefinedOrNull(paymentDetail.OneShotPaymentView[0].ShortTermPlanView)) {
                                        $scope.shortTermPlanId = paymentDetail.OneShotPaymentView[0].ShortTermPlanView.PlanId;
                                        $scope.shortTermPlanType = paymentDetail.OneShotPaymentView[0].ShortTermPlanView.PlanType;
                                    }
                                }
                            } else {
                                $scope.showOneShot = false;
                            }
                        }
                        $scope.showRecPrem = false;
                        if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView)) {
                            if (isTrue(paymentDetail.RecurrentPaymentView.IsEligibleForRecurrentPayment)) {
                                $scope.accountNewFrequency = [];
                                $.each(paymentDetail.RecurrentPaymentView.FrequencyView, function (index, value) {
                                    if (value.Id != 0) {
                                        $scope.accountNewFrequency.push(value);
                                    }
                                });
                                $scope.noRecurrent = paymentDetail.RecurrentPaymentView.NoRecurrent;
                                $scope.RecurrentPaymentViewMethod(paymentDetail.RecurrentPaymentView, BOOLEAN.TRUE);
                                $scope.ContractEndDate = getDateInString(new Date(paymentDetail.RecurrentPaymentView.ContractEndDate), DATE_FORMAT.DDMMYYYY, currentLanguage);
                                var lenghtOfEndDateList = paymentDetail.RecurrentPaymentView.RecurrentDate.length;
                                $scope.recurrentStartDateStart = new Date(paymentDetail.RecurrentPaymentView.RecurrentDate[0]);
                                $scope.recurrentStartDateEnd = new Date(paymentDetail.RecurrentPaymentView.RecurrentDate[lenghtOfEndDateList - 1]);

                                // $scope.changeFrequency("1", $scope.ContractEndDate)

                                if (!isTrue(localStorage.getItem("fromTimeline"))) {

                                    if (isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView.LongTermPlanView)
                                        && isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView.ShortTermPlanView)) {
                                        $scope.showRecPrem = false;
                                    }
                                    else {
                                        $scope.showRecPrem = true;
                                    }
                                }
                            }
                        }
                        if (!isEmptyOrUndefinedOrNull(paymentDetail.OneShotPaymentView) && !isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView)) {
                            // $scope.showPaymentType = false;
                            $scope.hideMessage = true;
                        } else {
                            if ($scope.entryPoint == 6 || $scope.entryPoint == 7) {
                                $scope.showPaymentType = false;
                            } else {
                                $scope.showPaymentType = true;
                            }
                        }

                        if (isTrue(paymentDetail.IsShortTermPreBirth)) {
                            $scope.showOneShot = true;
                            $scope.showRecPrem = false;
                            $scope.showPaymentType = true;
                            $scope.hideMessage = true;
                            $scope.hideLongTermIsShortTermPreBirth = true;
                        }
                    }//EnD of no update
                    if (isTrue(localStorage.getItem("brodcastMessage"))) {
                        $rootScope.$broadcast("basket-to-recpaymnet", { any: { "recurrentData": paymentDetail.RecurrentPaymentView } });
                        localStorage.setItem("brodcastMessage", false);
                    }
                    $scope.recurrenttimesoption = "success";
                }
                if ($scope.locationCalledFrom === 'updateViaBasketToPayment') {
                    // $scope.getPaymentIntiatingDetail($scope.childId);
                    $scope.basketToPaymentOneShot($scope.recurrentData);
                    // $scope.getChildrenDetail($scope.recurrentData.ChildView.PersonId);
                } else if ($scope.locationCalledFrom === 'updateViaPaymentConfirmationPageOnRetry') {
                    //$scope.OneShotOnRetry();
                    $scope.getChildrenDetail($scope.childId);
                }
                // $scope.changeFrequency($scope.value, $scope.ContractEndDate);
            }, function (error) {
                $scope.recurrenttimesoption = "error";
            });
        }

        $.removeCookie("entryPoint");
    }

    //Add the months

    Date.isLeapYear = function (year) {
        return (((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0));
    };

    Date.getDaysInMonth = function (year, month) {
        return [31, (Date.isLeapYear(year) ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
    };

    Date.prototype.isLeapYear = function () {
        return Date.isLeapYear(this.getFullYear());
    };

    Date.prototype.getDaysInMonth = function () {
        return Date.getDaysInMonth(this.getFullYear(), this.getMonth());
    };

    Date.prototype.addMonths = function (value) {
        var n = this.getDate();
        this.setDate(1);
        this.setMonth(this.getMonth() + value);
        this.setDate(Math.min(n, this.getDaysInMonth()));
        return this;
    };
    //

    $scope.recurrentTimeClicked = function () {
        if ($scope.recurrenttimesoption == "error") {
            $("#recurringPaymentDetails").modal("hide");
            genericErrorMessageDisplay(Resources.LoadPopup_Failed);
        } else {
            $("#recurringPaymentDetails").modal("show");
        }
    }

    $scope.updateRecurrentPaymentViaBasket = function (recurrent) {
        // $rootScope.$broadcast("basket-to-recpaymnet", { any: { "recurrentData": recurrent } });
        localStorage.setItem("brodcastMessage", true);
        // $state.go("contribute");
        $state.go("contribute", {
            recurrentData: recurrent,
            locationCalledFrom: 'updateViaBasket'
        }, {
            reload: true
        });
    }

    $scope.updateRecurrentPaymentViaChildView = function (recurrent) {
        localStorage.setItem("brodcastMessage", true);
        // $state.go("contribute");
        $state.go("contribute", {
            recurrentData: recurrent,
            locationCalledFrom: 'updateViaChildView'
        });
    }

    $scope.updateRecurrentPaymentStatus = function (contributorId, planId, childId) {
        $("#recurringPaymentDetails").css("z-index", "1050");
        $("#deletePaymentModal").hide();
        $("#recurringPaymentDetails").modal("hide");
        paymentDetail.ContributorViewModel.PersonId = contributorId;
        paymentDetail.SelectedChildId = childId;
        if (paymentDetail.RecurrentPaymentView.LongTermPlanView != null) {
            paymentDetail.RecurrentPaymentView.LongTermPlanView.PlanId = planId;
        } else if (paymentDetail.RecurrentPaymentView.ShortTermPlanView != null) {
            paymentDetail.RecurrentPaymentView.ShortTermPlanView.PlanId = planId;
        }
        var res = paymentService.getRecurrentPaymentStatus(paymentDetail);//.success(function (data, status) {
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (d) {
                $("#deletePaymentModalRecurrent").modal("hide");
                $("#recurringPaymentDetails").modal("hide");
                $scope.goToChild(childId, contributorId, false);
                $("#recurringPaymentDetails").modal("hide");
            }, function (error) {
                genericErrorMessageDisplay(Resources.DeleteRecurrentPayment_Failed);
            });

        }
    }

    $scope.checkPaymentDetail = function (value, recurrentPaymentView, oneShotPaymentView) {
        if ($scope.paymentDetail != null) {
            if (!isEmptyOrUndefinedOrNull($("#contributeForm").validate())) {
                $("#contributeForm").validate().resetForm();
            }
            $scope.optionSelected = value;
            $("#shortTermValue").val("");
            $("#messageForRecurrent").val("");
            if ($scope.optionSelected == OneShot) {
                $scope.signInButton = false;
                $("#messageForRecurrent").removeAttr("disabled").removeClass("disabled");
                $scope.hidePaymentDetails = true;
                $scope.hideIdentityDetails = true;
                $scope.hidePlanWhenShowingIdentityDetails = false;
                $scope.hideContinueButton = true;
                var isUploadIdExists = $scope.paymentDetail.IsUploadIdExists;
                if ((paymentDetail.OneShotPaymentView[0].TotalAmount >= paymentDetail.OneShotPaymentView[0].MaxContributionValue) && (!isUploadIdExists)) {
                    $scope.hidePlanWhenShowingIdentityDetails = false;
                    $scope.hideIdentityDetails = false;
                    $scope.hideContinueButton = true;
                    $scope.disabledProceedToPayment = true;
                    $scope.disabledAddToBasket = true;
                }
                //$scope.contributionAmountShotTermLongTerm = paymentDetail.OneShotPaymentView[0].TotalAmount -1000;

                $scope.hideOneShotButtons = false;
                $scope.showRecPhone = false;
                $scope.hideRecButtons = true; // check payment details
                angular.element(".payment-type.one-time").addClass("active");
                angular.element(".payment-type.recurrent-payment").removeClass("active");
                //TODO - Need someone who  can explain why it is being done then i can merge the below code too
                $scope.hideShortTerm = false;
                $scope.hideLongTerm = false;

                if (isTrue(localStorage.getItem("onRetry"))) {
                    $scope.hideShortTerm = false;
                    $scope.hideLongTerm = false;
                    if (!isEmptyOrUndefinedOrNull(oneShotPaymentView.LongTermPlanView)) {
                        $scope.hideLongTerm = true;
                        if ($scope.entryPoint == 6 || $scope.entryPoint == 7) {
                            $scope.maxValueLT = 500;
                            $scope.minValueLT = 10;
                        } else {
                            $scope.maxValueLT = oneShotPaymentView.LongTermPlanView.MaxValue;
                            $scope.minValueLT = oneShotPaymentView.LongTermPlanView.MinValue;
                        }
                    }

                    if (!isEmptyOrUndefinedOrNull(oneShotPaymentView.ShortTermPlanView)) {
                        if ($scope.entryPoint == 6 || $scope.entryPoint == 7) {
                            $scope.maxValueST = 500;
                            $scope.minValueST = 10;
                            $scope.showAddToBasket = false;
                        } else {
                            $scope.maxValueST = oneShotPaymentView.ShortTermPlanView.MaxValue;
                            $scope.minValueST = oneShotPaymentView.ShortTermPlanView.MinValue;
                        }
                        $scope.hideShortTerm = true;
                    }

                    //TODO - Need to re-write Amitabh
                    //$scope.busketCount = paymentDetail.NoOfContribution;

                    //if (paymentDetail.NoOfContribution >= 10) {
                    //    //$("#addToBasket").attr("disabled", "disabled").addClass("disabled");
                    //    $scope.enableAddtobasket = false;
                    //}

                    if (!isEmptyOrUndefinedOrNull($("#isUpdate").val()) || !isTrue($("#isUpdate").val())) {
                        $scope.longTermAmount = null;
                        $scope.shortTermAmount = null;
                        $("#longTermValue").val("");
                        $("#shortTermValue").val("");
                    }
                } else {
                    if (!isEmptyOrUndefinedOrNull(oneShotPaymentView.LongTermPlanView)) {
                        if ($scope.entryPoint == 6 || $scope.entryPoint == 7) {
                            $scope.maxValueLT = 500;
                            $scope.minValueLT = 10;
                        } else {
                            $scope.maxValueLT = oneShotPaymentView.LongTermPlanView.MaxValue;
                            $scope.minValueLT = oneShotPaymentView.LongTermPlanView.MinValue;
                        }
                    }
                    else {
                        $scope.hideLongTerm = true;
                    }

                    if (!isEmptyOrUndefinedOrNull(oneShotPaymentView.ShortTermPlanView)) {
                        if ($scope.entryPoint == 6 || $scope.entryPoint == 7) {
                            $scope.maxValueST = 500;
                            $scope.minValueST = 10;
                            $scope.showAddToBasket = false;
                        } else {
                            $scope.maxValueST = oneShotPaymentView.ShortTermPlanView.MaxValue;
                            $scope.minValueST = oneShotPaymentView.ShortTermPlanView.MinValue;
                        }
                    }
                    else {
                        $scope.hideShortTerm = true;
                    }

                    //TODO - Need to re-write Amitabh
                    //$scope.busketCount = paymentDetail.NoOfContribution;

                    //if (paymentDetail.NoOfContribution >= 10) {
                    //    //$("#addToBasket").attr("disabled", "disabled").addClass("disabled");
                    //    $scope.enableAddtobasket = false;
                    //}

                    if (!isEmptyOrUndefinedOrNull($("#isUpdate").val()) || !isTrue($("#isUpdate").val())) {
                        $scope.longTermAmount = null;
                        $scope.shortTermAmount = null;
                        $("#longTermValue").val("");
                        $("#shortTermValue").val("");
                    }
                }
                $scope.disableFieldLong = BOOLEAN.FALSE;
                $scope.longTextMessageLong = BOOLEAN.FALSE;
                $scope.shortTextMessageLong = BOOLEAN.FALSE;
                $scope.disableFieldShort = BOOLEAN.FALSE;
                $scope.longTextMessageShort = BOOLEAN.FALSE;
                $scope.shortTextMessageShort = BOOLEAN.FALSE;
                $scope.enableField('longTermValue');
                $scope.enableField('shortTermValue');
            } else if (value == RecurrentPremium) {
                setTimeout(function () {
                    $scope.recurrentStartDateStart = new Date(recurrentPaymentView.RecurrentDate[0]);
                    $scope.recurrentStartDateEnd = new Date(recurrentPaymentView.RecurrentDate[1]);
                    $("[id = 'contributeStartDate']").aagjeDatePicker();
                    $("[id = 'contributeStartDate']").aagjeDatePicker('setStartDate', $scope.recurrentStartDateStart);
                    $("[id = 'contributeStartDate']").aagjeDatePicker('setEndDate', $scope.recurrentStartDateEnd);
                    $scope.changeFrequency($scope.value, $scope.ContractEndDate, recurrentPaymentView.StartDate, recurrentPaymentView.EndDate);
                }, 500);
                $scope.hideShortTerm = false;
                $scope.hideLongTerm = false;

                $("#accountHolderIbanNumber").inputmask('IBAN');
                //Getting today's date in DD/MM/YYYY 4373 -Prefill start date
                // $("#contributeStartDate, #contributeEndDate").inputmask("remove");
                $("#contributeStartDate, #contributeEndDate").on("keypress", function () {
                    return false;
                });
                $scope.addressDoesNotExist = true;
                if (isTrue(recurrentPaymentView.IsAddressExist)) {
                    $scope.addressDoesNotExist = false;
                    $scope.accountHolderStreet = recurrentPaymentView.Address.street;
                    $scope.accountHolderHouseNumber = recurrentPaymentView.Address.houseNumber;
                    $scope.accountHolderZipCode = recurrentPaymentView.Address.zipCode;
                    $scope.accountHolderCity = recurrentPaymentView.Address.city;
                    $scope.accountHolderCountry = recurrentPaymentView.Address.country;
                    $scope.accountHolderZipCodeId = recurrentPaymentView.Address.cityZipCodeId;
                    $scope.accountHolderCountryCodeId = recurrentPaymentView.Address.countryCodeId.toString();
                } else {
                    if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.Address)) {
                        $scope.accountHolderZipCodeId = recurrentPaymentView.Address.cityZipCodeId.toString();
                        $scope.accountHolderCountryCodeId = recurrentPaymentView.Address.countryCodeId.toString();
                        $scope.accountHolderCountry = recurrentPaymentView.Address.country;
                        $scope.accountHolderStreet = recurrentPaymentView.Address.street;
                        $scope.accountHolderHouseNumber = recurrentPaymentView.Address.houseNumber;
                        $scope.accountHolderZipCode = recurrentPaymentView.Address.zipCode;
                        $scope.accountHolderCity = recurrentPaymentView.Address.city;
                    }
                }
                //if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.RecurrentDate)) {
                //    $("#contributeStartDate, #contributeEndDate").inputmask("ContributionDate");
                //    //Aliya need to add
                //}
                //change
                if (isEmptyOrUndefinedOrNull(recurrentPaymentView.ShortTermPlanView && recurrentPaymentView.ShortTermPlanExist)) {
                    $scope.hideShortTerm = true;
                }
                if (isEmptyOrUndefinedOrNull(recurrentPaymentView.LongTermPlanView && recurrentPaymentView.LongTermPlanExist)) {
                    $scope.hideLongTerm = true;
                }

                $scope.hidePaymentDetails = false;
                $scope.showRecPhone = true;
                angular.element(".payment-type.recurrent-payment").addClass("active");
                angular.element(".payment-type.one-time").removeClass("active");
                $("#messageForRecurrent").removeAttr("disabled").removeClass("disabled");

                $scope.hideIdentityDetails = false;
                $scope.hideContinueButton = false;
                $scope.hidePlanWhenShowingIdentityDetails = true;
                if (recurrentPaymentView.IsUploadIdExists) {
                    $scope.hideIdentityDetails = true;
                    $scope.hideContinueButton = true;
                    $scope.hidePlanWhenShowingIdentityDetails = false;
                    $("#id_contributor_dataFront").val("false");
                    $("#id_contributor_dataBack").val("false");
                }
                $scope.showError = false;
                $scope.showModifyError = false;
                $scope.confirmButton = false;
                $scope.signInButton = false;
                $scope.modifyRecButton = false;
                if (isTrue(recurrentPaymentView.NoRecurrent)) {
                    if (isTrue(recurrentPaymentView.IsMandateExists)) {//if contract date has n't passed but mandate exist
                        $scope.confirmButton = true;
                        $scope.modifyRecButton = false;
                    } else {//if contract date has n't passed but mandate does n't exist. This will create Only Mandate
                        $scope.signInButton = true;
                    }
                    //for modify payment
                    if (isTrue(localStorage.getItem("isContributionUpdate"))) {
                        $scope.confirmButton = false;
                        $scope.modifyRecButton = true;
                    }
                }
                else {
                    //if contract date has passed.
                    if (isTrue(localStorage.getItem("isContributionUpdate"))) {
                        $scope.showModifyError = true;
                    }
                    else {
                        $scope.showError = true;
                    }
                }

                $scope.hideOneShotButtons = true;
                $scope.hideRecButtons = false;
                var isNew = null;
                if (!isTrue(localStorage.getItem("isContributionUpdate"))) {
                    isNew = true;
                    //$scope.hideShortTerm = false;
                    // $scope.hideLongTerm = false;
                    if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.Message)) {
                        $scope.userMessage = recurrentPaymentView.Message;
                        $("#messageForRecurrent").val(recurrentPaymentView.Message);
                    }
                    if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.LongTermPlanView)) {
                        //$scope.hideLongTerm = false;
                        if (recurrentPaymentView.LongTermPlanView.NewAmount != 0) {
                            //$scope.hideLongTerm = BOOLEAN.FALSE;
                            $scope.longTermAmount = longTermAmount;
                            $scope.disableFieldLong = BOOLEAN.TRUE;
                            $scope.longTextMessageLong = BOOLEAN.FALSE;
                            $scope.shortTextMessageLong = BOOLEAN.TRUE;
                            $scope.disableField('longTermValue');
                            $scope.longTermAmount = recurrentPaymentView.LongTermPlanView.NewAmount;
                            // $("#longTermValue").val(recurrentPaymentView.LongTermPlanView.NewAmount);
                        } else {
                            //$scope.hideLongTerm = BOOLEAN.FALSE;
                            $scope.disableFieldLong = BOOLEAN.FALSE;
                            $scope.longTextMessageLong = BOOLEAN.FALSE;
                            $scope.shortTextMessageLong = BOOLEAN.FALSE;
                            $scope.enableField('longTermValue');
                            $scope.longTermAmount = null;
                            //$("#longTermValue").val("");
                        }
                    }
                    if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.ShortTermPlanView)) {
                        //$scope.hideShortTerm = false;
                        if (recurrentPaymentView.ShortTermPlanView.NewAmount != 0) {
                            //$scope.hideShortTerm = BOOLEAN.FALSE;
                            $scope.disableFieldShort = BOOLEAN.TRUE;
                            $scope.longTextMessageShort = BOOLEAN.FALSE;
                            $scope.shortTextMessageShort = BOOLEAN.TRUE;
                            $scope.disableField('shortTermValue');
                            $scope.shortTermAmount = recurrentPaymentView.ShortTermPlanView.NewAmount;
                            $("#shortTermValue").val(recurrentPaymentView.ShortTermPlanView.NewAmount);
                        } else {
                            //$scope.hideShortTerm = BOOLEAN.FALSE;
                            $scope.disableFieldShort = BOOLEAN.FALSE;
                            $scope.longTextMessageShort = BOOLEAN.FALSE;
                            $scope.shortTextMessageShort = BOOLEAN.FALSE;
                            $scope.enableField('shortTermValue');
                            $scope.shortTermAmount = null;
                            $("#shortTermValue").val("");
                        }
                    }


                }
                else {// if localStorage.getItem("isContributionUpdate") == "true"
                    isNew = false;
                    if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.LongTermPlanView)) {
                        if (returnANumberWithoutFormating(recurrentPaymentView.LongTermPlanView.NewAmount, currentLanguage) > 0) {
                            $scope.longTermAmount = recurrentPaymentView.LongTermPlanView.NewAmount;
                            $("#longTermValue").val(recurrentPaymentView.LongTermPlanView.NewAmount);
                        }
                        var longTermAmount = returnANumberWithoutFormating(recurrentPaymentView.LongTermPlanView.NewAmount, currentLanguage);
                        if (longTermAmount != 0) {
                            //$scope.hideLongTerm = BOOLEAN.FALSE;
                            $scope.longTermAmount = longTermAmount;
                            $scope.disableFieldLong = BOOLEAN.FALSE;
                            $scope.longTextMessageLong = BOOLEAN.FALSE;
                            $scope.shortTextMessageLong = BOOLEAN.FALSE;
                            $scope.enableField('longTermValue');
                        } else {
                            //$scope.hideLongTerm = BOOLEAN.FALSE;
                            $scope.disableFieldLong = BOOLEAN.TRUE;
                            $scope.longTextMessageLong = BOOLEAN.TRUE;
                            $scope.shortTextMessageLong = BOOLEAN.FALSE;
                            $scope.disableField('longTermValue');
                            $scope.recDeleteLT = false;
                        }
                    }
                    if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.ShortTermPlanView)) {
                        if (returnANumberWithoutFormating(recurrentPaymentView.ShortTermPlanView.NewAmount, currentLanguage) > 0) {
                            $scope.shortTermAmount = recurrentPaymentView.ShortTermPlanView.NewAmount;
                            $("#shortTermValue").val(recurrentPaymentView.ShortTermPlanView.NewAmount);
                        }
                        var shortTermAmount = returnANumberWithoutFormating(recurrentPaymentView.ShortTermPlanView.NewAmount, currentLanguage);
                        if (shortTermAmount != 0) {
                            //$scope.hideShortTerm = BOOLEAN.FALSE;
                            $scope.disableFieldShort = BOOLEAN.FALSE;
                            $scope.longTextMessageShort = BOOLEAN.FALSE;
                            $scope.shortTextMessageShort = BOOLEAN.FALSE;
                            $scope.enableField('shortTermValue');
                        } else {
                            //$scope.hideShortTerm = BOOLEAN.FALSE;
                            $scope.disableFieldShort = BOOLEAN.TRUE;
                            $scope.longTextMessageShort = BOOLEAN.TRUE;
                            $scope.shortTextMessageShort = BOOLEAN.FALSE;
                            $scope.disableField('shortTermValue');
                            $scope.recDeleteST = false;
                        }
                    }
                    if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.Message)) {
                        $scope.userMessage = recurrentPaymentView.Message;
                        $("#messageForRecurrent").val(recurrentPaymentView.Message);
                    }

                }
                if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.LongTermPlanView)) {
                    $scope.maxValueLT = recurrentPaymentView.LongTermPlanView.MaxValue;
                    $scope.minValueLT = recurrentPaymentView.LongTermPlanView.MinValue;
                }
                if (!isEmptyOrUndefinedOrNull(recurrentPaymentView.ShortTermPlanView)) {
                    $scope.maxValueST = recurrentPaymentView.ShortTermPlanView.MaxValue;
                    $scope.minValueST = recurrentPaymentView.ShortTermPlanView.MinValue;
                }

                var uniqueFrequency = [];
                $.each(recurrentPaymentView.FrequencyView, function (index, value) {
                    if (value.Id != 0) {
                        uniqueFrequency.push(value);
                    }
                });

                $scope.accountNewFrequency = uniqueFrequency;
                $scope.value = $scope.accountNewFrequency[0].Id.toString();
            }
            $scope.hidePlanDetails = false;
            $scope.hideMessage = false;
            if (!$scope.hideIdentityDetails) {
                if ($scope.optionSelected == OneShot) {
                    $scope.hideMessage = false;
                } else {
                    $scope.hideMessage = true;
                }
            }
            if (isTrue($scope.hideLongTerm) && isTrue($scope.hideShortTerm)) {
                $scope.hidePlanDetails = true;
                $scope.hideMessage = true;
            }
        } else {
            $scope.hideMessage = true;
            $scope.hidePlanDetails = true;
        }
    }

    $scope.changeValue = function (evt) {

        var shortTermInput = $(".short-term-input").find("input");
        var valueToCheckLongTerm = parseInt($scope.longTermAmount);
        var valueToCheckShortTerm = parseInt($scope.shortTermAmount);

        if (!$(".long-term-input").find("input").val()) {
            valueToCheckLongTerm = 0
        }
        if (!$(".short-term-input").find("input").val()) {
            valueToCheckShortTerm = 0
        }

        if ((evt == "btnLongUp")) {
            if (valueToCheckLongTerm >= parseInt($scope.maxValueLT)) {
                return false;
            }
            //$(".long-term-input").find("input").val(parseInt(valueToCheckLongTerm) + paymentDetail.IncrementalValue);
            $scope.longTermAmount = valueToCheckLongTerm + 10;//TODO Amitabh paymentDetail.IncrementalValue;
        } else if ((evt == "btnLongDown")) {
            if (valueToCheckLongTerm <= parseInt($scope.minValueLT)) {
                return false;
            }
            //$(".long-term-input").find("input").val(parseInt(valueToCheckLongTerm) - paymentDetail.IncrementalValue);
            $scope.longTermAmount = valueToCheckLongTerm - 10;//TODO Amitabh paymentDetail.IncrementalValue;
        }

        if ((evt == "btnShortUp")) {
            if (valueToCheckShortTerm >= parseInt($scope.maxValueST)) {
                return false;
            }
            //$(".short-term-input").find("input").val(parseInt(valueToCheckShortTerm) + paymentDetail.IncrementalValue);
            $scope.shortTermAmount = valueToCheckShortTerm + 10;//TODO Amitabh  paymentDetail.IncrementalValue;
        } else if ((evt == "btnShortDown")) {
            if (valueToCheckShortTerm <= parseInt($scope.minValueST)) {
                return false;
            }
            //$(".short-term-input").find("input").val(parseInt(valueToCheckShortTerm) - paymentDetail.IncrementalValue);
            $scope.shortTermAmount = valueToCheckShortTerm - 10;//TODO Amitabh paymentDetail.IncrementalValue;
        }

        if ($scope.optionSelected == OneShot) {
            var isContributionUpdateBool = isTrue(localStorage.getItem("isContributionUpdate"));
            var isUploadIdExists = $scope.paymentDetail.IsUploadIdExists;
            var totalAmount = $scope.paymentDetail.OneShotPaymentView[0].TotalAmount;
            if ($scope.shortTermAmount) {
                totalAmount = totalAmount + returnANumberWithoutFormating($scope.shortTermAmount, currentLanguage);
            }
            if ($scope.longTermAmount) {
                totalAmount = totalAmount + returnANumberWithoutFormating($scope.longTermAmount, currentLanguage);
            }
            //otalAmount = totalAmount + returnANumberWithoutFormating($scope.shortTermAmount, currentLanguage) + returnANumberWithoutFormating($scope.longTermAmount, currentLanguage);
            if (isContributionUpdateBool) {
                totalAmount = totalAmount - returnANumberWithoutFormating($scope.longOldAmount, currentLanguage) - returnANumberWithoutFormating($scope.shortOldAmount, currentLanguage);
            }
            if ((totalAmount >= $scope.paymentDetail.OneShotPaymentView[0].MaxContributionValue) && (!isUploadIdExists)) {
                $scope.hidePlanWhenShowingIdentityDetails = false;
                $scope.hideIdentityDetails = false;
                $scope.hideContinueButton = true;
                if (!$scope.proofOfIdentityUploadOption || $scope.proofOfIdentityUploadOption == undefined) {
                    $scope.disabledProceedToPayment = true;
                    $scope.disabledAddToBasket = true;
                }
            } else {
                $scope.hidePlanWhenShowingIdentityDetails = false;
                $scope.hideIdentityDetails = true;
                $scope.hideContinueButton = true;
                $scope.disabledProceedToPayment = false;
                $scope.disabledAddToBasket = false;
            }
        }

        setTimeout(function () {
            $("#longTermValue").valid();
            $("#shortTermValue").valid();
        }, 50);
    }



    $scope.deleteUpdateRecurrent = function () {
        $("#recurringPaymentDetails").css("z-index", "96");
        $("#deletePaymentModal").show();
    };

    $scope.deleteRecurentNo = function () {
        $("#recurringPaymentDetails").css("z-index", "1050");
        $("#deletePaymentModal").hide();
        $("#recurringPaymentDetails").modal("hide");
    };
    //Payment Basket
    //Add to basket
    $scope.changeFrequency = function (value, ContractEndDate, startDateModify, endDateModify) {
        if (isEmptyOrUndefinedOrNull(ContractEndDate)) {
            return;
        }
        var date = new Date();

        var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);

        var frequency = parseInt(value);
        var possibleDatesArray = [];
        var newPossibleDatesArray = [];
        var possibleYear = {};
        var possibleDates = [];
        var dates = {};
        var ContractEndDate = new Date(ContractEndDate.split("/")[2], (parseInt(ContractEndDate.split("/")[1]) - 1), ContractEndDate.split("/")[0]);

        var startDate = $("#contributeStartDate").val();

        var currentYearPushed = date.getFullYear();
        //if (date.getDate() <= 24) {
        if (date.getDate() > 24) {
            firstDay = new Date(date.getFullYear(), date.getMonth() + 2, 1);
        } else {
            firstDay = new Date(date.getFullYear(), date.getMonth() + 1, 1);
        }
        if (startDate) {
            date = new Date(startDate.split("/")[2], ((parseInt(startDate.split("/")[1]) - 1) + (frequency - 1)), startDate.split("/")[0]);
        }
        var numberOfMonths = new Date(ContractEndDate).getMonth() + 1 - new Date(date.getFullYear(), date.getMonth(), 1).addMonths(1).getMonth()
                + (12 * (new Date(ContractEndDate).getFullYear() - new Date(date.getFullYear(), date.getMonth(), 1).addMonths(1).getFullYear()));
        for (i = 0; i < numberOfMonths / frequency; i++) {
            possibleDatesArray.push(new Date(date.getFullYear(), date.getMonth(), 1).addMonths((i * frequency) + 1));
        }

        for (var j = 0; j < possibleDatesArray.length; j++) {
            var dateToPush = possibleDatesArray[j];
            var yearToPush = dateToPush.getFullYear();
            if (currentYearPushed != yearToPush) {
                dates.year = currentYearPushed;
                dates.dates = possibleDates;
                dates.frequency = frequency;
                newPossibleDatesArray.push(dates);
                currentYearPushed = yearToPush;
                possibleDates = [];
                dates = {};
                possibleDates.push(dateToPush);
                dates.year = currentYearPushed;
            } else {
                possibleDates.push(dateToPush);
            }
        }
        dates.dates = possibleDates;
        dates.frequency = frequency;
        newPossibleDatesArray.push(dates);

        $scope.possibleDates = newPossibleDatesArray;

        $scope.recurrentEndDateStart = new Date(possibleDatesArray[0]);
        $scope.recurrentEndDateEnd = new Date(possibleDatesArray[possibleDatesArray.length - 1]);
        var startDateToSet = "";
        var endDateToSet = "";
        if (!isEmptyOrUndefinedOrNull(startDateModify)) {
            startDateToSet = getDateInString(startDateModify, DATE_FORMAT.MMDDYYYY, currentLanguage, SEPARATOR.FORWARD);
        } else {
            if (!isEmptyOrUndefinedOrNull(startDate)) {
                startDateToSet = getDateInString(startDate, DATE_FORMAT.MMDDYYYY, currentLanguage, SEPARATOR.FORWARD);
            } else {
                startDateToSet = getDateInString(firstDay, DATE_FORMAT.MMDDYYYY, currentLanguage, SEPARATOR.FORWARD);
            }
        }
        if (!isEmptyOrUndefinedOrNull(endDateModify)) {
            endDateToSet = getDateInString(endDateModify, DATE_FORMAT.DDMMYYYY, currentLanguage, SEPARATOR.FORWARD);
        } else {
            endDateToSet = getDateInString($scope.recurrentEndDateEnd, DATE_FORMAT.DDMMYYYY, currentLanguage, SEPARATOR.FORWARD);
        }
        setTimeout(function () {
            $scope.startDates = startDateToSet;
            //$scope.endDates = endDateToSet;
            //$("#contributeStartDate").val(getDateInString(startDateToSet, DATE_FORMAT.DDMMYYYY, currentLanguage, SEPARATOR.FORWARD));
            $("#contributeEndDate").val(endDateToSet);
        }, 1000);
    }

    $scope.addToBasket = function (contributionObj, longTermAmount, shortTermAmount, userMessage, isUpdate, contributionId, longTermPlanId, longTermPlanType, shortTermPlanId, shortTermPlanType, modifiedChildId, longOldAmount, shortOldAmount) {
        if (!$('#contributeForm').valid()) {
            $('#contributeForm').valid();
            return;
        }
        if (!isTrue($scope.hideIdentityDetails)) {
            if (!$('#recurrentIdentificationForm').valid()) {
                $('#recurrentIdentificationForm').valid();
                return;
            }
            if (!$scope.Eid.front || !$scope.Eid.back) {
                return false;
            }
            $scope.uploadedIdNowContinue();
        }
        var paymentDetail = $scope.paymentDetail;

        paymentDetail.isContributionUpdate = isUpdate;
        if (isEmptyOrUndefinedOrNull(isUpdate) || !isTrue(isUpdate)) {
            var basketcount = parseInt($("#basketCount").text());

            if (basketcount == 10 && (!isEmptyOrUndefinedOrNull(longTermAmount) || !isEmptyOrUndefinedOrNull(shortTermAmount))) {
                $scope.hideAddToBasketPopUp = true;
                $scope.goToContribute(false, currentLanguage);
                genericErrorMessageDisplay(Resources.AddBasketError);
                return false;
            }
            else if (basketcount == 9 && !isEmptyOrUndefinedOrNull(longTermAmount) && !isEmptyOrUndefinedOrNull(shortTermAmount)) {
                $scope.hideAddToBasketPopUp = true;
                $scope.goToContribute(false, currentLanguage);
                genericErrorMessageDisplay(Resources.AddBasketError);
                return false;
            }
            else {
                paymentDetail.OneShotPaymentView[0].Message = userMessage;
                if (!isEmptyOrUndefinedOrNull(contributionObj)) {
                    paymentDetail.OneShotPaymentView[0].ContributionId = contributionObj.ContributionId;
                }
                if (typeof (longTermAmount) != "undefined" && longTermAmount != null) {
                    if (paymentDetail.OneShotPaymentView[0].LongTermPlanView != null) {
                        paymentDetail.OneShotPaymentView[0].LongTermPlanView.NewAmount = longTermAmount;
                    }
                }
                if (typeof (shortTermAmount) != "undefined" && shortTermAmount != null) {
                    if (paymentDetail.OneShotPaymentView[0].ShortTermPlanView != null) {
                        paymentDetail.OneShotPaymentView[0].ShortTermPlanView.NewAmount = shortTermAmount;
                    }
                }
                paymentDetail.RecurrentPaymentView = null;
            }
        } else {
            paymentDetail.OneShotPaymentView[0].Message = userMessage;

            if (!isEmptyOrUndefinedOrNull(contributionObj)) {
                paymentDetail.OneShotPaymentView[0].ContributionId = contributionObj.ContributionId;
            }

            if (!isEmptyOrUndefinedOrNull(longTermAmount)) {
                paymentDetail.OneShotPaymentView[0].LongTermPlanView = {};

                paymentDetail.OneShotPaymentView[0].LongTermPlanView.PlanId = longTermPlanId;
                paymentDetail.OneShotPaymentView[0].LongTermPlanView.PlanType = longTermPlanType;
                paymentDetail.OneShotPaymentView[0].LongTermPlanView.NewAmount = longTermAmount;
                paymentDetail.OneShotPaymentView[0].LongTermPlanView.OldAmount = longOldAmount;
                //}
            }
            if (!isEmptyOrUndefinedOrNull(shortTermAmount)) {
                paymentDetail.OneShotPaymentView[0].ShortTermPlanView = {};
                paymentDetail.OneShotPaymentView[0].ShortTermPlanView.PlanId = shortTermPlanId;
                paymentDetail.OneShotPaymentView[0].ShortTermPlanView.PlanType = shortTermPlanType;
                paymentDetail.OneShotPaymentView[0].ShortTermPlanView.NewAmount = shortTermAmount;
                paymentDetail.OneShotPaymentView[0].ShortTermPlanView.OldAmount = shortOldAmount;
                // }
            }
            paymentDetail.RecurrentPaymentView = null;
            paymentDetail.isContributionUpdate = true;
            if (typeof (modifiedChildId) != "undefined" && modifiedChildId != null) {
                paymentDetail.SelectedChildId = modifiedChildId;
            }
        }
        paymentService.addToBasket(paymentDetail).success(function (data, status) {
            $scope.hideAddToBasketPopUp = false;
            $scope.longTermAmount = null;
            $scope.shortTermAmount = null;
            $("#longTermValue").val(null);
            $("#shortTermValue").val(null);
            $rootScope.$broadcast('addToBasketModal-started', {
                any: {
                    "name": $scope.SelectedChildFirstName
                }
            });
        })
            .error(function (data, status) {
                genericErrorMessageDisplay(Resources.AddToBasket_Failed);
            });
    }

    $rootScope.$on('addAnotherChild-payment', function (event, args) {
        $scope.addAnotherChild();
    });

    $rootScope.$on('seeChildOverview-payment', function (event, args) {

        $scope.getBasketCount();
        $scope.seeChildOverview($scope.SelectedChild, $scope.contributorId, $scope.isUpdate);
    });

    $scope.$watch('editPic', function (newValue, oldValue) {
        if (newValue == "front") {
            $("#frontImage").click();
            $scope.editPic = false;
        }
        if (newValue == "back") {
            $("#backImage").click();
            $scope.editPic = false;
        }
    });

    $scope.$watch('Eid.front', function (newValue, oldValue) {
        if (!newValue || newValue == "") {
            $('#frontImage').val('');
        }
    });

    $scope.$watch('Eid.back', function (newValue, oldValue) {
        if (!newValue || newValue == "") {
            $('#backImage').val('');
        }
    });

    $scope.payOneShotPayment = function (longTermAmount, shortTermAmount, userMessage, isUpdate, contributionId, longTermPlanId, longTermPlanType, shortTermPlanId, shortTermPlanType, modifiedChildId) {
        if (!$('#contributeForm').valid()) {
            $('#contributeForm').valid();
            return;
        }



        if (!isTrue($scope.hideIdentityDetails)) {
            if (!$('#recurrentIdentificationForm').valid()) {
                $('#recurrentIdentificationForm').valid();
                return;
            }
            if (!$scope.Eid.front || !$scope.Eid.back) {
                return false;
            }
            $scope.uploadedIdNowContinue();
        }

        $scope.enableProceedtoPayment = false;
        paymentDetail.OneShotPaymentView[0].Message = userMessage;
        //paymentDetail.FromBasket = false;
        $.cookie("FromBasket", false);
        localStorage.setItem("isFromBasket", false);
        if (!isEmptyOrUndefinedOrNull(longTermAmount)) {
            //if (paymentDetail.OneShotPaymentView[0].LongTermPlanView != null) {
            paymentDetail.OneShotPaymentView[0].LongTermPlanView = {};

            paymentDetail.OneShotPaymentView[0].LongTermPlanView.PlanId = longTermPlanId;
            paymentDetail.OneShotPaymentView[0].LongTermPlanView.PlanType = longTermPlanType;
            paymentDetail.OneShotPaymentView[0].LongTermPlanView.NewAmount = longTermAmount;
            $.cookie("PaymentLongType", paymentDetail.OneShotPaymentView[0].LongTermPlanView.PlanType);
            //}
        }
        if (!isEmptyOrUndefinedOrNull(shortTermAmount)) {
            //if (paymentDetail.OneShotPaymentView[0].ShortTermPlanView != null) {
            paymentDetail.OneShotPaymentView[0].ShortTermPlanView = {};
            paymentDetail.OneShotPaymentView[0].ShortTermPlanView.PlanId = shortTermPlanId;
            paymentDetail.OneShotPaymentView[0].ShortTermPlanView.PlanType = shortTermPlanType;
            paymentDetail.OneShotPaymentView[0].ShortTermPlanView.NewAmount = shortTermAmount;
            $.cookie("PaymentShortType", paymentDetail.OneShotPaymentView[0].ShortTermPlanView.PlanType);
            // }
        }

        if ($scope.entryPoint == 6 || $scope.entryPoint == 7) // for free contributor + Invitation/EventInvitation
        {
            paymentDetail.InvitationId = $scope.invitationId;
        }

        paymentDetail.RecurrentPaymentView = null;
        paymentDetail.isContributionUpdate = true;
        if (!isEmptyOrUndefinedOrNull(modifiedChildId)) {
            paymentDetail.SelectedChildId = modifiedChildId;
            //paymentDetail.SelectedChildId = localStorage.getItem("ModifiedChildId");
        }
        if (!isEmptyOrUndefinedOrNull(contributionId)) {
            paymentDetail.OneShotPaymentView[0].ContributionId = contributionId;
        } else if (!isEmptyOrUndefinedOrNull($scope.contributorId)) {
            paymentDetail.OneShotPaymentView[0].ContributionId = $scope.contributorId;
            contributionId = $scope.contributorId;
        }
        var uniqueId = createUUID();
        paymentDetail.PaymentReferenceId = uniqueId;
        var res = paymentService.payOneShotPayment(paymentDetail);

        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (d) {
                var transactionId = d.data;
                var paymentReferenceNumber = uniqueId;
                var longTermPlanView = 0;
                if (paymentDetail.OneShotPaymentView[0].LongTermPlanView != null && paymentDetail.OneShotPaymentView[0].LongTermPlanView.NewAmount != "") {
                    longTermPlanView = paymentDetail.OneShotPaymentView[0].LongTermPlanView.NewAmount;
                }
                var shortTermPlanView = 0;
                if (paymentDetail.OneShotPaymentView[0].ShortTermPlanView != null && paymentDetail.OneShotPaymentView[0].ShortTermPlanView.NewAmount != "") {
                    shortTermPlanView = paymentDetail.OneShotPaymentView[0].ShortTermPlanView.NewAmount;
                }
                var totalAmount = parseFloat(longTermPlanView) + parseFloat(shortTermPlanView);
                $scope.paymentServicesOSP(transactionId, paymentReferenceNumber, totalAmount, $scope.contributorId);
            }
            , function (error) {
                genericErrorMessageDisplay(Resources.CreateOneShot_Failed);
            });

        }
    }

    function createUUID() {
        // http://www.ietf.org/rfc/rfc4122.txt
        var s = [];
        var hexDigits = "0123456789abcdef";
        for (var i = 0; i < 36; i++) {
            s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
        }
        s[14] = "4"; // bits 12-15 of the time_hi_and_version field to 0010
        s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
        s[8] = s[13] = s[18] = s[23] = "-";

        var uuid = s.join("");
        return uuid;
    }
    $scope.paymentServicesOSP = function (transactionId, paymentReferenceNumber, totalAmount, personId) {
        var postData = {
            UserId: personId,
            Amount: totalAmount,
            TransactionId: transactionId,
            PaymentReference: paymentReferenceNumber,
            IsFreeContribution: false
        };
        paymentService.paymentGateway(postData).success(function (paymentRes, status) {
            FormSubmitter.submit(paymentRes.RedirectionUrl, "POST", paymentRes);
        })
            .error(function (paymentRes, status) {
            });
    }

    $scope.modiyingRecPayment = function (modifyRecurrentData, longTermAmount, shortTermAmount, userMessage, value, accountHolderLastName, bicNumber, accountHolderIbanNumber, accountHolderFirstName, callType, ReferencedFrom, recurrentId, isDelete) {
        if (!$('#contributeForm').valid()) {
            $('#contributeForm').valid();
            return;
        }
        var paymentDetail = {};
        paymentDetail.RecurrentPaymentView = modifyRecurrentData;
        paymentDetail.ContributorViewModel = {};
        paymentDetail.isContributionUpdate = isTrue(localStorage.getItem("isContributionUpdate"));

        if (paymentDetail.isContributionUpdate) {
            var selectedChildName = $scope.SelectedChildFirstName;

            //  paymentDetail.RecurrentPaymentView.ProofOfIdentityViewModel = ProofOfIdentity;
            paymentDetail.RecurrentPaymentView.RecurrentPaymentId = recurrentId;
            paymentDetail.ContributorViewModel.PersonId = $scope.contributorId;
            if (accountHolderIbanNumber.indexOf('BE') != -1) {
                paymentDetail.RecurrentPaymentView.IbanAccountNumber = accountHolderIbanNumber;
            }else{
                paymentDetail.RecurrentPaymentView.IbanAccountNumber = 'BE'+accountHolderIbanNumber;
            }

            paymentDetail.RecurrentPaymentView.AccountHolderFirstName = accountHolderFirstName;
            paymentDetail.RecurrentPaymentView.AccountHolderLastName = accountHolderLastName;
            paymentDetail.RecurrentPaymentView.Message = userMessage;
            paymentDetail.RecurrentPaymentView.Swift = bicNumber;
            paymentDetail.RecurrentPaymentView.Frequency = value;
            paymentDetail.RecurrentPaymentView.StartDate = $("#contributeStartDate").val();
            paymentDetail.RecurrentPaymentView.EndDate = $("#contributeEndDate").val();
            paymentDetail.RecurrentPaymentView.CallType = callType;
            paymentDetail.RecurrentPaymentView.ReferencedFrom = ReferencedFrom;
            paymentDetail.RecurrentPaymentView.RedirectUrl = baseFrontEndUrl + "/connective/ConfirmSign";
            if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView.LongTermPlanView)) {
                var longTermOldAmount = parseInt(returnANumberWithoutFormating(paymentDetail.RecurrentPaymentView.LongTermPlanView.OldAmount));
                if (longTermOldAmount <= 0) {
                    paymentDetail.RecurrentPaymentView.LongTermPlanView.OldAmount = paymentDetail.RecurrentPaymentView.LongTermPlanView.NewAmount;
                }
                paymentDetail.RecurrentPaymentView.LongTermPlanView.NewAmount = longTermAmount;
            }
            if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView.ShortTermPlanView)) {
                var shortTermOldAmount = parseInt(returnANumberWithoutFormating(paymentDetail.RecurrentPaymentView.ShortTermPlanView.OldAmount));
                if (shortTermOldAmount <= 0) {
                    paymentDetail.RecurrentPaymentView.ShortTermPlanView.OldAmount = paymentDetail.RecurrentPaymentView.ShortTermPlanView.NewAmount;
                }
                paymentDetail.RecurrentPaymentView.ShortTermPlanView.NewAmount = shortTermAmount;
            }
            paymentDetail.OneShotPaymentView = {};
            if (isTrue(paymentDetail.RecurrentPaymentView.IsUploadIdExists)) {
                paymentDetail.RecurrentPaymentView.ProofOfIdentityViewModel = {};
            }
            paymentDetail.RecurrentPaymentView.IsRecurrentDelete = $scope.isDelete;
            $rootScope.$broadcast('updateRecurrentModal-started', {
                any: {
                    "recurrentData": paymentDetail,
                    "name": selectedChildName,
                    "locationCalledFrom": $scope.locationCalledFrom
                }
            });
        }
    }

    $scope.saveRecurrentPayment = function (modifyRecurrentData, longTermAmount, shortTermAmount, userMessage, value, accountHolderLastName, bicNumber, accountHolderIbanNumber, accountHolderFirstName, callType, ReferencedFrom, recurrentId, recPhone) {
        if (!$('#contributeForm').valid()) {
            $('#contributeForm').valid();
            return;
        }
        var paymentDetail = {};
        paymentDetail.RecurrentPaymentView = modifyRecurrentData;//need to initialize when creating new recurrent TODO:
        paymentDetail.ContributorViewModel = {};

        paymentDetail.isContributionUpdate = isTrue(localStorage.getItem("isContributionUpdate"));
        if (isTrue(localStorage.getItem("deleteRec"))) {
            paymentDetail.RecurrentPaymentView.IsRecurrentDelete = true;
        } else {
            paymentDetail.RecurrentPaymentView.IsRecurrentDelete = false;
        }
        paymentDetail.RecurrentPaymentView.PhoneNumber = recPhone;
        ;

        paymentDetail.RecurrentPaymentView.ProofOfIdentityViewModel = ProofOfIdentity;
        paymentDetail.RecurrentPaymentView.RecurrentPaymentId = recurrentId;
        paymentDetail.ContributorViewModel.PersonId = $scope.contributorId;
        if (accountHolderIbanNumber.indexOf('BE') != -1) {
            paymentDetail.RecurrentPaymentView.IbanAccountNumber = accountHolderIbanNumber;
        } else {
            // paymentDetail.RecurrentPaymentView.IbanAccountNumber = 'BE' + accountHolderIbanNumber;
            paymentDetail.RecurrentPaymentView.IbanAccountNumber = 'BE' + accountHolderIbanNumber.replace(/ +/g, "").replace('BE', "");
        }
        paymentDetail.RecurrentPaymentView.AccountHolderFirstName = accountHolderFirstName;
        paymentDetail.RecurrentPaymentView.AccountHolderLastName = accountHolderLastName;
        paymentDetail.RecurrentPaymentView.Message = userMessage;
        paymentDetail.RecurrentPaymentView.Swift = bicNumber;
        paymentDetail.RecurrentPaymentView.Frequency = value;
        paymentDetail.RecurrentPaymentView.StartDate = $("#contributeStartDate").val();
        paymentDetail.RecurrentPaymentView.EndDate = $("#contributeEndDate").val();
        paymentDetail.RecurrentPaymentView.CallType = callType;
        paymentDetail.RecurrentPaymentView.ReferencedFrom = ReferencedFrom;
        if (!isTrue(paymentDetail.RecurrentPaymentView.IsAddressExist)) {
            $scope.accountHolderStreet = $('#editStreeetNum').val();
            $scope.accountHolderHouseNumber = $('#editHouseNumber').val();
            // $scope.accountHolderCity = $('#editCity').val();
            paymentDetail.RecurrentPaymentView.Address.street = $scope.accountHolderStreet;
            paymentDetail.RecurrentPaymentView.Address.houseNumber = $scope.accountHolderHouseNumber;
            paymentDetail.RecurrentPaymentView.Address.zipCode = $scope.accountHolderZipCode;
            paymentDetail.RecurrentPaymentView.Address.city = $scope.accountHolderCity;
            paymentDetail.RecurrentPaymentView.Address.country = $scope.accountHolderCountry;
            paymentDetail.RecurrentPaymentView.Address.cityZipCodeId = $scope.accountHolderZipCodeId;
            paymentDetail.RecurrentPaymentView.Address.countryCodeId = $scope.accountHolderCountryCodeId;
        }
        paymentDetail.RecurrentPaymentView.RedirectUrl = baseFrontEndUrl + "/connective/ConfirmSign";
        if (paymentDetail.RecurrentPaymentView.LongTermPlanView != null) {
            paymentDetail.RecurrentPaymentView.LongTermPlanView.NewAmount = longTermAmount;
        }
        if (paymentDetail.RecurrentPaymentView.ShortTermPlanView != null) {
            paymentDetail.RecurrentPaymentView.ShortTermPlanView.NewAmount = shortTermAmount;
        }
        paymentDetail.OneShotPaymentView = {};
        if (paymentDetail.RecurrentPaymentView.IsUploadIdExists == true) {
            paymentDetail.RecurrentPaymentView.ProofOfIdentityViewModel = {};
        }
        var res = paymentService.addRecurrentPayment(paymentDetail);
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (data) {
                if (data.data.PaymentType = "RecurrentPayment") {
                    if (data.data.Url != null) {
                        $window.location.href = data.data.Url;
                    }
                }

                if (localStorage.getItem("isContributionUpdate") == "true") { //this should not be called on modifing
                    localStorage.setItem("isContributionUpdate", "false");
                    localStorage.setItem("deleteRec", false);
                    if (data.Url != null) {
                        $window.location.href = data.data.Url;
                    }
                    else {
                        $scope.goToChild($scope.modifiedChildId, $scope.contributorId, false);
                    }
                } else {
                    if (!isEmptyOrUndefinedOrNull(paymentDetail.RecurrentPaymentView.ChildView.PersonId) && paymentDetail.RecurrentPaymentView.ChildView.PersonId !== 0) {
                        $scope.childId = paymentDetail.RecurrentPaymentView.ChildView.PersonId;
                    } else {
                        if (isEmptyOrUndefinedOrNull(paymentDetail.SelectedChildId)) {
                            $scope.childId = $scope.SelectedChild; //paymentDetail.SelectedChildId;
                        } else {
                            $scope.childId = paymentDetail.SelectedChildId;
                        }
                    }
                    $scope.goToChild($scope.childId, $scope.contributorId, false);
                }
            }
            , function (error) {
                genericErrorMessageDisplay(Resources.CreateRecurrentPayment_Failed);
            });
        }
    }
    $scope.addAnotherChild = function () {
        $scope.getBasketCount();
        $scope.goToContribute(false, currentLanguage);
    }
    //Get updated basket countin
    $scope.getBasketCount = function () {
        if ($.cookie("personId") != null) {
            var res = paymentService.getBasketCount()
            if (!isEmptyOrUndefinedOrNull(res)) {
                res.then(function (data) {
                    $scope.updatedBasketCount = data;
                    $("#basketCount").html($scope.updatedBasketCount);
                    $rootScope.$broadcast('myCustomEvent', {
                        someProp: 'Sending you an Object!' // send whatever you want
                    });
                }, function (error) {
                });
            }
        }
    }
    $scope.goToContribute = function (obj, currentLanguageTemp) {
        //called from basket - contribute button
        localStorage.setItem("fromSuccessPayment", fromSuccessPayment);
        localStorage.setItem("contributeCond", obj);
        localStorage.setItem("isContributionUpdate", false);
        localStorage.setItem("fromTimeline", false);
        localStorage.setItem("fromNotification", false);
        //localStorage.setItem("childId", childId);
        //localStorage.setItem("contributorId", contributorId);
        var expires = new Date();
        expires.setUTCFullYear(expires.getUTCFullYear() - 1);
        document.cookie = "entryPoint=; expires=" + expires.toUTCString() + "; path=/";
        //  window.location.href = "/" + currentLanguageTemp + "/Contribute";
        var stateObj = { "hideContributeView": obj };
        // $state.go("contribute", { obj: stateObj });
        $state.go("contribute", {
            obj: stateObj,
            locationCalledFrom: 'goToContributeViaBasket'
        }, {
            reload: true
        });
    }
    $scope.seeChildOverview = function (SelectedChild, contributorId, isUpdate) {
        if (isUpdate) {
            localStorage.setItem("contributeCond", true);
            // window.location.href = "/" + currentLanguage + "/Contribute";
            $state.go("contribute.basket");
        } else {
            // window.location.href = "/" + currentLanguage + "/Home/Child/" + SelectedChild + "/plan";
            $state.go("child.detail.plan", {
                childId: SelectedChild
            });
        }
    }
    $scope.childOverview = function (SelectedChild, contributorId) {
        //  window.location.href = "/" + currentLanguage + "/Home/Child/" + $.cookie("childId") + "/plan";
        $state.go("child.detail.plan", {
            childId: $.cookie("childId")
        });
    }
    $scope.makeAnotherContribution = function (SelectedChild, contributorId) {
        //  window.location.href = "/" + currentLanguage + "/Home/Members/" + $.cookie("personId");
        $state.go("contribute");
    }
    $scope.goToChild = function (SelectedChild, contributorId, isUpdate) {
        localStorage.setItem("isContributionUpdate", "false");
        localStorage.setItem("sameNavigationHistory", "true");
        if ($scope.entryPoint == 6 || $scope.entryPoint == 7) // for free contributor
        {
            $window.history.back();
        } else {
            if (isUpdate) {
                //localStorage.setItem("contributeCond", true);
                if ($scope.locationCalledFrom === 'updateViaChildView') {
                    localStorage.setItem("recurrentRedirect", true);
                    $state.go("child.detail.plan", {
                        childId: SelectedChild
                    });
                    //$('#recurrentRedirect').trigger('click');
                } else if (($scope.locationCalledFrom === 'updateViaBasket') || ($scope.locationCalledFrom === 'updateViaBasketToPayment')) {
                    $state.go("contribute.basket");
                } else if ($scope.locationCalledFrom === "updateViaPaymentConfirmationPageOnRetry") {
                    localStorage.setItem("recurrentRedirect", true);
                    $state.go("child.detail.plan", {
                        childId: SelectedChild
                    });
                }
            } else {
                //window.location.href = "/" + currentLanguage + "/Home/Child/" + SelectedChild + "/plan";
                //$state.go("child.detail.recurrentpayment", {
                localStorage.setItem("recurrentRedirect", true);
                $state.go("child.detail.plan", {
                    childId: SelectedChild
                });
            }
        }
    }
    if (localStorage.getItem("contributeCond")) {
    $scope.contributeCond = JSON.parse(localStorage.getItem("contributeCond"));
}

    //Diable short and Long term
    $scope.deletePayemntOneByOne = function (evt, id) {
        $scope.disableField(id);
        if (id === 'longTermValue') {
            $scope.oldLongTermAmount = $scope.longTermAmount;
            $scope.softDelete = true;
            $scope.longTermAmount = 0;
            $scope.isDelete = true;
        } else if (id === 'shortTermValue') {
            $scope.oldShortTermAmount = $scope.shortTermAmount;
            $scope.softDeleteSt = true;
            $scope.shortTermAmount = 0;
            $scope.isDelete = true;
    }
        angular.element(evt.target).hide();
        angular.element(evt.target).next().show();
        localStorage.setItem("deleteRec", true);
}
    //enable Short term and Long term
    $scope.undoDeletePayemntOneByOne = function (evt, id) {
        $scope.enableField(id);
        if (id === 'longTermValue') {
            $scope.longTermAmount = $scope.oldLongTermAmount;
            $scope.softDelete = false;
            $scope.isDelete = false;
        } else if (id === 'shortTermValue') {
            $scope.shortTermAmount = $scope.oldShortTermAmount;
            $scope.softDeleteSt = false;
            $scope.isDelete = false;
    }
        //angular.element(evt.target).closest(".long-term-details").find(".contribute-spinner-btn .btn").removeAttr("disabled", "disabled");
        angular.element(evt.target).hide();
        angular.element(evt.target).prev().show();
        localStorage.setItem("deleteRec", false);
}

    //this method initializes the childId to scope if unavailable by passing  the contributor ID
    $scope.initializeChildId = function (contributorId) {
        var res = paymentService.getFirstChildIdByParent(contributorId);

        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (d) {
                $scope.childId = d;
            },
            function (error) {
        });
    }
}

    //this method gets the list of children to contribute
    $scope.getChildrenDetail = function (SelectedChildId) {
        if ($.cookie("entryPoint")) // for free contributor
        {
            var res = paymentService.getChildrenDetail($scope.contributorId, $scope.childId);
    }
        if ($.cookie("entryPoint") == null) // for registered contributor
        {
            var res = paymentService.getChildrenDetail($scope.contributorId, 0);
    }
        var language = "EN";

        if (res != undefined) {
            res.then(function (d) {
                var data = d;
                $scope.Persons = [];
                if (data.length > 0) {
                    $.each(data, function (index) {
                        var Person = [];
                        Person.ChildType = data[index].ChildrenType;
                        for (i = 0; i < data[index].PersonView.length; i += 1) {
                            var Child = {};
                            Child.ID = data[index].PersonView[i].PersonId;
                            Child.Name = data[index].PersonView[i].PersonFirstName + " " + data[index].PersonView[i].PersonLastName;
                            //{
                            if (SelectedChildId != null)
                                if (data[index].PersonView[i].PersonId == SelectedChildId) {
                                    $scope.SelectedChildFirstName = data[index].PersonView[i].PersonFirstName;
                                    $scope.SelectedChild = SelectedChildId;
                                    //localStorage.setItem("ModifiedChildId", paymentDetail.SelectedChildId);
                                    $scope.modifiedChildId = SelectedChildId;
                                    $scope.SelectedChildName = data[index].PersonView[i].PersonFirstName + " " + data[index].PersonView[i].PersonLastName;
                                    //for defect 6047
                                    if (localStorage.getItem("fromSuccessPayment") == fromSuccessPayment) {
                                        localStorage.setItem("fromSuccessPayment", null);
                                        $scope.IndInfo.imagePath = images.defaultPersonImage;
                                        $scope.childId = null;
                                        $("#select-option-groups").selectpicker("val", 0);
                                        $scope.showPaymentType = false;
                                    } else if (localStorage.getItem("fromSuccessPayment") == 'onretry') {
                                        localStorage.setItem("fromSuccessPayment", null);

                                        if (localStorage.getItem("onRetry") == "true") {
                                            $scope.OneShotOnRetry();
                                    }
                                        if (data[index].PersonView[i].PersonImageUrl) {
                                            $scope.IndInfo.imagePath = data[index].PersonView[i].PersonImageUrl;
                                        } else {
                                            $scope.IndInfo.imagePath = images.defaultPersonImage;
                                    }
                                    } else {
                                        if (data[index].PersonView[i].PersonImageUrl) {
                                            $scope.IndInfo.imagePath = data[index].PersonView[i].PersonImageUrl;
                                        } else {
                                            $scope.IndInfo.imagePath = images.defaultPersonImage;
                                    }
                                }
                        }
                            Child.childImage = data[index].PersonView[i].PersonImageUrl;
                            //}
                            Person.push(Child);
                    }
                        $scope.Persons.push(Person);
                });
            }
                if (!isEmptyOrUndefinedOrNull($scope.locationCalledFrom)) {
                    if ($scope.locationCalledFrom === 'updateViaBasketToPayment') {
                        $scope.contribution = $scope.recurrentData;
                        $scope.basketToPaymentOneShot($scope.contribution);
                    } else if ($scope.locationCalledFrom === 'goToContribute' || $scope.locationCalledFrom === 'updateViaPaymentConfirmationPage') {
                        $scope.getPaymentIntiatingDetail($scope.childId);
                    } else if ($scope.locationCalledFrom === 'updateViaNotificationView') {
                        $scope.getPaymentIntiatingDetail($scope.childId);
                    } else if ($scope.locationCalledFrom === 'addANewContribution') {
                        $scope.getPaymentIntiatingDetail($scope.childId);
                    } else if ($scope.locationCalledFrom === 'goToContributeViaBasket') {
                        setTimeout(function () {
                            $scope.IndInfo.imagePath = images.defaultPersonImage;
                            $("#select-option-groups").selectpicker("val", -1);
                            $scope.showPaymentType = false;
                    }, 50);
                }
            }
            }, function (error) {
        });
    }
}

    $("#contributeStartDate").on("change", function () {
        //$scope.recurrentEndDateStart = new Date($(this).val().split("/")[2], parseInt($(this).val().split("/")[1]), $(this).val().split("/")[0]);
        //$scope.endDates = "";
        $scope.changeFrequency($scope.value, $scope.ContractEndDate);
});
$("#contributeEndDate").on("change", function () {
        setTimeout(function () {
            $("#contributeEndDate").valid();
}, 50);
});
$scope.sendGemaltoData = function (gemaltoData) {
        var encryptedData = {};
        encryptedData.personId = $.cookie('personId');
        encryptedData.GemaltoResponse = gemaltoData;

        gemaltoFactory.eidUploadResponse(encryptedData).then(function (data) {
            if (data.data.Result) {
                //$scope.getPaymentIntiatingDetail($scope.childId);
                var res = paymentService.getPaymentIntiatingDetail($scope.contributorId, $scope.childId, $scope.entryPoint);
                if (!isEmptyOrUndefinedOrNull(res)) {
                    res.then(function (d) {
                        var response = JSON.stringify(d);
                        paymentDetail = JSON.parse(response);

                        if ($scope.optionSelected == RecurrentPremium) {
                            if (!isEmptyOrUndefinedOrNull(paymentDetail)) {
                                $scope.recurrentPaymentView = paymentDetail.RecurrentPaymentView;
                        }
                            $scope.checkPaymentDetail(2, $scope.recurrentPaymentView, null);
                        }
                        else if ($scope.optionSelected == OneShot) {
                            if (!isEmptyOrUndefinedOrNull(paymentDetail)) {
                                $scope.oneShotPaymentView = paymentDetail.OneShotPaymentView[0];
                        }
                            $scope.checkPaymentDetail(1, null, $scope.oneShotPaymentView);
                    }
                });
            }

                $scope.recurrentPaymentView.IsUploadIdExists = true;
                $scope.hideIdentityDetails = true;
                $scope.hideContinueButton = true;
                $scope.hidePlanWhenShowingIdentityDetails = false;
                genericSuccessMessageDisplay(Resources.EidDataSavedSucessfully);
            }
            else {
                $scope.hideIdentityDetails = false;
                $scope.hideContinueButton = false;
                $scope.hidePlanWhenShowingIdentityDetails = true;
                genericErrorMessageDisplay(Resources.EidProcessingCancelled);
        }
});
}
localStorage.fromPaymentStatusScreen = false;
}]);

myAppangular.controller("paymentBasketController", ["$scope", "$rootScope", "$filter", "$state", "$stateParams", "WebApiService", "paymentService", "FormSubmitter", function ($scope, $rootScope, $filter, $state, $stateParams, WebApiService, paymentService, FormSubmitter) {
    $scope.contributionList = null;
    $scope.$parent.recurrentSelected = false;
    $scope.$parent.hideRecButtons = true; //basket controller
    if ($stateParams.obj != null) {
        angular.element(".contribution-payment-content").scope().contributeCond = $stateParams.obj.hideContributeView;
        angular.element(".contribution-payment-content").scope().hideOneShotButtons = $stateParams.obj.hideContributeView;
    }
    $scope.paymentDetail = {};
    $scope.paymentDetail.ContributorViewModel = {};
    $("#payAtOnce").removeAttr("disabled").removeClass("disabled");

    $scope.init = function () {
        $scope.getListOfContributionForAPerson();
    }
    $scope.getListOfContributionForAPerson = function () {
        var parentId = $.cookie("personId");
        var res = paymentService.getListOfContributionForAPerson(parentId);

        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (data) {
                if (data.OneShotPaymentView.length == 0) {
                    $scope.$parent.paymentError = true;
                    $("#newPayment").css("display", "block")
                    $("#payAtOnce").css("display", "none")
                } else {
                    $("#newPayment").css("display", "block")
                }
                var response = JSON.stringify(data);
                var data = JSON.parse(response);
                $scope.contributionList = data.OneShotPaymentView;
                $scope.recurrentList = data.RecurrentView;
                $scope.languageCulture = $.cookie("language");
                if ($scope.contributionList) {
                    for (i = 0; i < $scope.contributionList.length; i++) {
                        if (!isEmptyOrUndefinedOrNull($scope.contributionList[i].ChildView.PersonImageUrl)) {
                            $scope.contributionList[i].ChildView.PersonImage = $scope.contributionList[i].ChildView.PersonImageUrl;
                        } else {
                            $scope.contributionList[i].ChildView.PersonImage = images.defaultPersonImage;
                        }
                        if (!isEmptyOrUndefinedOrNull($scope.contributionList[i].LongTermPlanView)) {
                            $scope.contributionList[i].LongTermPlanView.OldAmount = formatAmountField($scope.contributionList[i].LongTermPlanView.OldAmount, currentLanguage);
                        } else if (!isEmptyOrUndefinedOrNull($scope.contributionList[i].ShortTermPlanView)) {
                            $scope.contributionList[i].ShortTermPlanView.OldAmount = formatAmountField($scope.contributionList[i].ShortTermPlanView.OldAmount, currentLanguage);
                        }
                        if (!isEmptyOrUndefinedOrNull($scope.contributionList[i].ChildView)) {
                            $scope.contributionList[i].ChildView.FormattedUpdatedDate = getDateInString($scope.contributionList[i].ChildView.FormattedUpdatedDate, DATE_FORMAT.DD_MONTH_YYYY, currentLanguage, SEPARATOR.SPACE);
                        }
                    }
                    $scope.basketID = data.BasketId;
                    //debugger;
                    $("#basketCount").html($scope.contributionList.length);
                }
                $scope.basketID = data.BasketId;
                if ($scope.contributionList) {
                    $("#viewContributionList").show();
                    // $scope.hideEmptyBasket = true;
                    if (data) {
                        $.cookie("basketId", data.BasketId);
                    }
                    for (i = 0; i < $scope.contributionList.length; i++) {
                        if ($scope.contributionList[i].ShortTermPreBirth) {
                            // $("#contributionDate").removeClass("payment-overflow")
                        } else {
                            $("#contributionDate").addClass("payment-overflow");
                        }
                    }
                    if (data.IsShortTermPreBirth == false) {
                        if ($scope.contributionList.length == 0) {
                            $scope.paymentError = true;
                        } else {
                            $("#payAtOnce").attr("disabled", "disabled").addClass("disabled");
                            $scope.paymentError = false;
                        }
                    } else {
                        $("#payAtOnce").removeAttr("disabled").removeClass("disabled");
                        $scope.paymentError = true;
                    }
                } else {
                    $scope.contributeCond = false;
                    $("#viewContributionList").hide();
                    $("#newPayment").css("display", "block")
                }
                // For recurrent section

                if ($scope.recurrentList != undefined && $scope.recurrentList.length) {
                    for (i = 0; i < $scope.recurrentList.length; i++) {
                        if ($scope.recurrentList[i].ChildView.PersonImageUrl != null) {
                            $scope.recurrentList[i].ChildView.PersonImageUrl = $scope.recurrentList[i].ChildView.PersonImageUrl;
                        } else {
                            $scope.recurrentList[i].ChildView.PersonImageUrl = images.defaultPersonImage;
                            // $scope.recurrentList[i].ChildView.PersonFirstName = $scope.recurrentList[i].ChildView.PersonFirstName;
                        }

                        $scope.recurrentList[i].accountFrequeny = $scope.recurrentList[i].Frequency;
                        if ($scope.recurrentList[i].LongTermPlanView !== null && $scope.recurrentList[i].ShortTermPlanView !== null) {
                            $scope.recurrentList[i].LongTermPlanView.NewAmount = formatAmountField($scope.recurrentList[i].LongTermPlanView.NewAmount, currentLanguage);

                            if ($scope.recurrentList[i].LongTermPlanView.NewAmount.trim() != "0,00" && $scope.recurrentList[i].LongTermPlanView.NewAmount.trim() != "0.00") {
                                $scope.recurrentList[i].recurrentPaymentLongTerm = true;
                            } else {
                                $scope.recurrentList[i].recurrentPaymentLongTerm = false;
                            }
                            $scope.recurrentList[i].RecurrentInitiated = getDateInString($scope.recurrentList[i].RecurrentInitiated, DATE_FORMAT.DD_MONTH_YYYY, currentLanguage, SEPARATOR.SPACE);

                            $scope.recurrentList[i].ShortTermPlanView.NewAmount = formatAmountField($scope.recurrentList[i].ShortTermPlanView.NewAmount, currentLanguage);
                            if ($scope.recurrentList[i].ShortTermPlanView.NewAmount.trim() != "0,00" && $scope.recurrentList[i].ShortTermPlanView.NewAmount.trim() != "0.00") {
                                $scope.recurrentList[i].recurrentPaymentShortTerm = true;
                            } else {
                                $scope.recurrentList[i].recurrentPaymentShortTerm = false;
                            }
                        } else if ($scope.recurrentList[i].LongTermPlanView !== null) {
                            $scope.recurrentPaymentLongTerm = true;
                            $scope.recurrentList[i].LongTermPlanView.NewAmount = formatAmountField($scope.recurrentList[i].LongTermPlanView.NewAmount, currentLanguage);
                            $scope.recurrentList[i].RecurrentInitiated = getDateInString($scope.recurrentList[i].RecurrentInitiated, DATE_FORMAT.DD_MONTH_YYYY, currentLanguage, SEPARATOR.SPACE);
                        } else if ($scope.recurrentList[i].ShortTermPlanView !== null) {
                            $scope.recurrentPaymentShortTerm = true;
                            $scope.recurrentList[i].ShortTermPlanView.NewAmount = formatAmountField($scope.recurrentList[i].ShortTermPlanView.NewAmount, currentLanguage);
                            $scope.recurrentList[i].RecurrentInitiated = getDateInString($scope.recurrentList[i].RecurrentInitiated, DATE_FORMAT.DD_MONTH_YYYY, currentLanguage, SEPARATOR.SPACE);
                        }
                        $scope.recurrentList[i].NextDueDate = getDateInString($scope.recurrentList[i].NextDueDate, DATE_FORMAT.DD_MONTH_YYYY, currentLanguage, SEPARATOR.SPACE);
                    }
                }

                
            }, function (error) {
                $scope.recurrenttimesoption = "error";
                
            });
        }
    }

    $scope.deleteContribution = function (contribution) {
        $scope.hideDeleteRecurrent = false;
        $scope.contributionObj = contribution;
        $scope.contributionObj.BasketId = $scope.basketID;
    }
    $scope.deleteContributionDetails = function (contribution) {

        paymentService.deleteContributionDetails($scope.contributionObj).success(function (data, status) {
            $("#deletePaymentModal").modal("hide");
            $scope.hideDeleteRecurrent = true;
            $scope.getListOfContributionForAPerson();
        })
            .error(function (data, status) {
                $("#deletePaymentModal").modal("hide");
                genericErrorMessageDisplay(Resources.RemoveFromBasket_Failed);
            });
    }

    $scope.modifyPaymentModal = function (contribution) {
        // $rootScope.$broadcast("basket-to-paymnet", { any: { "contributionData": contribution } });
        localStorage.setItem("isContributionUpdate", "true");
        $("html, body").animate({
            scrollTop: 0
        }, "fast");

        $state.go("contribute", {
            recurrentData: contribution,
            childId: contribution.ChildView.PersonId,
            locationCalledFrom: 'updateViaBasketToPayment'
        }, {
            reload: true
        });

        $scope.disableFieldLong = BOOLEAN.FALSE;
        $scope.longTextMessageLong = BOOLEAN.FALSE;
        $scope.shortTextMessageLong = BOOLEAN.FALSE;
        $scope.disableFieldShort = BOOLEAN.FALSE;
        $scope.longTextMessageShort = BOOLEAN.FALSE;
        $scope.shortTextMessageShort = BOOLEAN.FALSE;
        $scope.enableField('longTermValue');
        $scope.enableField('shortTermValue');
    }
    $scope.modifyBasket = function (longTermAmount, shortTermAmount, userMessage) {
        paymentDetail.OneShotPaymentView[0].Message = userMessage;
        paymentDetail.OneShotPaymentView[0].LongTermPlanView.NewAmount = longTermAmount;
        paymentDetail.OneShotPaymentView[0].ShortTermPlanView.NewAmount = shortTermAmount;
        paymentDetail.RecurrentPaymentView = null;
        paymentDetail.IsContributionUpdate = true;
        var res = paymentService.addToBasket(paymentDetail);

        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (d) {
            }
                , function (error) {
                });
        }
    }
    

    $scope.payAtOnce = function () {
        $scope.paymentDetail.ContributorViewModel.PersonId = $scope.contributorId;
        $scope.paymentDetail.BasketId = $.cookie("basketId");
        $.cookie("FromBasket", true); // = true;
        localStorage.setItem("isFromBasket", true);
        var res = paymentService.payAll($scope.paymentDetail);//.success(function (data, status) {
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (data) {
                var urlResponse = JSON.stringify(data.data);
                response = JSON.parse(urlResponse);

                if (response != undefined || response != null) {
                    var transactionId = response.PaymentReferenceNumber;
                    var paymentReferenceNumber = response.PaymentReferenceId;
                    var totalAmount = response.BasketAmount;
                    paymentServices(transactionId, paymentReferenceNumber, totalAmount, $scope.contributorId);
                }
            }, function (error) {
            });

        }
    }

    function paymentServices(transactionId, paymentReferenceNumber, totalAmount, personId) {
        var postData = {
            UserId: personId,
            Amount: totalAmount,
            TransactionId: transactionId,
            PaymentReference: paymentReferenceNumber
        };
        var res = paymentService.paymentGateway(postData).success(function (paymentRes, status) {
            FormSubmitter.submit(paymentRes.RedirectionUrl, "POST", paymentRes);
        })
                        .error(function (paymentRes, status) {
                        });
        
    }

    $scope.generateUUID = function () {
        // http://www.ietf.org/rfc/rfc4122.txt
        var s = [];
        var hexDigits = "0123456789abcdef";
        for (var i = 0; i < 36; i++) {
            s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
        }
        s[14] = "4"; // bits 12-15 of the time_hi_and_version field to 0010
        s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
        s[8] = s[13] = s[18] = s[23] = "-";

        var uuid = s.join("");
        return uuid;
    }
    $scope.init();
}]);

myAppangular.directive("dropdowndirective", function () {
    return {
        link: function ($scope, element, attrs) {
            var watch = $scope.$watch(function () {
                return element.children().length;
            }, function () {
                $scope.$evalAsync(function ($scope) {
                    $(element).selectpicker("destroy");
                    $(element).find("option").each(function () {
                        if ($(this).val().indexOf("?") != -1) {
                            $(this).remove();
                        }
                    });
                    $(element).selectpicker();
                    if (($scope.Persons != "undefined") && ($scope.Persons != null)) {
                        if (attrs.info == "img") {
                            var count = 2;
                            for (var i = 0; i < $scope.Persons.length; i++) {
                                for (var j = 0; j < $scope.Persons[i].length; j++) {
                                    $(".dropdown-menu li[data-original-index=" + count + "] a.option-with-image").prepend("<img class='dropdown-image-value' src=" + $scope.Persons[i][j].childImage + " />");
                                    count++;
                                }
                            }
                        }
                    }
                });
            });
        }
    }
});