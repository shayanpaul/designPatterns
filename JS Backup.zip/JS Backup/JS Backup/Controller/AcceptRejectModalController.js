﻿myAppangular.controller("acceptDeclineSupporterModal", ["$scope","$state", "$rootScope", "SupporterService", function ($scope,$state, $rootScope, SupporterService) {
    $scope.acceptSupporterModalVisible = false;
    
    $rootScope.$on('acceptRejectSupporter', function (event, args) {
        $scope.acceptSupporterModalVisible = false;
        var supporterId = args.any.timelineID;
        var popupRequired = args.any.popupRequired;
       
        SupporterService.GetSupporterInvitation(supporterId).then(
            function (data) {
                
                $scope.InvitationInfo = {
                    ActionReference: supporterId,
                    inviterFirstName: data.InviterFirstName,
                    inviterLastName: data.InviterLastName,
                    invitedFirstName: data.InvitedFirstName,
                    invitedLastName: data.InvitedLastName,
                    invitedNickName: data.InvitedNickName,
                    inviterNickName: data.InviterNickName,
                    inviterRelationship: data.InviterRelationship,
                    inviteMessage: data.InviteMessage,
                };

                if (data.InviterImageUrl != null)
                    $scope.InvitationInfo.inviterImage = data.InviterImageUrl;
                else
                    $scope.InvitationInfo.inviterImage = images.defaultPersonImage;
                if (popupRequired) {
                    $scope.acceptSupporterModalVisible = true;
                }
                
                localStorage.setItem("childId", data.InviterChildId);
                if (!popupRequired) {
                    $rootScope.$broadcast('gotocontributeFromNotification');
                }

            },
                function (error) {
                
        }
        );
    });

    $rootScope.$on('AcceptInvitationBySupporter', function (event, args) {
        var notificationId = args.any.notificationId;

        SupporterService.AcceptInvitationBySupporter(notificationId).then(
            function (data) {
                $scope.acceptSupporterModalVisible = false;
                angular.element("#notificationIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                angular.element("#notificationId" + notificationId).find(".notifications-action-btns").find("button").attr("disabled", "disabled").addClass("disabled");
                angular.element("#timelineIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                angular.element("#timelineIds" + notificationId).parent().removeClass("actionable").addClass("non-actionable");
                angular.element("#supportedChildDetails").scope().initSupporterChild();
                $rootScope.$broadcast('refresh-timeline', {});//added by anshul for invite supporter module
            },
            function (error) {
               
            }
        );
    });

    $rootScope.$on('DeclineInvitationBySupporter', function (event, args) {
        var notificationId = args.any.notificationId;

        SupporterService.DeclineInvitationBySupporter(notificationId).then(
            function (data) {
                $scope.acceptSupporterModalVisible = false;
                angular.element("#notificationIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                angular.element("#notificationId" + notificationId).find(".notifications-action-btns").find("button").attr("disabled", "disabled").addClass("disabled");
                angular.element("#timelineIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                angular.element("#timelineIds" + notificationId).parent().removeClass("actionable").addClass("non-actionable");
                angular.element("#supportedChildDetails").scope().initSupporterChild();
                $rootScope.$broadcast('refresh-timeline', {});//added by anshul for invite supporter module
            },
            function (error) {
               
            }
        );
    });

    $scope.AcceptInvitationBySupporter = function (notificationId) {        
        $rootScope.$broadcast('AcceptInvitationBySupporter', { any: { "notificationId": notificationId } });
    }

    $scope.DeclineInvitationBySupporter = function (notificationId) {
        SupporterService.DeclineInvitationBySupporter(notificationId).then(
            function (data) {
                $scope.acceptSupporterModalVisible = false;
                angular.element("#notificationIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                angular.element("#notificationId" + notificationId).find(".notifications-action-btns").find("button").attr("disabled", "disabled").addClass("disabled");
                angular.element("#timelineIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                angular.element("#timelineIds" + notificationId).parent().removeClass("actionable").addClass("non-actionable");
                $rootScope.$broadcast('refresh-timeline', {});//added by anshul for invite supporter module

            },
            function (error) {
                
            }
        );
    }
}]);

myAppangular.controller("timelineEventInvitationController", ["$scope", "$state", "$rootScope", "WebApiService", function ($scope,$state, $rootScope, WebApiService) {
    $rootScope.$on('eventDetailsFromTimelineAccept', function (event, args) {
        var eventId = args.any.eventId;
        //US2799--start
        var url = "/events/" + eventId;
            var res = WebApiService.getWebApiData(url, currentLanguage);
            if (res != undefined) {
                res.then(function (d) {
                    var response = JSON.stringify(d.data);
                    var data = JSON.parse(response);
                    $scope.EventInvitationInfo = {};
                    $scope.EventInvitationInfo.FormattedEventDate = data.FormattedEventDate;
                    $scope.EventInvitationInfo.EventMessage = data.EventMessage;
                    $scope.EventInvitationInfo.EventName = data.EventName;
                    $scope.EventInvitationInfo.EventDate = data.EventDate;
                    $scope.EventInvitationInfo.EventPlace = data.EventPlace;
                    $scope.EventInvitationInfo.ChildName = data.ChildName;
                    $scope.EventInvitationInfo.ChildImage = data.ChildImageUrl;
                    $scope.EventInvitationInfo.ParentName = data.ParentName;
                    $scope.EventInvitationInfo.ParentImage = data.ParentImageUrl;
                    $scope.EventInvitationInfo.Projectlist = data.NowProjectViewModel;
                    $scope.EventInvitationInfo.ShowProject = data.ShowProject;
                    localStorage.setItem("childId", data.SelectedChildId);

                    if (data.EventPictureUrl != null)
                        $scope.EventInvitationInfo.EventPicture = data.EventPictureUrl;
                    else
                        $scope.EventInvitationInfo.EventPicture = images.defaultPersonImage;

                    $("#invitationEmailModal").modal();
                    $('.notifications-header .close').trigger("click");
                    $rootScope.$broadcast('refresh-timeline', {});
                },
              function (error) {
                  
              });
            }        

        //US329--end
    });

    $rootScope.$on('eventDetailsFromTimelineApprove', function (event, args) {
        var eventId = args.any.eventId;

        var url = "/events/" + eventId;
        var res = WebApiService.getWebApiData(url);
        
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                $scope.existingEventData = data;
                var childId = data.SelectedChildId;
                if ($.cookie("personId") == childId) {
                    parentId = $scope.childParentId;
                } else {
                    parentId = $.cookie("personId");
                }
                var url = "/person/" + $.cookie("personId") + "/child/" + childId + "/supporters";
                $scope.parentId = $.cookie("personId");
                $scope.languageid = $.cookie("language");
                $scope.supporterChildIds = [];
                if ($.cookie("personId") != "" && $.cookie("personId") != undefined && childId != "" && childId != undefined) {
                    var res = WebApiService.getWebApiData(url);
                }
                if (res != undefined) {
                    res.then(function (d) {
                        var response = JSON.stringify(d.data);
                        var data = JSON.parse(response);
                        $scope.ActiveSupporterInfo = [];
                        if (data.length > 0) {
                            $.each(data, function (index) {
                                $scope.Info = {
                                };
                                $scope.Info.firstName = data[index].PersonFirstName;
                                $scope.Info.lastName = data[index].PersonLastName;
                                if (data[index].PersonNickName) {
                                    $scope.Info.nickName = data[index].PersonNickName;
                                } else {
                                    $scope.Info.nickName = data[index].PersonFirstName + " " + data[index].PersonLastName;
                                }
                                $scope.Info.email = data[index].PersonEmail;
                                $scope.Info.roleValue = data[index].supporterRoleValue;
                                $scope.Info.roleText = data[index].supporterRoleText;
                                if (data[index].PersonImageUrl) {
                                    $scope.Info.image = data[index].PersonImageUrl;
                                } else {
                                    $scope.Info.image = images.defaultPersonImage;
                                }
                                $scope.Info.parentId = $.cookie("personId");
                                $scope.Info.supporterId = data[index].PersonId;
                                $scope.Info.cultureCode = $.cookie("language");
                                $.each(data[index].supporterRoleText, function (roleIndex) {
                                    if (data[index].Status === Status.Active && data[index].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                                        $("#divActive").css("display", "block");
                                        $scope.ActiveSupporterInfo.push($scope.Info);
                                    }
                                });
                            });
                        }
                        $scope.ActiveRegisteredSupporterInfo = [];
                        $.each($scope.ActiveSupporterInfo, function (index) {
                            $scope.supInfo = {};
                            $scope.supInfo.supporterFirstName = $scope.ActiveSupporterInfo[index].firstName;
                            $scope.supInfo.supporterLastName = $scope.ActiveSupporterInfo[index].lastName;
                            if ($scope.ActiveSupporterInfo[index].image != null) { // need to be checked as per new image URL
                                $scope.supInfo.supporterImage = $scope.ActiveSupporterInfo[index].image; // the image is already decoded base64
                            } else {
                                $scope.supInfo.supporterImage = images.defaultPersonImage;
                            }
                            $scope.supInfo.supporterID = $scope.ActiveSupporterInfo[index].supporterId;
                            if ($scope.ActiveSupporterInfo[index].roleValue[0] == 2)
                                $scope.ActiveRegisteredSupporterInfo.push($scope.supInfo);
                        })

                        $rootScope.$broadcast('eventModal-started', { any: { "SupporterInfoList": $scope.ActiveRegisteredSupporterInfo, "images": images, "editevent": true, "data": $scope.existingEventData, "selectedChildId": childId, "isCreatedByChild": true, "isApprove": true } });
                    }, function (error) {
                        
                    });
                }

                
            }, function (error) {
            });
        }

    });

    $scope.goToContributeFromTimeline = function (obj) {
        localStorage.setItem("contributeCond", obj);
        localStorage.setItem("isContributionUpdate", false);
        localStorage.setItem("fromTimeline", true);
        $state.go("contribute", {
            locationCalledFrom: 'updateViaNotificationView'
        });
    }
}
]);
