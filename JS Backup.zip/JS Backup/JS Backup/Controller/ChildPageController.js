﻿/*global $, jQuery, alert, window*/
/*jslint browser: true*/
//var childPage = angular.module("childPage", []);

childPage.controller("childPageController", ["$scope", "$rootScope", "$stateParams", "$state", "$filter", "EditProfileService", "InvitationService", "ChildProfileService", "WebApiService", "savingSchoolService", "DisplaySupportersService", "ModalFactory", "utilityFactory", 'allSupporterData', 'parentalsettingsService', function ($scope, $rootScope, $stateParams, $state, $filter, EditProfileService, InvitationService, ChildProfileService, WebApiService, savingSchoolService, DisplaySupportersService, ModalFactory, utilityFactory, allSupporterData, parentalsettingsService) {
    $scope.currentStateName = $rootScope.$state.current.name;
    $scope.loginAsChildEntry = $stateParams.childEntry;
    $scope.selectedChildID = $stateParams.childId;//String
    $scope.actualChildId = parseInt($stateParams.childId);//Integer
    localStorage.setItem("IsUserSettingsEntryPoint", "false");
    localStorage.setItem("isSavingSchool", false);
    $scope.showlongtermforInfant = true;
    $scope.showshorttermforInfant = true;
    $scope.addPlanSb = function () {
        linkUrl = "/" + currentLanguage + "/Subscription/start?pageName=childDetails";
        location.href = linkUrl + "&childId=" + $scope.selectedChildID + "&from=ST";
    };
    $scope.myYongoPlanActive = true;
    $scope.hideContributeButton = false;
    if ($rootScope.isChild) {
        $scope.hideContributeButton = true;
    }
    $scope.showEventBackLabel = false;
    $scope.eventModalVisible = false;
    $scope.showPlanOverviewTab = true;
    $scope.showSavingSchoolTab = true;
    $scope.showSupporterTab = true;
    $scope.showEventTab = true;
    $scope.showTrophyTab = true;
    $scope.showEditProfileTab = true;
    $scope.allCountryList = [];
    $scope.editChildPictureUrl = '';
    $scope.isSTExceedLmtChilPage = false;
    var shortTermPlanValidationType = 1;
    $scope.$parent.selectedchildidforevent = "";
    $scope.ifcratechildselected = true;
    $scope.uploadpicSuceess = true;
    $scope.realtionShipselected = false;
    $scope.childListSelect = [];
    $scope.iConfirmParent = true;
    $scope.nameRegexp = nameRegex;
    $scope.emailregexp = emailRegex;
    $scope.userIsmandatory = true;
    $("#supporter-details-transaction").css("display", "none");
    $(document).bind("FileuploadCancelled", function (e, status) {
        $scope.uploadpicSuceess = true;
    });
    $scope.nameRegexp = nameRegex;
    $scope.emailRegexp = emailRegex;
    $scope.txtEventDatepattern = false;
    $scope.txtEventDatevalue = false;
    $scope.txtEventDateDate = false;
    $scope.button = showMore;
    $scope.hideCurrentvalueST = true;
    $scope.clickCount = 0;
    $scope.PlanInfo = {};
    $scope.PartnerInfo = {};
    $scope.PartnerInfoExists = false;
    $scope.id = $.cookie("childId");
    $scope.childList = [];
    $scope.childList.push(parseInt($scope.id));
    $scope.selectedSupporter = {};
    $scope.backBtnInSupporterOverviewShow = false;
    $scope.supporterChildIds = [];
    $scope.isEditEventPage = false;
    $scope.planDetailIconLongTerm = true;
    $scope.planDetailIconShortTerm = true;
    $scope.languageid = $.cookie("language");
    $scope.selectNowProjects = [];
    $scope.IndInfo = {};
    $scope.showAddButton = true;
    $scope.showCloseButton = false;
    $scope.relationshipcount = [];
    $scope.childListSelect = [];
    //Parameters to fill and rearrange child details
    $scope.GlobalGroupInfo = [];
    //Parameters to fill and rearrange support details
    $scope.GlobalSupportInfo = [];
    $scope.isAValidEmailID = false;
    $scope.inputAdminEmail = {
        "required": false,
        "pattern": false
    };

    $scope.childUserName = '';
    $scope.childPassword = '';
    var allSupporterInfo = allSupporterData.getData('Dataname');
    var supporterData = "";
    if ($.isEmptyObject(allSupporterInfo)) {
        var url = "/members/" + $.cookie("personId") + "/supporters";
        var language = $.cookie("language");
        if ($.cookie("personId") != null && $.cookie("personId") != undefined) {
            WebApiService.getWebApiData(url, language).then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                supporterData = data;
                allSupporterData.setData('Dataname', { 'supporterArr': supporterData });
            });
        }
    }
    $scope.windowWidth = window.innerWidth;
    var todaysDate = new Date();
    todaysDate = todaysDate.toDateString().split(" ");
    $scope.dateString = todaysDate[2] + " " + todaysDate[1] + " " + todaysDate[3];
    $scope.init = function () {
        $scope.paymentController = {};
        $scope.savingSchoolController = {};
        $scope.getAllSupporterByParentAndChild();
        $scope.clearTransactionHistoryObjectAndReset();
        var childId = $stateParams.childId;
        $scope.$on("DATAUPDATED", function () {
            var filterObject = ModalFactory.getData();
            $scope.filterDataObject = filterObject.filterDataObj;
            $scope.filterRequestObj = filterObject.requestObj;
            $scope.getTransactionsWithFilterCriteria(filterObject.locationFromWhereFilterIsCalled);
        });
        $scope.GetMyChildrenDetail();
        $scope.GetSupportChildrenDetail();
        $scope.ShowItemsOnChildOverview(childId);
        $scope.SetContentVisible(childId);
        $scope.GetAdminByChild();
        $scope.GetMyDetail();
        $scope.supporterIdList.length = 0;
        $scope.NonRegSupporterInfoList.length = 0;
        GetDefaultInviterDetails();
        GetMyChildernList();
        $scope.SetChildPersonalDataVisible(childId);
        $scope.isSupporterHistoryVisible = false;
        $scope.isTransactionHistoryVisible = false;
        $scope.IsAChild = false;
        $scope.isChildSupporterListToBeshown = false;
        if (localStorage.getItem("currentSection") === "event" && localStorage.getItem("sameNavigationHistory") === "true") {
            setTimeout(function () {
                $('.modal-body li #event').trigger('click');
            }, 100);
        }
        localStorage.setItem("currentSection", "plan");
    }
    if (localStorage.getItem("moneyOutConfirmSuccess") === "true") {
        $("#successfulYourPersonalDetailsAreSaved").text(Resources.MoneyOut_Success);

        $("#failSuccessGlyphicon").addClass("success-notification");
        $("#top .save-edit-details-notification").slideDown();
        setTimeout(function () {
            $("#top .save-edit-details-notification").slideUp();
        }, 10000);
        localStorage.setItem("moneyOutConfirmSuccess", "false");
    }

    $scope.broadcastChildId = function () {
        $rootScope.$broadcast('getSelected-childId', { any: { "selectedChildId": $scope.actualChildId, "parentPersonId": $scope.childParentId, "childFirstName": $scope.childFirstName } });
    }
    //Getting my children details
    $scope.GetMyChildrenDetail = function () {
        var childId = $stateParams.childId;
        GetMyChildren(childId);
    };

    //Getting My Child Details
    function GetMyChildren(childId) {
        if (childId == null || childId == 0) {
            childId = $.cookie("childId");
        }

        var personId = $.cookie("personId");

        ChildProfileService.GetMyChildrenDetail(personId).then(
            function (data) {
                if (localStorage.getItem("planOverviewChildLoggedIn") === "true") {
                    $scope.IsAChild = true;
                    localStorage.setItem("planOverviewChildLoggedIn", "false");
                }
                else {
                    $.each(data, function (index) {
                        $scope.GlobalGroupInfo = data;
                        setGroupInfo(childId);
                    });
                }
                $("#createevent").click(function () {
                    $scope.eventModalVisible = true;
                });
            },
            function (error) {
                $("#createevent").click(function () {
                    $scope.eventModalVisible = false;
                    genericErrorMessageDisplay(angular.element('#errorForPopupInstantiation').val());
                });
            }
        );
    }
    $scope.changeFilters = function (data) {
        $scope.filterDataObject.removeFromFilterData = data;
        ModalFactory.setchangefilterData($scope.filterDataObject);

        $rootScope.$broadcast("FilterUPDATED");
    };
    //Removing or deleting the previous cookie
    $scope.clearChildIdCookie = function () {
        $.cookie("childId", null, { path: "/" });
        localStorage.setItem("sameNavigationHistory", "false");
    }
    $scope.goToSupporter = function () {
        $state.go('supporters', {}, { reload: true });
    }
    $scope.goToDashboard = function () {
        $state.go('dashboard', {}, { reload: true });
    }
    $scope.RearrangedChild = function (child) {
        $scope.backButtonClick();
        $scope.clearTransactionHistoryObjectAndReset();
        localStorage.setItem("sameNavigationHistory", "true");
        $scope.hideCurrentvalueST = false;
        $.cookie("childId", null, { path: "/" });
        $("#editParentalControlContent,#editParentContent").addClass("collapsed").next().removeClass("in");
        $("#childCtrlQuesId").removeClass("in");
        $("#parentCtrlQuesId").removeClass("in");
        $(".about-metnav-desc").css("height", "auto");
        var childId = child.childId;
        $scope.childNickName = child.childNickName;
        setGroupInfo(childId);
        setSupportInfo(childId);
        $scope.id = childId;

        $.cookie("childId", childId, { path: "/" });
        $scope.ShowItemsOnChildOverview(childId);
        $scope.GetTransactionHistory(childId);
        $scope.GetAllEventInformation();
        //$scope.SetEditProfileContentVisible();
        $scope.GetParentInformtionForEditProfile();
        $scope.GetChildInformtionForEditProfile();
        $scope.SetContentVisible(childId);
        $scope.GetAdminByChild();
        $scope.isAdminSectionVisible = false;
        $scope.isAddAdminSectionVisible = false;
        $scope.isDeleteAdminSectionVisible = false;
        $scope.getAllSupporterByParentAndChild();
        $scope.GetParentalInformationBasedonParentID();
        //$scope.getSavingSchoolInformation();
        $scope.SetChildPersonalDataVisible(childId);
        // $scope.paymentController.new.getPaymentIntiatingDetail($.cookie("childId"));// For defect 5453
        // $scope.ChildProfile();
        if ($(".trans-history").is(":visible")) {
            $(".trans-history").css("display", "none");
            $scope.isChildSupporterListToBeshown = false;
            $scope.isSupporterHistoryVisible = false;
            $scope.isTransactionHistoryVisible = false;
            $(".long-term").css("left", "0%");
            $(".short-term").css("left", "0%");
        }
        var name = $("#myChildModal .active-menu .menu-label").text();
        $scope.sectionname = name;
        $rootScope.$broadcast('getSavingSchoolInfoForChild');
        //$scope.$broadcast.getSavingSchoolInformation();
    }
    $scope.backButtonClick = function () {
        $(".ss-container-left").animate({
            'left': '0'
        }).css("position", "relative");
        $(".ss-container-right").animate({
            'left': '115%'
        }).css("position", "absolute");
    }
    function setGroupInfo(topChildId) {
        var response = JSON.stringify($scope.GlobalGroupInfo);
        var data = JSON.parse(response);
        var lenMyChild = data.length;
        $scope.GroupInfoList = [];
        // $scope.IndInfo = {};
        $scope.IndChild = [];
        $.each($scope.GlobalGroupInfo, function (index) {
            $scope.Info = {};
            if (!data[index].IsPending || data[index].IsPendingSubscription) {
                if (data[index].PersonId == topChildId) {
                    $scope.IndInfo.firstName = data[index].PersonFirstName;
                    $scope.childFirstName = $scope.IndInfo.firstName;
                    $rootScope.childName = $scope.IndInfo.firstName;
                    $scope.childNickName = data[index].PersonNickName;
                    $scope.IndInfo.childId = data[index].PersonId;
                    $scope.IndInfo.childNickName = data[index].PersonNickName;
                    $scope.IndInfo.lastName = data[index].PersonLastName;
                    if (data[index].PersonImageUrl) {
                        $scope.IndInfo.imagePath = data[index].PersonImageUrl;
                        angular.element("#changeChild-image-web .demoImg").attr('src', $scope.IndInfo.imagePath);
                        angular.element("#changeChild-image-mobile .demoImg").attr('src', $scope.IndInfo.imagePath);
                    }
                    //else {
                    //    //$scope.IndInfo.imagePath = images.defaultPersonImage;
                    //}
                }
                $scope.Info.firstName = data[index].PersonFirstName;
                $scope.Info.lastName = data[index].PersonLastName;
                if (data[index].PersonImageUrl) {
                    $scope.Info.imagePath = data[index].PersonImageUrl;
                    $scope.Info.imageInChild = true;
                } else {
                    $scope.Info.imagePath = images.defaultPersonImage;
                    $scope.Info.imageInChild = false;
                }
                $scope.Info.parentId = $.cookie("personId");
                $scope.Info.childId = data[index].PersonId;
                $scope.IndInfo.cultureCode = $.cookie("language");
                $scope.Info.childNickName = data[index].PersonNickName;
                $scope.GroupInfoList.push($scope.Info);
            }
            else {
                if (data[index].PersonId == topChildId) {
                    $scope.IndInfo.firstName = data[index].PersonFirstName;
                    $scope.childFirstName = $scope.IndInfo.firstName;
                    $rootScope.childName = $scope.IndInfo.firstName;
                    $scope.childNickName = data[index].PersonNickName;
                    $scope.IndInfo.childId = data[index].PersonId;
                    $scope.IndInfo.childNickName = data[index].PersonNickName;
                    $scope.IndInfo.lastName = data[index].PersonLastName;
                    if (data[index].PersonImageUrl) {
                        $scope.IndInfo.imagePath = data[index].PersonImageUrl;
                        angular.element("#changeChild-image-web .demoImg").attr('src', $scope.IndInfo.imagePath);
                        angular.element("#changeChild-image-mobile .demoImg").attr('src', $scope.IndInfo.imagePath);
                    }
                    else {
                        $scope.IndInfo.imagePath = images.defaultPersonImage;
                    }
                }
            }
            //  alert(JSON.stringify($scope.Info.childId));
        });
    }

    function setSupportInfo(topChildId) {
        var response = JSON.stringify($scope.GlobalSupportInfo);
        var data = JSON.parse(response);
        $scope.SupportInfo = [];
        $scope.IndSupChild = {};
        // $scope.IndInfo = {};
        $.each(data, function (index) {
            if (data[index].PersonId == topChildId) {
                $scope.IndInfo.firstName = data[index].PersonFirstName;
                $scope.IndInfo.lastName = data[index].PersonLastName;
                $scope.childNickName = data[index].PersonNickName;
                if (data[index].PersonImageUrl) {
                    $scope.IndInfo.imagePath = data[index].PersonImageUrl;
                } else {
                    $scope.IndInfo.imagePath = images.defaultPersonImage;
                }
            }
            $scope.supportDetail = {};
            $scope.supportDetail.firstName = data[index].PersonFirstName;
            $scope.supportDetail.lastName = data[index].PersonLastName;
            if (data[index].PersonImageUrl) {
                $scope.supportDetail.imagePath = data[index].PersonImageUrl;
            } else {
                $scope.supportDetail.imagePath = images.defaultPersonImage;
            }
            //$scope.supportDetail.image = images.dataImage + data[index].PersonImage;// changes for defect 4957
            $scope.supportDetail.parentId = $.cookie("personId");
            $scope.supportDetail.childId = data[index].PersonId;
            $scope.supportDetail.childNickName = data[index].PersonNickName;

            for (var item = 0; item < data[index].RelatedPersonRole.length; item++) {
                if (data[index].RelatedPersonRole[item] == 5 || data[index].RelatedPersonRole[item] == 10) {
                    //$("#createevent").hide();
                    //Hide Create Event button for the Supporting Children
                }
            }
            $scope.SupportInfo.push($scope.supportDetail);
        });
    }

    function GetMySupportedChilderens(childId) {
        //if (childId == null || childId == 0) {
        //    childId = $.cookie("childId");
        //}

        var personId = $.cookie("personId");
        ChildProfileService.GetSupportChildrenDetail(personId).then(
            function (data) {
                $.each(data, function (index) {
                    $scope.GlobalSupportInfo = data;
                    setSupportInfo(childId);
                })
            },
            function (error) {
            }
        );
    }

    //Getting support children details
    $scope.GetSupportChildrenDetail = function () {
        var childId = $stateParams.childId;
        GetMySupportedChilderens(childId);
    }

    $scope.selectNowProjects = function () {
        radioButton1.setAttribute("onclick", "SetRadioAnswer(this)");
    }

    $scope.GetChildProfile = function () {
        var personId = $.cookie('personId');
        var childId = $stateParams.childId;
        $scope.getAllCountriesList();

        EditProfileService.GetUsersChildProfile(personId, childId).then(
         function (data) {
             if (data.profilePictureUrl != null) {
                 $scope.editChildPictureUrl = data.profilePictureUrl;
             }
             if (data.dateOfBirth == '0001-01-01T00:00:00') {
                 data.dateOfBirth = null;
             }
             if (data.userName != null) {
                 $scope.hasAccount = true;
             }
             data.countryCodeId = data.countryCodeId.toString();
             data.cityCodeId = data.cityZipCodeId.toString();

             $scope.childProfileDetails = data;
         },
         function (error) {
             genericErrorMessageDisplay();
         }
     );
    }

    $scope.showChildAccount = function () {
        $scope.hasAccount = true;
        $scope.createAccount = true;
    }

    $scope.checkConfirmPassword = function (confirmPassword) {
        if (confirmPassword) {
            angular.element('#confirmPassword').valid();
        }
    }

    $scope.validateUserName = function (userName) {
        if (userName.trim()) {
            EditProfileService.checkUserNameExist(userName).then(
             function (data) {
                 if (data) {
                     $("#userName").closest(".form-group").find("label.error").remove();
                     $("#userName").closest(".form-group").addClass("group-validation-error user-exist").append("<label class='error'>" + $('#userName').attr('data-msg-aagjeusername') + "</label>");
                     $(".save-child-profile").prop('disabled', true).addClass("disabled");
                 }
                 else {
                     $("#userName").closest(".form-group").removeClass("group-validation-error user-exist");
                     $("#userName").closest(".form-group").find("label.error").remove();
                     $(".save-child-profile").prop('disabled', false).removeClass("disabled");;
                 }
             },
             function (error) {
                 genericErrorMessageDisplay();
             }
     );
        }
    }
    $scope.removeExistingUserErrorMsg = function () {
        $("#userName").closest(".form-group").removeClass("group-validation-error user-exist");
        $("#userName").closest(".form-group").find("label.error").remove();
    }
    $scope.CreateChildAccount = function (newChildProfileObj) {
        if (!$('#childAccountForm').valid()) {
            $('#childAccountForm').valid();
            return;
        }

        //$scope.childUserName = $('#userName').val();
        //$scope.childPassword = $('#password').val();
        var request = {
            userName: newChildProfileObj.childUserName,
            password: newChildProfileObj.childPassword
        };

        EditProfileService.CreateChildAccount($stateParams.childId, request).then(
         function (data) {
             genericSuccessMessageDisplay();
             $scope.createAccount = false;
             $scope.childProfileDetails.userName = newChildProfileObj.childUserName;
         },
         function (error) {
             genericErrorMessageDisplay();
         }
     );
    }

    $scope.RearrangedSupportedChild = function (child) {
        //$("ul.secondary-menu > li:eq(0) > a ").trigger("click");
        setTimeout(function () {
            $("ul.secondary-menu > li:eq(0) > a ").trigger("click");
        }, 200);//With less than 200 also works, kept 200 for future
        $scope.clearTransactionHistoryObjectAndReset();
        $scope.hideCurrentvalueST = true;
        var childId = child.childId
        setGroupInfo(childId);
        setSupportInfo(childId);
        $scope.id = childId;
        $.cookie("childId", childId, { path: "/" });
        $scope.ShowItemsOnChildOverview(childId);
        $scope.GetTransactionHistory(childId);
        $scope.GetAllEventInformation();
        //$scope.SetEditProfileContentVisible();
        $scope.GetParentInformtionForEditProfile();
        $scope.GetChildInformtionForEditProfile();
        $scope.SetContentVisible(childId);
        $scope.GetAdminByChild();
        $scope.SetChildPersonalDataVisible(childId);
        $scope.childNickName = child.childNickName;
        if ($(".trans-history").is(":visible")) {
            $(".trans-history").css("display", "none");
            $scope.isChildSupporterListToBeshown = false;
            $scope.isSupporterHistoryVisible = false;
            $scope.isTransactionHistoryVisible = false;
            $(".long-term").css("left", "0%");
            $(".short-term").css("left", "0%");
        }
        var name = $("#myChildModal .active-menu .menu-label").text();
        $scope.sectionname = name;
    }

    //Changes for US5293 and 3627 to fetch all flags from backend to show/hide items in child overview page
    $scope.ShowItemsOnChildOverview = function (childId) {
        var personId = $.cookie("personId");
        ChildProfileService.ShowItemsOnChildOverview(personId, childId).then(
            function (data) {
                var showItems = data;
                $scope.recurrentPreLongTerm = true;
                $scope.recurrentPreShortTerm = false;
                $scope.hideNoShortTermMessage = false;
                $scope.hideNoShortTermData = true;
                $scope.hideCurrentvalueST = !showItems.ShowCurrentValueShortTerm;
                $scope.hideCurrentvalueLT = !showItems.ShowCurrentValueLongTerm;
                $scope.hideNoLongTerm = showItems.ShowLongTerm;
                $scope.hideNoShortTerm = showItems.ShowShortTerm;
                $scope.hideTransactionButton = !showItems.ShowTransactionButton;
                $scope.showProjectProgressBar = showItems.ShowProjectProgressBar;
                $scope.showCreateEventBtn = showItems.ShowCreateEvent;
                $scope.hideMoneyOut = !showItems.ShowMoneyOut;
                $scope.showCreateProjectButton = showItems.ShowAddProjects;
                $scope.showPlanOverviewTab = showItems.ShowSubmenuPlan;
                $scope.showSavingSchoolTab = showItems.ShowSubmenuSavingSchool;
                $scope.showSupporterTab = showItems.ShowSubmenuSupporter;
                $scope.showTrophyTab = showItems.ShowSubmenuTrophy;
                $scope.showEventTab = showItems.ShowSubmenuEvent;
                $scope.showEditProfileTab = showItems.ShowSubmenuEditProfile;
                $scope.showLongTerm = showItems.ShowLTPlan;
                $scope.showShortTerm = showItems.ShowSTPlan;
                $scope.hideAddPlanLongTerm = !showItems.ShowLTPlanAddIcon;
                $scope.planDetailIconLongTerm = showItems.ShowLTPlanInfoIcon;
                $scope.hidePendingValue = !showItems.ShowPendingAmount;
                $scope.hideAddPlanShortTerm = !showItems.ShowSTPlanAddIcon;
                $scope.planDetailIconShortTerm = showItems.ShowSTPlanInfoIcon;
                $scope.hideAvailableAmount = !showItems.ShowAvailableAmount;
                $scope.showProjectProgressBar = showItems.ShowProjectProgressBar;
                $scope.childSupporterForFilter = showItems.IsTheChildISupport;
                $scope.hidePendingValueST = !showItems.ShowPendingAmountST;
                var showMenuOne = showItems.ShowMenuMyAagje;
                var showMenuTwo = showItems.ShowMenuAllSupporters;
                var showMenuThree = showItems.ShowMenuMyCredits;
                var showMenuFour = showItems.ShowMenuPartners;
                $rootScope.$broadcast("menu-flag-recieved", {
                    "flagObj": { "showMenuOne": showMenuOne, "showMenuTwo": showMenuTwo, "showMenuThree": showMenuThree, "showMenuFour": showMenuFour }
                });
                $scope.GetChildSavingPlan(childId);
            },
            function (error) {
            }
        );
    }
    $scope.GotoTransactionHistory = function () {
        $scope.GetTransactionHistory()
        $(".csm-sub-menu-list").removeClass("active-sub-menu");
        $('#transactionHistorytab').parent().addClass("active-sub-menu");
    };

    $scope.gotoSupporters = function () {
        allSupporterData.setData('Dataname', {});
        $state.go('supporters', {}, { reload: true });
    };
    //Getting child saving plans== need tp read the $scope
    $scope.GetChildSavingPlan = function (childId) {
        var personId = $.cookie("personId");
        $scope.childParentId = personId;
        ChildProfileService.GetChildSavingPlan(personId, childId).then(
            function (data) {
                if (data.Parent && data.Parent.PersonId) {
                    $scope.childParentId = data.Parent.PersonId;
                    $scope.getAllSupporterByParentAndChild();
                }
                if ($scope.showShortTerm) {
                    if ($scope.savingSchoolController.savingSchoolDetail != undefined) {
                        if (localStorage.getItem("currentSection") === "savingSchool") {
                            $scope.savingSchoolController.savingSchoolDetail.getSavingSchoolDetail($scope.personId, childId);
                        }
                    }
                    $scope.getShortTermProjectsDetail($scope.personId, childId);
                }
                // This seems to be incorrect validate whether below stringify is required

                var response = JSON.stringify(data);
                var data = JSON.parse(response);
                $scope.PlanInfo.PlanID = data.PlanId;
                //change for money out
                localStorage.setItem(planId, $scope.PlanInfo.PlanID);
                // $rootScope.$broadcast("localstorageplan");

                //if user dont have short term plan then Saving school section will not display
                if (data.IsSubscribingParent || data.IsAdmin || data.IsRegisterSupporter) {
                    if (data.LongTermPlanView != null && data.LongTermPlanView.PendingAmountForLongTerm != 0) {
                        if (currentLanguage == languages.languageEN || currentLanguage == languages.languageENSmall) {
                            //$scope.PendingAmount = data.LongTermPlanView.PendingAmountForLongTerm.toFixed(2);
                            $scope.PendingAmount = data.LongTermPlanView.PendingAmountForLongTerm;
                            $scope.PendingAmount = Number($scope.PendingAmount).toLocaleString(currentLanguage, { minimumFractionDigits: 2 })
                            $scope.PendingAmountAbsoluteVal = $scope.PendingAmount; //$scope.PendingAmount.split(".")[0].trim();
                            var pendingAmountLongTerm = $scope.PendingAmountAbsoluteVal.toString();
                            //$scope.PendingAmountDecimalVal = "." + $scope.PendingAmount.split(".")[1];
                            $.each($('.available-pending-amount'), function () {
                                var price = pendingAmountLongTerm;
                                $(this).html(price.replace(/(\D*)(\d*\.)(\d*)/, '<span style="font-weight: 400;">$2</span><span style="font-weight: 400;">$3</span>'));
                            });
                        } else {
                            var PendingAmount = data.LongTermPlanView.PendingAmountForLongTerm;
                            $scope.PendingAmount = $filter("currency")(PendingAmount, "");
                            $scope.PendingAmountAbsoluteVal = $scope.PendingAmount;//$scope.PendingAmount.split(",")[0].trim();
                            //$scope.PendingAmountDecimalVal = "," + $scope.PendingAmount.split(",")[1];
                            $.each($('.available-pending-amount'), function () {
                                var price = $scope.PendingAmount;
                                $(this).html(price.replace(/(\D*)(\d*\,)(\d*)/, '<span style="font-weight: 400;">$2</span><span style="font-weight: 400;">$3</span>'));
                            });
                        }
                    }

                    if (data.ShortTermPlanView != null && data.ShortTermPlanView.PendingAmountForShortTerm != 0) {
                        if (currentLanguage == languages.languageEN || currentLanguage == languages.languageENSmall) {
                            //Adding code for pending amount
                            $scope.PendingAmountST = data.ShortTermPlanView.PendingAmountForShortTerm;
                            $scope.PendingAmountST = Number($scope.PendingAmountST).toLocaleString(currentLanguage, { minimumFractionDigits: 2 })
                            $scope.PendingAmountAbsoluteValST = $scope.PendingAmountST; //$scope.PendingAmount.split(".")[0].trim();
                            var pendingAmountShortTermST = $scope.PendingAmountAbsoluteValST.toString();
                            //$scope.PendingAmountDecimalVal = "." + $scope.PendingAmount.split(".")[1];
                            $.each($('.available-pending-amount'), function () {
                                var price = pendingAmountShortTermST;
                                $(this).html(price.replace(/(\D*)(\d*\.)(\d*)/, '<span style="font-weight: 400;">$2</span><span style="font-weight: 400;">$3</span>'));
                            });
                        } else {
                            //Adding code for Pending Amount
                            var PendingAmountST = data.ShortTermPlanView.PendingAmountForShortTerm;
                            $scope.PendingAmountST = $filter("currency")(PendingAmountST, "");
                            $scope.PendingAmountAbsoluteValST = $scope.PendingAmountST;//$scope.PendingAmount.split(",")[0].trim();
                            //$scope.PendingAmountDecimalVal = "," + $scope.PendingAmount.split(",")[1];
                            $.each($('.available-pending-amount'), function () {
                                var price = $scope.PendingAmountST;
                                $(this).html(price.replace(/(\D*)(\d*\,)(\d*)/, '<span style="font-weight: 400;">$2</span><span style="font-weight: 400;">$3</span>'));
                            });
                        }
                    }
                    //else {
                    //    $scope.hidePendingValue = true;
                    //}

                    if (data.ShortTermPlanView != null && data.ShortTermPlanView.AvailableAmountForShortTerm != data.ShortTermPlanView.CurrentPlanValue) {
                        if (currentLanguage == languages.languageEN || currentLanguage == languages.languageENSmall) {
                            //$scope.AvailableAmount = data.ShortTermPlanView.AvailableAmountForShortTerm.toFixed(2);
                            $scope.AvailableAmount = data.ShortTermPlanView.AvailableAmountForShortTerm;
                            $scope.AvailableAmount = Number($scope.AvailableAmount).toLocaleString(currentLanguage, { minimumFractionDigits: 2 })
                            $scope.AvailableAmountAbsoluteVal = $scope.AvailableAmount;//$scope.AvailableAmount.split(".")[0].trim();
                            //$scope.AvailableAmountDecimalVal = "." + $scope.AvailableAmount.split(".")[1];
                            var AvailableAmountShortTerm = $scope.AvailableAmountAbsoluteVal.toString();
                            $.each($('.available-pending-amount'), function () {
                                var price = AvailableAmountShortTerm;
                                $(this).html(price.replace(/(\D*)(\d*\.)(\d*)/, '<span style="font-weight: 400;">$1</span><span style="font-weight: 400;">$2</span><span style="font-weight: 400;">$3</span>'));
                            });
                        } else {
                            var AvailableAmount = data.ShortTermPlanView.AvailableAmountForShortTerm;
                            $scope.AvailableAmount = $filter("currency")(AvailableAmount, "");
                            $scope.AvailableAmountAbsoluteVal = $scope.AvailableAmount; //$scope.AvailableAmount.split(",")[0].trim();
                            $.each($('.available-pending-amount'), function () {
                                var price = $scope.AvailableAmount;
                                $(this).html(price.replace(/(\D*)(\d*\,)(\d*)/, '<span style="font-weight: 400;">$1</span><span style="font-weight: 400;">$2</span><span style="font-weight: 400;">$3</span>'));
                            });
                            // $scope.AvailableAmountDecimalVal = "," + $scope.AvailableAmount.split(",")[1];
                        }
                    }
                }
                if (data.LongTermPlanView != null) {
                    if (data.LongTermPlanView.RecurrentFrequecy == "N" || data.LongTermPlanView.RecurrentFrequecy == null) {
                        $scope.recurrentPreLongTerm = false;
                    } else {
                        $scope.recurrentPreLongTerm = true;
                    }
                    if (data.LongTermPlanView.ValidationType == shortTermPlanValidationType) {
                        //if ($scope.languageCulture == languages.languageFR) {
                        //    $scope.NoLongtermPlanValidationMessage = noLongTermPlan_fr;
                        //}
                        //else if ($scope.languageCulture == languages.languageNL) {
                        //    $scope.NoLongtermPlanValidationMessage = noLongTermPlan_nl;
                        //}
                        //else {
                        //    $scope.NoLongtermPlanValidationMessage = noLongTermPlan_en;
                        //}
                        $scope.NoLongtermPlanValidationMessage = Resources.NoLongTermPlan;
                    }
                }
                if (data.ShortTermPlanView != null) {
                    if (data.ShortTermPlanView.RecurrentFrequency == "N" || data.ShortTermPlanView.RecurrentFrequency == null) {
                        $scope.recurrentPreShortTerm = false;
                    } else {
                        $scope.recurrentPreShortTerm = true;
                    }
                    if (data.ShortTermPlanView.ValidationType == shortTermPlanValidationType) {
                        $scope.NoShorttermPlanValidationMessage = Resources.NoShortTermPlan;
                    }
                } else {
                    $scope.hideNoShortTermMessage = true;
                    $scope.hideNoShortTermData = false;
                }
                //if (data.LongTermPlanView != null) {
                //}
                //if (data.ShortTermPlanView != null) {
                //}
                $scope.showRecurrentPayment = true;
                var shortTermPlanCurrentValue = data.ShortTermPlanView;
                var longTermPlanCurrentValue = data.LongTermPlanView;
                if (data.ShortTermPlanView) {
                    var shortTermPlan = data.ShortTermPlanView.ShortTemProject;
                }
                if (data.LongTermPlanView != null) {
                    if (data.LongTermPlanView.ContributionGraphView) {
                        var longTermPlan = data.LongTermPlanView.ContributionGraphView.GraphData;
                    }
                }
                $scope.labels = [];
                $scope.dataBar = [];
                $scope.data = [];
                if (longTermPlan != null) {
                    var lenLT = longTermPlan.length;
                    for (i = 0; i < lenLT; i++) {
                        $scope.labels.push(longTermPlan[i].MonthName);
                        $scope.dataBar.push(longTermPlan[i].Value);
                    }
                }
                $scope.data.push($scope.dataBar);
                $scope.languageCulture = $.cookie("language");
                if (longTermPlanCurrentValue) {
                    if (currentLanguage == languages.languageEN || currentLanguage == languages.languageENSmall) {
                        $scope.CurrentPlanValueLT = longTermPlanCurrentValue.CurrentPlanValue;
                        $scope.CurrentPlanValueLT = Number($scope.CurrentPlanValueLT).toLocaleString($.cookie("language"), { minimumFractionDigits: 2 });
                        $scope.CurrentPlanValueLTAbsoluteVal = $scope.CurrentPlanValueLT.toString();
                        var priceLT = $scope.CurrentPlanValueLTAbsoluteVal;
                        setTimeout(function () {
                            $("#longTermAmountValue").html(priceLT.replace(/(\d*)([\.]\d*)/, '<span style="font-size:50px;">$1</span><span style="font-size:25px;">$2</span>'));
                        }, 500);
                    } else {
                        var CurrentPlanValueLT = longTermPlanCurrentValue.CurrentPlanValue;
                        $scope.CurrentPlanValueLT = $filter("currency")(CurrentPlanValueLT, "");
                        var currentValueLTString = $scope.CurrentPlanValueLT.toString();
                        $scope.CurrentPlanValueLTAbsoluteVal = currentValueLTString; //currentValueLTString.split(",")[0].trim();
                        var priceLT = currentValueLTString;
                        setTimeout(function () {
                            $("#longTermAmountValue").html(priceLT.replace(/(\d*)([\,]\d*)/, '<span style="font-size:50px;">$1</span><span style="font-size:25px;">$2</span>'));
                        }, 500);
                    }
                }
                if (shortTermPlanCurrentValue) {
                    if (currentLanguage == languages.languageEN || currentLanguage == languages.languageENSmall) {
                        $scope.CurrentPlanValueST = shortTermPlanCurrentValue.CurrentPlanValue;
                        $scope.CurrentPlanValueST = Number($scope.CurrentPlanValueST).toLocaleString($.cookie("language"), { minimumFractionDigits: 2 });
                        $scope.CurrentPlanValueSTAbsoluteVal = $scope.CurrentPlanValueST.toString() //currentValueSTString.split(".")[0].trim();
                        var price = $scope.CurrentPlanValueSTAbsoluteVal;
                        setTimeout(function () {
                            $("#shortTermAmountValue").html(price.replace(/(\d*)([\.]\d*)/, '<span style="font-size:50px;">$1</span><span style="font-size:25px;">$2</span>'));
                        }, 500);
                    } else {
                        var CurrentPlanValueST = shortTermPlanCurrentValue.CurrentPlanValue;
                        $scope.CurrentPlanValueST = $filter("currency")(CurrentPlanValueST, "");
                        var currentValueSTString = $scope.CurrentPlanValueST.toString();
                        $scope.CurrentPlanValueSTAbsoluteVal = currentValueSTString//currentValueSTString.split(",")[0].trim();
                        var price = currentValueSTString;
                        setTimeout(function () {
                            $("#shortTermAmountValue").html(price.replace(/(\d*)([\,]\d*)/, '<span style="font-size:50px;">$1</span><span style="font-size:25px;">$2</span>'));
                        }, 500);
                    }
                }

                $scope.series = ["Series A"];
                $scope.colours = [{
                    fillColor: "rgba(3, 170, 179, 1)",
                    strokeColor: "rgba(3, 170, 179, 1)",
                    highlightFill: "rgba(3, 170, 179, 1)",
                    highlightStroke: "rgba(3, 170, 179, 1)"
                }];
                $scope.languageCulture = $.cookie("language");

                $scope.options = {
                    scaleShowGridLines: false,
                    scaleShowLabels: false,
                    scaleLineColor: "transparent",
                    responsive: true,
                    barShowStroke: true,
                    barStrokeWidth: 1,
                    barValueSpacing: 5,
                    barDatasetSpacing: 1,
                    animation: false,
                    scaleLineWidth: 1,
                    scaleFontSize: 12,
                    scaleFontStyle: "normal"
                };

                if ($scope.languageCulture == languages.languageEN) {
                    $scope.options.tooltipTemplate = function (dataBar) {
                        return formatNumber(dataBar.value, true, 2, ".", ",");
                    };
                } else {
                    $scope.options.tooltipTemplate = function (dataBar) {
                        return formatNumber(dataBar.value, true, 2, ",", ".");
                    };
                }
                $scope.shortTermItem = [];
                $scope.shortTermItemInfo = {};
                $scope.languageCulture = $stateParams.language;
                if (shortTermPlan != null) {
                    var lenST = shortTermPlan.length;
                    if ($scope.languageCulture.toUpperCase() == languages.languageEN) {
                        for (i = 0; i < lenST; i++) {
                            $scope.shortTermItem.push({
                                itemName: shortTermPlan[i].ProjectTitle,
                                current: shortTermPlan[i].ProjectCurrentValue,
                                currentEuro: shortTermPlan[i].ProjectCurrentValue.toLocaleString($scope.languageCulture, { minimumFractionDigits: 2 }),
                                total: shortTermPlan[i].ProjectTargetAmount,
                                totalEuro: shortTermPlan[i].ProjectTargetAmount.toLocaleString($scope.languageCulture, { minimumFractionDigits: 2 }),
                                projectStatus: shortTermPlan[i].ProjectStatus,
                                ImagePath: shortTermPlan[i].ProjectImage
                            });
                        }
                    } else {
                        for (i = 0; i < lenST; i++) {
                            $scope.shortTermItem.push({
                                itemName: shortTermPlan[i].ProjectTitle,
                                current: shortTermPlan[i].ProjectCurrentValue,
                                currentEuro: $filter("currency")(shortTermPlan[i].ProjectCurrentValue, ""),
                                total: shortTermPlan[i].ProjectTargetAmount,
                                totalEuro: $filter("currency")(shortTermPlan[i].ProjectTargetAmount, ""),
                                projectStatus: shortTermPlan[i].ProjectStatus,
                                ImagePath: shortTermPlan[i].ProjectImage
                            });
                        }
                    }
                }

                var IsPersonLongTermContractExist = data.IsLongTermContractExist;
                var IsPersonShortTermContractExist = data.IsShortTermContractExist;
                var ShowPersonShortTermSection = data.ShowShortTermSection;

                if ($rootScope.isChildPlanCalled) {
                    if (!ShowPersonShortTermSection) {
                        if (IsPersonLongTermContractExist && IsPersonShortTermContractExist) {//LT,ST,RP
                            $scope.state = 1;
                            if (!$stateParams.routingEntry) {
                                $state.go("child.detail.plan.termPlan", {
                                    state: $scope.state
                                });
                            }
                            else {
                                $(".csm-sub-menu-list").removeClass("active-sub-menu");
                                $(".csm-menu-list").removeClass("csm-active-list");
                                $("#savingSchool").parent().addClass("csm-active-list");
                            }
                            if (data.IsRegisterSupporter || $rootScope.isChild) {// Register Supporter should not see contract details
                                $scope.showLT = false;
                                $scope.showST = false;
                            }
                            else {
                                $scope.showLT = true;
                                $scope.showST = true;
                            }

                            //$scope.showRP = true;
                        }
                        else if (!IsPersonLongTermContractExist && IsPersonShortTermContractExist) {//!LT,ST,!RP
                            $scope.state = 2;
                            if (!$stateParams.routingEntry) {
                                $state.go("child.detail.plan.termPlan", {
                                    state: $scope.state
                                });
                            }
                            else {
                                $(".csm-sub-menu-list").removeClass("active-sub-menu");
                                $(".csm-menu-list").removeClass("csm-active-list");
                                $("#savingSchool").parent().addClass("csm-active-list");
                            }
                            $scope.showLT = false;
                            if (data.IsRegisterSupporter)
                                $scope.showST = false;// Register supporter should not see Short term Details
                            else
                                $scope.showST = true;

                            $scope.showRP = false;
                        }
                        else if (IsPersonLongTermContractExist && !IsPersonShortTermContractExist) {//LT,!ST,RP
                            $scope.state = 1;
                            if (!$stateParams.routingEntry) {
                                $state.go("child.detail.plan.termPlan", {
                                    state: $scope.state
                                });
                            }
                            else {
                                $(".csm-sub-menu-list").removeClass("active-sub-menu");
                                $(".csm-menu-list").removeClass("csm-active-list");
                                $("#savingSchool").parent().addClass("csm-active-list");
                            }
                            if (data.IsRegisterSupporter)
                                $scope.showLT = false; //Register Supporter should not see Long Term Details
                            else
                                $scope.showLT = true;

                            $scope.showST = false;
                            $scope.showRP = true;
                        }
                    }
                    else if (ShowPersonShortTermSection) {
                        $scope.state = 3;
                        if (!$stateParams.routingEntry) {
                            $state.go("child.detail.plan.termPlan", {
                                state: $scope.state
                            });
                        }
                        else {
                            $(".csm-sub-menu-list").removeClass("active-sub-menu");
                            $(".csm-menu-list").removeClass("csm-active-list");
                            $("#savingSchool").parent().addClass("csm-active-list");
                        }
                        $scope.showLT = true;
                        $scope.showST = false;
                        $scope.showRP = true;
                    }
                }

                if (data.IsShortTermPreBirth || $rootScope.isChild) {
                    $scope.showRecurrentPayment = false;
                    $scope.ShowHideChildOptions = true;
                }
                $scope.isSTExceedLmtChilPage = data.ShowShortTermCashout;
                $scope.shortTermMaxAmount = data.shortTermMaxAmount;
            },
            function (error) {
            }
        );
    }
    $scope.initializeRP = function () {
        if (localStorage.recurrentRedirect && JSON.parse(localStorage.recurrentRedirect)) {
            localStorage.removeItem('recurrentRedirect');
            angular.element('#recurrentRedirect').trigger('click');
            $('#recurrentRedirect').scope().NavigateRP(true, true);
            setTimeout(function () {
                $("#recurringPaymentDetails").scope().getPaymentIntiatingDetail($scope.childId);
            }, 500)
        }
    }
    function formatNumber(number, isdecimalrequired, decimalsLength, decimalSeparator, thousandSeparator) {
        if ((currentLanguage.toLowerCase() == "fr") || (currentLanguage.toLowerCase() == "nl")) {
            var n = number,
                decimalsLength = isNaN(decimalsLength = Math.abs(decimalsLength)) ? 2 : decimalsLength,
                decimalSeparator = decimalSeparator == undefined ? "," : decimalSeparator,
                thousandSeparator = thousandSeparator == undefined ? "." : thousandSeparator,
                sign = n < 0 ? "-" : "",
                i = parseInt(n = Math.abs(+n || 0).toFixed(decimalsLength)) + "",
                j = (j = i.length) > 3 ? j % 3 : 0;

            var responseamountfrnl = sign + (j ? i.substr(0, j) + thousandSeparator : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousandSeparator);

            if (isdecimalrequired == true) {
                responseamountfrnl = sign + (j ? i.substr(0, j) + thousandSeparator : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousandSeparator) +
                                     (decimalsLength ? decimalSeparator + Math.abs(n - i).toFixed(decimalsLength).slice(2) : "");
            }

            return responseamountfrnl;
        } else if (currentLanguage.toLowerCase() == "en") {
            var n = number,
                decimalsLength = isNaN(decimalsLength = Math.abs(decimalsLength)) ? 2 : decimalsLength,
                decimalSeparator = decimalSeparator == undefined ? "." : decimalSeparator,
                thousandSeparator = thousandSeparator == undefined ? "," : thousandSeparator,
                sign = n < 0 ? "-" : "",
                i = parseInt(n = Math.abs(+n || 0).toFixed(decimalsLength)) + "",
                j = (j = i.length) > 3 ? j % 3 : 0;

            var responseamounten = sign + (j ? i.substr(0, j) + thousandSeparator : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousandSeparator);

            if (isdecimalrequired == true) {
                responseamounten = sign + (j ? i.substr(0, j) + thousandSeparator : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousandSeparator) +
                                   (decimalsLength ? decimalSeparator + Math.abs(n - i).toFixed(decimalsLength).slice(2) : "");
            }

            return responseamounten;
        } else {
            var n = number,
                    decimalsLength = isNaN(decimalsLength = Math.abs(decimalsLength)) ? 2 : decimalsLength,
                    decimalSeparator = decimalSeparator == undefined ? "." : decimalSeparator,
                    thousandSeparator = thousandSeparator == undefined ? "," : thousandSeparator,
                    sign = n < 0 ? "-" : "",
                    i = parseInt(n = Math.abs(+n || 0).toFixed(decimalsLength)) + "",
                    j = (j = i.length) > 3 ? j % 3 : 0;

            var responseamount = sign + (j ? i.substr(0, j) + thousandSeparator : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousandSeparator);

            if (isdecimalrequired == true) {
                responseamount = sign + (j ? i.substr(0, j) + thousandSeparator : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousandSeparator) +
                                (decimalsLength ? decimalSeparator + Math.abs(n - i).toFixed(decimalsLength).slice(2) : "");
            }

            return responseamount;
        }
    }

    $scope.planTransactionLoadItems = function (fromWhereItIsCalled) {
        var childId = $stateParams.childId;
        if ($scope.busy) return;
        if (!((fromWhereItIsCalled === 'planSupporter') && $scope.isTransactionHistoryVisible)) {
            return;
        }
        if ($scope.serviceCalled) {
            if (($scope.transData != undefined) && ($scope.transData.length <= 9)) return;
        }
        if (($scope.childId == undefined) || ($scope.childId == 'null')) {
            return;
        }
        var lastLoadedPage = $scope.lastLoadedId;
        if (lastLoadedPage == undefined) {
            $scope.lastLoadedId = 1;
            lastLoadedPage = 1;
        }
        $scope.busy = true;
        if ($scope.isFilter) {
            var webApiurl = "/contribution/contributiondetail/";
            $scope.filterRequestObj.PageNumber = $scope.lastLoadedId;
            $scope.filterRequestObj.ChildId = $stateParams.childId;
            WebApiService.getWebApiData1(webApiurl, "", $scope.filterRequestObj).then(
                function (data) {
                    if ((data.data != 'null') && (data.data != undefined)) {
                        if (data.data.ContributionViewList.length > 0) {
                            $scope.serviceCalled = true;

                            $scope.transData = data.data.ContributionViewList;
                            for (i = 0; i < $scope.transData.length; i++) {
                                if ($scope.transData[i].ContributorAvatarUri != null) {
                                    $scope.transData[i].ContributorAvatar = $scope.transData[i].ContributorAvatarUri;
                                }
                            }
                            $.each($scope.transData, function () {
                                var ContributionFormatAmt = formatNumber(this.ContributionAmount, false);
                                var TaxFormatAmt = formatNumber(this.ContributionCalculation.TaxAmount, true);
                                var TotalFormatAmt = formatNumber(this.ContributionCalculation.TotalAmount, true);
                                this.ContributionFormatAmt = ContributionFormatAmt;
                                this.TaxFormatAmt = TaxFormatAmt;
                                this.TotalFormatAmt = TotalFormatAmt;

                                var contributionDate = this.ContributionFormattedDate.split(" ");
                                var day = contributionDate[0];
                                var month = contributionDate[1].slice(0, 3);
                                var year = contributionDate[2];
                                this.ContributionFormattedDate = day + " " + month + " " + year;
                            });

                            for (i = 0; i < $scope.transData.length; i++) {
                                $scope.transHisData.push($scope.transData[i]);
                            }
                        }

                        lastLoadedPage = lastLoadedPage + 1;
                        $scope.lastLoadedId = lastLoadedPage;
                    }

                    $scope.busy = false;
                },
                function (error) {
                    $scope.busy = false;
                }
            );
        } else {
            var parentId = $.cookie("personId");
            var childId = $stateParams.childId;
            ChildProfileService.GetTransactionHistory(parentId, childId, lastLoadedPage).then(
                function (data) {
                    if ((data != 'null') && (data != undefined)) {
                        if (data.ContributionViewList.length > 0) {
                            $scope.serviceCalled = true;
                            $scope.transData = data.ContributionViewList;
                            $scope.planTransactionHistorySupporterList = data.ContributorInfo;
                            for (i = 0; i < $scope.planTransactionHistorySupporterList.length; i++) {
                                if ($scope.planTransactionHistorySupporterList[i].PersonImageUrl != null) {
                                    $scope.planTransactionHistorySupporterList[i].PersonImage = $scope.planTransactionHistorySupporterList[i].PersonImageUrl;
                                }
                            }
                            for (i = 0; i < $scope.transData.length; i++) {
                                if ($scope.transData[i].ContributorAvatar != null) {
                                    $scope.transData[i].ContributorAvatar = $scope.transData[i].ContributorAvatarUri;
                                }
                            }

                            $.each($scope.transData, function () {
                                var ContributionFormatAmt = formatNumber(this.ContributionAmount, false);
                                var TaxFormatAmt = formatNumber(this.ContributionCalculation.TaxAmount, true);
                                var TotalFormatAmt = formatNumber(this.ContributionCalculation.TotalAmount, true);
                                this.ContributionFormatAmt = ContributionFormatAmt;
                                this.TaxFormatAmt = TaxFormatAmt;
                                this.TotalFormatAmt = TotalFormatAmt;

                                var contributionDate = this.ContributionFormattedDate.split(" ");
                                var day = contributionDate[0];
                                var month = contributionDate[1].slice(0, 3);
                                var year = contributionDate[2];
                                this.ContributionFormattedDate = day + " " + month + " " + year;
                            });
                            for (i = 0; i < $scope.transData.length; i++) {
                                $scope.transHisData.push($scope.transData[i]);
                                if ($scope.transData[i].MoneyInOut === true) {
                                    if ($scope.transData[i].TransactionPaymentId == $scope.transData[i + 1].TransactionPaymentId) {
                                        $scope.transHisData[i].STtoLT = true;
                                    }
                                    else {
                                        $scope.transHisData[i].STtoLT = false;
                                    }
                                }
                            }
                            for (i = 0; i < $scope.transHisData.length; i++) {
                                //console.log($scope.transHisData[i]);
                                if ($scope.transHisData[i].SavingTypeId == 1) {
                                    $scope.transHisData[i].isShortTermTaxCalculation = true;
                                }
                                else {
                                    $scope.transHisData[i].isShortTermTaxCalculation = false;
                                }
                            }

                            lastLoadedPage = lastLoadedPage + 1;
                            $scope.lastLoadedId = lastLoadedPage;
                        }
                    }
                    $scope.busy = false;

                    if ($rootScope.isChild) {
                        EditProfileService.CheckAdultChild(childId).then(
                                function (data, status) {
                                    if (data) {
                                        $scope.isinfantChild = data;                                       
                                    }
                                    else {
                                        $scope.isinfantChild = false;
                                    }

                                    var parentalcontrolforInfant = EditProfileService.getParentalControl();
                                    console.log($scope.isinfantChild);
                                    console.log(parentalcontrolforInfant);
                                    if ($scope.isinfantChild) {
                                        if (!parentalcontrolforInfant.longTermAnswer) {
                                            $scope.showlongtermforInfant = false;
                                        }                                        
                                        if (!parentalcontrolforInfant.currentAmountAnswer) {
                                            $scope.showshorttermforInfant = false;
                                        }                                        
                                    }
                                },
                                function (error) {
                           });
                    }
                },
                function (error) {
                    $scope.busy = false;
                }
            );
        }
    }

    $scope.getTransactionsWithFilterCriteria = function (locationFromWhereFilterIsCalled) {
        $scope.isTransactionHistoryVisible = false;
        $scope.isSupporterHistoryVisible = false;
        $scope.isChildSupporterListToBeshown = false;
        $scope.transHisData = [];
        $scope.serviceCalled = false;
        $scope.lastLoadedId = 1;
        $scope.busy = false;
        if ($scope.filterDataObject.filterBooleanShowAmount || $scope.filterDataObject.filterBooleanShowDate || $scope.filterDataObject.filterBooleanShowPlan || $scope.filterDataObject.filterBooleanShowSupporter || $scope.filterDataObject.filterBooleanShowTransaction) {
            $scope.isFilter = true;
            $scope.lastLoadedId = 1;
        } else {
            $scope.isFilter = false;
            $scope.lastLoadedId = 1;
        }
        if (locationFromWhereFilterIsCalled == "planSupporter") {
            $scope.isTransactionHistoryVisible = true;
            $scope.planTransactionLoadItems("planSupporter");
        } else if (locationFromWhereFilterIsCalled == "childSupporter") {
            $scope.isChildSupporterListToBeshown = true;
            $scope.childSupporterLoadItems("childSupporter");
        }
    }
    $scope.clearTransactionHistoryObjectAndReset = function () {
        $scope.transHisData = [];
        $scope.serviceCalled = false;
        $scope.lastLoadedId = 1;
        $scope.busy = false;
        $scope.isSupporterHistoryVisible = false;
        $scope.isTransactionHistoryVisible = false;
        $scope.isChildSupporterListToBeshown = false;
        $(".trans-history").css("display", "none");
    }
    //Transaction History
    $scope.GetTransactionHistory = function () {
        $scope.myYongoPlanActive = true;
        $state.go("child.detail.transaction-history");
        $scope.isTransactionHistoryVisible = true;
        $scope.isSupporterHistoryVisible = false;
        $scope.isChildSupporterListToBeshown = false;
        $scope.transHisData = [];
        $scope.serviceCalled = false;
        $scope.lastLoadedId = 1;
        $scope.busy = false;
        $scope.isSupporterHistoryVisible = false;
        $scope.isTransactionHistoryVisible = true;
        $scope.isChildSupporterListToBeshown = false;
        $scope.planTransactionLoadItems('planSupporter');
        angular.element(".csm-sub-menu-list").removeClass("active-sub-menu");
        angular.element(".csm-sub-menu-list:eq(1)").addClass("active-sub-menu");
    }

    $scope.GetAdminByChild = function () {
        EditProfileService.GetAdminByChildId($scope.actualChildId).then(
            function (data) {
                if (data.Result != null) {
                    if (data.Result.PersonId != 0) {
                        $scope.isAdminSectionVisible = true;
                        $scope.isAddAdminSectionVisible = false;
                        if (parentId == data.Result.PersonId) /// Check Login Person whether he is a admin ; if he is  admin dont display Deete  button
                            $scope.isDeleteAdminSectionVisible = false;
                        else
                            $scope.isDeleteAdminSectionVisible = true;
                        $scope.adminId = data.Result.PersonId;
                        if (data.Result.PersonImageUrl) {
                            $scope.adminImage = data.Result.PersonImageUrl;
                        } else {
                            $scope.adminImage = images.defaultPersonImage;
                        }
                        $scope.adminNickName = data.Result.PersonNickName;
                        $scope.adminFullName = data.Result.PersonFirstName + " " + data.Result.PersonLastName;
                    }
                    else {
                        $scope.adminNickName = "";
                        $scope.adminImage = "";
                        $scope.adminFullName = "";
                        $scope.isAdminSectionVisible = false;
                        $scope.isAddAdminSectionVisible = true;
                    }
                }
                else {
                    $scope.adminNickName = "";
                    $scope.adminImage = "";
                    $scope.adminFullName = "";
                    $scope.isAdminSectionVisible = false;
                    $scope.isAddAdminSectionVisible = true;
                }
            },
        function (error) {
        });
    }

    $scope.SetChildPersonalDataVisible = function (childId) {
        var url = "/invitations/person/" + $.cookie("personId") + "/child/" + childId + "/issubscribingparentinvited";
        var res = WebApiService.getWebApiData(url);
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                if (data == true) {
                    $scope.isEditChildPersonalDataVisible = true;
                } else {
                    $scope.CheckIsAdmin();
                }
            });
        }
    }

    $scope.CheckIsAdmin = function () {
        var url = "/invitations/child/" + $scope.actualChildId + "/admin";
        var res = WebApiService.getWebApiData(url);
        if (res != undefined && res != null) {
            res.then(function (d) {
                var response = JSON.stringify(d.data.Result);
                var data = JSON.parse(response);
                if (data) {
                    if (data.PersonId != 0) {
                        if (data.PersonId == $.cookie("personId")) {
                            $scope.isEditChildPersonalDataVisible = true;
                        } else {
                            $scope.isEditChildPersonalDataVisible = false;
                        }
                    } else if (data.PersonId == 0) {
                        $scope.isEditChildPersonalDataVisible = false;
                    }
                }
            });
        }
    }

    //Get the details of parent for child
    $scope.GetParentInformtionForEditProfile = function () {
        var urlRetrieveParentInformation = "/members/" + $.cookie("personId");
        var res = WebApiService.getWebApiData(urlRetrieveParentInformation);
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                $scope.parentFullName = data.PersonFirstName + " " + data.PersonLastName;
            });
        }
    }

    $scope.GetChildInformtionForEditProfile = function () {
        var urlRetrieveChildInformation = "/members/" + $.cookie("childId");
        var res = WebApiService.getWebApiData(urlRetrieveChildInformation);
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
            });
        }
    }
    //Getting my details
    $scope.GetMyDetail = function () {
        var parentId = $.cookie("personId");
        ChildProfileService.GetMyDetail(parentId).then(
            function (data) {
                $scope.ParentFirstName = data.PersonFirstName;
                $scope.ParentId = $.cookie("parentId")
                $scope.ParentLastName = data.PersonLastName;
                $scope.ParentCity = data.City;
                $scope.ParentMail = data.MailId;
                $scope.ParentAddress = data.Address;
                $scope.ParentZipCode = data.ZipCode;
                $scope.ParentNickName = data.PersonNickName;
                $scope.ParentPhone = data.Phone;
                $scope.responseData = data;
                $scope.isInfantSupporter = data.IsInfantSupporter;
                if ($rootScope.isChild && $scope.isInfantSupporter) {
                    $scope.$broadcast('child-is-supporter');
                }
            },
            function (error) {
            }
        );
    }

    $scope.validEmail = function () {
        var resultEmailval = utilityFactory.validEmail($scope.email);
        $scope.inputAdminEmail = resultEmailval[0];
        $scope.isAValidEmailID = resultEmailval[1];
    }
    $scope.removeErrorStyle = function () {
        $scope.isAValidEmailID = false;
        $scope.inputAdminEmail = {
            "required": false,
            "pattern": false
        };
    }
    $scope.showEditProfileForm = function () {
        $rootScope.$broadcast('userModal-started', {
            any: {
                "userProfileDetails": angular.copy($scope.childProfileDetails),
                "countryList": $scope.allCountryList,
                "isChildProfile": true,
            }
        });
        setTimeout(function () {
            $('#editBirthDate').inputmask();
        }, 300);
    }

    $scope.getAllCountriesList = function () {
        EditProfileService.GetAllCountries().then(
            function (data) {
                var countryArray = [];
                $scope.allCountryList = [];
                for (i = 0; i < data.Result.length; i++) {
                    $scope.allCountryList.push(data.Result[i]);
                }
            },
            function (error) {
            }
        );
    };

    var FutureDate = new Date();
    FutureDate.setMonth(FutureDate.getMonth() + 6);

    $scope.DownloadAllDoc = function (contractReferenceId) {
        var webApiResponse = ChildProfileService.getContractDocument(contractReferenceId).then(
            function (data) {
                if (data != undefined) {
                    window.open(data);
                }
            },
            function (error) {
            }
        );
    }

    $scope.setChildFlag = function (isChildExists, childId, linkUrl) {
        $scope.isChildExists = isChildExists;
        localStorage.setItem("MandateId", "");
        if (isChildExists) {
            localStorage.setItem("isChildExists", isChildExists);
        } else {
            localStorage.setItem("isChildExists", isChildExists);
        }
        linkUrl = "/" + currentLanguage + "/Subscription/start";
        location.href = linkUrl;
    };

    $scope.DownloadDoc = function (document) {
        var url = baseUrl + "/childsaving/contractdocument/documentreferenceno/" + document.DocumentReferenceNo + "/documenttype/" + document.DocumentType + "/documentname/" + document.DocumentName;
        $.fileDownload(url)
       .done(function () { })
       .fail(function () { });
        return false; //this is critical to stop the click event which will trigger a normal file download
    }

    //Get plan details

    $scope.GetPlanDetail = function (planid, plantype) {
        $scope.myYongoPlanActive = true;
        $state.go('child.detail.contract');
        $scope.IndPlan = [];
        $scope.ShowLongTerm = false;
        var webApiResponse = ChildProfileService.GetPlanDetail(planid, plantype);
        if (webApiResponse != undefined) {
            webApiResponse.then(function (data) {
                var response = JSON.stringify(data);
                var data = JSON.parse(response);
                $scope.PlanInfo.PlanType = data.PlanType;
                $scope.PlanInfo.ProductType = data.ProductType;

                if ($scope.PlanInfo.ProductType == 1) {
                    $scope.ShowLongTerm = true;
                } else {
                    $scope.ShowLongTerm = false;
                }
                $scope.PlanInfo.ProductName = data.ProductName;
                $scope.PlanInfo.PlanStartDate = data.PlanStartDate;
                $scope.PlanInfo.PlanEndDate = data.PlanEndDate;
                $scope.PlanInfo.HyperLink = data.HyperLink;
                $scope.PlanInfo.NumberOfUnit = data.NumberOfUnit;
                $scope.PlanInfo.FundType = data.FundType;
                $scope.PlanInfo.FundTypeCode = data.FundTypeCode;
                $scope.PlanInfo.FundValue = data.FundValue;
                $scope.PlanInfo.FundName = data.FundName;
                $scope.PlanInfo.PlanStatus = data.PlanStatus;
                $scope.PlanInfo.ContractReferenceId = data.ContractReferenceId;
                $.each(data.ContractDocumentViewModel, function (index) {
                    $scope.IndPlan.push({
                        DocumentName: data.ContractDocumentViewModel[index].DocumentName,
                        DocumentId: data.ContractDocumentViewModel[index].DocumentId,
                        DocumentReferenceNo: data.ContractDocumentViewModel[index].DocumentReferenceNo,
                        DocumentType: data.ContractDocumentViewModel[index].DocumentType,
                    });
                });
                if (data.PartnerInfo) {
                    $scope.PartnerInfoExists = true;
                    $scope.PartnerInfo = data.PartnerInfo;
                    if ($scope.PartnerInfo.PartnerImage != null) {
                        $scope.PartnerInfo.PartnerImage = images.dataImage + $scope.PartnerInfo.PartnerImage;
                    }
                }
                else {
                    $scope.PartnerInfoExists = false;
                }
                $scope.PlanInfo.responseData = data;
                if (plantype == "0") {
                    angular.element("#contractType").text(angular.element("#longTermText").val());
                    angular.element("#dynamicContractHeader").text(angular.element("#longTermHeader").val());
                    angular.element("#dynamicContractHeaderMob").text(angular.element("#longTermHeader").val());
                }
                else {
                    angular.element("#contractType").text(angular.element("#shortTermText").val());
                    angular.element("#dynamicContractHeader").text(angular.element("#shortTermHeader").val());
                    angular.element("#dynamicContractHeaderMob").text(angular.element("#shortTermHeader").val());
                }
            }).catch(function (data) {
            });
        }
    }
    $scope.NavigateRP = function (recurrentPreLongTerm, recurrentPreShortTerm) {
        $scope.myYongoPlanActive = true;
        localStorage.setItem("isContributionUpdate", true);
        if (recurrentPreLongTerm || recurrentPreShortTerm) {
            $state.go("child.detail.recurrentpayment", {
                locationCalledFrom: 'childDetailsViaRecurrentpayment'
            });
            setTimeout(function () {
                $('#ibanNumberRP').inputmask('IBAN');
            }, 1000);
        } else {
            $state.go("child.detail.recurrentpayment", {
                locationCalledFrom: ''
            });
        }
    }
    $scope.childNaviagtionOverview = function (childId) {
        savingSchoolService.setSavingSchoolData("");
        if (childId) {
            $state.go("child.detail.plan", {
                childId: childId,
                routingEntry: null
            },
                {
                    reload: true
                });
        }
    }
    //Copied from ChildSupporterController.js starts here
    $scope.getAllSupporterByParentAndChild = function () {
        $scope.editPenBtn = true;
        $scope.childId = parseInt($stateParams.childId);//Integer
        if ($.cookie("personId") == $scope.childId) {
            parentId = $scope.childParentId;
        } else {
            parentId = $.cookie("personId");
        }

        var url = "/person/" + $.cookie("personId") + "/child/" + $scope.childId + "/supporters";

        $scope.parentId = $.cookie("personId");
        $scope.languageid = $.cookie("language");
        $scope.supporterChildIds = [];
        if ($.cookie("personId") != "" && $.cookie("personId") != undefined) {
            WebApiService.getWebApiData(url).then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                $scope.ActiveSupporterInfo = [];
                $scope.WaitForApprovalSupporterInfo = [];
                $scope.PendingSupporterInfo = [];
                if (data.length > 0) {
                    $.each(data, function (index) {
                        $scope.Info = {
                        };
                        $scope.Info.firstName = data[index].PersonFirstName;
                        $scope.Info.lastName = data[index].PersonLastName;
                        if (data[index].PersonNickName) {
                            $scope.Info.nickName = data[index].PersonNickName;
                        } else {
                            $scope.Info.nickName = data[index].PersonFirstName + " " + data[index].PersonLastName;
                        }
                        $scope.Info.email = data[index].PersonEmail;
                        $scope.Info.roleValue = data[index].supporterRoleValue;
                        $scope.Info.roleText = data[index].supporterRoleText;
                        if (data[index].PersonImageUrl) {
                            $scope.Info.image = data[index].PersonImageUrl;
                        } else {
                            $scope.Info.image = images.defaultPersonImage;
                        }
                        $scope.Info.parentId = $.cookie("personId");
                        $scope.Info.supporterId = data[index].PersonId;
                        $scope.Info.cultureCode = $.cookie("language");
                        $.each(data[index].supporterRoleText, function (roleIndex) {
                            if (data[index].Status === Status.Active && data[index].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                                $("#divActive").css("display", "block");
                                $scope.ActiveSupporterInfo.push($scope.Info);
                            }
                            if (data[index].Status === Status.Pending && data[index].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                                $("#divPending").css("display", "block");
                                $scope.PendingSupporterInfo.push($scope.Info)
                            }
                            if (data[index].Status === Status.Draft && data[index].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                                $("#divWait").css("display", "block");
                                $scope.WaitForApprovalSupporterInfo.push($scope.Info);
                            }
                        });
                    });
                }
            }, function (error) {
            });
        }
    }
    $rootScope.$on('getAllSupporterbyParent', function () {
        if ($scope.loginAsChildEntry) {
            $.cookie("childId", $.cookie("personId"), { path: "/" });
        }
        $scope.getAllSupporterByParentAndChild();
    });
    $scope.backToChildView = function (supporterInfo) {
        $scope.backBtnInSupporterOverviewShow = false;
        $scope.$parent.selectedSupporter = {};
        $("#supporter-details-pageForChild").css("display", "block");
        $("#supporter-details-historyForChild").css("display", "none");
        $("#supporter-details-transaction").css("display", "none");
        $scope.$parent.selectedSupporter.previousFirstName = "";
        $scope.$parent.selectedSupporter.previousLastName = "";
        $scope.$parent.selectedSupporter.previousNickName = "";
        $scope.$parent.selectedSupporter.previousEmail = "";
        $("#inputSupporterFirstName").val("");
        $("#inputSupporterLastname").val("");
        $("#inputSupportNickName").val("");
        $("#inputSupportEmail").val("");
    }

    $scope.showChildSupporterInfo = function (supporterInfo) {
        $scope.backBtnInSupporterOverviewShow = true;
        $("#supporter-details-pageForChild").css("display", "none");
        $("#supporter-details-historyForChild").css("display", "block");
        $("#supporter-details-transaction").css("display", "block");
        var url = "/members/" + supporterInfo.supporterId;
        var res = WebApiService.getWebApiData(url);
        var children = [];
        $scope.$parent.supporterChildIds = [];
        $scope.nickplaceholder = supporterInfo.nickName;
        $scope.selectedSupporter = supporterInfo;
        $scope.$parent.supporterChildIds.push($scope.id);
        $scope.getTransactionSupporterHistoryForChild(supporterInfo.supporterId);
    }

    $scope.editPenClicked = function () {
        $("#nickNameSave").css("display", "block");
        $("#nickNameCancel").css("display", "block");
        $("#editPenBtn").css("display", "none");
        $("#nickNameShowInitial").css("display", "none");
        $("#nickNameShowOnPenClick").css("display", "block");
    }

    $scope.CancelNickName = function () {
        $("#nickNameSave").css("display", "none");
        $("#nickNameCancel").css("display", "none");
        $("#editPenBtn").css("display", "block");
        $("#nickNameShowInitial").css("display", "block");
        $("#nickNameShowOnPenClick").css("display", "none");
        $scope.showChildSupporterInfo($scope.selectedSupporter);
    }

    $scope.SaveMyNickName = function (supporterInfo, nickName) {
        $scope.txtNickNameChange = nickName;
        $scope.supporterId = supporterInfo.supporterId;
        var updateImageUrl = "/members/" + $.cookie("personId") + "/nickname";
        updateImageUrl = baseUrl + updateImageUrl;
        $scope.responseObject = {
            NickName: $scope.txtNickNameChange,
            SupporterId: $scope.supporterId
        }
        $.ajax({
            url: updateImageUrl,
            method: "POST",
            data: $scope.responseObject,
            dataType: "json",
            success: function (data) {
                $("#nickNameSave").css("display", "none");
                $("#nickNameCancel").css("display", "none");
                $("#editPenBtn").css("display", "block");
                $("#nickNameShowInitial").css("display", "block");
                $("#nickNameShowOnPenClick").css("display", "none");
                $scope.showChildSupporterInfo($scope.selectedSupporter);
            },
            error: function () {
            }
        });
    }

    $scope.SaveSupporterNickName = function (supporterInfo, nickName) {
        $scope.txtNickNameChange = nickName;
        $scope.supporterId = supporterInfo.supporterId;
        supporterInfo.nickName = nickName;
        var apiUrl = "/members/" + $.cookie("personId") + "/supporter/" + supporterInfo.supporterId + "/nickname";
        $scope.responseObject = {
            ParentId: $.cookie("personId"),
            NickName: $scope.txtNickNameChange,
            SupporterId: $scope.supporterId
        }

        EditProfileService.EditSupporterNickName(apiUrl, $scope.responseObject).then(
            function (data) {
                $("#nickNameSave").css("display", "none");
                $("#nickNameCancel").css("display", "none");
                $("#editPenBtn").css("display", "block");
                $("#nickNameShowInitial").css("display", "block");
                $("#nickNameShowOnPenClick").css("display", "none");
                $scope.showChildSupporterInfo($scope.selectedSupporter);
                var url = "/members/" + $.cookie("personId") + "/supporters";
                var language = $.cookie("language");
                WebApiService.getWebApiData(url, language).then(function (d) {
                    supporterData = d.data;
                    allSupporterData.setData('Dataname', { 'supporterArr': supporterData });
                }, function (error) {
                });
            },
            function (error) {
            }
        );
    }

    $scope.getTransactionSupporterHistoryForChild = function (supporterId) {
        $scope.transHisData = [];
        $scope.serviceCalled = false;
        $scope.lastLoadedId = 1;
        $scope.busy = false;
        $scope.isChildSupporterListToBeshown = true;
        $scope.isSupporterHistoryVisible = false;
        $scope.isTransactionHistoryVisible = false;
        $scope.childSupporterLoadItems('childSupporter');
    }

    $scope.childSupporterLoadItems = function (fromWhereItIsCalled) {
        if ($scope.isChildSupporterListToBeshown) {
            if ($scope.busy) return;
            if (!((fromWhereItIsCalled === 'childSupporter') && $scope.isChildSupporterListToBeshown)) {
                return;
            }
            if ($scope.serviceCalled) {
                if (($scope.transData != undefined) && ($scope.transData.length <= 9)) return;
            }
            if (($scope.selectedSupporter == undefined) || ($scope.selectedSupporter == 'null')) {
                return;
            }
            var supporterId = $scope.selectedSupporter.supporterId;
            var lastLoadedPage = $scope.lastLoadedId;
            if (lastLoadedPage == undefined) {
                $scope.lastLoadedId = 1;
                lastLoadedPage = 1;
            }
            $scope.busy = true;
            if ($scope.isFilter) {
                var webApiurl = "/contribution/allcontributiondetail/";

                $scope.filterRequestObj.PageNumber = $scope.lastLoadedId;
                WebApiService.getWebApiData1(webApiurl, "", $scope.filterRequestObj).then(
                    function (data) {
                        if ((data.data != 'null') || (data.data != undefined)) {
                            $scope.serviceCalled = true;
                            if ((data.data != 'null') && (data.data != undefined)) {
                                if (data.data.length > 0) {
                                    $scope.transData = data.data;
                                    $scope.LtransHisData = $scope.transData;
                                    $.each($scope.LtransHisData, function () {
                                        var contributionDate = this.ContributionFormattedDate.split(" ");
                                        var day = contributionDate[0];
                                        var month = contributionDate[1].slice(0, 3);
                                        var year = contributionDate[2];
                                        this.ContributionFormattedDate = day + " " + month + " " + year;
                                    });
                                    for (i = 0; i < $scope.LtransHisData.length; i++) {
                                        $scope.transHisData.push($scope.LtransHisData[i]);
                                    }
                                }

                                $scope.busy = false;
                                lastLoadedPage = lastLoadedPage + 1;
                                $scope.lastLoadedId = lastLoadedPage;
                            }
                            else {
                                $scope.busy = false;
                            }
                        }
                    },
                    function (error) {
                        $scope.busy = false;
                    }
                );
            } else {
                var personId = $.cookie("personId");
                var childId = $scope.actualChildId;

                ChildProfileService.getTransactionSupporterHistoryForChild(personId, childId, supporterId, lastLoadedPage).then(
                    function (data) {
                        if ((data != 'null') && (data != undefined)) {
                            if (data.length > 0) {
                                $scope.serviceCalled = true;
                                $scope.transData = data;
                                for (i = 0; i < $scope.transData.length; i++) {
                                    if ($scope.transData[i].ContributorAvatarUri != null) {
                                        $scope.transData[i].ContributorAvatar = $scope.transData[i].ContributorAvatarUri;
                                    }
                                    //else {
                                    //    $scope.transData[i].ContributorAvatar = images.defaultPersonImage;
                                    //}
                                }

                                $.each($scope.transData, function () {
                                    var contributionDate = this.ContributionFormattedDate.split(" ");
                                    var day = contributionDate[0];
                                    var month = contributionDate[1].slice(0, 3);
                                    var year = contributionDate[2];
                                    this.ContributionFormattedDate = day + " " + month + " " + year;
                                });
                                for (i = 0; i < $scope.transData.length; i++) {
                                    $scope.transHisData.push($scope.transData[i]);
                                }

                                $scope.busy = false;
                                lastLoadedPage = lastLoadedPage + 1;
                                $scope.lastLoadedId = lastLoadedPage;
                            }
                        }
                    },
                    function (error) {
                        $scope.busy = false;
                    }
                );
            }
        }
    }
    $scope.getTaxDetail = function (item, index) {
        $scope.isShortTermTaxCalculation = false;
        if (!item.count) {
            item.count = 1;
        }

        item.count = item.count + 1;
        if ((item.count % 2 !== 0) || item.serviceCalled) {
            return;
        }
        if (item.SavingTypeId == 1) {
            $scope.isShortTermTaxCalculation = true;
        }
        var contractReference = item.ContractReferenceExternal;
        var paymentTransactionId = item.TransactionPaymentId;
        ChildProfileService.GetTaxofTransaction(contractReference, paymentTransactionId).then(
                    function (data) {
                        if ((data != 'null') && (data != undefined)) {
                            item.serviceCalled = true;
                            item.ContributionFormatAmtTax = formatAmountField(data.ContributionAmount, $scope.language);
                            item.TaxFormatAmt = formatAmountField(data.TaxAmount, $scope.language);
                            item.TotalFormatAmt = formatAmountField(data.TotalAmount, $scope.language);
                            $scope.busy = false;
                        }
                    },
                    function (error) {
                        $scope.busy = false;
                    });
    }
    //Copied from ChildSupporterController.js ends here
    //Invite Supporter code starts here US 328
    $scope.showEnterLastname = false;
    $scope.showEnterFirstname = false;
    $scope.showEnterNickname = false;
    $scope.showEnterEmail = false;
    $scope.showNotMatchPattern = false;
    $scope.showEnterMessage = false;

    $scope.childList = [];

    //GetMyChildDetails
    function GetMyChildernList() {
        var personId = $.cookie("personId");

        ChildProfileService.GetMyChildrenDetail(personId).then(
            function (data) {
                $scope.GroupInfo = [];
                $.each(data, function (index) {
                    $scope.Info = {};
                    $scope.Info.childFirstName = data[index].PersonFirstName;
                    $scope.Info.childLastName = data[index].PersonLastName;
                    if (data[index].PersonImageUrl) {
                        $scope.Info.image = data[index].PersonImageUrl;
                    } else {
                        $scope.Info.image = images.defaultPersonImage;
                    }
                    $scope.Info.ID = data[index].PersonId;
                    $scope.GroupInfo.push($scope.Info);
                })
            },
            function (error) {
            }
        );
    }
    //Getting GetDefaultInviterDetails
    function GetDefaultInviterDetails() {
        DisplaySupportersService.GetDefaultInviterDetails().then(
            function (data) {
                $scope.relationships = data.Relationship;
            },
            function (error) {
            }
        );
    }

    $scope.inviteSupporter = function () {
        $rootScope.$broadcast('inviteSupporterStart', { any: { "selectedSupporter": $scope.$parent.selectedSupporter, "supporterData": supporterData, "personEmail": $rootScope.PersonEmail, "setChildLoginEntry": $scope.loginAsChildEntry, "childId": $scope.actualChildId, "fromTimeLine": false, "isSTExceedLmtSendfromChild": $scope.isSTExceedLmtChilPage, "ChildFirstName": $scope.childFirstName, "shortTermAmount": $scope.shortTermMaxAmount } });
    }

    /*---------------------------------------------------------Event code starts here----------------------------------------------*/
    $scope.hideChildProject = true;
    $scope.nonUserSection = true;
    $scope.displayChildProject = false;
    $scope.displayYexNo = false;
    $scope.showChildProject = function (id) {
        if (id != "undefined") {
            getChildProjectById(id);
        }
    }

    var imageIdarrayforService = [];
    $scope.getImageid = function (event) {
        if (imageIdarrayforService.length !== 0) {
            var countofId = 0;
            for (var i = 0; i < imageIdarrayforService.length; i++) {
                if (imageIdarrayforService[i] === event.target.id) {
                    imageIdarrayforService.splice(i, 1);
                    countofId++;
                    break;
                }
            }
            if (countofId === 0) {
                imageIdarrayforService.push(event.target.id);
            }
        } else {
            imageIdarrayforService.push(event.target.id);
        }
    };

    //US2799--start
    function getChildProjectById(id) {
        ChildProfileService.getChildProjectById(id).then(
            function (data) {
                $scope.transInfo = {};
                $scope.transHisData = [];

                var response = JSON.stringify(data);
                var transData = JSON.parse(response);
                for (i = 0; i < data.length; i++) {
                    data[i].ProjectImage = images.dataImage + data[i].ProjectImage;
                    data[i].Title = data[i].Title;
                }
                $scope.transHisData = data;

                for (i = 0; i < $scope.transHisData.length; i++) {
                    if ($scope.transHisData[i].PaymentStatus === 2) {
                        $scope.transHisData[i].pending = true;
                    }
                    else if ($scope.transHisData[i].PaymentStatus === 3) {
                        $scope.transHisData[i].cancelled = true;
                    }
                    else {
                        $scope.transHisData[i].success = true;
                    }
                }

                $("#displayChildProject" + id).show();
            },
            function (error) {
            }
        );
    }

    //US329--end
    $scope.hideChildProject = function (id) {
        $("#displayChildProject" + id).hide();
    }
    $scope.showNonUserSection = function () {
        $scope.nonUserSection = false;
    }
    $scope.addNonSupporterUser = function () {
        $scope.nonUserSection = true;
    }
    var isEventCreatedByChild;
    $scope.CreateEvent = function (customEvent) {
        $scope.ActiveRegisteredSupporterInfo = [];
        $.each($scope.ActiveSupporterInfo, function (index) {
            $scope.supInfo = {};
            $scope.supInfo.supporterFirstName = $scope.ActiveSupporterInfo[index].firstName;
            $scope.supInfo.supporterLastName = $scope.ActiveSupporterInfo[index].lastName;
            if ($scope.ActiveSupporterInfo[index].image != null) { // need to be checked as per new image URL
                $scope.supInfo.supporterImage = $scope.ActiveSupporterInfo[index].image; // the image is already decoded base64
            } else {
                $scope.supInfo.supporterImage = images.defaultPersonImage;
            }
            $scope.supInfo.supporterID = $scope.ActiveSupporterInfo[index].supporterId;
            if ($scope.ActiveSupporterInfo[index].roleValue[0] == 2)
                $scope.ActiveRegisteredSupporterInfo.push($scope.supInfo);
        })
        var SupporterInfoList = $scope.ActiveRegisteredSupporterInfo;
        if ($stateParams.childEntry) {
            isEventCreatedByChild = true;
        } else {
            isEventCreatedByChild = false;
        }
        $("#createOrEditEvent").val("createEvent");
        $scope.eventactiontype = "CREATEEVENT";
        $rootScope.$broadcast('eventModal-started', { any: { "SupporterInfoList": SupporterInfoList, "images": images, "editevent": false, "clickEvent": customEvent, "childid": $stateParams.childId, "isEventCreatedByChild": isEventCreatedByChild, "childFirstName": $scope.childFirstName, "isSTExceedLmtSendfromChild": $scope.isSTExceedLmtChilPage, "shortTermAmount": $scope.shortTermMaxAmount } });
    }

    $scope.GetInvitedSupportersByEvent = function (eventid, isActive) {
        if (!isActive) {
            $scope.isEditEventButtonVisible = false;
            $scope.isDeletEventButtonVisible = false;
        }
        // need to pass event id
        var url = "/events/" + eventid + "/invitee";
        var res = WebApiService.getWebApiData(url);
        $scope.invitedsupporterlist = [];
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                $.each(data, function (index) {
                    $scope.invitedsupporter = {
                    };
                    $scope.invitedsupporter.supporterfirstname = data[index].PersonFirstName;
                    if (data[index].PersonNickName != null && $.trim(data[index].PersonNickName) != "" && data[index].PersonId != 0) {
                        $scope.invitedsupporter.supporternickname = data[index].PersonNickName;
                    } else {
                        $scope.invitedsupporter.supporternickname = data[index].PersonFirstName + " " + data[index].PersonLastName;
                    }
                    if (data[index].PersonImageUrl) {
                        $scope.invitedsupporter.supporterpicture = data[index].PersonImageUrl;
                    }
                    $scope.invitedsupporterlist.push($scope.invitedsupporter);
                });
            }, function (error) {
                //
            });
        }
    }

    $scope.DeleteEvent = function (eventid, parentid) {
        var url = "/parent/ " + parentid + "/events/" + eventid + "/status/false"; ///rejectevent/eventid/" + eventid + "/parentid/" + parentid; //+ "/action/4";
        var res = WebApiService.getWebApiData(url);
        if (res != undefined) {
            res.then(function (d) {
                $scope.GetAllEventInformation();
                $("#childEventDetails").animate({
                    "right": "-1053px",
                    "left": "100%"
                }, function () {
                    // Animation complete.
                    var maxHeight = -1;

                    $('#childEventHomePage').find('.event-timline-box').each(function () {
                        maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
                    });

                    $('#childEventHomePage').find('.event-timline-box').each(function () {
                        $(this).height(maxHeight);
                    });
                });
                $("#childEventHomePage").css({
                    "height": "auto",
                    "overflow-y": "visible"
                });
                $("#childEventHomePage").show();
            }).catch(function (d) {
                genericErrorMessageDisplay(angular.element('#errorForPopupInstantiation').val());
            });
        }
    };

    $scope.EditEventData = function (eventid) {
        $("#createOrEditEvent").val("editEvent");
        $scope.eventactiontype = "EDITEVENT";
        $scope.ActiveRegisteredSupporterInfo = [];
        $.each($scope.ActiveSupporterInfo, function (index) {
            $scope.supInfo = {};
            $scope.supInfo.supporterFirstName = $scope.ActiveSupporterInfo[index].firstName;
            $scope.supInfo.supporterLastName = $scope.ActiveSupporterInfo[index].lastName;
            if ($scope.ActiveSupporterInfo[index].image != null) { // need to be checked as per new image URL
                $scope.supInfo.supporterImage = $scope.ActiveSupporterInfo[index].image; // the image is already decoded base64
            } else {
                $scope.supInfo.supporterImage = images.defaultPersonImage;
            }
            $scope.supInfo.supporterID = $scope.ActiveSupporterInfo[index].supporterId;
            if ($scope.ActiveSupporterInfo[index].roleValue[0] == 2)
                $scope.ActiveRegisteredSupporterInfo.push($scope.supInfo);
        })
        var SupporterInfoList = $scope.ActiveRegisteredSupporterInfo;
        // need to pass event id
        var url = "/events/" + eventid;
        var res = WebApiService.getWebApiData(url);
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                $scope.existingEventData = data;
                $rootScope.$broadcast('eventModal-started', { any: { "SupporterInfoList": SupporterInfoList, "images": images, "editevent": true, "data": data, "isCreatedByChild": $stateParams.childEntry } });
            }, function (error) {
            });
        }
    }

    $scope.SeeChildActiveEventDetails = function (eventid) {
        $scope.childactiveeventid = eventid;
        var url = "/events/" + eventid;
        var res = WebApiService.getWebApiData(url);
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                $scope.eventMessage = data.EventMessage;
                $scope.eventTitle = data.EventName;
            }, function (error) {
            });
        }
        $("#childEventDetails").animate({
            "right": "0px"
        });
        $("#childEventHomePage").hide();
    }
    var nonsopporterid;
    $scope.NonRegSupporterInfoList = [];
    $scope.NonSupporterInfo = {};

    $scope.getContributeScreen = function () {
        $(".child-mobile").hide();
        $(".contribute-view").show();
    }

    /// For Setting thye content visisble for screen
    $scope.SetContentVisible = function (childId) {
        //Set the default value

        //Set the dafault content for Plan Details

        //Set the default content for the supporter
        $scope.isInvietASupporterButtonVisible = true;

        //Set the default content for the profile
        $scope.isParentalSettingSectionVisible = true
        $scope.isManageAdminSectionVisible = true;

        //set the default content of the events
        $scope.isCreateEventButtonVisible = true;
        $scope.isEditEventButtonVisible = true;
        /*---- change ïsDeletEventButtonVisible to isDeletEventButtonVisible due to jslint error ------*/
        $scope.isDeletEventButtonVisible = true;
        var url = "/person/" + $.cookie("personId") + "/otherpersonid/" + childId + "/applicationcontent";
        var res = WebApiService.getWebApiData(url);

        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);

                //Set the content for Plan Details

                //Set the content for the supporter
                $scope.isInvietASupporterButtonVisible = data.SuppporterContentModel.InviteSupporterButton;

                //Set the content for the profile
                $scope.isManageAdminSectionVisible = data.ProfileContentModel.ManageAdminSection;
                $scope.isParentalSettingSectionVisible = data.ProfileContentModel.ParentalSettingSection;

                ///set the content of the events
                $scope.isCreateEventButtonVisible = data.EventContentModel.CreateEventButton;
                $scope.isEditEventButtonVisible = data.EventContentModel.EditEventButton;
                $scope.isDeletEventButtonVisible = data.EventContentModel.DeleteEventButton;
            })
        }
    }

    //Getting default relationship list
    $scope.DefaultRelationship = function () {
        ChildProfileService.DefaultRelationship().then(
            function (data) {
                var result = [];
                for (var i in data)
                    result.push({
                        id: i,
                        name: data[i]
                    });
                $scope.defaultRelationship = result;
            },
            function (error) {
            }
        );
    }

    // Get all project by child
    $scope.getAllProjectsByChild = function (childId) {
        $scope.selectedchildidforevent = childId;

        if ($("#radio" + childId).prop("checked")) {
            for (i = 0; i < $scope.GroupInfoList.length; i++) {
                if ($scope.GroupInfoList[i].childId == childId) {
                    $("#childProject" + childId).css("display", "block");
                } else {
                    $("#radio" + $scope.GroupInfoList[i].childId).prop("checked", false);
                    $("#childProject" + $scope.GroupInfoList[i].childId).css("display", "none");
                }
            }
        }
        ChildProfileService.getAllProjectsByChild(childId).then(
            function (data) {
                $scope.projectInfoList = [];
                $.each(data, function (index) {
                    $scope.projectInfo = {
                    };
                    $scope.projectInfo.projectTitle = data[index].Title;
                    $scope.projectInfo.projectPlanId = data[index].PlanId;
                    if (data[index].Image != null) {
                        $scope.projectInfo.projectImage = images.dataImage + data[index].Image;
                    } else {
                        $scope.projectInfo.projectImage = images.defaultPersonImage;
                    }
                    $scope.projectInfo.projectId = data[index].ID;
                    $scope.projectInfoList.push($scope.projectInfo);
                })
            },
            function (error) {
            }
        );
    }

    $scope.getAllProjectsByChildAdd = function (childId) {
        ValidateEventFields();
        $scope.selectedchildidforevent = childId;

        if ($("#radio" + childId).prop("checked")) {
            $scope.ifcratechildselected = false;
            for (i = 0; i < $scope.GroupInfoList.length; i++) {
                if ($scope.GroupInfoList[i].childId == childId) {
                    if ($scope.isEditEventPage) {
                        $("#childProject" + childId).css("display", "block"); //commented for Defect 5340
                    }
                } else {
                    $("#radio" + $scope.GroupInfoList[i].childId).prop("checked", false);
                    $("#childProject" + $scope.GroupInfoList[i].childId).css("display", "none");
                }
            }
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        }
        ChildProfileService.getChildProjectById(childId).then(
            function (data) {
                if (!$scope.isEditEventPage) {
                    $("#childProject" + childId).css("display", "block");//added for Defect 5340
                }
                $scope.transInfo = {};
                $scope.transHisData = [];

                for (i = 0; i < data.length; i++) {
                    data[i].ProjectImage = images.dataImage + data[i].ProjectImage;
                    data[i].Title = data[i].Title;
                }
                $scope.transHisData = data;

                for (i = 0; i < $scope.transHisData.length; i++) {
                    if ($scope.transHisData[i].PaymentStatus === 2) {
                        $scope.transHisData[i].pending = true;
                    }
                    else if ($scope.transHisData[i].PaymentStatus === 3) {
                        $scope.transHisData[i].cancelled = true;
                    }
                    else {
                        $scope.transHisData[i].success = true;
                    }
                }

                if (data.length > 0) {
                    $("#childProject" + childId).css("display", "block");
                }
                else {
                    $("#childProject" + childId).css("display", "none");
                }
            },
            function (error) {
            }
        );
    }
    //Posting Event invitation details
    $scope.supporterIdList = [];
    $scope.selectedProjectList = [];
    $scope.NonRegSelectedSupporterIdList = [];
    $scope.NonRegSelectedSupporterIdListNew = [];

    $scope.ValidateRegSupporterSelectionOnSave = function () {
        var blnresponse = ValidateRegSupporterSelection($scope.supporterIdList, $scope.NonRegSelectedSupporterIdList);
        return blnresponse;
    }

    // Getting Active Event Details
    $scope.GetActiveEventDetails = function () {
        $scope.activeEventDetails = MapEventDetails($scope.activeEvents);
        $.each($scope.activeEventDetails, function () {
            var eventName = this.EventName;
            var thisLength = eventName.length;
            if (thisLength > 60) {
                eventName = eventName.substring(1, 60) + "...";
                this.EventName = eventName;
            }
        })
    }

    $scope.EventModalClosed = function () {
        $scope.ifcratechildselected = false;

        if ($scope.isEditEventPage = false) {
            $("#childProject" + $scope.selectedchildidforevent).css("display", "none");
            $("#eventModal input").prop("checked", false);
        }

        $scope.dateFiledTextBox = false;
        if ($('html').hasClass('touch')) {
            $("#createevent").show();
            $("#btneventcontribute").show();
            $("#childBlock .child-group").show();
            $("#wrapper #divHideFirst").show();
        }
        else {
            $("#createevent").show();
            $("#btneventcontribute").show();
            $("#childBlock .child-group").show();
            $("#wrapper #divHideFirst").show();
        }
    }

    $rootScope.$on("onEventSuccess", function () {
        setTimeout(function () {
            angular.element(".csm-first-menu").removeClass("csm-expanded-menu");
            angular.element(".csm-sub-menu-list").removeClass("active-sub-menu");
            angular.element("#event").parent().addClass("csm-active-list");
            $scope.GetAllEventInformation();
            $scope.backToEvent();
        }, 1000);
    })

    $scope.GetAllEventInformation = function () {
        $scope.myYongoPlanActive = false;
        $state.go("child.detail.event");
        $scope.sectionname = "Event";
        var childId = $scope.actualChildId;
        if ($rootScope.isChild) {
            $scope.hideContributeButton = true;
        } else {
            $scope.hideContributeButton = false;
        }
        ChildProfileService.GetAllEvents(childId).then(

                function (data) {
                    $scope.activeEvents = [];
                    $scope.pendingEvents = [];
                    $scope.pastTwoEvents = [];
                    $.each(data, function (index) {
                        if (data[index].IsActiveEvent) {
                            $scope.activeEvents.push(data[index]);
                        }
                        if (data[index].IsPendingEvent) {
                            $scope.pendingEvents.push(data[index]);
                        }
                        if (data[index].IsPastEvent) {
                            $scope.pastTwoEvents.push(data[index]);
                        }
                    });
                    $scope.GetActiveEventDetails();
                    $scope.GetWaitingEventDetails();
                    $scope.GetPastEventDetails();
                },
                function (error) {
                }
            );
        $("#divDescription").css("height", "auto");
    }

    $scope.sectionname = "Plan";

    $scope.GetChildPlanInformation = function (state) {
        $scope.myYongoPlanActive = true;
        $state.go("child.detail.plan.termPlan", {
            'state': state,
            'routingEntry': null
        }, {
            reload: true
        });
        $scope.sectionname = "Plan";
        var childId = $scope.id;
        $scope.isSupporterHistoryVisible = false;
        $scope.isTransactionHistoryVisible = false;
        $scope.isChildSupporterListToBeshown = false;
        $(".trans-history").css("left", "100%");
        $(".trans-history").css("display", "none");
        $(".long-term").css("left", "0%");
        $(".short-term").css("left", "0%");
        //change
        localStorage.setItem("currentSection", "plan");
        $scope.getShortTermProjectsDetail($scope.personId, childId);
    }
    $scope.savingSchoolDataBindingForChild = function (savingSchoolDetail) {
        var activeProjectCount = 0;
        $scope.shortTermProjects = [];

        if ($rootScope.isChild && !savingSchoolDetail.IsSubscribingParent) { //defect 6895 fix
            $scope.hideContributeButton = true;
        } else {
            $scope.hideContributeButton = false;
        }

        $.each(savingSchoolDetail.ShortTermProjects, function (index) {
            if ($scope.shortTermProjects.length <= 3) {
                if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active") {
                    var shortTermProjectInfo = {};
                    shortTermProjectInfo.projectCurrentAmount = 0;
                    shortTermProjectInfo.projectOtherAmount = 0;
                    shortTermProjectInfo.projectTitle = savingSchoolDetail.ShortTermProjects[index].ProjectTitle;
                    shortTermProjectInfo.projectPriority = savingSchoolDetail.ShortTermProjects[index].ProjectPriority;
                    shortTermProjectInfo.projectId = savingSchoolDetail.ShortTermProjects[index].ProjectId;

                    shortTermProjectInfo.projectStatus = savingSchoolDetail.ShortTermProjects[index].ProjectStatus;
                    if ($scope.showProjectProgressBar == false) {
                        shortTermProjectInfo.projectStatus = "InActive";
                    }
                    shortTermProjectInfo.projectDescription = savingSchoolDetail.ShortTermProjects[index].ProjectDescription;
                    shortTermProjectInfo.projectCategory = savingSchoolDetail.ShortTermProjects[index].ProjectCategory;
                    shortTermProjectInfo.projectImage = savingSchoolDetail.ShortTermProjects[index].ProjectImageUrl;
                    shortTermProjectInfo.targetProjectAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectTargetAmount, $scope.language);

                    if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active") {
                        shortTermProjectInfo.projectCurrentAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectCurrentValue, $scope.language);
                        shortTermProjectInfo.projectTotalAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectTotalAmount, $scope.language);

                        if (savingSchoolDetail.Level == SavingSchoolLevel.Level2) {
                            shortTermProjectInfo.projectOtherAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectOtherAmount, $scope.language);
                        }
                        activeProjectCount++;
                    }
                    var graphDetails = $scope.graphCalculator(Number(savingSchoolDetail.ShortTermProjects[index].ProjectTargetAmount), Number(savingSchoolDetail.ShortTermProjects[index].ProjectCurrentValue), Number(savingSchoolDetail.ShortTermProjects[index].ProjectOtherAmount));
                    shortTermProjectInfo.offset1 = graphDetails.offset1;
                    shortTermProjectInfo.offset2 = graphDetails.offset2;
                    $scope.shortTermProjects.push(shortTermProjectInfo);
                }
            }
            else {
                return false;
            }
        });
        $scope.numOfActiveProj = activeProjectCount;
    }
    $scope.savingSchoolDataBinding = function (savingSchoolDetail) {
        var activeProjectCount = 0;
        $scope.shortTermProjects = [];
        $.each(savingSchoolDetail.ShortTermProjects, function (index) {
            if ($scope.shortTermProjects.length <= 3) {
                if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active" || savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Pending") {
                    var shortTermProjectInfo = {};
                    shortTermProjectInfo.projectCurrentAmount = 0;
                    shortTermProjectInfo.projectOtherAmount = 0;
                    shortTermProjectInfo.projectTitle = savingSchoolDetail.ShortTermProjects[index].ProjectTitle;
                    shortTermProjectInfo.projectPriority = savingSchoolDetail.ShortTermProjects[index].ProjectPriority;
                    shortTermProjectInfo.projectId = savingSchoolDetail.ShortTermProjects[index].ProjectId;

                    shortTermProjectInfo.projectStatus = savingSchoolDetail.ShortTermProjects[index].ProjectStatus;
                    if ($scope.showProjectProgressBar == false) {
                        shortTermProjectInfo.projectStatus = "InActive";
                    }
                    shortTermProjectInfo.projectDescription = savingSchoolDetail.ShortTermProjects[index].ProjectDescription;
                    shortTermProjectInfo.projectCategory = savingSchoolDetail.ShortTermProjects[index].ProjectCategory;
                    shortTermProjectInfo.projectImage = savingSchoolDetail.ShortTermProjects[index].ProjectImageUrl;
                    shortTermProjectInfo.targetProjectAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectTargetAmount, $scope.language);

                    if (savingSchoolDetail.ShortTermProjects[index].ProjectStatus == "Active") {
                        shortTermProjectInfo.projectCurrentAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectCurrentValue, $scope.language);
                        shortTermProjectInfo.projectTotalAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectTotalAmount, $scope.language);

                        if (savingSchoolDetail.Level == SavingSchoolLevel.Level2) {
                            shortTermProjectInfo.projectOtherAmount = formatAmountField(savingSchoolDetail.ShortTermProjects[index].ProjectOtherAmount, $scope.language);
                        }
                        activeProjectCount++;
                    }
                    var graphDetails = $scope.graphCalculator(Number(savingSchoolDetail.ShortTermProjects[index].ProjectTargetAmount), Number(savingSchoolDetail.ShortTermProjects[index].ProjectCurrentValue), Number(savingSchoolDetail.ShortTermProjects[index].ProjectOtherAmount));
                    shortTermProjectInfo.offset1 = graphDetails.offset1;
                    shortTermProjectInfo.offset2 = graphDetails.offset2;
                    $scope.shortTermProjects.push(shortTermProjectInfo);
                }
            }
            else {
                return false;
            }
        });
        $scope.numOfActiveProj = activeProjectCount;
    }
    $scope.getShortTermProjectsDetail = function (personId, childId) {
        $scope.activeProjectsNumber = 0;
        var shortTermPlanValidationType = 1;
        if (!savingSchoolService.getSavingSchoolData()) {
            if (childId && personId) {
                savingSchoolService.getSavingSchoolDetail(personId, childId).then(
                     function (data) {
                         $scope.savingSchoolDetail = {};
                         var savingSchoolDetail = data;
                         savingSchoolService.setSavingSchoolData(savingSchoolDetail);
                         $scope.activeProjects = [];
                         $scope.shortTermProjects = [];
                         if (savingSchoolDetail != null) {
                             if (savingSchoolDetail.ShortTermProjects != null) {
                                 if (savingSchoolDetail.ShortTermProjects.length > 0) {
                                     if (!$rootScope.isChild) {
                                         $scope.savingSchoolDataBinding(savingSchoolDetail);
                                     }
                                     else {
                                         $scope.savingSchoolDataBindingForChild(savingSchoolDetail);
                                     }
                                 }
                             }
                             //end change
                         }
                     },
                function (error) {
                }
            );
            }
        }
        else {
            var savingSchoolDetail = savingSchoolService.getSavingSchoolData();
            if (!$rootScope.isChild) {
                $scope.savingSchoolDataBinding(savingSchoolDetail);
            } else {
                $scope.savingSchoolDataBindingForChild(savingSchoolDetail);
            }
        }
    }

    $scope.graphCalculator = function (totalVal, graphOne, graphTwo) {
        var totalGraphValue = totalVal;
        var primaryVal = graphOne;
        var secondaryVal = graphTwo;
        var primaryValPercentage = Number(primaryVal / totalGraphValue * 100);
        var secondaryValPercentage = Number(secondaryVal / totalGraphValue * 100);
        // code for putting values in graph
        var graphCircumference = 220; //constant value for the radius used in the circular graph
        var primaryValGraph = Number(primaryValPercentage / 100 * graphCircumference);
        var secondaryValGraph = Number(secondaryValPercentage / 100 * graphCircumference);
        var primaryOffset = graphCircumference - primaryValGraph;
        var secondaryOffset = graphCircumference - (primaryValGraph + secondaryValGraph);

        var secondGraphPath = graphCircumference - primaryValGraph;
        return {
            "offset1": primaryOffset, "offset2": primaryOffset != 220 ? secondaryOffset + 2 : secondaryOffset
        };
    };

    $scope.$on("isSavingSchool", function () {
        $scope.sectionname = "Saving School";
    })
    $scope.GetSupporterInformation = function () {
        $scope.myYongoPlanActive = false;
        $scope.sectionname = "Supporter";
        $state.go("child.detail.supporter");
    }
    $scope.GetProfileInformation = function () {
        $scope.myYongoPlanActive = false;
        $state.go("child.detail.profile");
        $scope.sectionname = "Profile";
    }

    $scope.SeeDetails = function (active) {
        $scope.chidDetails = active;
        $scope.showEventBackLabel = true;
        $scope.GetInvitedSupportersByEvent(active.ID, true)
        $scope.selectedeventid = active.ID;
        $state.go("child.detail.event.detail", {
            eventId: $scope.selectedeventid
        });
    }

    $scope.SeePastDetails = function (past) {
        $scope.chidDetails = past;
        $scope.showEventBackLabel = true;
        $scope.GetInvitedSupportersByEvent(past.ID, false)
        $scope.selectedeventid = past.ID;
        $state.go("child.detail.event.detail", {
            eventId: $scope.selectedeventid
        });
    }

    $scope.backToEvent = function () {
        $scope.showEventBackLabel = false;
        $("#childEventDetails").animate({
            "left": "110%"
        });
        $("#childEventHomePage").css({
            "height": "auto",
            "overflow-y": "visible"
        });
        $state.go("child.detail.event");
    }
    // Getting waiting for approval Event Details
    $scope.GetWaitingEventDetails = function () {
        $scope.waitingEventDetails = MapEventDetails($scope.pendingEvents);
        $.each($scope.waitingEventDetails, function () {
            var eventName = this.EventName;
            var thisLength = eventName.length;
            if (thisLength > 60) {
                eventName = eventName.substring(1, 60) + "...";
                this.EventName = eventName;
            }
        })
    }

    // Getting waiting Event Details
    $scope.GetPastEventDetails = function () {
        $scope.pastEventDetails = MapEventDetails($scope.pastTwoEvents);
        $.each($scope.pastEventDetails, function () {
            var eventName = this.EventName;
            var thisLength = eventName.length;
            if (thisLength > 60) {
                eventName = eventName.substring(1, 60) + "...";
                this.EventName = eventName;
            }
        })
    }

    function MapEventDetails(data) {
        $.each(data, function (index, element) {
            if (element.PictureUrl != null) {
                element.Picture = element.PictureUrl;
            }
        });

        return data;
    }

    $(document).ready(function () {
        $("#childEventDetails").animate({
            "right": "-1053px"
        });
        $(".scroll").mCustomScrollbar({
            axis: "y",
            scrollbarPosition: "outside"
        });
    });

    $("#SaveAndNotify, #NotToSave").on("click", function () {
        $("#eventModal").css("z-index", "1050");
        $("#saveSubWindow").hide();

        if ($('html').hasClass('touch')) {
            $("#createevent").show();
            $("#btneventcontribute").show();
            $("#childBlock .child-group").show();
            $("#wrapper #divHideFirst").show();
        }
        else {
            $("#createevent").show();
            $("#btneventcontribute").show();
            $("#childBlock .child-group").show();
            $("#wrapper #divHideFirst").show();
        }
    });
    $("#NotToSave").on("click", function () {
        $("#eventModal").modal("show");
    });

    /*Copied from EditProfileController.js--  for defect 2184*/
    var emailPattern = /^[-a-zA-Z0-9~!$%^&*_=+}|`#{/'?]+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var language = $.cookie("language");
    $scope.language = language;
    $scope.personId = $.cookie("personId");
    var urlRetrieveParentInformation = "/members/" + $scope.selectedChildID + "/subscribingparent";
    var res = WebApiService.getWebApiData(urlRetrieveParentInformation);
    if (res != undefined) {
        res.then(function (d) {
            if (d.data != null) {
                var response = JSON.stringify(d.data.Result);
                var data = JSON.parse(response);
                $scope.parentFullName = data.PersonFirstName + " " + data.PersonLastName;
                var parentName = $scope.parentFullName;
                var thisLength = parentName.length;
                if (thisLength > 43) {
                    parentName = parentName.substring(0, 43) + "...";
                    $scope.parentFullName = parentName;
                }
                $scope.childParentId = data.PersonId;
                if (data.PersonImageUrl) {
                    $scope.parentImage = data.PersonImageUrl;
                } else {
                    $scope.parentImage = images.defaultPersonImage;
                }
            }
        });
    }

    $scope.deleteParentConfirmModal = function (customEvent) {
        customEvent.stopPropagation();
        customEvent.stopImmediatePropagation();
        $rootScope.$broadcast('deleteParent-started', { any: { "adminNickName": $scope.adminNickName, "firstName": $scope.IndInfo.firstName } });
    }
    $scope.$on('deleteParent-confirm', function (event, args) {
        $scope.DeleteAdmin();
    });
    $rootScope.$on('addParent-confirm', function (event, args) {
        $scope.GetAdminByChild();
    });

    $scope.DeleteAdmin = function () {
        EditProfileService.DeleteAdmin($scope.personId, $scope.actualChildId, $scope.adminId).then(
            function (data) {
                $("#deleteParentConfirmModal").modal("hide");
                genericSuccessMessageDisplay(Resources.DeleteAdmin_Success);
                $scope.GetAdminByChild();
                $scope.isAdminSectionVisible = false;
                $scope.isAddAdminSectionVisible = true;
                $scope.isDeleteAdminSectionVisible = false;
            },
            function (error) {
                $("#deleteParentConfirmModal").modal("hide");
                genericErrorMessageDisplay(Resources.DeleteAdmin_Failed);
            }
        );
    }

    /* Saving Paental Control*/
    $scope.SaveParentalControl = function () {
        if ($.cookie("childId") == 0 || $.cookie("childId") == null || $.cookie("childId") == "") {
            var childId = $scope.selectedChildID;
        }
        else {
            var childId = $.cookie("childId");
        }
        var postData = {
            ParentID: $.cookie("personId"),
            ChildID: childId,
            LTSP: $scope.parentalControl.longTermAnswer,
            ContributionHistoryLTSP: $scope.parentalControl.createEvent,
            AmountonShortTermplan: $scope.parentalControl.currentAmountAnswer,
            ManageEvents: $scope.parentalControl.createEvent, //changes as part of Event module sanitizing
            InviteContributors: $scope.parentalControl.inviteContributor,
            updatedBy: $scope.personId,
            EditPersonalData: $scope.parentalControl.editPersonalData,
            EditProfilePicture: $scope.parentalControl.editProfilePicture,
            CreateProject: $scope.parentalControl.createProject,
            ActivateSavingSchoolLevel2: $scope.parentalControl.levelActivate
        }
        EditProfileService.SaveParentalControl(postData).then(
            function (data) {
                $scope.GetParentalInformationBasedonParentID();
                savingSchoolService.setSavingSchoolData("");
                $scope.parentalButton = false; //added for US330
                parentalsettingsService.setData('Dataname', { 'parentalArr': $scope.parentalControl });
                genericSuccessMessageDisplay();
            },
            function (error) {
                genericErrorMessageDisplay(angular.element('#errorForPopupInstantiation').val());
            }
        );
    }

    /*Rset Parental Control button*/ //US330
    $scope.ResetParentalControl = function () {
        $scope.GetParentalInformationBasedonParentID();
    }
    //Added for parentalsetting popup change--start//US330
    $scope.IsValueChange = function () {
        var selectedlngtrm = $("input[type='radio'][name='longTermPlan']:checked");
        var selectedcurrntPln = $("input[type='radio'][name='currentTermPlan']:checked");
        var selectedinviteTermPlan = $("input[type='radio'][name='inviteTermPlan']:checked");
        var selectedlcreateTermPlan = $("input[type='radio'][name='createTermPlan']:checked");
        var selectedlpersonalData = $("input[type='radio'][name='personalData']:checked");
        var selectedprofilePictureEdit = $("input[type='radio'][name='profilePictureEdit']:checked");
        var selectedprojectCreate = $("input[type='radio'][name='projectCreate']:checked");
        var selectedactivateLevel = $("input[type='radio'][name='activateLevel']:checked");
        var currentpage = window.location.pathname;
        var ab = currentpage.substring(1, 14);

        if (selectedlngtrm.length > 0 || selectedcurrntPln.length > 0 || selectedinviteTermPlan.length > 0 || selectedlcreateTermPlan.length > 0 || selectedlpersonalData.length > 0 || selectedprofilePictureEdit.length > 0 || selectedprojectCreate.length > 0 || selectedactivateLevel.length > 0) {
            setting = "changed";
            return setting;
        }
    }

    //Added for parentalsetting popup change--end

    $("#modalCancelBtn").on("click", function () {
        var checked = $(this).attr("checked");
        if (checked) {
            $(this).attr("checked", false);
        } else {
            $(this).attr("checked", true);
        }
    });

    $scope.initParentalControl = function () {
        $scope.initializingParentalControl = true;
        $scope.defaultParentalControl();

        $scope.$watch('parentalControl', function (newVal, oldVal) {
            if (!$scope.initializingParentalControl) {
                $scope.parentalButton = true;
            }
        }, true);
    }

    $scope.defaultParentalControl = function () {
        $scope.parentalControl = {
            currentAmountAnswer: false,
            longTermAnswer: false,
            inviteContributor: false,
            createEvent: false,
            parentalButton: false,
            editPersonalData: false,
            editProfilePicture: false,
            createProject: false,
            levelActivate: false
        };
    }

    /* Get Parental Information Based on Parent ID*/
    $scope.GetParentalInformationBasedonParentID = function () {
        var parentId = $.cookie("personId");
        if ($.cookie("childId") == 0 || $.cookie("childId") == null || $.cookie("childId") == "") {
            var childId = $scope.selectedChildID;
        }
        else {
            var childId = $.cookie("childId");
        }

        $scope.initParentalControl();

        $scope.initializingParentalControl = true;

        EditProfileService.GetParentalInformationBasedonParentID(parentId, childId).then(
            function (data) {
                if (data) {
                    $scope.CheckAdultChild();

                    $scope.parentalControl = {
                        longTermAnswer: data.LTSP,
                        currentAmountAnswer: data.AmountonShortTermplan,
                        inviteContributor: data.InviteContributors,
                        createEvent: data.ManageEvents,
                        editPersonalData: data.EditPersonalData,
                        editProfilePicture: data.EditProfilePicture,
                        createProject: data.CreateProject,
                        levelActivate: data.ActivateSavingSchoolLevel2
                    };
                    parentalsettingsService.setData('Dataname', { 'parentalArr': $scope.parentalControl });
                    $scope.parentalButton = false;
                } else {
                    $scope.CheckAdultChild();
                    $scope.defaultParentalControl();
                }
                setTimeout(function () { $scope.initializingParentalControl = false; }, 0);
            },
            function (error) {
                setTimeout(function () { $scope.initializingParentalControl = false; }, 0);
            }
        );
    }

    $scope.questionOptionChanged = function (questionType) {
        if (questionType == 'levelActivate' && $scope.parentalControl.levelActivate) {
            if (!$scope.parentalControl.currentAmountAnswer && $scope.parentalControl.levelActivate) {
                $rootScope.$broadcast("parental-setting-change-triggered", { childFirstName: $scope.IndInfo.firstName, showMsgForProjects: true, showMsgForShortTerm: false });
                $("#parentalSettingChangeModal").modal("show");
            }
        }
        if (questionType == 'currentAmountAnswer' && !$scope.parentalControl.currentAmountAnswer) {
            if (!$scope.parentalControl.currentAmountAnswer && $scope.parentalControl.levelActivate) {
                $rootScope.$broadcast("parental-setting-change-triggered", { childFirstName: $scope.IndInfo.firstName, showMsgForProjects: false, showMsgForShortTerm: true });
                $("#parentalSettingChangeModal").modal("show");
            }
        }
    }
    $scope.$on("revert-setting-for-saving-academy-option", function (event, args) {
        $scope.parentalControl.levelActivate = false;
    });

    $scope.$on("revert-setting-for-short-term-option", function (event, args) {
        $scope.parentalControl.currentAmountAnswer = true;
    });
    $scope.$on("implement-setting-for-saving-academy-option", function (event, args) {
        $scope.parentalControl.currentAmountAnswer = true;
        $scope.parentalControl.levelActivate = true;
    });
    $scope.$on("implement-setting-for-short-term-option", function (event, args) {
        $scope.parentalControl.currentAmountAnswer = false;
        $scope.parentalControl.levelActivate = false;
    })
    $scope.CheckAdultChild = function () {
        var childId = $scope.selectedChildID;//$.cookie("childId");
        EditProfileService.CheckAdultChild(childId).then(
            function (data, status) {
                if (data.Result) {
                    $scope.isAdultChild = data.Result;
                    if ($scope.isAdultChild) {
                        $scope.isCreateProject = true;
                        $scope.isActivateLevel = true;
                    }
                    else {
                        $scope.isCreateProject = false;
                        $scope.isActivateLevel = false;
                    }
                }
            },
            function (error) {
            });
    }
    $scope.newNameregex = newnameRegex;

    $rootScope.$on('userModal-update-child', function (event, args) {
        $scope.childProfileDetailsForEdit = args.userProfileDetailsForEdit;
        $scope.updateSettingData();
    });
    
    $scope.updateSettingData = function () {
        EditProfileService.UpdateChildProfile($scope.selectedChildID, $scope.childProfileDetailsForEdit).then(
            function (data) {
                $("#editProfileModal").modal("hide");
                $scope.GetChildProfile();
                genericSuccessMessageDisplay(Resources.SuccessfulYourPersonalDetailsAreSaved);
            },
            function (error) {
                genericModalErrorDisplayMessage(Resources.EditChildProfile_Failed, "edit-profile-failure-msg");
            }
        );
        $scope.childProfileDetailsForEdit = '';
    };

    $scope.updateChildPicture = function (elemName) {
        var personId = $.cookie("personId");
        var childId = $scope.selectedChildID;
        $scope.personImage = $('#' + elemName).find('.demoImg').attr('src');

        //GroupInfoList

        var request = {
            profilePictureData: $scope.personImage,
        };

        EditProfileService.UpdateChildPicture(request, childId).then(
            function (data) {
                genericSuccessMessageDisplay();
                $scope.editChildPictureUrl = $scope.personImage;
                $scope.GetMyChildrenDetail();
            },
            function (error) {
            }
        );
    }

    $scope.navigateToMoneyOut = function (selectedChildId, state) {
        $state.go('moneyout', { childId: selectedChildId, childState: state });
    };
    $scope.navigateToSavingSchool = function (entryPoint) {
        savingSchoolService.setSavingSchoolData("");
        $scope.myYongoPlanActive = false;
        $state.go('child.detail.savingschool', { routingEntry: entryPoint, childFirstName: $rootScope.childName, canDoMoneyOut: $scope.hideMoneyOut, childImage: $scope.IndInfo.imagePath });
    };
    $scope.createProjectForChild = function () {
        $rootScope.$broadcast('projectModal-started', {
            any: {
                "isEdit": false, "editData": "", "isProject": true, "language": $scope.languageid, "edit": null, "childId": $stateParams.childId, "entryLocation": "childplan", "childFirstName": $scope.IndInfo.firstName
            }
        });
    }
    localStorage.fromPaymentStatusScreen = false;

    $(window).resize(function () {
        $scope.$apply(function () {
            $scope.windowWidth = window.innerWidth;
        });
        angular.element('.defs-container').removeClass('info-mobile-overlay').css('display', 'none');
        angular.element(".term-desc").removeClass('info-mobile-overlay-defs').css('top', 0);
        unfreezeBackground();
    });
    $scope.triggerImgChangeInMobile = function () {
        angular.element("#changeChild-image-mobile button.select-image-dropzone").trigger('click');
}
    $scope.$on('$viewContentLoaded', function (event) {
        if ($stateParams.navigateToEventFromChildDB && $rootScope.$state.current.name == 'child.detail.plan') {
            $scope.GetAllEventInformation();
        }
    });
    $scope.sendAReminder = function (supporterId) {
        $("#SupporterReminderModal").modal('show');
        WebApiService.GetPendingSupporterDetails(supporterId).then(function (d) {
            console.log(d);
            $rootScope.$broadcast('remindTheSupporter', { any: { supporterData: d.data, childName: $scope.IndInfo.firstName, childImage: $scope.IndInfo.imagePath } });
        });
    }

}]);

myAppangular.directive("toggleDefBlock", function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            elem.bind('click', function () {
                var className = elem.attr('click-target');
                if (window.innerWidth > 767) {
                    angular.element(".defs-container").hide();
                    angular.element("." + className).toggle();
                } else {
                    freezeBackground();

                    var elemPosTop = elem.offset().top - angular.element(document).scrollTop();
                    var elemPosLeft = elem.offset().left - angular.element(document).scrollLeft();
                    angular.element("." + className).show();
                    angular.element("." + className).addClass('info-mobile-overlay').height(window.innerHeight);
                    if (Number(elemPosTop + angular.element("." + className + " .term-desc").height()) > Number(window.innerHeight - 30)) {
                        angular.element("." + className + " .term-desc").addClass('info-mobile-overlay-defs').css('top', Number(elemPosTop - 30 - angular.element("." + className + " .term-desc").height()));
                    }
                    else {
                        angular.element("." + className + " .term-desc").addClass('info-mobile-overlay-defs').css('top', Number(elemPosTop + 30));
                    }
                    angular.element("." + className + " .info-mobile").css({ 'top': elemPosTop, 'left': elemPosLeft });
                }
                $(document).bind('click', function (event) {
                    if (event.target.className.indexOf('term-desc') == -1 && event.target.className.indexOf('def-icon') == -1) {
                        $('.defs-container').hide();
                        unfreezeBackground();
                    }
                })
            });
        }
    };
});
myAppangular.directive('closeDefBlock', function () {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            elem.bind('click', function () {
                var className = elem.attr('click-target');
                if (window.innerWidth < 768) {
                    unfreezeBackground();
                    angular.element("." + className).hide();
                    angular.element("." + className).removeClass('info-mobile-overlay');
                    angular.element("." + className + " .term-desc").removeClass('info-mobile-overlay-defs').css('top', 0);
                }
            });
        }
    }
});