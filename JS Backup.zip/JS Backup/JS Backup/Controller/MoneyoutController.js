﻿myAppangular.controller("moneyoutController", ["$scope", "$rootScope", "WebApiService", "$filter", "$stateParams", "$state", "savingSchoolService", "gemaltoFactory", function ($scope, $rootScope, WebApiService, $filter, $stateParams, $state, savingSchoolService, gemaltoFactory) {

    $scope.overviewState = $stateParams.childState;
    $scope.selectedChildId = $stateParams.childId;
    $scope.language = $stateParams.language;
    // var phoneNumber = $rootScope.personPhone;
    // $scope.lastTwoDigit = phoneNumber % 100;
    var timeLimit = 0;
    var phoneNumber = $rootScope.personPhone;
    if (phoneNumber) {
    $scope.lastTwoDigit = phoneNumber.slice(-2);
    }
    if (eidSwitch == true) {
        $scope.eidSwitch = true;
    }
    window.onbeforeunload = confirmExit;
    function confirmExit() {
        if (!(localStorage.getItem("moneyOutConfirmSuccess") === "true")) {
            var autoDeleteMoneyOutUrl = '/moneyout/person/self/child/' + $scope.selectedChildId + '/autodelete';
            WebApiService.updateData(autoDeleteMoneyOutUrl, $scope.moneyOutDetail).success(function (data, status) {

            })
            .error(function (data, status) {

            });
        }
    }
    $scope.$on('$stateChangeStart', function (e, toState, toParams, fromState, fromParams) {
        if (!(toState.name == 'child.detail.plan.termPlan' || toState.name == 'moneyout')) {
            confirmExit();
        }
    });
    var ProofOfIdentity = [{
        "Barcode": "",
        "ChildId": 0,
        "ExpiryDate": "",
        "IdentityProofNumber": "",
        "Image": "",
        "ImageBase64": [],
        "ImageBase64ForSingleImage": "",
        "ImageForSingleImage": "",
        "ImageName": "BackImage",
        "ImageTypeCode": 2,
        "ImageUri": "",
        "IsUserSettings": "",
        "PersonId": parentID
    }, {
        "Barcode": "",
        "ChildId": 0,
        "ExpiryDate": "",
        "IdentityProofNumber": "",
        "Image": "",
        "ImageBase64": [],
        "ImageBase64ForSingleImage": "",
        "ImageForSingleImage": "",
        "ImageName": "FrontID",
        "ImageTypeCode": 3,
        "ImageUri": "",
        "IsUserSettings": "",
        "PersonId": parentID
    }];

    $scope.Eid = {
        "front": "",
        "back": ""
    };
    $scope.init = function () {

        $scope.stProjectId = "";
        $scope.stProjectPriority = "";
        $scope.moneyOutDetail = {};




        $scope.childId = $.cookie("childId");
        $scope.personId = $.cookie("personId");
        $scope.childFirstName;
        $scope.parentFirstName;
        $scope.childImage;
        $scope.childNickName;
        $scope.childName;
        $scope.availableAmount;
        $scope.reserveAmount = 0;
        $scope.minValue;
        $scope.maxValue;
        $scope.projectInfoList = [];
        $scope.childDetail = {};
        $scope.planId;
        $scope.accountHolderFirstName;
        $scope.accountHolderLastName;
        $scope.iban;
        $scope.bic;

        $scope.longTermValue;
        $scope.nextDisabled = true;
        $scope.totalProjectValue = 0;
        //show & hide sections based on conditions
        $scope.showInitialHeader = false;
        $scope.showShortTermToFreeTransfer = false;
        $scope.showShortTermToLongTerm = false;
        $scope.showLabelSection = false;
        $scope.showDropdownSection = false;
        $scope.showPaymentDetails = false;
        $scope.showShortTermTitle = false;
        $scope.showLongTermTitle = false;
        $scope.showSummary = false;
        $scope.showInitialSection = false;
        $scope.showNext = false;
        $scope.showConfirm = false;
        $scope.showSummaryForLongTerm = false;
        $scope.showSummaryForTransfer = false;
        $scope.showSummaryPayment = false;
        $scope.showSmsInfo = false;
        $scope.showSummaryTitleForLT = false;
        $scope.showSummaryTitleForTransfer = false;
        $scope.backFromConfirm = false;
        $scope.showMoneyOutView = true;
        //$scope.bankAccountchecked = true;
        $scope.FiscalResidenceDetails = [{ "CountryCodeForFiscalResidence": "", "FiscalResidenceId": 0, "TinNumber": "" }];

        //fetch money out details
        $scope.getMoneyOutDetails($scope.personId, $scope.selectedChildId);
        $scope.getMoneyOutQuestionDetails($scope.personId, $scope.language);
        $scope.moneyOutType = "longTermRadioVal";
        $scope.navigatedFromSavingschool = false;
        if ($stateParams.obj) {
            $scope.navigatedFromSavingschool = true;
        }
    }

    $scope.getMoneyOutQuestionDetails = function (personId, language) {
        var url = '/moneyout/person/' + personId + '/getMoneyOutLegalQuestion';
        if (personId) {
            var res = WebApiService.getWebApiData(url, language);
        }
        if (res) {
            res.then(function (d) {
                var questionResponse = d.data.Result;
                $scope.questionDetails = {
                    "HasUsaCitizenship": questionResponse.OtherDetails.HasUsaCitizenship.toString(),
                    "IsUsaCitizenOrResident": questionResponse.OtherDetails.IsUsaCitizenOrResident.toString(),
                    "IsBelgiumOnlyFiscalResidence": questionResponse.OtherDetails.IsBelgiumOnlyFiscalResidence.toString()
                }
                $.each(questionResponse.FiscalResidence, function () {
                    this.CountryCodeForFiscalResidence = this.CountryCodeForFiscalResidence.toString()
                })
                $scope.FiscalResidenceDetails = questionResponse.FiscalResidence;
                if ($scope.FiscalResidenceDetails.length == 0 || $scope.FiscalResidenceDetails[$scope.FiscalResidenceDetails.length - 1].CountryCodeForFiscalResidence != '') {
                    $scope.FiscalResidenceDetails.push({
                        "CountryCodeForFiscalResidence": "",
                        "FiscalResidenceId": 0,
                        "TinNumber": ""
                    });
                }
            });
        }
    }
    WebApiService.getallCountries().then(
            function (data) {
                var countryArray = [];
                $scope.allCountryList = [];
               

                for (i = 0; i < data.data.Result.length; i++) {
                    $scope.allCountryList.push(data.data.Result[i]);
                }
            },
            function (error) {
            }
        );
    //fetch money out details
    $scope.getMoneyOutDetails = function (personId, childId) {

        $scope.showInitialHeader = true;
        $scope.showInitialSection = true;
        $scope.showNext = true;
        $scope.showConfirm = false;
        $scope.backFromConfirm = false;

        $scope.showSummary = false;
        $scope.showShortTermToLongTerm = false;
        $scope.showShortTermToFreeTransfer = false;


        var url = '/moneyout/person/' + personId + '/child/' + childId;
        var language = currentLanguage;
        if (childId != '' && childId != undefined && personId != '' && personId != undefined) {

            var res = WebApiService.getWebApiData(url, language);
        }
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                //$scope.moneyOutDetail = JSON.parse(response);
                $scope.moneyOutDetail = d.data.Result;
                $scope.identificationExist = $scope.moneyOutDetail.IsUploadIdExists;
                if ($scope.moneyOutDetail != null) {

                    //code start: TODO : need to implement caching here instead of calling backend
                    //fetch person details
                    var language = currentLanguage;
                    var url = "/members/" + personId + '/children/' + childId;
                    var res = WebApiService.getWebApiData(url, language);
                    if (res != undefined) {
                        res.then(function (d) {
                            var response = JSON.stringify(d.data);
                            childDetail = JSON.parse(response);
                            if (childDetail !== null) {
                                $scope.childFirstName = childDetail.PersonFirstName;
                                $scope.childName = childDetail.PersonFirstName + " " + childDetail.PersonLastName;
                                if (childDetail.PersonNickName !== null && childDetail.PersonNickName !== childDetail.PersonFirstName) {
                                    $scope.childNickName = childDetail.PersonFirstName + " " + childDetail.PersonLastName;
                                }
                                else {
                                    $scope.childNickName = childDetail.PersonFirstName + " " + childDetail.PersonLastName;

                                }
                                if (childDetail.PersonImageUrl !== null) {
                                    $scope.childImage = childDetail.PersonImageUrl;
                                }
                                //else {
                                //    $scope.childImage = images.defaultPersonImage;
                                //}
                            }
                        })
                    }

                    //fetch project details
                    //$scope.$on("localstorageplan", function (event, args) {

                    if (localStorage.getItem(planId) !== null && localStorage.getItem(planId) !== undefined) {
                        $scope.planId = localStorage.getItem(planId);
                        var language = currentLanguage;
                        var url = '/childsaving/plan/' + $scope.planId + '/shorttermprojects';

                        if ($scope.planId != '' && $scope.planId != undefined) {

                            $scope.projectInfoList = [];
                            $scope.projectModelArr = [];
                            var res = WebApiService.getWebApiData(url, language);
                            if (res != undefined) {
                                res.then(function (d) {
                                    var response = JSON.stringify(d.data);
                                    projectInfoList = JSON.parse(response);
                                    projectInfoList = projectInfoList;

                                    if (projectInfoList != null) {

                                        if (projectInfoList.length > 0) {
                                            $.each(projectInfoList, function (index) {

                                                $scope.projectInfo = {};
                                                $scope.projectInfo.projectTitle = projectInfoList[index].Title;
                                                $scope.projectInfo.projectPlanId = projectInfoList[index].PlanId;
                                                //if (projectInfoList[index].ProjectImage != null) {
                                                //    $scope.projectInfo.projectImage = images.dataImage + projectInfoList[index].ProjectImage;
                                                //} else {
                                                //    $scope.projectInfo.projectImage = images.projectDefaultImage;
                                                //}


                                                if (projectInfoList[index].ProjectImageUrl != null) {
                                                    $scope.projectInfo.projectImage = projectInfoList[index].ProjectImageUrl;
                                                }

                                                $scope.projectInfo.projectId = projectInfoList[index].NowProjectId;
                                                $scope.projectInfo.modelName = "model-" + $scope.projectInfo.projectId;
                                                $scope.projectInfo.isFinished = projectInfoList[index].IsFinished;
                                                $scope.projectInfo.targetProjectAmount = projectInfoList[index].TargetProjectAmount;
                                                $scope.projectModelArr.push(false);
                                                $scope.projectInfoList.push($scope.projectInfo);

                                            });

                                            setTimeout(function () {
                                                var iterationIndex = 0;
                                                angular.forEach(angular.element(".projects-from-db .long-term-input"), function (value, key) {
                                                    var elem = angular.element(value);
                                                    elem.val(projectInfoList[iterationIndex].TargetProjectAmount);
                                                    iterationIndex++;
                                                });
                                                if (localStorage.getItem("isSavingSchool") && JSON.parse(localStorage.getItem("isSavingSchool"))) {
                                                    // coming from saving school
                                                    $scope.projectBalance();

                                                    // coming from saving school
                                                    if ($stateParams.obj) {
                                                        $scope.stProjectId = $stateParams.obj.stProjectId;
                                                        $scope.stProjectPriority = $stateParams.obj.stProjectPriority;
                                                        angular.element('label[for=bankAccountRadio]').trigger('click');
                                                        $scope.moneyOutType = "bankAccountRadioVal";
                                                        var selectedElem = angular.element('input[pid=' + $scope.stProjectId + ']');
                                                        selectedElem.trigger('click');
                                                        $scope.stateChanged(Number(selectedElem.attr('elemIndex')), Number(selectedElem.attr('targetAmount')));
                                                    }


                                                }
                                            }, 1000);
                                        }
                                    }
                                })
                            }
                        }

                    }
                    //code end

                    if ($scope.moneyOutDetail.BankDetailsViewModel !== null) {

                        $scope.accountHolderFirstName = $scope.moneyOutDetail.BankDetailsViewModel.AccountHolderFirstName;
                        $scope.accountHolderLastName = $scope.moneyOutDetail.BankDetailsViewModel.AccountHolderLastName;
                        $scope.parentFirstName = $scope.moneyOutDetail.BankDetailsViewModel.AccountHolderFirstName;
                        if ($scope.moneyOutDetail.BankDetailsViewModel.SaveFlag) {
                            if ($scope.moneyOutDetail.BankDetailsViewModel.IbanAccountNumber != null) {
                                $scope.ValidIban = true;
                                $scope.IbanNumberVal = $scope.moneyOutDetail.BankDetailsViewModel.IbanAccountNumber;
                                var ibanNumberFromDB = $scope.ibanNumberCreate($scope.IbanNumberVal, 4).join(" ");
                                $scope.IbanNumberVal = ibanNumberFromDB;

                                $scope.IbanNumberVal = $scope.moneyOutDetail.BankDetailsViewModel.IbanAccountNumber;
                                $("#editBicCode").attr("disabled", "disabled").addClass("disabled");
                            }
                            if ($scope.moneyOutDetail.BankDetailsViewModel.Swift != null) {
                                $("#editBicCode").val($scope.moneyOutDetail.BankDetailsViewModel.Swift);
                            }
                        }
                    }

                    //change for saving school
                    if ($scope.stProjectId) {

                        $scope.showLabelSection = true;
                        $scope.showDropdownSection = false;
                        $scope.showShortTermToLongTerm = false;
                        $scope.showShortTermToFreeTransfer = true;
                        $scope.showPaymentDetails = true;
                        $scope.showShortTermTitle = true;
                        $scope.showLongTermTitle = false;

                    } else {
                        if ($scope.moneyOutDetail.IsLongTermExisting !== null) {

                            //If child has both LT & ST then only dropdown will be visible
                            if ($scope.moneyOutDetail.IsLongTermExisting === true) {

                                $scope.showLabelSection = false;
                                $scope.showDropdownSection = true;
                                $scope.showShortTermToLongTerm = true;
                                $scope.showShortTermToFreeTransfer = false;
                                $scope.showPaymentDetails = false;
                                $scope.showShortTermTitle = false;
                                $scope.showLongTermTitle = true;
                            }
                            else //else only editable text should be visible:start
                            {
                                $scope.showLabelSection = true;
                                $scope.showDropdownSection = false;
                                $scope.showShortTermToLongTerm = false;
                                $scope.showShortTermToFreeTransfer = true;
                                $scope.showPaymentDetails = true;
                                $scope.showShortTermTitle = true;
                                $scope.showLongTermTitle = false;


                                $scope.selectedMoType = 2;
                                $scope.moneyOutType = "bankAccountRadioVal";

                            } //end
                        }
                    }

                    //bind amount details:start 
                    if ($scope.moneyOutDetail.AvailableAmount !== null) {
                        $scope.startingAvailableAmount = $scope.moneyOutDetail.AvailableAmount;
                        $scope.moneyOutDetail.AvailableAmount = formatAmountField($scope.moneyOutDetail.AvailableAmount, $scope.language);
                        $scope.availableAmount = $scope.moneyOutDetail.AvailableAmount;
                    }
                    if ($scope.moneyOutDetail.MinimumLimit !== null) {
                        $scope.minValue = $scope.moneyOutDetail.MinimumLimit;
                    }
                    if ($scope.moneyOutDetail.MaximumLimit !== null) {
                        $scope.maxValue = $scope.moneyOutDetail.MaximumLimit;
                    }
                    if ($scope.moneyOutDetail.ReserveAmount) {
                        $scope.reserveAmount = $scope.moneyOutDetail.ReserveAmount;
                    }
                    //end
                    //$scope.stProjectId = null;
                    ////$.cookie("stProjectId", null, { path: "/" });

                }
            }
            , function (error) {
               // alert("Error while getting Money out Information.");
            });
        }
        $scope.$watch('moneyOutType', function (newValue, oldValue) {
            $scope.getSelectedView();
        });
    }

    //change view based on dropdown value
    $scope.getSelectedView = function () {
        if ($scope.moneyOutDetail !== undefined && $scope.moneyOutDetail !== '')
            $scope.availableAmount = $scope.moneyOutDetail.AvailableAmount;
        $scope.longTermAmount = '';

        if ($scope.moneyOutType !== '' && $scope.moneyOutType !== undefined) {
            if ($scope.moneyOutType === "longTermRadioVal") {

                $scope.showShortTermToLongTerm = true;
                $scope.showShortTermToFreeTransfer = false;
                $scope.showPaymentDetails = false;
                $scope.showShortTermTitle = false;
                $scope.showLongTermTitle = true;
                $scope.longTermAmount = '';
                $($scope.projectInfoList).each(function () {
                    this.modelName = false;
                });
                $scope.freeTrans = false;
                $scope.projectInfo3 = false;
                $scope.projectModelArr = [false, false, false];
                $scope.totalProjectValue = 0;
                $scope.showTotalAmountSection = false;
                $scope.valueMoreThanAvailableAmount = false;
                if ($("#bankTransferContributionForm").length) {
                    $("#bankTransferContributionForm").validate().resetForm();
                }
                //$scope.exceededProjectValue = false;            
                //$(".next-money-out-btn").addClass("disabled").prop("disabled", true);
                $scope.nextDisabled = true;
                $scope.ValidIban = true;
                $scope.validProjectMoney = true;
                $scope.lowProjectValue = false;
                $scope.lowLongTermProjectValue = false;
                $scope.longTermAmount = ""
                $scope.checkConfirm = true;
                $scope.bankAccountchecked = true;
                $scope.availableAmount = formatAmountField(angular.copy($scope.startingAvailableAmount), $scope.language);
                angular.element("#saveMoneyOut").attr("data-action","save it for later-next");
            } else if ($scope.moneyOutType === "bankAccountRadioVal") {
                $scope.showShortTermToLongTerm = false;
                $scope.showShortTermToFreeTransfer = true;
                $scope.showPaymentDetails = true;
                $scope.showShortTermTitle = true;
                $scope.showLongTermTitle = false;
                $scope.showBicNumberTitle = true; // Ticket 6208
                //$(".moneyout-container-two .moneyout-spinner input").val("");
                $scope.exceededValue = false;
                $scope.nextDisabled = false;
                $scope.longTermAmount = "";
                $scope.exceededProjectValue = false;
                $scope.validProjectMoney = false;
                $("#moneyOutLongTermForm").validate().resetForm();
                $scope.showTotalAmountSection = true;
                $scope.checkConfirm = false;
                $('[id^=longTermValue]').inputmask('NUMBERField');
                $scope.bankAccountchecked = false;
                angular.element("#iConfirmThisIsMyBankAccount").prop('checked', false);
                $scope.availableAmount = formatAmountField(angular.copy($scope.startingAvailableAmount), $scope.language);
                angular.element("#saveMoneyOut").attr("data-action", "Complete project-next");
                if ($scope.IbanNumberVal) {
                    $scope.ValidIban = true;
                }
                else {
                    $scope.ValidIban = false;
                }
                $scope.lowProjectValue = false;
                $scope.lowLongTermProjectValue = false;
                if (window.innerWidth > 767) {
                    setTimeout(function () {

                        var longestBlock = 0;
                        var completedProject = 0;
                        $(".projects-block").each(function () {

                            if ($(this).find(".moneyout-project-block").height() > longestBlock) {
                                longestBlock = $(this).find(".moneyout-project-block").height();
                            }
                            if ($(this).find(".moneyout-project-block input").prop("disabled")) {
                                completedProject++;
                            }
                        });
                        $(".projects-block").find(".moneyout-project-block").css("height", longestBlock);
                        $(".projects-block").find(".base-container-img-span").css("height", Number(longestBlock + 35));
                        if (completedProject > 0) {
                            $(".projects-block .moneyout-spinner").css("margin-top", "5px");
                        }
                        $scope.IbanNumberVal = $scope.ibanNumberCreate($scope.IbanNumberVal, 4).join(" ");
                    }, 1000);
                }
                angular.forEach(angular.element(".projects-from-db"), function (value, key) {
                    var elem = angular.element(value);
                    var projectValFromDb = elem.find(".moneyout-project-checkbox").attr("projectvalue");
                    elem.find(".initialDbValue").text(projectValFromDb);
                });

            }
        }

    }
    angular.element("#iConfirmThisIsMyBankAccount").change(function () {
        if (angular.element("#iConfirmThisIsMyBankAccount").prop('checked')) {
            $scope.$apply(function () {
                $scope.bankAccountchecked = true;
            });
        }
        else {
            $scope.$apply(function () {
                $scope.bankAccountchecked = false;
            });
        }
    });
    $scope.saveMoneyOutDetails = function (longTermAmount, IbanNumberVal, bicCodeVal, checkConfirm, checkForSave) {
        if (IbanNumberVal) {
            //IbanNumberVal = IbanNumberVal.replace('BE', "");
            IbanNumberVal = 'BE' + IbanNumberVal.replace(/ +/g, "").replace('BE', "");
        }
        var value = $scope.moneyOutType;
        //        var longTermFlag = true;
        //        if ($scope.identificationExist) {
        //            longTermFlag = true;
        //        }
        //        else {
        //            if ($("#editEidForm").valid() && angular.element("#pic").prop('checked')) {
        //                longTermFlag = true;
        //            }
        //            else {
        //                longTermFlag = false;
        //}
        //}
        if ((value == "longTermRadioVal" && $("#moneyOutLongTermForm").valid()) || (value == "bankAccountRadioVal" && $("#bankTransferContributionForm").valid() && $("#moneyOutForm").valid() && !$scope.valueMoreThanAvailableAmount && $scope.questionDetails.HasUsaCitizenship == "false" && $scope.questionDetails.IsUsaCitizenOrResident == "false")) {

            $scope.selectedProjectList = [];


            $(".active-project-value").each(function () {
                var longTermObj = {
                    "ProjectId": $(this).attr("inputId"),
                    "ProjectAmount": $(this).val(),
                    "ProjectTitle": $(this).attr("titleid")
                };
                if (longTermObj.ProjectId == undefined) {
                    longTermObj.ProjectTitle = freeTransfer;
                }
                $scope.selectedProjectList.push(longTermObj);
            });
            var url = '/moneyout/person/self/';
            //if ($scope.stProjectId) {
            //    $scope.moneyOutDetail.IsLongTermExisting = false;
            //}
            if (checkConfirm === undefined) {
                if ($("#iConfirmThisIsMyBankAccount").prop("checked")) {
                    checkConfirm = true;
                } else {
                    checkConfirm = false;
                }
            }
            if (checkForSave === undefined) {
                if ($("#saveAccountDetailsForNextTime").prop("checked")) {
                    checkForSave = true;
                } else {
                    checkForSave = false;
                }
                //checkForSave = $("#saveAccountDetailsForNextTime").checked;
            }
            $scope.backFromConfirm = true;
            $scope.moneyOutDetail.ChildId = $scope.selectedChildId;
            $scope.moneyOutDetail.PersonId = $scope.personId;

            if ($scope.moneyOutDetail.BankDetailsViewModel != null) {

                $scope.moneyOutDetail.BankDetailsViewModel.IbanAccountNumber = null;
                $scope.moneyOutDetail.BankDetailsViewModel.Swift = null;
                $scope.moneyOutDetail.BankDetailsViewModel.SaveFlag = false;

            }
            //case when ST --> LT
            if ($scope.moneyOutDetail.IsLongTermExisting !== null && $scope.moneyOutDetail.IsLongTermExisting === true) {
                if (value !== '' && value !== undefined) {
                    $scope.moneyOutType = value;
                    $scope.moneyOutDetail.CategoryType = (value == "bankAccountRadioVal" ? 1 : 0);
                    if (value === "longTermRadioVal") {
                        if (longTermAmount !== '' && longTermAmount !== undefined) {
                            $scope.moneyOutDetail.AvailableAmount = returnANumberWithoutFormating(longTermAmount, $scope.language);
                            longTermAmount = formatAmountField(longTermAmount, $scope.language);
                            //$scope.longTermValue = longTermAmount;
                            //$scope.longTermAmount = longTermAmount;
                        }
                    }
                    else {

                        $scope.moneyOutDetail.OtherDetails = {
                            "HasUsaCitizenship": $.parseJSON($scope.questionDetails.HasUsaCitizenship),
                            "IsUsaCitizenOrResident": $.parseJSON($scope.questionDetails.IsUsaCitizenOrResident),
                            "IsBelgiumOnlyFiscalResidence": $.parseJSON($scope.questionDetails.IsBelgiumOnlyFiscalResidence)
                        }
                        if (!($scope.questionDetails.IsBelgiumOnlyFiscalResidence || $scope.questionDetails.IsBelgiumOnlyFiscalResidence == "false")) {
                            var FiscalResidenceDetails = [];
                        }
                        else {
                            var FiscalResidenceDetails = angular.copy($scope.FiscalResidenceDetails);

                            for (var i = 0; i < FiscalResidenceDetails.length; i++) {
                                if (FiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                                    FiscalResidenceDetails.splice(i, 1);
                                    i--;
                                }
                            }
                        }
                        $scope.moneyOutDetail.FiscalResidence = FiscalResidenceDetails;
                        $scope.totalAmount = 0;
                        $(".active-project-value").each(function () {
                            $scope.totalAmount += Number(parseInt($(this).val(), 10));
                        });
                        $scope.moneyOutDetail.AvailableAmount = $scope.totalAmount;
                        $scope.totalAmount = formatAmountField($scope.totalAmount, $scope.language);
                        $scope.moneyOutDetail.ShortTermProjects = $scope.selectedProjectList;
                        $($scope.selectedProjectList).each(function () {
                            this.ProjectAmount = returnANumberWithoutFormating(this.ProjectAmount, $scope.language);
                        });
                        if ($scope.moneyOutDetail.BankDetailsViewModel != null) {

                            $scope.moneyOutDetail.BankDetailsViewModel.IbanAccountNumber = IbanNumberVal;
                            $scope.moneyOutDetail.BankDetailsViewModel.Swift = bicCodeVal;
                            $scope.moneyOutDetail.BankDetailsViewModel.SaveFlag = checkForSave;
                            $scope.iban = IbanNumberVal;
                            $scope.bic = bicCodeVal;
                            if (bicCodeVal == undefined || bicCodeVal == "" || bicCodeVal == null)   // ticket 6208
                                $scope.showBicNumberTitle = false;
                        }
                    }
                }
            } else //case when ST --> bank transfer
            {
                $scope.moneyOutDetail.CategoryType = transferToBankAccount;
                $scope.totalAmount = 0;

                $(".active-project-value").each(function () {
                    $scope.totalAmount += Number($(this).val());
                    if (!$scope.stProjectId) {
                        var ammounttotransfer = formatAmountField($(this).val(), $scope.language);
                        $(this).val(ammounttotransfer);
                    }
                });

                $scope.moneyOutDetail.AvailableAmount = $scope.totalAmount;
                $scope.totalAmount = formatAmountField($scope.totalAmount, $scope.language);
                $scope.moneyOutDetail.ShortTermProjects = $scope.selectedProjectList;
                if ($scope.stProjectId) {
                    $scope.moneyOutDetail.ShortTermProjects[0].ProjectAmount = returnANumberWithoutFormating($scope.moneyOutDetail.ShortTermProjects[0].ProjectAmount, $scope.language);
                }
                else {
                    $($scope.selectedProjectList).each(function () {
                        this.ProjectAmount = returnANumberWithoutFormating(this.ProjectAmount, $scope.language);
                    });
                }

                if ($scope.moneyOutDetail.BankDetailsViewModel != null) {

                    $scope.moneyOutDetail.BankDetailsViewModel.IbanAccountNumber = IbanNumberVal;
                    $scope.moneyOutDetail.BankDetailsViewModel.Swift = bicCodeVal;
                    $scope.moneyOutDetail.BankDetailsViewModel.SaveFlag = checkForSave;
                    $scope.iban = IbanNumberVal;
                    $scope.bic = bicCodeVal;

                }
            }
            if ((parseInt($scope.availableAmount) <= parseInt($scope.reserveAmount) && parseInt($scope.availableAmount) > 0) || (parseInt($scope.availableAmount) === 0)) {
                $scope.reserveAmount = parseInt($scope.availableAmount);
            }
            $scope.moneyOutDetail.ReserveAmount = $scope.reserveAmount;

            WebApiService.updateData(url, $scope.moneyOutDetail).success(function (data, status) {
                var urlResponse = JSON.stringify(data);
                var response = JSON.parse(urlResponse);
                if (response != undefined || response != null) {
                    $scope.moneyOutDetail = response.Result;
                    $scope.showSummary = true;
                    $scope.showInitialHeader = false;
                    $scope.showShortTermToLongTerm = false;
                    $scope.showShortTermToFreeTransfer = false;
                    $scope.showInitialSection = false;
                    $scope.showNext = false;
                    $scope.showConfirm = true;
                    $scope.showPaymentDetails = false;
                    $scope.showMoneyOutView = false;
                    try {
                        $scope.nextSavedProjectDetails = response.Result.ShortTermProjects;
                        $.each($scope.nextSavedProjectDetails, function () {
                            this.ProjectAmount = formatAmountField(this.ProjectAmount, $scope.language);
                        });
                    }
                    catch (e) {
                    }
                    $scope.savedProjectTotalCost = 0;
                    $.each($scope.nextSavedProjectDetails, function () {
                        $scope.savedProjectTotalCost += returnANumberWithoutFormating(this.ProjectAmount, $scope.language);
                    });



                    //If child has both LT & ST then only dropdown will be visible
                    if ($scope.moneyOutDetail.IsLongTermExisting != null) {
                        if ($scope.moneyOutDetail.IsLongTermExisting === true) {
                            if (value != '' && value != undefined) {
                                if (value === "longTermRadioVal") {
                                    $scope.showSummaryForLongTerm = true;
                                    $scope.showSummaryForTransfer = false;
                                    $scope.showSummaryPayment = false;
                                    $scope.showSmsInfo = false;
                                    $scope.showSummaryTitleForLT = true;
                                    $scope.showSummaryTitleForTransfer = false;
                                    $scope.totalLongTermAmount = formatAmountField(response.Result.AvailableAmount, $scope.language);

                                }

                                else {
                                    $scope.showSummaryForLongTerm = false;
                                    $scope.showSummaryForTransfer = true;
                                    $scope.showSummaryPayment = true;
                                    $scope.showSmsInfo = true;
                                    $scope.showSummaryTitleForLT = false;
                                    $scope.showSummaryTitleForTransfer = true;
                                }
                            }
                        } else // for free transfer
                        {
                            $scope.showSummaryForLongTerm = false;
                            $scope.showSummaryForTransfer = true;
                            $scope.showSummaryPayment = true;
                            $scope.showSmsInfo = true;
                            $scope.showSummaryTitleForLT = false;
                            $scope.showSummaryTitleForTransfer = true;
                        }
                    }
                }
                var otpUrl = "/common/user/" + $scope.personId;
                WebApiService.sendOtp(otpUrl).success(function (data, status) {
                });
            })
               .error(function (data, status) {
                   genericErrorMessageDisplay(Resources.MoneyOut_Failed);
               });
        }
        else {
            if ($(".group-validation-error").length || $(".error").length) {
                if ($(".group-validation-error").length && $("div.error").length) {
                    var firstErrorBlockPosition = Math.min(Number($(".group-validation-error:eq(0)").offset().top), Number($("div.error:eq(0)").offset().top));
                }
                else if ($(".group-validation-error").length && !$("div.error").length) {
                    var firstErrorBlockPosition = $(".group-validation-error:eq(0)").offset().top;
                }
                else if (!$(".group-validation-error").length && !$("div.error").length) {
                    var firstErrorBlockPosition = $(".error:eq(0)").offset().top;
                }
                if (value == "longTermRadioVal") {
                    $("#moneyOutLongTermForm").valid();

                    $("body").scrollTop(Number(firstErrorBlockPosition - 100), 300);
                }
                else {
                    $("#bankTransferContributionForm,#moneyOutForm").valid();
                    if ($scope.identificationExist) {
                        $("#editEidForm").valid();
                    }
                    $("body").scrollTop(Number(firstErrorBlockPosition - 100), 300);
                }
            }
        }
    }

    $scope.otpStatus = function () {
        if ($scope.otpValue) {
            var otpCheckUrl = "/common/code/" + $scope.otpValue + "?userId=" + $scope.personId;
            WebApiService.checkOtp(otpCheckUrl).success(function (data, status) {
                if (data) {
                    if (data.Result) {
                        angular.element("#moneyout-code-block").parent().removeClass('error');
                        //angular.element("#moneyout-code-block").parent().find('.otp-error').remove();
                        angular.element("#moneyout-code-block").parent().next('.otp-error').removeClass('show');
                        $scope.confirmMoneyOut();
                    }
                    if (!data.Result) {
                        angular.element("#moneyout-code-block").parent().find('.otp-error').remove();
                        angular.element("#moneyout-code-block").parent().addClass('error');
                        //angular.element("#moneyout-code-block").parent().append("<p class='otp-error'>" + angular.element("#textForInvalidOtp").val() + "</p>");
                        angular.element("#moneyout-code-block").parent().next('.otp-error').addClass('show');
                    }
                }
            });
        }
    }
    var interval;
    $scope.resendOtp = function () {

        if (timeLimit == 0) {
            $scope.otpValue = "";
            var otpUrl = "/common/user/" + $scope.personId;
            WebApiService.sendOtp(otpUrl).success(function (data, status) {
            });
            angular.element("#moneyout-code-block").parent().removeClass('error');
            angular.element("#moneyout-code-block").parent().find('.otp-error').remove();
        }

       
    }
    $scope.removeErrorFromOtpField = function () {
        angular.element("#moneyout-code-block").parent().removeClass('error');
        angular.element("#moneyout-code-block").parent().find('.otp-error').remove();
    }
    $scope.resetMoneyOutDetails = function () {
        timeLimit = 0;
        $('.alt-option-msg').removeClass('mo-disabled-otp-text');
        clearInterval(interval);
        $("#moneyout-code-block").val("");
        if ($scope.backFromConfirm === true) {
            $scope.showMoneyOutView = true;
            $scope.showInitialHeader = true;
            $scope.showInitialSection = true;
            $scope.showNext = true;
            $scope.showConfirm = false;
            $scope.backFromConfirm = false;

            $scope.showSummary = false;
            $scope.showShortTermToLongTerm = false;
            $scope.showShortTermToFreeTransfer = false;

            if ($scope.moneyOutDetail.IsLongTermExisting !== null) {

                //If child has both LT & ST then only dropdown will be visible
                if ($scope.moneyOutDetail.IsLongTermExisting === true) {

                    $scope.showLabelSection = false;
                    $scope.showDropdownSection = true;
                    if ($scope.moneyOutType === "longTermRadioVal") {

                        $scope.showShortTermToLongTerm = true;
                        $scope.showShortTermTitle = false;
                        $scope.showLongTermTitle = true;
                        $scope.showShortTermToFreeTransfer = false;
                        $scope.showPaymentDetails = false;
                    }
                    else if ($scope.moneyOutType === "bankAccountRadioVal") {

                        $scope.showShortTermToLongTerm = false;
                        $scope.showShortTermTitle = false;
                        $scope.showLongTermTitle = true;
                        $scope.showShortTermToFreeTransfer = true;
                        $scope.showPaymentDetails = true;
                    }

                }
                else //else only editable text should be visible
                {
                    $scope.showLabelSection = true;
                    $scope.showDropdownSection = false;
                    $scope.showShortTermToLongTerm = false;
                    $scope.showShortTermToFreeTransfer = true;
                    $scope.showPaymentDetails = true;
                    $scope.showShortTermTitle = true;
                    $scope.showLongTermTitle = false;

                }
            }
            confirmExit();
        }
        else {
            if ($scope.stProjectId) {
                // coming from saving school
                getApprovalProjectDetails($scope.stProjectId);
            }
            else {
                //window.location.href = "/" + currentLanguage + "/Home/Child/" + $scope.childId + "/Overview";
                $state.go("child.detail.plan", {
                    //state: childState,
                    childId: $scope.selectedChildId
                });
            }
        }


    }


    //US 4371
    function getApprovalProjectDetails(nowProjectId) {
        var url = "/savingschool/person/self/project/" + nowProjectId + "/projectdetails";

        var res = WebApiService.getWebApiData(url, currentLanguage);
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                data = data.Result;
                $scope.edit = {};
                $scope.edit.projectId = data.ProjectId;
                $scope.edit.projectStatus = data.ProjectStatus;
                $scope.edit.projectTitle = data.ProjectTitle;
                $scope.edit.targetProjectAmount = data.ProjectTargetAmount;
                $scope.edit.projectDescription = data.ProjectDescription;
                $scope.edit.assignee = data.Assignee;

                if (data.ProjectImage != null)
                    $scope.edit.projectImage = data.ProjectImage;
                //else
                    //$scope.edit.projectImage = images.projectDefaultImage;// Need to comment this line too otherwise default image round svg not found issue will persist

                window.location.href = "/" + currentLanguage + "/Home/Child/" + $scope.edit.assignee + "/Overview?pId=" + $scope.edit.projectId + "&ss=" + true;
            },
          function (error) {

          });
        }
    }

    $scope.confirmMoneyOut = function () {
        if ($scope.stProjectPriority) {
            $scope.moneyOutDetail.ShortTermProjects[0].ProjectPriority = $scope.stProjectPriority;
        }
        var confirmMoneyOutUrl = '/moneyout/person/self/child/' + $scope.moneyOutDetail.ChildId + '/confirm';
        WebApiService.updateData(confirmMoneyOutUrl, $scope.moneyOutDetail).success(function (data, status) {
            localStorage.setItem("moneyOutConfirmSuccess", "true");
            if ($scope.stProjectId) {
                //window.location.href = "/" + currentLanguage + "/Home/Child/" + $scope.childId + "/Overview?&=" + true;
                // $state.go('moneyout', { childID: selectedChildId, childState: state });                
                // window.location.href = "/" + currentLanguage + "/Home/Child/" + $scope.childId + "/Overview";
                $state.go('child.detail.plan.termPlan', { childId: $scope.selectedChildId, state: $scope.overviewState });
            }
            else {
                savingSchoolService.setSavingSchoolData("");
                // window.location.href = "/" + currentLanguage + "/Home/Child/" + $scope.childId + "/Overview";
                $state.go('child.detail.plan.termPlan', { childId: $scope.selectedChildId, state: $scope.overviewState });
            }

        })
            .error(function (data, status) {
                genericErrorMessageDisplay(Resources.MoneyOut_Failed);
            });
    }

    $scope.exceededValue = false;

    $scope.$watch("longTermAmount", function (newvalue, oldvalue) {
        var modelvalue = newvalue;
        if (Number(newvalue) == 0) {
            modelvalue = 0;
        } 
        $scope.inputKeyPress(modelvalue);
    });

    $scope.inputKeyPress = function (modelValue) {
        //$scope.lowLongTermProjectValue = false;
        if (modelValue >= 0) {
            $scope.availableAmount = $scope.startingAvailableAmount - modelValue;
            if ($scope.availableAmount < 0) {
                $scope.exceededValue = true;
            }
            else {
                $scope.exceededValue = false;
            }

            $scope.$evalAsync(function(){
                $scope.availableAmount = $scope.availableAmount.toLocaleString($scope.language, { minimumFractionDigits: 2 });
            })



        }

    }

    $scope.projectBalance = function (modelValue) {
        var totalInputVal = 0;

        angular.forEach(angular.element(".active-project-value"), function (value, key) {
            var elem = angular.element(value);
            totalInputVal += Number(elem.val());
        });
        $scope.totalProjectValue = formatAmountField(totalInputVal, $scope.language);
        $scope.availableAmount = $scope.startingAvailableAmount - totalInputVal;
        if ($scope.availableAmount < 0) {
            $scope.valueMoreThanAvailableAmount = true;
            angular.element("#bankTransferContributionForm").validate().resetForm()
            angular.element(".active-project-value").parent().addClass("error");
            angular.element("#tinNumber").parent().removeClass("group-validation-error");
            angular.element("#tinNumber").next().remove();
            angular.element("#tinExpDateId").parent().parent().removeClass("group-validation-error");
            angular.element("#tinExpDateId").parent().next().remove();
        }
        else {
            $scope.valueMoreThanAvailableAmount = false;
            angular.element(".active-project-value").parent().removeClass("error");
            initializeFormValidation($("#editEidForm"));
        }
        if ($scope.language.toUpperCase() == languages.languageEN) {
            $scope.availableAmount = $scope.availableAmount.toLocaleString($scope.language, { minimumFractionDigits: 2 });
        }
        else {
            $scope.availableAmount = formatAmountField($scope.availableAmount, $scope.language);
        }

    }
    $scope.changeValue = function (event) {
        //alert(event.currentTarget.id);
        var currentId = event.currentTarget.id;
        if (currentId.indexOf("btnLongUp") != -1 && currentId != "btnLongUp") {
            var currentVal = Number($("#" + currentId).parent().parent().find("input[type = text]").val());
            currentVal++;
            $("#" + currentId).parent().parent().find("input[type = text]").val(currentVal);
            $scope.projectBalance(currentVal);
        }
        else if (currentId.indexOf("btnLongDown") != -1 && currentId != "btnLongDown") {
            var currentVal = Number($("#" + currentId).parent().parent().find("input[type = text]").val());
            if (currentVal > 1) {
                currentVal--;
                $("#" + currentId).parent().parent().find("input[type = text]").val(currentVal);
                $scope.projectBalance(currentVal);
            }
        }
        else if (currentId == "btnLongUp") {
            var currentVal = Number($scope.longTermAmount);
            currentVal++;
            $scope.longTermAmount = currentVal;
            //if ($scope.longTermAmount > Number($scope.availableAmount)) {
            //angular.element("#moneyOutLongTermValue").trigger('blur');
            setTimeout(function () {
                angular.element("#moneyOutLongTermValue").trigger('blur');
            }, 100);
            //}
            //$scope.inputKeyPress(longTermAmount);
        }
        else if (currentId == "btnLongDown") {
            var currentVal = returnANumberWithoutFormating($scope.longTermAmount, $scope.language); //Number($scope.longTermAmount);
            if (currentVal > 1) {
                currentVal--;
                $scope.longTermAmount = currentVal;
                //$scope.inputKeyPress(currentVal);
            }
            setTimeout(function () {
                angular.element("#moneyOutLongTermValue").trigger('blur');
            }, 100);
        }
    }
    
    $scope.ibanNumberCreate = function (str, n) {
        var ret = [];
        var i;
        var len;

        if (str != undefined && str != null) {
            for (i = 0, len = str.length; i < len; i += n) {
                ret.push(str.substr(i, n))
            }
        }

        return ret
    };

    $scope.stateChanged = function (qId, targetAmount) {
        if (angular.element("#moneyoutCircle" + qId).prop('checked')) {
            //alert('test');
            $scope.availableAmount = returnANumberWithoutFormating($scope.availableAmount, $scope.language) - Number(targetAmount);
            $scope.totalProjectValue = Number($scope.startingAvailableAmount) - returnANumberWithoutFormating($scope.availableAmount, $scope.language);
            $scope.totalProjectValue = formatAmountField($scope.totalProjectValue, $scope.language);
            if (returnANumberWithoutFormating($scope.availableAmount, $scope.language) < 0) {
                $scope.valueMoreThanAvailableAmount = true;
                angular.element(".active-project-value").parent().addClass("error");
            }
            $scope.availableAmount = formatAmountField($scope.availableAmount, $scope.language);
            setTimeout(function () {
                angular.element("#longTermValue" + qId).val(targetAmount);

            }, 500);
        }
        else {
            if (qId < 3) {
                $scope.availableAmount = returnANumberWithoutFormating($scope.availableAmount, $scope.language) + Number(angular.element("#longTermValue" + qId).val());
            }
            else {
                $scope.availableAmount = returnANumberWithoutFormating($scope.availableAmount, $scope.language) + Number(angular.element("#freeTransfer").val());

                angular.element("#freeTransfer").val("");
            }
            $scope.totalProjectValue = Number($scope.startingAvailableAmount) - returnANumberWithoutFormating($scope.availableAmount, $scope.language);
            $scope.totalProjectValue = formatAmountField($scope.totalProjectValue, $scope.language);
            if (returnANumberWithoutFormating($scope.availableAmount, $scope.language) > 0) {
                $scope.valueMoreThanAvailableAmount = false;
                angular.element(".active-project-value").parent().removeClass("error");
            }
            $scope.availableAmount = formatAmountField($scope.availableAmount, $scope.language);
            setTimeout(function () {
                //$scope.projectBalance();
                angular.element("#longTermValue" + qId).val(targetAmount);
                angular.element("#longTermValue" + qId).parent().removeClass("group-validation-error");
                angular.element("#longTermValue" + qId + "-error").remove();
                if (qId == 3) {
                    angular.element("#freeTransfer").parent().removeClass("group-validation-error");
                    angular.element("#freeTransfer-error").remove();
                }
                if (angular.element(".active-project-value").length == 0) {

                    angular.element("#tinNumber").parent().removeClass("group-validation-error");
                    angular.element("#tinNumber").next().remove();
                    angular.element("#tinExpDateId").parent().parent().removeClass("group-validation-error");
                    angular.element("#tinExpDateId").parent().next().remove();
                }

            }, 500);

        }
    }

    var fiscalResidenceSelected = function (currentDropDown) {
        if (!($(currentDropDown).closest(".fiscal-drop-down").next().hasClass("fiscal-drop-down"))) {
            $scope.FiscalResidenceDetails.push({
                "CountryCodeForFiscalResidence": "",
                "FiscalResidenceId": 0,
                "TinNumber": ""
            });
            $scope.$apply();
        }

    }
    $(document).on("change", "[name ^='inputParentFiscalCountry_']", function () {
        fiscalResidenceSelected($(this))
    });
    $scope.$watch('editPic', function (newValue, oldValue) {
        if (newValue == "front") {
            $("#frontImage").click();
            $scope.editPic = false;
        }
        if (newValue == "back") {
            $("#backImage").click();
            $scope.editPic = false;
        }
    });
    $scope.$watch('Eid.front', function (newValue, oldValue) {
        if (!newValue || newValue == "") {
            $('#frontImage').val('');
        }
    });
    $scope.$watch('Eid.back', function (newValue, oldValue) {
        if (!newValue || newValue == "") {
            $('#backImage').val('');
        }
    });

    $scope.returnToPlan = function () {
        $state.go("child.detail.plan", {
            childId: $scope.selectedChildId,
            childEntry: false
        });
    }
    $scope.eidSelected = function () {
        angular.element("#gemaltoContainer").height(Number(window.innerHeight - 80));
        angular.element('html').css('overflow-y', 'hidden');
        localStorage.identityInitiator = 'moneyOut';
        localStorage.childIdMoneyOut = $stateParams.childId;
    }
    $scope.picUploadSelected = function () {
        $scope.reader = 'picture';
        angular.element('html').css('overflow-y', 'auto');
        initializeFormValidation($("#editEidForm"));
    }

    $scope.saveIdentityDetails = function () {
        if (!$('#editEidForm').valid()) {
            $('#editEidForm').valid();
            return false;
        }

        if (ProofOfIdentity[0].ImageBase64[0]) {
            ProofOfIdentity[0].ImageBase64[0] = $scope.Eid.front;
        }
        else {
            ProofOfIdentity[0].ImageBase64.push($scope.Eid.front);
        }


        if (ProofOfIdentity[1].ImageBase64[0]) {
            ProofOfIdentity[1].ImageBase64[0] = $scope.Eid.back;
        }
        else {
            ProofOfIdentity[1].ImageBase64.push($scope.Eid.back);
        }



        ProofOfIdentity[0].IdentityId = 1;
        ProofOfIdentity[1].IdentityId = 2;
        ProofOfIdentity[0].IdentityProofNumber = angular.element("#tinNumber").val();
        ProofOfIdentity[1].IdentityProofNumber = angular.element("#tinNumber").val();
        var dt = angular.element("#tinExpDateId").val();


        ProofOfIdentity[0].ExpiryDate = new Date(dt.split("/")[1] + "/" + dt.split("/")[0] + "/" + dt.split("/")[2]);

        ProofOfIdentity[1].ExpiryDate = new Date(dt.split("/")[1] + "/" + dt.split("/")[0] + "/" + dt.split("/")[2]);
        ProofOfIdentity[0].PersonId = $scope.personId;
        ProofOfIdentity[1].PersonId = $scope.personId;

        for (var i = 0; i < ProofOfIdentity.length; i++) {
            if (ProofOfIdentity[i].ImageBase64[0].substring(0, 4) == 'data') {
                var array = ProofOfIdentity[i].ImageBase64[0].split(",");
                ProofOfIdentity[i].ImageBase64[0] = array[1];
            } else {
                ProofOfIdentity[i].ImageBase64[0] = null;
            }
        }
        var IdentityDetails = ProofOfIdentity;

        var url = '/moneyout/person/self/identity';
        WebApiService.updateIdentity(url, IdentityDetails).success(function (data, status) {
            $scope.identificationExist = true;
        }).error(function (data) {
            $scope.identificationExist = false;
        });
    }
    $scope.sendGemaltoData = function (gemaltoData) {
        var encryptedData = {};
        encryptedData.personId = $.cookie('personId');
        encryptedData.GemaltoResponse = gemaltoData;
        
        gemaltoFactory.eidUploadResponse(encryptedData).then(function (data) {
            if (data.data.Result) {
                $scope.identificationExist = true;
                genericSuccessMessageDisplay(Resources.EidDataSavedSucessfully);
            }
            else {
                $scope.identificationExist = false;
                genericErrorMessageDisplay(Resources.EidProcessingCancelled);
            }
        });
    }
    angular.element(".mo-type-container").height(Math.max(Number(angular.element(".mo-type-container:eq(0)").height()), Number(angular.element(".mo-type-container:eq(1)").height())) + "px");
}]);
myAppangular.directive("appFilereader", ["$q", function ($q) {
    var slice = Array.prototype.slice;

    return {
        restrict: 'A',
        require: '?ngModel',
        link: function (scope, element, attrs, ngModel) {
            if (!ngModel) return;

            ngModel.$render = function () { };

            element.bind('change', function (e) {
                var element = e.target;
                var file = e.target.files[0];
                if (file) {
                    var imageIdofElement = e.target.id;
                    var nameArray = file.name.split('.');
                    if (nameArray[nameArray.length - 1].toUpperCase() != 'JPG' && nameArray[nameArray.length - 1].toUpperCase() != 'PNG' && nameArray[nameArray.length - 1].toUpperCase() != 'TIFF') {
                        if (imageIdofElement == 'frontImage') {
                            $(document).trigger('deleteFrontImage', [false]);
                        }
                        else {
                            $(document).trigger('deleteBackImage', [false]);
                        }
                        $(element).closest(".sb-picture-blk").find(".sb-file-type-error").show();
                        $(element).closest(".sb-picture-blk").find(".sb-max-file-size").hide();
                        return;
                    }
                    else {
                        $(element).closest(".sb-picture-blk").find(".sb-file-type-error").hide();
                    }
                    var validFile = true;
                    if (attrs.maxSize != null) {

                        var maxSize = attrs.maxSize;
                        if (((file.size / 1024) / 1024) > maxSize) {
                            var validFile = false;
                        }

                    }

                    if (validFile) {

                        function readFile(file) {
                            var deferred = $q.defer();

                            var reader = new FileReader();
                            reader.onload = function (e) {
                                deferred.resolve(e.target.result);
                            };
                            reader.onerror = function (e) {
                                deferred.reject(e);
                            };
                            reader.readAsDataURL(file);
                            $(element).closest(".sb-picture-blk").find(".sb-max-file-size").hide();
                            $(element).closest(".sb-picture-blk").find(".sb-file-type-error").hide();
                            return deferred.promise;
                        }

                        $q.all(slice.call(element.files, 0).map(readFile))
                            .then(function (values) {
                                if (element.multiple) ngModel.$setViewValue(values);
                                else ngModel.$setViewValue(values.length ? values[0] : null);
                            });



                    }
                    else {
                       
                        if (imageIdofElement == 'frontImage') {
                            $(document).trigger('deleteFrontImage', [false]);
                        }
                        else {
                            $(document).trigger('deleteBackImage', [false]);
                        }
                        $(element).closest(".sb-picture-blk").find(".sb-max-file-size").show();
                        return;
                    }
                }
                else {
                    return; 
                }

            }); //change

        } //link
    }; //return
    
    
}]);
$(document).ready(function () {

    $('#editIbanNum').on('keypress', function (e) {


        var k = e.which;
        var validLetters = k == 8 || k >= 65 && k <= 90 || // A-Z
            k >= 97 && k <= 122 || // a-z
            k >= 48 && k <= 57; // 0-9

        if (!validLetters) {
            e.preventDefault();
        }

        $("#invalidIbanNum").css("display", "none");


    });
    $("#editIbanNum").on("paste", function () {
        $('#editIbanNum').removeAttr('maxLength');
        $(this).val($(this).val().replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').replace(/^(-)+|(-)+$/g, ''));
        setTimeout(function () {
            $('#editIbanNum').attr('maxLength', 16);
        }, 500);
    });

    $('#editIbanNum').on('focus', function () {
        $(this).val($(this).val().replace(/[\s]/g, ""));
        $(this).parent().parent().removeClass("error");
        $("#invalidIbanNum").css("display", "none");
    });

});
