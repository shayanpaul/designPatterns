﻿myAppangular.controller("UserOnBoardingController", ["$scope", "$filter", "$state", "$stateParams", "WebApiService", "$window", "$rootScope", function ($scope, $filter, $state, $stateParams, WebApiService, $window, $rootScope) {
    //<script src="https://code.createjs.com/createjs-2015.11.26.min.js"></script>
    //<script src="SavingSchool_mockup.js?1481130827477"></script>

    var stage;
    var countNext = 1;
    var countPrev = 2;
    var slide = 0;

    var exportRoot_s1 = null;
    var exportRoot_s2 = null;
    var exportRoot_s3 = null;
    var exportRoot_s4 = null;
    $scope.showThisDiv = false;
    var isSubOrReg = -1;
    var MODEL_OPEN_FOR = {'SUBSCRIPTION':0,'REGISTRATION':1};

    $scope.init = function () {
        $('.single-item').slick({
            dots: true,
            infinite: false,
            slidesToShow: 1,
            initialSlide: 0,
            fade: true,
            swipe: true,
            swipeToSlide: true,
            lazyLoad: 'ondemand',
            prevArrow: '<button class="btn btn-lnk slick-prev"><i class="glyphicon glyphicon-aagje-arrow-left btn-icon-left slick-i-previous"></i><span id="slick-span-previous">' + Resources.Back + '</span></button>',
            nextArrow: '<button class="btn btn-lnk slick-next"><span id="slick-span-next">' + Resources.Next + '</span><i class="glyphicon glyphicon-aagje-arrow-right btn-icon-right slick-i-next"></i></button>',
            slidesToScroll: 1
        });
        //$('.slick-i-previous').addClass('hidden');
        $('.slick-prev').addClass('hidden');
        $('.single-item').on('afterChange', function (event, slick, currentSlide) {
            if (currentSlide === 3) {
                $('.slick-i-next').addClass('hidden');
                $('#slick-span-next').text(Resources.Done);
            } else {
                $('.slick-i-next').removeClass('hidden');
                $('.slick-next').removeClass('hidden');
                $('#slick-span-next').text(Resources.Next);
            }

            if (currentSlide === 0) {
                //$('.slick-i-previous').addClass('hidden');
                $('.slick-prev').addClass('hidden');
            } else {
                //$('.slick-i-previous').removeClass('hidden');
                $('.slick-prev').removeClass('hidden');
            }
        });
    };

    $scope.$parent.initialiseLibrary = function (caseGiven) {
        isSubOrReg = caseGiven;
        switch (caseGiven) {
            case 0: //on Subscription message
                $scope.showThisDiv = true;
                exportRoot_s1 = new lib.Subscription_slide1();
                exportRoot_s2 = new lib.Subscription_slide2();
                exportRoot_s3 = new lib.Subscription_slide3();
                $("#userOnBoardingModal .modal-title").text(Resources.UserOnBoardingSubscription_Title);
                $("#h-s1").text(Resources.UserOnBoardingSubscription_Step1);
                $("#h-s2").text(Resources.UserOnBoardingSubscription_Step2);
                $("#h-s3").text(Resources.UserOnBoardingSubscription_Step3);
                $("#p-s1").text(Resources.UserOnBoardingSubscription_Step4);
                $("#p-s2").text(Resources.UserOnBoardingSubscription_Step5);
                $("#p-s3").text(Resources.UserOnBoardingSubscription_Step6);

                $("#div-1-s4").text(Resources.GettingStarted);
                $("#div-2-s4").text(Resources.DiscoverYongoFunctionalitiesByYourself);
                $("#div-3-s4").text(Resources.UserOnBoardingSubscription_Step2);
                //$("#div-4-s4").text(Resources.DoItNow);
                $("#div-4-s4").text(Resources.Contribute);
                $("#div-5-s4").text(Resources.UserOnBoardingSubscription_Step1);
                //$("#div-6-s4").text(Resources.DoItNow);
                $("#div-6-s4").text(Resources.InviteSupporter);
                $("#div-7-s4").text(Resources.UserOnBoardingSubscription_Step3);
                //$("#div-8-s4").text(Resources.DoItNow);
                $("#div-8-s4").hide();
                $("#div-8-s4").siblings().hide();

                
                $("#img-1-s4").attr("src", "/Images/subs_01_contribute_child.svg");
                $("#img-2-s4").attr("src", "/Images/subs_02_invite_supporter.svg");
                $("#img-3-s4").attr("src", "/Images/subs_03_personalize_child.svg");
                $("#sub-navigation-3").addClass('disabled');
                break;

            case 1: //on registration finish
                $scope.showThisDiv = false;
                exportRoot_s1 = new lib.Registration_slide1();
                exportRoot_s2 = new lib.Registration_slide2();
                exportRoot_s3 = new lib.Registration_slide3();
                $("#userOnBoardingModal .modal-title").text(Resources.UserOnBoardingRegistration_Title);
                $("#h-s1").text(Resources.UserOnBoardingRegistration_Step1);
                $("#h-s2").text(Resources.UserOnBoardingRegistration_Step2);
                $("#h-s3").text(Resources.UserOnBoardingRegistration_Step3);
                $("#p-s1").text(Resources.UserOnBoardingRegistration_Step4);
                $("#p-s2").text(Resources.UserOnBoardingRegistration_Step5);
                $("#p-s3").text(Resources.UserOnBoardingRegistration_Step6);

                $("#div-1-s4").text(Resources.GettingStarted);
                $("#div-2-s4").text(Resources.DiscoverYongoFunctionalitiesByYourself);
                $("#div-3-s4").text(Resources.UserOnBoardingRegistration_Step2);
                $("#div-4-s4").text(Resources.AddYourChild);
                //$("#div-3-s4").text(Resources.PersonalizeYourExperience);
                //$("#div-4-s4").text(Resources.DoItNow);
                $("#div-5-s4").text(Resources.UserOnBoardingRegistration_Step3);
                //$("#div-6-s4").text(Resources.DoItNow);
                $("#div-6-s4").text(Resources.BecomeSupporter);
                $("#div-7-s4").text(Resources.UserOnBoardingRegistration_Step1);
                //$("#div-7-s4").text(Resources.BecomeSupporterOfChild);
                //$("#div-8-s4").text(Resources.DoItNow);
                $("#div-8-s4").text(Resources.MySettings);
                $("#div-9-s4").text(Resources.GetYongoing);
                $("#div-10-s4").text(Resources.DiscoverYongoYourself);
                $("#div-8-s4").show();
                $("#div-8-s4").siblings().show();
                $("#sub-navigation-3").removeClass('disabled');

                $("#img-1-s4").attr("src", "/Images/reg_01_add_child.svg");
                $("#img-2-s4").attr("src", "/Images/add_supporter.svg");
                $("#img-3-s4").attr("src", "/Images/reg_03_personalise.svg");
                
                break;
        }
        callAnimation(0);
    }

    function resizeCanvas() {
        if ($('#userOnBoardingModal').is(':visible')) {
            callAnimation(slide);
        }
    }

    //Registers the "tick" event listener.
    var fnStartAnimation = function (fnExportRoot, fnCanvasOnboarding, fnDom_overlay_container, fnAnim_container) {
        
        var fnStage = new createjs.Stage(fnCanvasOnboarding);

       
        fnStage.addChild(fnExportRoot);

        //createjs.Ticker.setFPS(lib.properties.fps);
        //createjs.Ticker.addEventListener("tick", fnStage);

        createjs.Ticker.setFPS(lib.properties.fps);
        if (fnExportRoot !== null) {
            listener = createjs.Ticker.on("tick", handleTick, this);
        } else {
            listener = createjs.Ticker.removeEventListener("tick", handleTick);
        }
       
        
        function handleTick(event) {
            var cameraInstance = fnExportRoot.___camera___instance;
            if (cameraInstance) {
                if (cameraInstance._off != null && cameraInstance._off == true)
                    fnExportRoot.transformMatrix = new createjs.Matrix2D();
                else {
                    var mat = cameraInstance.getMatrix();
                    var stageCenter = { 'x': lib.properties.width / 2, 'y': lib.properties.height / 2 };
                    mat.tx -= stageCenter.x;
                    mat.ty -= stageCenter.y;
                    var inverseMat = mat.invert();
                    inverseMat.prependTransform(stageCenter.x, stageCenter.y, 1, 1, 0, 0, 0, 0, 0);
                    inverseMat.appendTransform(-stageCenter.x, -stageCenter.y, 1, 1, 0, 0, 0, 0, 0);
                    fnExportRoot.transformMatrix = inverseMat;
                }
            }
            fnStage.update();
        }

        makeResponsive(true, 'both', false, 1, fnCanvasOnboarding, fnDom_overlay_container, fnAnim_container, fnStage);
    }

    $(document).ready(function () {
        // On before slide change
        $('.single-item').on('beforeChange', function (event, slick, currentSlide, nextSlide) {
            callAnimation(nextSlide);
        });
            
        //TODO
        $('#userOnBoardingModal').on('hidden.bs.modal', function () {
            // do something…
            $(this).removeData();
        });
        $('#userOnBoardingModal').on('hide.bs.modal', function (e) {
            $(e.target).removeData('bs.modal');
        });
        $('#userOnBoardingModal').on('show.bs.modal', function (event) {
           $('.single-item').slick('slickGoTo', 0, true);
        });
        
        $('.slick-next').click(function (event) {
            var label = $(this).text();
            if (label === Resources.Next) {
                
            } else if (label === Resources.Done) {
                $('#userOnBoardingModal').modal('hide');
           }
        });
        
        $('#sub-navigation-1').click(function (event) {
            if (isSubOrReg === MODEL_OPEN_FOR.SUBSCRIPTION) {
                $('#userOnBoardingModal').modal('hide');
                localStorage.setItem("contributeCond", false);
                localStorage.setItem("isContributionUpdate", false);
                localStorage.setItem("fromTimeline", false);
                localStorage.setItem("fromNotification", false);
                var expires = new Date();
                expires.setUTCFullYear(expires.getUTCFullYear() - 1);
                document.cookie = "entryPoint=; expires=" + expires.toUTCString() + "; path=/";
                $state.go("contribute", {
                    childId: '',
                    locationCalledFrom: 'goToContribute'
                });
            } else if (isSubOrReg === MODEL_OPEN_FOR.REGISTRATION) {
                $('#userOnBoardingModal').modal('hide');
                location.href = "/" + currentLanguage + "/Subscription/start";
            }
        });
        $('#sub-navigation-2').click(function (event) {
            if (isSubOrReg === MODEL_OPEN_FOR.SUBSCRIPTION) {
                $('#userOnBoardingModal').modal('hide');
                $state.go('supporters', {}, { reload: true });
            } else if (isSubOrReg === MODEL_OPEN_FOR.REGISTRATION) {
                $('#userOnBoardingModal').modal('hide');
                $('#becomeSupporterModal').modal('show');
            }
        });
        $('#sub-navigation-3').click(function (event) {
            if (isSubOrReg === MODEL_OPEN_FOR.SUBSCRIPTION) {
                   //DONT do anything
            } else if (isSubOrReg === MODEL_OPEN_FOR.REGISTRATION) {
                $('#userOnBoardingModal').modal('hide');
                $state.go('profile.edit', {});
           }
        });
    });

    //Code to support hidpi screens and responsive scaling.
    function makeResponsive(isResp, respDim, isScale, scaleType, fnCanvasOnboarding, fnDom_overlay_container, fnAnim_container, fnStage) {
        var lastW, lastH, lastS = 1;
        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();
        function resizeCanvas() {
            if ($(window).width() > 767) {
                $('#animation_container4').show();
            }
            var w = lib.properties.width, h = lib.properties.height;
            var iw = window.innerWidth, ih = window.innerHeight;
            if ($(window).width() < 768) {
                iw = window.innerWidth - 60;
                ih = window.innerHeight - 80;
                $('.onboarding-text').css('width', iw);
            }
            var iw = window.innerWidth, ih = window.innerHeight;
            var pRatio = window.devicePixelRatio || 1, xRatio = iw / w, yRatio = ih / h, sRatio = 1;
            if (isResp) {
                if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
                    sRatio = lastS;
                }
                else if (!isScale) {
                    if (iw < w || ih < h)
                        sRatio = Math.min(xRatio, yRatio);
                }
                else if (scaleType == 1) {
                    sRatio = Math.min(xRatio, yRatio);
                }
                else if (scaleType == 2) {
                    sRatio = Math.max(xRatio, yRatio);
                }
            }
            fnCanvasOnboarding.width = w * pRatio * sRatio;
            
            fnCanvasOnboarding.style.width = fnDom_overlay_container.style.width = fnAnim_container.style.width = w * sRatio + 'px';
            setTimeout(function () {
               
                if ($('.slick-active').width() > 0) {
                    $('.onboarding-text').css('width', $('.slick-list').width());
                } else {
                    if ($(window).width() < 768) {
                        $('.onboarding-text').css('width', 400);
                    } else {
                        $('.onboarding-text').css('width', 610);
                    }
                }
            }, 500);
            
            fnStage.scaleX = pRatio * sRatio;
            lastW = iw; lastH = ih;
            if ($(window).width() < 768) {
                if (slide === 3) {
                    sRatio = 1;
                }
            }
            
            fnCanvasOnboarding.height = h * pRatio * sRatio;
            fnCanvasOnboarding.style.height = fnAnim_container.style.height = fnDom_overlay_container.style.height = h * sRatio + 'px';
            fnStage.scaleY = pRatio * sRatio;
            lastS = sRatio;
        }
    }

    $rootScope.$on('RegistrationOnboardingModalShow', function (event, args) {
        $scope.RegistrationOnboardingModalShow = true;
    });

    $rootScope.$on('SubscriptionOnboardingModalShow', function (event, args) {
        $scope.RegistrationOnboardingModalShow = false;
    });

    function callAnimation(callSlide) {
        var exportRoot = null;
        var canvasOnboarding = null;
        var anim_container = null;
        var dom_overlay_container = null;
        slide = callSlide;
        if ($(window).width() < 768) {
            if (slide === 3) {
                $('#animation_container4').show();
            } else {
                $('#animation_container4').hide();
            }
        } else {
            $('#animation_container4').show();
        }
        switch (callSlide) {
            case 0:
                exportRoot = exportRoot_s1;
                canvasOnboarding = document.getElementById("canvas");
                anim_container = document.getElementById("animation_container");
                dom_overlay_container = document.getElementById("dom_overlay_container");
                fnStartAnimation(exportRoot, canvasOnboarding, dom_overlay_container, anim_container);
                countNext = 1;
                countPrev = 3;
                break;
            case 1:
                exportRoot = exportRoot_s2;
                canvasOnboarding = document.getElementById("canvas2");
                anim_container = document.getElementById("animation_container2");
                dom_overlay_container = document.getElementById("dom_overlay_container2");
                fnStartAnimation(exportRoot, canvasOnboarding, dom_overlay_container, anim_container);
                countNext = 2;
                countPrev = 0;
                break;
            case 2:
                exportRoot = exportRoot_s3;
                canvasOnboarding = document.getElementById("canvas3");
                anim_container = document.getElementById("animation_container3");
                dom_overlay_container = document.getElementById("dom_overlay_container3");
                fnStartAnimation(exportRoot, canvasOnboarding, dom_overlay_container, anim_container);
                countNext = 3;
                countPrev = 1;
                break;
            case 3:
                exportRoot = exportRoot_s4;
                canvasOnboarding = document.getElementById("canvas4");
                anim_container = document.getElementById("animation_container4");
                dom_overlay_container = document.getElementById("dom_overlay_container4");
                fnStartAnimation(exportRoot, canvasOnboarding, dom_overlay_container, anim_container);
                countNext = 0;
                countPrev = 2;
                break;
        }
    }
}]);