/// <reference path="../common/jquery.mcustomscrollbar.concat.min.js" />
/*global $, jQuery, alert, window*/
/*jslint browser: true*/
var simulationModule = angular.module("simulationModule", []);
simulationModule.controller("simulationController", ["$scope", "$state", "$rootScope", function ($scope, $state, $rootScope) {
    //$state.go('members');
    window.location.href = location.protocol + '//' + location.host;
}]);


myAppangular.controller("PersonSavingProject", ["$scope", "$filter", "$rootScope", "ChildProfileService", "WebApiService", function ($scope, $filter, $rootScope, ChildProfileService, WebApiService) {

    var shortTermPlanValidationType = 1;
    $scope.GetChildSavingPlanByChildId = function (childId) {
        var personId = $.cookie("personId");

        ChildProfileService.GetChildSavingPlanByChild(personId, childId).then(
            function (data) {
                var shortTermPlanCurrentValue = data.CurrentPlanValue;
                if (data.ShortTemProject) {
                    var shortTermPlan = data.ShortTemProject;
                }
                localStorage.isShortTermChildPage = true;
                $scope.showSsLink = true;
                if (data.ValidationType == shortTermPlanValidationType) {
                    localStorage.isShortTermChildPage = false;
                    $scope.showSsLink = false;
                }
                $scope.languageCulture = currentLanguage;
                if (shortTermPlanCurrentValue) {
                    if ($scope.languageCulture === languages.languageEN) {
                        $scope.CurrentPlanValueST = shortTermPlanCurrentValue.toFixed(2);
                    } else {
                        var CurrentPlanValueST = shortTermPlanCurrentValue;
                        $scope.CurrentPlanValueST = $filter("currency")(CurrentPlanValueST, "");
                    }
                }
                $scope.series = ["Series A"];
                $scope.colours = [{
                    fillColor: "rgba(3, 170, 179, 1)",
                    strokeColor: "rgba(3, 170, 179, 1)",
                    highlightFill: "rgba(3, 170, 179, 1)",
                    highlightStroke: "rgba(3, 170, 179, 1)"
                }];

                $scope.languageCulture = currentLanguage;

                $scope.options = {
                    scaleShowGridLines: false,
                    scaleShowLabels: false,
                    scaleLineColor: "transparent",
                    responsive: true,
                    barShowStroke: true,
                    barStrokeWidth: 1,
                    barValueSpacing: 5,
                    barDatasetSpacing: 1,
                    animation: false,
                    scaleLineWidth: 1,
                    scaleFontSize: 12,
                    scaleFontStyle: "normal"
                };

                if ($scope.languageCulture === languages.languageEN) {
                    $scope.options.tooltipTemplate = function (dataBar) {
                        return formatNumber(dataBar.value, true, 2, ".", ",");
                    };
                } else {
                    $scope.options.tooltipTemplate = function (dataBar) {
                        return formatNumber(dataBar.value, true, 2, ",", ".");
                    };
                }

                $scope.shortTermItem = [];
                $scope.shortTermItemInfo = {};
                $scope.languageCulture = currentLanguage;
                $scope.personId = $.cookie("personId");
                if (shortTermPlan != null) {
                    var shortTermProjectLength = shortTermPlan.length;
                    if ($scope.languageCulture === languages.languageEN) {
                        for (i = 0; i < shortTermProjectLength; i++) {
                            $scope.shortTermItem.push({
                                itemName: shortTermPlan[i].ProjectTitle,
                                current: shortTermPlan[i].ProjectCurrentValue,
                                currentEuro: shortTermPlan[i].ProjectCurrentValue,
                                total: shortTermPlan[i].ProjectTargetAmount,
                                totalEuro: shortTermPlan[i].ProjectTargetAmount,
                                ImagePath: images.dataImage + shortTermPlan[i].ProjectImage
                            });
                        }
                    } else {
                        for (i = 0; i < shortTermProjectLength; i++) {
                            $scope.shortTermItem.push({
                                itemName: shortTermPlan[i].ProjectTitle,
                                current: shortTermPlan[i].ProjectCurrentValue,
                                currentEuro: $filter("currency")(shortTermPlan[i].ProjectCurrentValue, ""),
                                total: shortTermPlan[i].ProjectTargetAmount,
                                totalEuro: $filter("currency")(shortTermPlan[i].ProjectTargetAmount, ""),
                                ImagePath: images.dataImage + shortTermPlan[i].ProjectImage
                            });
                        }
                    }
                }
            },
            function (error) {

            }
        );
    };
}]);

myAppangular.controller("pendingSubscriptionController", ["$scope", "$rootScope", '$state', function ($scope, $rootScope, $state) {
    $scope.$on("pendingChildSelected", function (event, args) {
        $scope.childID = args.any.childData.childId;
        $scope.childFirstName = args.any.childData.childFirstName;
        $scope.stepsLeft = args.any.childData.stepsLeft;
        $scope.image = args.any.childData.image;
        $scope.isPersonLongTermPending = args.any.childData.isPersonLongTermPending;
        $scope.isPersonShortTermPending = args.any.childData.isPersonShortTermPending;

        $("#pendingSubscriptionModal").modal('show');
        args.any.customEvent.stopImmediatePropagation();
        args.any.customEvent.stopPropagation();

        $scope.gotoSubscription = function () {
            linkUrl = "/" + currentLanguage + "/Subscription/start?pageName=childDetails";
            location.href = linkUrl + "&childId=" + $scope.childID;
        }

        $scope.childNavigation = function () {
            $("#pendingSubscriptionModal").modal('hide');
            $state.go("child.detail.plan", {
                //state: childState,
                childId: args.any.childData.childId
            });
        }
    })
}]);

myAppangular.controller("SubscriptionOptionsController", ["$scope", "$rootScope", '$state', 'WebApiService', function ($scope, $rootScope, $state, WebApiService) {
    var personId = $.cookie('personId');
    $scope.subscriptionUrl = "/" + currentLanguage + "/Subscription/" + personId;
    $scope.initiateController = function () {
        $scope.getPendingChildrenList();
    }

    $scope.takeToSubscription = function (isChildExists, childId, linkUrl) {
        $scope.isChildExists = isChildExists;
        localStorage.setItem("MandateId", "");
        if (isChildExists) {
            localStorage.setItem("isChildExists", isChildExists);
        } else {
            localStorage.setItem("isChildExists", isChildExists);
            linkUrl = "/" + currentLanguage + "/Subscription/start";
            location.href = linkUrl;
        }
    }
    $scope.getPendingChildrenList = function () {
        WebApiService.GetPendingChildrenList().then(function (data) {
            //console.log(data);
            $scope.pendingChildList = data.data;
        });
    }
    $scope.gotoSubscription = function (childId) {
        location.href = "/" + currentLanguage + "/Subscription/start?pageName=childDetails" + "&childId=" + childId;
    }
    //    $scope.$on('checkPendingChildList', function () {
    //        if (!$scope.pendingChildList.length) {
    //            $("#pendingSubscriptionModalWhom").modal('hide');
    //            location.href = "/" + currentLanguage + "/Subscription/start";
    //}
    //    });
}]);


myAppangular.controller("SupporterController", ["$scope", "WebApiService", "ChildProfileService", "$rootScope", function ($scope, WebApiService, ChildProfileService, $rootScope) {
    $scope.linkUrl = "#";
    $scope.showMyChildButton = false;
    $scope.showSupportedChildButton = false;
    $scope.initSupporterChild = function () {
        GetSupportChildrenDetail();
    }
    $scope.getApproveSupportedChildDetails = function () {
        GetSupportChildrenDetail();
    }

    function GetSupportChildrenDetail() {
        var personId = $.cookie("personId");

        ChildProfileService.GetSupportChildrenDetail(personId).then(
            function (data) {
                $rootScope.totalSupporterCount = data.length;
                if (localStorage.getItem(isChild) === boolFlag.trueValue) {
                    if (Number(localStorage.getItem(personRole)) === roles.child) {
                        $scope.showSupportedChildren = false;
                        $scope.ShowNameAndPicture = false;
                        $scope.timelineClass = timelineClass.withNoChild;
                    } else {
                        if (localStorage.getItem(isInfantSupporter) === boolFlag.trueValue) {
                            if (data.length > 0) {
                                $scope.showSupportedChildren = true;
                                $scope.ShowNameAndPicture = true;
                                $scope.timelineClass = timelineClass.withChild;
                            } else {
                                $scope.showSupportedChildren = false;
                                $scope.ShowNameAndPicture = false;
                                $scope.timelineClass = timelineClass.withNoChild;
                            }
                        } else {
                            $scope.showSupportedChildren = true;
                            $scope.ShowNameAndPicture = true;
                            $scope.timelineClass = timelineClass.withChild;
                        }
                    }
                }
                dataLayer = [{
                    'Children supported': $rootScope.totalSupporterCount
                }];

                $scope.GroupInfo = [];
                if (data.length > 0) {
                    $scope.showSupportedChildButton = false;
                    $("a[id^='addChildrenSupporter']").show();
                    $scope.plus = true;
                } else {
                    $scope.showSupportedChildButton = true;
                    $("a[id^='addChildrenSupporter']").hide();
                    $scope.plus = false;
                }
                $.each(data, function (index) {
                    $scope.Info = {};
                    $scope.Info.childFirstName = data[index].PersonFirstName;
                    $scope.Info.childLastName = data[index].PersonLastName;
                    $scope.Info.childNickName = data[index].PersonNickName;
                    if (data[index].PersonImageUrl) {
                        $scope.Info.image = data[index].PersonImageUrl;
                    } else {
                        $scope.Info.image = images.defaultPersonImage;
                    }
                    $scope.Info.parentId = $.cookie("personId");
                    $scope.Info.childId = data[index].PersonId;
                    $scope.Info.cultureCode = $.cookie("language");
                    $scope.GroupInfo.push($scope.Info);
                });
            })
    }

    $scope.$on("localstorageset", function (event, args) {
        GetSupportChildrenDetail();
    });
}]);

myAppangular.controller("BasketController", ["$scope", "paymentService", function ($scope, paymentService) {
    if ($.cookie("personId") != null) {
    }
}]);
myAppangular.controller("PersonController", ["$scope", "$rootScope", "$state", "$stateParams", "$window", "WebApiService", "paymentService", "timelineService", "ChildProfileService", "HeaderServices", "$sce", "utilityFactory", function ($scope, $rootScope, $state, $stateParams, $window, WebApiService, paymentService, timelineService, ChildProfileService, HeaderServices, $sce, utilityFactory) {
    //Removing or deleting the previous cookie
    $scope.readMore = false;
    $scope.clearChildIdCookie = function () {
        $.cookie("childId", null, {
            path: "/"
        });
    };
    $scope.goToSupporter = function () {
        $state.go('supporters', {}, { reload: true });
    }
    $scope.goToDashboard = function () {
        $state.go('dashboard', {}, { reload: true });
    }
    localStorage.setItem("personloggedinChild", false);
    $scope.init = function (isSubscription) {
        //This function is sort of private constructor for controller
        $scope.isSubscription = isTrue(isSubscription);
    };
    $scope.nocase = true;
    $scope.userprofileParent = "";
    $rootScope.$on('thankyouModal-getData', function (event, args) {
        $scope.GetContributionDetailOnTimeline(args.any.id, "thankyouModal-started");
    });
    $scope.flagData = { "showMenuOne": true, "showMenuTwo": true, "showMenuThree": true, "showMenuFour": true };

    $rootScope.$on('menu-flag-recieved', function (event, args) {
        $scope.flagData = args.flagObj;
    });
    $rootScope.$on('menu-flag-recieved-as-parent', function (event, args) {
        $scope.flagData = args.flagObj;
    });
    if ($.cookie("personId") != null) {
        var url = "/members/" + $.cookie("personId");
        var language = $.cookie("language");
        $scope.childList = [];
        $scope.childList.push(parseInt($scope.id));
        $scope.hideSavingSchool = true;
        $scope.timelineClass = timelineClass.withChild;
        $scope.showMenuHeader = false;
        $scope.ShowNameAndPicture = false;
        $scope.ShowHideChildOptions = true;
        $scope.showMyChildren = false;
        $scope.showSupportedChildren = false
        $scope.showMyChildrenBlockonTop = false;
        $scope.showSupportedChildrenBlockonTop = false;
        //declaration end
        $scope.personId = $.cookie("personId");
        var res = WebApiService.getWebApiData(url, language);
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                $rootScope.personPhone = data.Phone;
                if (data.PersonImageUrl) {
                    $("#personImage").attr("src", data.PersonImageUrl);
                    $("#personImageHeader").attr("src", data.PersonImageUrl);
                } else {
                    $("#personImage").attr("src", images.defaultPersonImage);
                    $("#personImageHeader").attr("src", images.defaultPersonImage);
                }
                var headerImage = "";
                $("#header-image-div").removeClass();
                $("#header-image-div").addClass('header-image');
                if ($scope.isSubscription) {
                    headerImage = 'subscription-header-image';
                    if ($('#header-image-div').hasClass("header-image")) {
                        $('body').addClass('subscriptionStart');
                    }
                } else {
                    $rootScope.personPhone = data.Phone;
                    $scope.DateOfBirth = data.DateOfBirth;
                    $scope.Gender = data.Gender;
                    $rootScope.PersonEmail = data.EmailAddress;
                    var today = getDateInString(new Date(), "ddmmyyyy");
                    var dob = getDateInString(new Date(data.DateOfBirth), "ddmmyyyy");
                    var age = ageDifferenceCalculator(dob, today, "years");
                    if ($scope.Gender == 2) { //Female
                        if (age >= 0 && age <= 10) {
                            //$scope.case1 = true;
                            headerImage = 'f-0-c1-header-image';
                        } else if (age > 10 && age <= 16) {
                            //case2 = true;
                            headerImage = 'f-10-c2-header-image';
                        } else if (age > 16 && age <= 24) {
                            // case3 = true;
                            headerImage = 'f-16-c3-header-image';
                        } else if (age > 24 && age <= 50) {
                            // case4 = true;
                            headerImage = 'f-24-c4-header-image';
                        } else if (age > 50) {
                            // case5 = true;
                            headerImage = 'f-50-c5-header-image';
                        }
                    } else if ($scope.Gender == 1) { //Male
                        if (age >= 0 && age <= 10) {
                            // $scope.case6 = true;
                            headerImage = 'm-0-c1-header-image';
                        } else if (age > 10 && age <= 16) {
                            // case7 = true;
                            headerImage = 'm-10-c2-header-image';
                        } else if (age > 16 && age <= 24) {
                            // case8 = true;
                            headerImage = 'm-16-c3-header-image';
                        } else if (age > 24 && age <= 50) {
                            // case9 = true;
                            headerImage = 'm-24-c4-header-image';
                        } else if (age > 50) {
                            // case10 = true;
                            headerImage = 'm-50-c5-header-image';
                        }
                    } else if ($scope.Gender == 0) { //Unborn child
                        headerImage = 'ub-0-c0-header-image';
                    }
                }
                $("#header-image-div").addClass(headerImage);
                localStorage.setItem(personRole, data.PersonRole);
                localStorage.setItem(isInfantSupporter, data.IsInfantSupporter);
                localStorage.setItem(isChild, true);
                $rootScope.isChild = false;
                var birthYear = data.DateOfBirth.split("-")[0];
                localStorage.YOB = birthYear;
                var DobObj = new Date(data.DateOfBirth);
                var today = new Date();
                $scope.personAge = Math.floor((today - DobObj) / (365.25 * 24 * 60 * 60 * 1000));
                if ($scope.personAge == 0) {
                    $scope.personAgeInMonths = today.getMonth() - DobObj.getMonth() + (12 * (today.getFullYear() - DobObj.getFullYear()));
                    if ($scope.personAgeInMonths == 0) {
                        $scope.personAgeInDays= Math.floor((today - DobObj) / (24 * 60 * 60 * 1000));
                }
                } else if ($scope.personAge < 0) {
                    $scope.unbornChild =true;
                }

                $rootScope.$broadcast("localstorageset");

                if (data.IsChild === true) {
                    dataLayer = [{
                        'User profile': 'child'
                    }];
                    localStorage.setItem("personloggedinChild", true);
                    if (data.PersonRole === roles.child) { //for infant & unborn child
                        $scope.showMyChildren = false;
                        $scope.showSupportedChildren = false;
                        $scope.ShowNameAndPicture = false;
                        $scope.ShowHideChildOptions = false;
                        $scope.timelineClass = timelineClass.withNoChild;
                        $rootScope.$broadcast("infant-logged-in");
                    }
                    else if (data.PersonRole === roles.adultChild) {
                        $scope.ShowHideChildOptions = false;
                        $rootScope.$broadcast("adult-logged-in");
                    }
                    else {
                        if (data.IsInfantSupporter) {
                            $scope.showMyChildren = false;
                        } else {
                            $scope.showMyChildren = true;
                    }
                        $scope.showSupportedChildren = true;
                        $scope.ShowNameAndPicture = true;
                        $scope.timelineClass = timelineClass.withChild;
}

                    if (data.PersonRole !== roles.child && data.PersonRole !== roles.adultChild) {
                        $scope.showMenuHeader = true;
                        $rootScope.$broadcast("adult-logged-in");
                    } else {
                        $scope.showMenuHeader = false;
}
                    $scope.hideSavingSchool = false;
                    $rootScope.childImageURL = data.PersonImageUrl;
                    $rootScope.childFirstName = data.PersonNickName;
                    $scope.childLastName = data.PersonLastName;
                    $rootScope.isChild = true;
                    //only for dashboard
                    angular.element("#changeChild-image-dashboard .demoImg").attr('src', $rootScope.childImageURL);
  
} else { //for SP/Admin/Supporter
                    $scope.ShowNameAndPicture = true;
                    $scope.showMenuHeader = true;
                    $scope.hideSavingSchool = true;

    // change: 19/08/2016
                    $scope.showMyChildren = true;
                    $scope.showSupportedChildren = true;
                    localStorage.setItem(isChild, false);
                    $rootScope.isChild = false;
                    $rootScope.$broadcast("adult-logged-in");
            }
            $scope.$broadcast("isChildEvent");
                //end
                if (data.PersonRole === roles.supporter) {
                    $scope.showSupportedChildrenBlockonTop = true;
                }
                else {
                    $scope.showMyChildrenBlockonTop = true;
            }
                //

                //change as per defect 3517
                if (data.PersonFirstName) {
                    $scope.personNickName = data.PersonFirstName; //+ " " + data.PersonLastName;
                    $scope.PersonFullName = data.PersonFirstName + " " + data.PersonLastName;
                } else {
                    $scope.personNickName = data.PersonNickName;
            }
                //$scope.personImage = images.dataImage + data.PersonImage;// defect 6690
                if (data.PersonImageUrl) {
                    $scope.personImage = data.PersonImageUrl;
                } else {
                    $scope.personImage = images.defaultPersonImage;
            }
            $scope.personImageHeader = images.dataImage + data.PersonImage;
            $rootScope.parentName = $scope.personNickName;
            $scope.IsEligibleForSubscription = data.IsEligibleForSubscription;
            if (data.IsEligibleForSubscription == false) {
                    $("div[id^='newSubscription']").hide();
                }
                }, function (error) {
            // alert(personInfoError);
    });
}
}








    //This Code snipet is to prevent backspace navigqation from keyboard for Defect 1900. Change starts here.
    $(document).keydown(function (e) {
        var nodeName = e.target.nodeName.toLowerCase();
        if (e.which === 8) {
            if ((nodeName === "input" && e.target.type === "text") || nodeName === "textarea" || e.target.type === "number" || e.target.type === "password") {
            // do nothing
        } else {
                e.preventDefault();
    }
        }
        });

    $scope.selectedSupporter = null;
    $scope.supporterChildIds = [];

    $scope.goToContribute = function (obj, currentLanguageTemp, childId) {
        localStorage.setItem("contributeCond", obj);
        localStorage.setItem("isContributionUpdate", false);
        localStorage.setItem("fromTimeline", false);
        localStorage.setItem("fromNotification", false);
        var expires = new Date();
        expires.setUTCFullYear(expires.getUTCFullYear() - 1);
        document.cookie = "entryPoint=; expires=" + expires.toUTCString() + "; path=/";
        $state.go("contribute", {
            childId: childId,
                locationCalledFrom: 'goToContribute'
        });
        };
    $scope.timelineClicked = function (itemClickedOnTimeline) {

        $scope.ContributionId = 0;

        HeaderServices.markTimelineRead(itemClickedOnTimeline.TimeLineId);
        switch (true) {
            case (itemClickedOnTimeline.Category === category.RegistraionOnboarding):

                $scope.initialiseLibrary(1);
                $("#userOnBoardingModal").modal('show');
                HeaderServices.markTimelineRead(itemClickedOnTimeline.TimeLineId);
                $rootScope.$broadcast('refresh-timeline', {});
                break;
            case (itemClickedOnTimeline.Category === category.SubscriptionOnboarding):
                $scope.initialiseLibrary(0);
                $("#userOnBoardingModal").modal('show');
                HeaderServices.markTimelineRead(itemClickedOnTimeline.TimeLineId);
                $rootScope.$broadcast('refresh-timeline', {});
                break;
            case (itemClickedOnTimeline.Category === category.invitesupporter) && (itemClickedOnTimeline.PositiveButtonAction === actioncode.accept):
                var timelineID = itemClickedOnTimeline.TimeLineId;
                $rootScope.$broadcast('acceptRejectSupporter', { any: { "timelineID": timelineID, "popupRequired": true } });
                break;
            case (itemClickedOnTimeline.Category === category.invitesupporter) && (itemClickedOnTimeline.PositiveButtonAction === actioncode.approve):
                var timelineID = itemClickedOnTimeline.TimeLineId;
                $rootScope.$broadcast('inviteSupporterStart', { any: { "timelineID": timelineID, "fromTimeLine": true } });
                break;
            case (itemClickedOnTimeline.Category === category.becomesupporter) && (itemClickedOnTimeline.PositiveButtonAction === actioncode.accept):
                var timelineID = itemClickedOnTimeline.TimeLineId;
                var Category = itemClickedOnTimeline.Category;
                $rootScope.$broadcast('supportYourChildStart', { any: { "timelineID": timelineID, "Category": Category, "fromNotification": false } });
                $rootScope.$broadcast('refresh-timeline', {});
                break;
            case (itemClickedOnTimeline.Category === category.createevent) && (itemClickedOnTimeline.PositiveButtonAction === actioncode.approve):
                var eventId = itemClickedOnTimeline.CategoryIdentifier;
                $rootScope.$broadcast('eventDetailsFromTimelineApprove', { any: { "eventId": eventId } });
                break;
            case (itemClickedOnTimeline.Category === category.createevent) && (itemClickedOnTimeline.PositiveButtonAction === actioncode.accept):
                var eventId = itemClickedOnTimeline.CategoryIdentifier;
                $rootScope.$broadcast('eventDetailsFromTimelineAccept', { any: { "eventId": eventId } });
                break;
            case (itemClickedOnTimeline.Category === category.contribution) && (itemClickedOnTimeline.PositiveButtonAction === actioncode.thankyou):
                $scope.ContributionId = itemClickedOnTimeline.CategoryIdentifier;
                $scope.GetThankYouDetail($scope.ContributionId);
                $rootScope.$broadcast('refresh-timeline', {});
                break;
            case (itemClickedOnTimeline.Category === category.contribution) && (itemClickedOnTimeline.PositiveButtonAction === 2):
                $scope.ContributionId = itemClickedOnTimeline.CategoryIdentifier;
                $scope.GetContributionDetailOnTimeline($scope.ContributionId, "thankyouModal - started");
                $scope.isThankyou = false;
                $rootScope.$broadcast('refresh-timeline', {});
                break;
            case (itemClickedOnTimeline.Category === category.BackOffice) && (itemClickedOnTimeline.PositiveButtonAction === actioncode.accept):
                $scope.auditId = itemClickedOnTimeline.CategoryIdentifier;
                $rootScope.$broadcast('backOfficeAuditId', { any: { "auditId": $scope.auditId } });
                break;

            case (itemClickedOnTimeline.Category === category.PromoCode):
                $scope.ContributionId = itemClickedOnTimeline.CategoryIdentifier;
                $scope.GetContributionDetailOnTimeline($scope.ContributionId, 'promocode');
                $rootScope.$broadcast('refresh-timeline', {});
                break;

            case (itemClickedOnTimeline.Category == category.activateproject):
                $state.go("child.detail.savingschool", {
                    'childId': itemClickedOnTimeline.SenderId,
                    'routingEntry': 'cp',
                    childEntry: true,
                    isTimeline: true,
                        projectId: itemClickedOnTimeline.CategoryIdentifier
                });

                break;
            default:
                $rootScope.$broadcast('refresh-timeline', {});
                break;
        }
        angular.element("#notifications-container").removeClass('open');
        };

    $scope.GetContributionDetailOnTimeline = function (ContributionId, source) {
        var codeForContribution = 1;
        if (source && source == 'promocode') {
            codeForContribution = 2;
        }
        paymentService.GetContributionDetailOnTimeline(ContributionId, codeForContribution).then(
            function (data) {
                $scope.languageCulture = currentLanguage;
                $scope.TimelineInfo = {
            };
            $scope.TimelineInfo.contributorFirstName = data.ContributorViewModel.PersonFirstName;
            $scope.TimelineInfo.contributorLastName = data.ContributorViewModel.PersonLastName;
            $scope.TimelineInfo.contributorType = data.ContributorViewModel.PersonCode;
            $scope.TimelineInfo.contributeeFirstName = data.ContributeeViewModel.PersonFirstName;
            $scope.TimelineInfo.contributeeLastName = data.ContributeeViewModel.PersonLastName;
            $scope.TimelineInfo.ContributionId = ContributionId;
            $scope.TimelineInfo.ContributorId = data.ContributorViewModel.PersonId;
            $scope.TimelineInfo.childId = data.ContributeeViewModel.PersonId
            if (data.OneShotPaymentView[0]!= null) {
                    if (data.OneShotPaymentView[0].LongTermPlanView != null) {
                        $scope.TimelineInfo.contributionAmount = data.OneShotPaymentView[0].LongTermPlanView.OldAmount;
                        $scope.TimelineInfo.plantype = data.OneShotPaymentView[0].LongTermPlanView.PlanType;
                    } else {
                        $scope.TimelineInfo.contributionAmount = data.OneShotPaymentView[0].ShortTermPlanView.OldAmount;
                        $scope.TimelineInfo.plantype = data.OneShotPaymentView[0].ShortTermPlanView.PlanType;
            }
                    $scope.TimelineInfo.contributionMessage = data.OneShotPaymentView[0].Message;
                    if ($scope.TimelineInfo.contributionMessage != null) {
                        $scope.TimelineInfo.isMessage = true;
                    }
                    else {
                        $scope.TimelineInfo.isMessage = false;
            }
                $scope.readMore = false;
                    if ($(window).width() < 768) {
                        if ($scope.TimelineInfo.contributionMessage.length > 50) {
                            $scope.readMore = true;
                            $scope.reserveTextforRead = { "text": $scope.TimelineInfo.contributionMessage
                        };
                            $scope.TimelineInfo.contributionMessage = $scope.TimelineInfo.contributionMessage.substring(0, 50);
                    }
            }
            }
            if ($scope.isThankyou) {
                    if (data.ContributeeViewModel.PersonImageUrl != null)
                        $scope.TimelineInfo.contributeeImage = data.ContributeeViewModel.PersonImageUrl;
                    else
                        $scope.TimelineInfo.contributeeImage = images.PersonImageUrl;
            } else {
                    if (data.ContributorViewModel.PersonImageUrl != null)
                        $scope.TimelineInfo.contributorImage = data.ContributorViewModel.PersonImageUrl;
                    else
                        $scope.TimelineInfo.contributorImage = images.defaultPersonImage;
            }

                if (codeForContribution == 2) // for promo code
{
                    if (data.ContributeeViewModel.PersonImageUrl != null)
                        $scope.TimelineInfo.contributorImage = data.ContributeeViewModel.PersonImageUrl;
                    else
                        $scope.TimelineInfo.contributorImage = images.defaultPersonImageUrl;
            }

                if (data.ThankYouMessage != null) {
                    $scope.TimelineInfo.thankYouSent = true;
                    $scope.TimelineInfo.ThankYouMessage = data.ThankYouMessage;
                    if (data.ThankYouDate != null) {
                        $scope.TimelineInfo.ThankYouDate = data.ThankYouDate;
                        var thakyouDate = $scope.TimelineInfo.ThankYouDate.split("-");
                        var day = thakyouDate[0];
                        var month = thakyouDate[1].slice(0, 3);
                        var year = thakyouDate[2];
                        $scope.TimelineInfo.ThankYouDate = day + " " + month + " " + year;
}
} else {
                    $scope.TimelineInfo.thankYouSent = false;
            }
            $scope.TimelineInfo.HeaderName = Resources.Header_TransactionDetails;


                $("#transactionDetailModal_label").text($scope.TimelineInfo.HeaderName);

                if (source && source == "thankyouModal-started") {
                    $rootScope.$broadcast('thankyouModal-data', {
                            any: {
                            "data": $scope.TimelineInfo
                    }
});
                }else if (source) {
                    if (source == "promocode") {
                        $scope.TimelineInfo.promocodeModal = true;
                        $scope.TimelineInfo.HeaderName = Resources.Header_PartnerDetails;
                }
                    $rootScope.$broadcast('transactionDetailModal-started', {
                            any: {
                            "data": $scope.TimelineInfo
                    }
                });
        }
            },
            function (error) {
                genericErrorMessageDisplay(Resources.CustomAmount_Failed);
    }
        );
        }



    $scope.GetThankYouDetail = function (ContributionId, source) {
        $scope.imagesrc; //= images.thankYouDefaultImage;
        paymentService.GetThankYouDetail(ContributionId).then(
            function (data) {
                // data = data.data;
                $scope.languageCulture = currentLanguage;
                $scope.TimelineInfo = {
            };

                $scope.TimelineInfo.contributeeFirstName = data.ContributeeViewModel.PersonFirstName;
                $scope.TimelineInfo.contributeeLastName = data.ContributeeViewModel.PersonLastName;
                $scope.TimelineInfo.childId = data.ContributeeViewModel.PersonId;
                $rootScope.$broadcast('thankyouModal-started', { any: { "data": data, "thankYouSent": true
            }
        });
            },
            function (error) {
                genericErrorMessageDisplay(Resources.CustomAmount_Failed);
    }
        );
}

    //// Become a supporter

    $scope.readMoreText = function () {
        $scope.TimelineInfo.contributionMessage = $scope.reserveTextforRead.text;
        $scope.readMore = false;
        }

    $scope.SayThankYou = function (item) {
        $rootScope.$broadcast('thankyouModal-started', {
            any: {
                "data": item,
                "alreadyThanked": false,//$scope.TimelineInfo.thankYouSent
                "thankYouSent": false
    }
        });
        }
    $scope.hideUserMenu = function () {
        $('#userSetting').parent().removeClass("open");
        if (localStorage.isSubscriptionFlow && JSON.parse(localStorage.isSubscriptionFlow)) {
            $window.location.href = '/' + currentLanguage + '/Home/Profile';
}

        }
    $scope.reloadPage = function () {
        $window.location.href = '/' + currentLanguage + '/Account/Logout';
        return false;
    }
    }]);



$(document).ready(function () {
    var navHeight = $(".nav-header").height();
    var navigationmenu = $(".navigation-menu").height();
    $(window).scroll(function () {
        var screenWidth = window.innerWidth;
        if($(this).scrollTop() > 162) {
            $("header").addClass("fixed-menu");
            if (screenWidth >= 768) {
                $(".save-edit-details-notification").css("top", navHeight + 'px');
        }
        } else {
            $("header").removeClass("fixed-menu");
            if (screenWidth >= 768) {
                $(".save-edit-details-notification").css("top", navHeight + navigationmenu + 'px');
    }
        }
        });

    $(window).resize(function () {
        var windowWidth = window.innerWidth;
        if (windowWidth >= 768) {
            $('#moreOptionModal').modal('hide');
        }
        });
    $("body").css('padding', '0');

    $("#childEventDetails").animate({
        "right": "-1053px"
        });
    $(".evnt-timeline-home").click(function () {
        $("#childEventDetails").animate({
            "right": "-1053px"
        });
        $("#childEventHomePage").show();
        });
    $(".navbar-toggle").click(function () {
        $(".navbar-xsbtn-visible").show();
        });
    $(".navbar-xsbtn-visible").click(function () {
        $("#menuitems").removeClass("in");
        $(".navbar-xsbtn-visible").hide();
        });
    var textArea = $(".message textarea");
    var textAreaWrapper = textArea.closest(".message");
    textAreaWrapper.mCustomScrollbar({
        axis: "y",
        scrollbarPosition: "outside",
        mouseWheelPixels: 50,
        scrollInertia: 0,
            advanced: {
            autoScrollOnFocus: false
}
});


if ($("#messageForRecurrent").prop("disabled")) {
    $(".message").addClass("disabled");
    } else {
        $(".message").removeClass("disabled");
        }
    $("#bicNumber").attr("disabled", "disabled").addClass("disabled");
    if ($("#select-defaults-option").prop("disabled")) {
        $("#select-defaults-option").parent().find("button").addClass("disabled");
    } else {
        $("#select-defaults-option").parent().find("button").removeClass("disabled");
        }
    if ($(window).width() < 768) {
        var minimized_elements = $(".read-more-function p");
        var counter = 1;
        minimized_elements.each(function () {
            if (counter == 1) {
                $(this).addClass("first");
                var t = $(this).text();
                if (t.length < 50) return;
                $(this).html(
                t.slice(0, 50) + "<a class='link-more'>Read more</a>" +
            "<span style='display:none;'>" + t.slice(50, t.length) + "</span>"
            );
        } else {
                $(this).hide();
            }
            counter++;
        });

        $("a.link-more", minimized_elements).click(function (event) {
            event.preventDefault();
            $(this).hide().prev().hide();
            $(this).next().show();
            $(".row-payment-details-msg p").show();
            $(".link-more").hide();
});
    }


    $(".close-notification-tab-icon").click(function () {
        $("#top .save-edit-details-notification").slideUp();
        });
    $(".dropzone-user").mouseenter(function () {
        $(".take-pic-img, .take-pic-edit").css("opacity", "0.7");
    }).mouseleave(function () {
        $(".take-pic-img, .take-pic-edit").css("opacity", "1");
        });
    $(".scroll-up-modal").click(function () {
        $("#becomeSupporterModal").animate({
            scrollTop: 0
}, 300);
});
$(".next-step-modal").click(function () {
    $(".modal-content-one").animate({
        left: "-110%"
        }, 300);
        $(".modal-content-two").css("display", "block");
        $(".modal-content-two").animate({
        left: "0%"
        }, 300);
        setTimeout(function () {
            $(".modal-content-one").css("display", "none");
            $("#becomeSupporterModal_label").text($("#hiddenHeaderText2").val())
}, 300)
});
$("#addChildrenSupporter").click(function () {
    $.event.trigger({
        type: "newMessage",
        message: "",
        time: new Date()
        });
        $(".modal-content-one").css({
            "left": 0,
            "display": "block"
        });
        $(".modal-content-two").find(".text-box").removeClass("error");
        $("#sendEditedDetails").prop("disabled", false);
        $(".modal-content-two").css("display", "none");
        $("#failSuccessGlyphicon").removeClass("failure-notification");
        $("#failSuccessGlyphicon").removeClass("success-notification");

        $("#becomeSupporterModal_label").text($("#hiddenHeaderText1").val());
        });
    $("#addSupporterChildren").click(function () {
        $.event.trigger({
            type: "newMessage",
            message: "",
            time: new Date()
        });
        $(".modal-content-one").css({
            "left": 0,
            "display": "block"
        });
        $(".modal-content-two").find(".text-box").removeClass("error");
        $("#sendEditedDetails").prop("disabled", false);
        $(".modal-content-two").css("display", "none");
        $("#failSuccessGlyphicon").removeClass("failure-notification");
        $("#failSuccessGlyphicon").removeClass("success-notification");

        $("#becomeSupporterModal_label").text($("#hiddenHeaderText1").val());
    });

    $("#becomeSupporterModal").on("hidden.bs.modal", function () {
        $(".modal-content-one").css({ "display": "block", "left": 0 });
        $(".modal-content-two").css({ "display": "none", "left": "110%"
        });
        $("#becomeSupporterModal_label").text($("#hiddenHeaderText1").val());
        $("#supporterFirstName").val("");
        $("#supporterLastName").val("");
        $("#supporterEmail").val("");
        $("#supporterChildFirstName").val("");
        $("#supporterChildLastName").val("");
        });

    $(".modal").on("hidden.bs.modal", function () {
        $(this).find(".post-failure-notification").removeClass(".failure-notification").css("display", "none");
        });

    $("#addSupporterChildren").mouseenter(function () {
        $(".pp-child-each").css('box-shadow', '0 4px 8px 2px');
        $("#addSupporterChildren").css('opacity', '0.8');
        });

    $("#addSupporterChildren").mouseout(function () {
        $(".pp-child-each").css('box-shadow', '0 0 0 0');
        $("#addSupporterChildren").css('opacity', '1');
        });

    var url = $("#yongoVideo").attr('src');
    $("#yongoVideo").attr('src', '');
    $("#extraInfoModal").on('hide.bs.modal', function () {
        $("#yongoVideo").attr('src', '');
        });
    $("#extraInfoModal").on('show.bs.modal', function () {
        $("#yongoVideo").attr('src', url);
});

    });





    function genericSuccessMessageDisplay(customMessage) {
        if (customMessage != "") {
            $("#successfulYourPersonalDetailsAreSaved").text(customMessage);
            $("#failSuccessGlyphicon").removeClass("failure-notification");
            $("#failSuccessGlyphicon").addClass("success-notification");
            }
        $("#webappContainer .save-edit-details-notification").slideDown();
        setTimeout(function () {
            $("#webappContainer .save-edit-details-notification").slideUp();
    }, 10000);
    }

    function genericErrorMessageDisplay(message) {
        if (message != "") {
            $("#failedSomethingWentWrongTryAgainLater").text(message);
            $("#failSuccessGlyphicon").removeClass("success-notification");
            $("#failSuccessGlyphicon").addClass("failure-notification");
            }

        $("#webappContainer .save-edit-details-notification").slideDown();
        setTimeout(function () {
            $("#webappContainer .save-edit-details-notification").slideUp();
    }, 10000);
    }

    function genericErrorMessageDisplayModal(message) {
        if (message != "") {
            $(".failedSomethingWentWrongTryAgainLaterModal").text(message);
            $("#failSuccessGlyphiconSS").addClass("failure-notification");
            }
        $("#failSuccessGlyphiconSS").slideDown();
        }

        function genericModalErrorDisplayMessage(errMsg, className) {
            var parentClass = "." + className;
            if (errMsg != "") {
                $(parentClass + " .failed-err-msg").text(errMsg);
                $(parentClass).addClass("failure-notification");
                }

            $(parentClass).slideDown();
            }

        var clearSuccessMessage=function(e) {
            $(e.target).closest("#failSuccessGlyphicon").slideUp();
            }

            function clearSuccessMessageModal() {
                $("#failSuccessGlyphiconSS").slideUp();
                }

                function clearMultipleErrorModal() {
                    $("#failSuccessGlyphiconPC").hide();
                    }
                    function clearEventNotificationModal(messageId) {
                        $("#" + messageId).hide();
                        }
                        function clearModalErrMsg() {
                            $(".post-failure-notification").hide();
                            $(".post-failure-notification").removeClass(".failure-notification");
                            }

                            function check(e, value) {
                                var unicode = e.charCode ? e.charCode : e.keyCode;
                                if (unicode == 46 || unicode == 101) {
                                    return false;
                                    }
                                if (value.length < 4) {
                                    return true;
    } else {
                                    e.preventDefault();
                                    }
                                    }


                            myAppangular.directive("onlynumberdir", function () {
                                return {
                                require: "ngModel",
                                    link: function (scope, element, attr, ngModelCtrl) {
                                    function fromUser(text) {
                                        text = text.toString();
                                        var transformedInput = text.replace(/[^0-9]/g, "");
                                        if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                                            ngModelCtrl.$render();
                                    }
                                        return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
        }
        });

myAppangular.directive("onlyalphabetdir", function () {
    return {
    require: "ngModel",
        link: function (scope, element, attr, ngModelCtrl) {
        function fromUser(text) {
            var transformedInput = text.replace(/[^a-zA-Z\s]+/g, "");
            if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                ngModelCtrl.$render();
        }
            return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
        }
        });

myAppangular.directive("onlyalphabetapostrophdir", function () {
    return {
    require: "ngModel",
        link: function (scope, element, attr, ngModelCtrl) {
        function fromUser(text) {
            var transformedInput = text.replace(/[^a-zA-Z\'\\s]+/g, "");
            if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                ngModelCtrl.$render();
        }
            return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
        }
        });

myAppangular.directive("onlyalphanumbericdir", function () {
    return {
    require: "ngModel",
        link: function (scope, element, attr, ngModelCtrl) {
        function fromUser(text) {
            var transformedInput = text.replace(/[^0-9a-zA-Z\s]+/g, "");
            if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                ngModelCtrl.$render();
        }
            return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
        }
        });
myAppangular.directive('messageParsing', function () {
    return {
    restrict: 'E',
        scope: {
    myindex: '='
        },

            link: function (scope, element, attrs) {
                element.html($.parseHTML(scope.myindex));
},
};
});

myAppangular.directive("onlyvaliddatedir", function () {
    return {
    require: "ngModel",
        link: function (scope, element, attr, ngModelCtrl) {
        function fromUser(text) {
            var transformedInput = text.replace(/[^0-9\/]/g, "");
            if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                ngModelCtrl.$render();
        }
        var textLength = transformedInput.length;
            var replaceText = "";
            var str = transformedInput;
            var indices =[];
            for (var i = 0; i < str.length; i++) {
                    if (str[i]=== "/") {
                        indices.push(i);
            }
        }

                if ((transformedInput.length == 1) && (indices.length == 0)) {
                    transformedInput = transformedInput.slice(0, 1);
                } else if ((transformedInput.length == 2) && (indices.length == 0)) {
                    if (transformedInput > 31) {
                        transformedInput = transformedInput.slice(0, 1);
                    } else {
                        if (ngModelCtrl.$modelValue.length == 2) {
                            transformedInput = transformedInput + "/";
                    }
                }
                } else if ((transformedInput.length > 2) && (indices.length == 0)) {
                    transformedInput = transformedInput.slice(0, 2);
                    transformedInput = transformedInput + "/";
                } else if (indices.length == 1) {
                    if (indices[0]== 0) {
                        transformedInput = "";
                    } else if (indices[0]== 1) {
                        if ((transformedInput.length == 4) && (indices.length == 1)) {
                            if (transformedInput.slice(2, 4) > 12) {
                                transformedInput = transformedInput.slice(0, 3);
                            } else {
                                transformedInput = transformedInput + "/";
                        }
                        } else if (transformedInput.length > 4) {
                            transformedInput = transformedInput.slice(0, 4);
                            transformedInput = transformedInput + "/";
                    }
                    } else if (indices[0]== 2) {
                        if ((transformedInput.length == 5) && (indices.length == 1)) {
                            if (transformedInput.slice(3, 5) > 12) {
                                transformedInput = transformedInput.slice(0, 4);
                        }
                        } else if (transformedInput.length > 5) {
                            transformedInput = transformedInput.slice(0, 5);
                            transformedInput = transformedInput + "/";
                    }
                    } else {

                }
                } else if (indices.length == 2) {
                    if (indices[0]== 1) {
                        if (indices[1]== 3) {
                            if (transformedInput.length > 8) {
                                transformedInput = transformedInput.slice(0, 8);
                        }
                        } else if (indices[1]== 4) {
                            if (transformedInput.length > 9) {
                                transformedInput = transformedInput.slice(0, 9);
                        }
                        } else {
                            transformedInput = transformedInput.slice(0, 2);
                    }
                    } else if (indices[0]== 2) {
                        if (indices[1]== 4) {
                            if (transformedInput.length > 9) {
                                transformedInput = transformedInput.slice(0, 9);
                        }
                        } else if (indices[1]== 5) {
                            if (transformedInput.length > 10) {
                                transformedInput = transformedInput.slice(0, 10);
                        }
                        } else {
                            transformedInput = transformedInput.slice(0, 3);
                    }
                    } else {
                        transformedInput = transformedInput.slice(0, 3);
                }
                } else {
                    //not a date exception
                    transformedInput = transformedInput.slice(0, 3);
        }
        ngModelCtrl.$setViewValue(transformedInput);
            ngModelCtrl.$render();
            return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
}
}
});

// Constants which can be also utalised in HTML as well
myAppangular.filter('trusted', ['$sce', function ($sce) {
    var div = document.createElement('div');
    return function (text) {
        return $sce.trustAsHtml(text);
        };
        }]);
myAppangular.factory('httpInterceptor', ['$q', '$rootScope',
    function ($q, $rootScope) {
        var requestEnd = 0;
        return {
                request: function (config) {
                    if (config.url.substring(config.url.length -12, config.url.length) != "orderservice") {
                    if (!(getParameterByNameInAjaxCall("ispagination", config.url) || getParameterByNameInAjaxCall("pageSize", config.url))) {
                        $('#pageLoader').addClass('show');
                        $('html').addClass('no-scroll');
                        $('body').removeClass('ng-cloak');
                    }
                    else {
                        $('#pageLoader').removeClass('show');
                        $('html').removeClass('no-scroll');
                }
                        requestEnd++;
                    return config || $q.when(config);
                }
                else {
                    return config || $q.when(config);
        }
            },

                response: function (response) {
                requestEnd--;
                if (requestEnd == 0) {
                    $('#pageLoader').removeClass('show');
                    $('html').removeClass('no-scroll');
            }

                return response || $q.when(response);
            },

                responseError: function (response) {
                requestEnd--;
                if (requestEnd == 0) {
                    $('#pageLoader').removeClass('show');
                    $('html').removeClass('no-scroll');
            }
            return $q.reject(response);
    }
        };
        }]).config(['$httpProvider', function ($httpProvider) {
            $httpProvider.interceptors.push('httpInterceptor');
            }]);
    myAppangular.factory('allSupporterData', function () {
        var supporterData =[];
            return {
                setData: function (key, data) {
                    supporterData[key]= data;
        },
            getData: function (key) {
                return supporterData[key];
        }
        }
        });
        function getParameterByNameInAjaxCall(name, ajaxUrl) {
            var regexS = "[\\?&]" +name + "=([^&#]*)",
          regex = new RegExp(regexS),
          results = regex.exec(ajaxUrl);
            if (results == null) {
                return "";
    } else {
        return decodeURIComponent(results[1].replace(/\+/g, " "));
        }
        }

myAppangular.directive('eidInfoMessageParser', function () {
    return {
    restrict: 'C',
        link: function (scope, element, attrs) {
            element.html($.parseHTML(element.text()));
},
};
});











