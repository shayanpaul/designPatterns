﻿/*global $, jQuery, alert, window*/
/*jslint browser: true*/
myAppangular.controller("PromoCodeController", ["$scope", "$rootScope", "PromoCodeService", "subscriptionFactory", function ($scope, $rootScope, PromoCodeService, subscriptionFactory) {
    var promoCode = $.cookie("promoCode");
    var parentID = $.cookie("personId");
    if (parentID) {
        $scope.linkUrl = "/" + currentLanguage + "/Subscription/start";
    }
    else {
        $scope.linkUrl = "/" + currentLanguage + "/Account/SignIn?redirectUrl=" + "/" + currentLanguage + "/Subscription/start";
    }
    if (!promoCode){
        $scope.ValidPromoCode = false;
    }
    else{
        $scope.ValidPromoCode = true;
    }
    $scope.hideCrossButton = hideCrossButton;
    $rootScope.$on('deleteCross', function (event, args) {

        setTimeout(function () { $scope.hideCrossButton = true; }, 20);
        
    });
    PromoCodeService.GetPartnerDetails(promoCode).then(
        function (data, status) {
            var promoCodeDetails = {};
            promoCodeDetails = data.Result;
            $scope.ValidPromoCode = promoCodeDetails.IsValid;
            if (promoCodeDetails.IsValid) {
                $scope.info = {
                    "promotionalLeadAmount":promoCodeDetails.Amount,
                    "partnerCompanyName": promoCodeDetails.PartnerName,
                    "partnerAddressStreetOne": promoCodeDetails.PartnerAddress.HouseNumber + ' ' + promoCodeDetails.PartnerAddress.Street,
                    "partnerAddressStreetTwo": promoCodeDetails.PartnerAddress.ZipCode + ' ' + promoCodeDetails.PartnerAddress.City,
                    "partnerPhoneNumber": promoCodeDetails.PartnerPhone,
                    "partnerEmailID": promoCodeDetails.PartnerEmail,
                    "promoCode": promoCodeDetails.PromoCode,
                    "partnerImageSrc":  promoCodeDetails.PartnerImageUrl
                }
            }
            else
            {
                $.cookie("promoCode", "", { path: "/" });
            }
            subscriptionFactory.setpartnershipIdForOther(data.Result.PartnerId);
            $rootScope.$broadcast('PartnerShip', { any: { "partnershipId": data.Result.PartnerId } });
        },
        function (error) {
            $scope.ValidPromoCode =false;
        }
    );
    $scope.setChildFlag=function(isChildExists, childId, linkUrl){
        $scope.isChildExists = isChildExists;
        localStorage.setItem("MandateId", "");
        if (isChildExists) {
            localStorage.setItem("isChildExists", isChildExists);
        } else {
            localStorage.setItem("isChildExists", isChildExists);
        }
        location.href = linkUrl;
    }
    
}]);
