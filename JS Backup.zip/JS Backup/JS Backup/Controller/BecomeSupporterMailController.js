﻿supporterinvitationapp.controller("BecomeSupporterMailController", ["$scope", "FactoryHelper", "WebApiService", function ($scope, FactoryHelper, WebApiService) {
   // var url = "/invitations/becomesupporterid/" + $.cookie("becomeSupporterId") + "/parentid/" +$.cookie("parentId") + becomesupporterdetails";
    var url = "/invitations/becomesupporterid/" + $.cookie("becomeSupporterId") + "/becomesupporterdetails";
    var language = $.cookie("language");
    var res = FactoryHelper.CallApiGetAnonymous(url);
    if (res !== undefined) {
        res.then(function (d) {
            //   var response = JSON.stringify(d.data.Result);
            var data = d;
            $scope.childLastName = data.Result.ChildLastName;
            $scope.childFirstName = data.Result.ChildFirstName;
            $scope.ParentLastName = data.Result.ParentLastName;
            $scope.ParentFirstName = data.Result.ParentFirstName;
            $scope.senderFirstName = data.Result.SenderFirstName;
            $scope.senderLastName = data.Result.SenderLastName;
        }, function (error) {           
        });
    }
    $scope.validateUser = function () {
        var hostName = window.location.host;
        window.location.href = location.protocol + '//' + hostName;
    }
    
}]);