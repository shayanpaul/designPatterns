﻿/*global $, angular, jQuery, alert, window*/
/*jslint browser: true*/
/*jslint this:true */
/*jslint white:true, for:true */
/*jslint  devel: true */
myAppangular.controller("filterController", ["$scope", "WebApiService", "ModalFactory", "$rootScope", function ($scope, WebApiService, ModalFactory, $rootScope) {
   
    //var settingsForStart = { autoclose: true, format: "dd/mm/yyyy", language: "en", todayHighlight: false, orientation: "bottom", weekStart: 1 };
    //var settingsForEnd = { autoclose: true, format: "dd/mm/yyyy", language: "en", todayHighlight: true, orientation: "bottom", weekStart: 1 };
    var startDateObj = null;
    var endDateObj = null;
    var startDateMMDDYYYY = null;
    var endDateMMDDYYYY = null;

    $scope.init = function () {
        $('#filterStartDateId').inputmask('FilterDate');
        $('#filterEndDateId').inputmask('FilterDate');
       // $('#filterStartDateId,#filterEndDateId').inputmask({ "showMaskOnHover": false });
        $scope.filterBooleanShowDate = false;
        $scope.filterBooleanShowSupporter = false;
        $scope.filterBooleanShowTransaction = false;
        $scope.filterBooleanShowPlan = false;
        $scope.filterBooleanShowAmount = false;

        $scope.filterShowDateIfSelected = false;
        $scope.filterShowSupporterIfSelected = false;
        $scope.filterShowTransactionIfSelected = false;
        $scope.filterShowPlanIfSelected = false;
        $scope.filterShowAmountIfSelected = false;

        $scope.showClearFilterButton = false;

        $scope.filterTransactionTypeRadio = null;
        $scope.filterPlanTypeRadio = null;
        $scope.filterTransactionTypeRadio = null;
        $scope.maxRange = 0;
        $scope.minRange = 0;
        $scope.filterChildSupporterList = [];
        $scope.filterSupporterList = [];
        $scope.selectFromToDate = [
            { "id": 0, "label": "All" },
            { "id": 1, "label": "This week" },
            { "id": 2, "label": "Last Week" },
            { "id": 3, "label": "Today" },
            { "id": 4, "label": "This month" },
            { "id": 5, "label": "Last month" },
            { "id": 6, "label": "Yesterday" },
            { "id": 7, "label": "This year" },
            { "id": 8, "label": "Last year" }
        ];
        $scope.filterDateRadio = Resources.All;
        $scope.typeOfTransaction = [
        { "id": 0, "label": Resources.All, "value": 0 },
        { "id": 1, "label": Resources.MoneyIn, "value": 1 },
        { "id": 2, "label": Resources.FilterMoneyout, "value": 2 }
        ];
        $scope.planType = [
           { "id": 0, "label": Resources.All, "value": 2},
           { "id": 1, "label": Resources.ShortTerm, "value": 1},
           { "id": 2, "label": Resources.LongTerm, "value": 0 }
        ];
        $scope.selectARange = [
            { "id": 0, "label": "All", "max": 0, "min": 0 },
            { "id": 1, "label": Resources.From1to10 + " \u20ac", "min": 1, "max": 10 },
            { "id": 2, "label": Resources.From10to30 + " \u20ac", "min": 10, "max": 30 },
            { "id": 3, "label": Resources.From30to50 + " \u20ac", "min": 30, "max": 50 },
            { "id": 4, "label": Resources.From50to100 + " \u20ac", "min": 50, "max": 100 },
            { "id": 5, "label": Resources.Morethan100 + " \u20ac", "min": 100, "max": 100000 }
        ];
        $scope.supporterListModel = [];
        //$scope.data = { "id": 0, "label": "All", "max": 0, "min": 0 };
        $scope.filterDateRadio = $scope.selectFromToDate[0].label;
        $scope.filterPlanTypeRadio = $scope.planType[0].label;
        $scope.filterTransactionTypeRadio = $scope.typeOfTransaction[0].label;
        $scope.rangeSelected = $scope.selectARange[0].label;
    };
    var parentId = "";
    var supporterId = "";
    var planFilter = true;
    var locationFromWhereFilterIsCalled = "";
    $(".filter-content-module").on("click", function (e) {
        e.preventDefault();
    });
    //When you click on the "Filter" text on the page
    $scope.$parent.getFilterView = function (filterDataFor) {
        if (filterDataFor === "planSupporter") {
            locationFromWhereFilterIsCalled = filterDataFor;
            planFilter = true;
            $scope.childSupporter = true;
            $scope.supporterChild = false;
            $scope.showFilterSupporterView = true;
            $scope.showFilterTypeOfTransactionView = true;
            $scope.showFilterTypeOfPlanView = true;
            $scope.showFilterAmountRangeView = true;
            $scope.showFilterDateRangeView = true;
            parentId = $.cookie("personId");
           // var supporterList = $scope.$parent.transHisData;
            if (isEmptyOrUndefinedOrNull($scope.filterSupporterList) || $scope.filterSupporterList.length === 0) {
                $scope.getFilterSupporterList($scope.planTransactionHistorySupporterList);
            }
        } else if (filterDataFor === "childSupporter") {
            locationFromWhereFilterIsCalled = filterDataFor;
            planFilter = true;
            $scope.showFilterSupporterView = false;
            $scope.showFilterTypeOfTransactionView = false;
            $scope.showFilterTypeOfPlanView = true;
            $scope.showFilterAmountRangeView = true;
            $scope.showFilterDateRangeView = true;
            parentId = $scope.$parent.selectedSupporter.supporterId;
            supporterId = $.cookie("personId"); 
        } else if (filterDataFor === "supporter") {
            locationFromWhereFilterIsCalled = filterDataFor;
            planFilter = false;
            $scope.childSupporter = false;
            $scope.supporterChild = true;
            $scope.showFilterSupporterView = true;
            $scope.showFilterTypeOfTransactionView = false;
            $scope.showFilterTypeOfPlanView = true;
            $scope.showFilterAmountRangeView = true;
            $scope.showFilterDateRangeView = true;
            parentId = $scope.$parent.selectedSupporter.supporterId;
            supporterId = $.cookie("personId");
            //var childList = $scope.$parent.transHisData;
            if (isEmptyOrUndefinedOrNull($scope.filterSupporterList) || $scope.filterSupporterList.length === 0) {
                $scope.getFilterSupporterList($scope.selectedSupporter.childInfo);
            }
        }
        $(window).bind("resize load", function () {
            $(".filter-panel-collapse").attr("style", "");
        });

};

     /*List of Supporter*/
    $scope.getFilterSupporterList = function (supporterList) {
        if (supporterList) {
            var len = supporterList.length;
            var image = "";
            var name = "";
            var id = "";
            var supporterObj = {};
            for (i = 0; i < len; i += 1) {
                image = supporterList[i].PersonImage;
                name = supporterList[i].PersonFirstName;
                id = supporterList[i].PersonId;
                supporterObj = {
                    image: image,
                    name: name,
                    id: i,
                    idSupporter: id
                };
                 $scope.filterSupporterList.push(supporterObj);
            }
        }
    };

    $scope.supporterSelected = function (childSelected) {
        var checked = $(this).attr("checked");
        if (checked) {
            childSelected.filterBooleanShowSupporter = true;
            $scope.filterChildSupporterList.push(childSelected);
        } else {
            if ($scope.filterChildSupporterList && $scope.filterChildSupporterList.length > 0) {
                $scope.filterChildSupporterList = jQuery.grep($scope.filterChildSupporterList, function (value) {
                    return value.idSupporter != childSelected.idSupporter;
                });
            }
        }
        if ($scope.supporterListModel.length === 0) {
            $scope.filterShowSupporterIfSelected = false;
        } else {
            $scope.filterShowSupporterIfSelected = true;
        }
    };

    /*Date Range*/

   

    //var active_dates = ["10/10/2016"];
    //var today = new Date();
    //var two_weeks_back_date = new Date(today.getTime() - 14 * 24 * 60 * 60 * 1000);
    //var two_weeks_back_date_curr_date = two_weeks_back_date.getDate();
    //var two_weeks_back_date_curr_month = two_weeks_back_date.getMonth() + 1; //Months are zero based
    //var two_weeks_back_date_curr_year = two_weeks_back_date.getFullYear();
    //var formatted_two_weeks_back_date = two_weeks_back_date_curr_date + "/" + two_weeks_back_date_curr_month + "/" + two_weeks_back_date_curr_year;
    //var active_dates = [];
    //active_dates.push(formatted_two_weeks_back_date);
    //Listen for the change even on the input
    //$("#filterStartDateId").change(function (event) {
    //    event.stopPropagation();
    //    event.stopImmediatePropagation();
    //    var selectedDate = $(this).val();
    //    var format = selectedDate.split("/");
    //    var startDates = new Date(format[2], format[1] - 1, format[0]);
    //    $scope.filterEndDateStart = startDates;
    //    //setTimeout(function () {
    //    //    $scope.filterStartDate = getDateInString(startDates, DATE_FORMAT.DDMMYYYY);
    //    //   // $("#filterStartDateId").val(getDateInString(startDates, DATE_FORMAT.DDMMYYYY));
    //    //}, 1000);
    //        $scope.filterStartDate = getDateInString(startDates, DATE_FORMAT.DDMMYYYY);
        
    //    startDateMMDDYYYY = getDateInString(startDates, DATE_FORMAT.MMDDYYYY);
    //   // $('#filterStartDateId').inputmask('FilterDate');
    //    $scope.filterBooleanShowDate = true;
    //});
    //$("#filterEndDateId").change(function (event) {
    //    event.stopPropagation();
    //    event.stopImmediatePropagation();
    //    var selectedDate = $(this).val();
    //    var format = selectedDate.split("/");
    //    var endDateObj = new Date(format[2], format[1] - 1, format[0]);
    //    //setTimeout(function () {
    //    //    $scope.filterEndDate = getDateInString(endDateObj, DATE_FORMAT.DDMMYYYY);
    //    //   //$("#filterEndDateId").val(getDateInString(endDateObj, DATE_FORMAT.DDMMYYYY));
    //    //}, 1000);
    //    $scope.filterEndDate = getDateInString(endDateObj, DATE_FORMAT.DDMMYYYY);
    //    endDateMMDDYYYY = getDateInString(endDateObj, DATE_FORMAT.MMDDYYYY);
    //    //$('#filterEndDateId').inputmask('FilterDate');
    //    $scope.filterBooleanShowDate = true;
    //});

    //$scope.$watch('filterStartDate', function (newValue,oldValue) {
    //    alert('start changed!');
    //});
    //$scope.$watch('filterEndDate', function (newValue, oldValue) {
    //    alert('end changed!');
    //});
    $scope.FilterFirstdateClick = function () {
        var endDateSearch = getDateInString(new Date(new Date().getFullYear() + 1, 11, 31), DATE_FORMAT.DDMMYYYY);
        var twoWeekBack = getDateInString(new Date(new Date().getTime() - 14 * 24 * 60 * 60 * 1000), DATE_FORMAT.DDMMYYYY);
        $scope.filterEndDateStart = twoWeekBack;
        $scope.filterEndDateEnd = endDateSearch;
        $scope.filterStartDateStart = twoWeekBack;
        $scope.filterStartDateEnd = endDateSearch;
       // $('#filterStartDateId').inputmask('remove');
    };

    $scope.$watch("filterStartDate", function (newValue, oldValue) {
        if ($scope.filterStartDate && $scope.filterEndDate) {
            $scope.filterShowDateIfSelected = true;
        }
        $scope.filterStartDateInHeader = getDateInString(newValue, DATE_FORMAT.DDMMYYYY);
        startDateMMDDYYYY = getDateInString(newValue, DATE_FORMAT.MMDDYYYY);
        $scope.filterEndDateStart = new Date(newValue);
    });
    $scope.$watch("filterEndDate", function (newValue, oldValue) {
        if ($scope.filterStartDate && $scope.filterEndDate) {
            $scope.filterShowDateIfSelected = true;
        }
        $scope.filterEndDateInHeader = getDateInString(newValue, DATE_FORMAT.DDMMYYYY);
        endDateMMDDYYYY = getDateInString(newValue, DATE_FORMAT.MMDDYYYY);
    });
    /*Dropdown Range*/


    $scope.dateRangeUnitChanged = function () {
        var startDate = "";
        var endDate = "";
        $('#filterStartDateId').attr("disabled", "disabled");
        $('#filterEndDateId').attr("disabled", "disabled");
        if ($scope.filterDateRadio === $scope.selectFromToDate[0].label) { // all
            $('#filterStartDateId').removeAttr("disabled", "disabled");
            $('#filterEndDateId').removeAttr("disabled", "disabled");
            $scope.filterBooleanShowDate = false;
            startDateObj = "";
            endDateObj = "";
            startDateMMDDYYYY = null;
            endDateMMDDYYYY = null;
            $scope.filterShowDateIfSelected = false;
        } else if ($scope.filterDateRadio === $scope.selectFromToDate[1].label) { //this week
            var curr = new Date(); // get current date
            var first = curr.getDate() - curr.getDay() + 1; // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6
            startDateObj = new Date(curr.setDate(first));
            endDateObj = new Date();
            $scope.filterShowDateIfSelected = true;
        } else if ($scope.filterDateRadio === $scope.selectFromToDate[2].label) { //last week
            var curr = new Date(); // get current date
            var first = curr.getDate() - curr.getDay() - 6; // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6
            startDateObj = new Date(curr.setDate(first));
            endDateObj = new Date(curr.setDate(last));
             $scope.filterShowDateIfSelected = true;
        } else if ($scope.filterDateRadio === $scope.selectFromToDate[3].label) {//today
            var dateObj = new Date();
            startDateObj = dateObj;
            endDateObj = startDateObj;
            // $("#filterEndDateId").datepicker({ startDate: dateObj });
             $scope.filterShowDateIfSelected = true;
        } else if ($scope.filterDateRadio === $scope.selectFromToDate[4].label) {//this month
            var date = new Date();
            var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
            var lastDay = new Date();//new Date(date.getFullYear(), date.getMonth() + 1, 0);
            startDateObj = firstDay;
            endDateObj = lastDay;
             $scope.filterShowDateIfSelected = true;
        } else if ($scope.filterDateRadio === $scope.selectFromToDate[5].label) {//last month
            var firstDay = new Date();
            firstDay.setDate(1);
            firstDay.setMonth(firstDay.getMonth() - 1);
            var lastDay = new Date();
            lastDay.setDate(0);
            lastDay.setMonth(lastDay.getMonth());
            startDateObj = firstDay;
            endDateObj = lastDay;
             $scope.filterShowDateIfSelected = true;
        } else if ($scope.filterDateRadio === $scope.selectFromToDate[6].label) {//yesterday
            var yesterday = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
            startDateObj = yesterday;
            endDateObj = startDateObj;
             $scope.filterShowDateIfSelected = true;
        } else if ($scope.filterDateRadio === $scope.selectFromToDate[7].label) {//this year
            var dateObj = new Date();
            startDateObj = new Date(dateObj.getFullYear(), "00", "01");
            endDateObj = dateObj;
             $scope.filterShowDateIfSelected = true;
        } else if ($scope.filterDateRadio === $scope.selectFromToDate[8].label) {//last year
            var date = new Date();
            var firstDay = new Date(date.getFullYear() - 1, 0, 1);
            var lastDay = new Date(date.getFullYear() - 1, 11, 31);
            startDateObj = firstDay;
            endDateObj = lastDay;
             $scope.filterShowDateIfSelected = true;
        }

        if ((startDateObj != "") || (endDateObj != "")) {
            startDate = getDateInString(startDateObj, DATE_FORMAT.DDMMYYYY);
            endDate = getDateInString(endDateObj, DATE_FORMAT.DDMMYYYY);
            startDateMMDDYYYY = getDateInString(startDateObj, DATE_FORMAT.MMDDYYYY);
            endDateMMDDYYYY = getDateInString(endDateObj, DATE_FORMAT.MMDDYYYY);
        }
        /*set the start date and end date*/
       // $scope.filterStartDate = getDateInString(startDate, DATE_FORMAT.DDMMYYYY);
      //  $scope.filterEndDate = getDateInString(endDate, DATE_FORMAT.DDMMYYYY);
        $scope.filterStartDateInHeader = startDate;
        $scope.filterEndDateInHeader = endDate;
        
        $("#filterStartDateId").aagjeDatePicker('update', startDate);
        $("#filterEndDateId").aagjeDatePicker('update', endDate);
    };

    /*Type of Transactions*/

    $scope.typeOfTransactionUnitChanged = function () {
        if ($scope.filterTransactionTypeRadio === $scope.typeOfTransaction[0].label) {
            $scope.typeOfTransactionValue = $scope.typeOfTransaction[0].value;
            $scope.filterShowTransactionIfSelected = false;
        } else if ($scope.filterTransactionTypeRadio === $scope.typeOfTransaction[1].label) {
            $scope.typeOfTransactionValue = $scope.typeOfTransaction[1].value;
            $scope.filterShowTransactionIfSelected = true;
        } else if ($scope.filterTransactionTypeRadio === $scope.typeOfTransaction[2].label) {
            $scope.typeOfTransactionValue = $scope.typeOfTransaction[2].value;
            $scope.filterShowTransactionIfSelected = true;
        } else {
            $scope.typeOfTransactionValue = "";
            $scope.filterShowTransactionIfSelected = false;
        }
    };

    /*Plan*/

    $scope.filterPlanTypeUnitChanged = function () {
        if ($scope.filterPlanTypeRadio === $scope.planType[0].label) {
            $scope.planTypeValue = $scope.planType[0].value;
            $scope.filterShowPlanIfSelected = false;
        } else if ($scope.filterPlanTypeRadio === $scope.planType[1].label) {
            $scope.planTypeValue = $scope.planType[1].value;
            $scope.filterShowPlanIfSelected = true;
        } else if ($scope.filterPlanTypeRadio === $scope.planType[2].label) {
            $scope.planTypeValue = $scope.planType[2].value;
            $scope.filterShowPlanIfSelected = true;
        } else {
            $scope.planTypeValue = "";
            $scope.filterShowPlanIfSelected = false;
        }
    };

    /*Dropdown Range*/
    $scope.unitChanged = function () {
        $scope.rangeSelected = $scope.selectARange[$scope.selectedRange].label;
        $scope.maxRange = $scope.selectARange[$scope.selectedRange].max;
        $scope.minRange = $scope.selectARange[$scope.selectedRange].min;
        if ($scope.selectedRange === "0") {
            $scope.filterShowAmountIfSelected = false;
        } else {
            $scope.filterShowAmountIfSelected = true;
        }
        $("#select-default-filter").selectpicker("refresh");
       // { "id": 0, "label": "All", "max": 0, "min": 0 },
    };

    $scope.$parent.clearFilterAndReset = function () {
        $scope.resetFilterValues("All");
        //  $scope.$parent.transHisData = $scope.transHisDataFilterAll;
        // Call service to get fresh list
};
    /**/
    $scope.resetFilterValues = function (reset) {
        if (reset == "All") {
            $scope.filterBooleanShowDate = false;
            $scope.filterBooleanShowSupporter = false;
            $scope.filterBooleanShowTransaction = false;
            $scope.filterBooleanShowPlan = false;
            $scope.filterBooleanShowAmount = false;

            $scope.filterShowDateIfSelected = false;
            $scope.filterShowSupporterIfSelected = false;
            $scope.filterShowTransactionIfSelected = false;
            $scope.filterShowPlanIfSelected = false;
            $scope.filterShowAmountIfSelected = false;
            $scope.filterDateRadio = $scope.selectFromToDate[0].label;
            $scope.dateRangeUnitChanged();
            $scope.filterPlanTypeRadio = $scope.planType[0].label;
            $scope.filterPlanTypeUnitChanged();
            $scope.filterTransactionTypeRadio = $scope.typeOfTransaction[0].label;
            $scope.typeOfTransactionUnitChanged();
            $scope.selectedRange = "0";
            $scope.unitChanged();

            $("#select-default-filter").selectpicker("val", 0);
            if ($scope.filterDataObject != undefined) { 
                for (var i = 0; i < $scope.filterDataObject.filterSupporterCheckedListModel.length; i++) {
                    $scope.filterDataObject.filterSupporterCheckedListModel.splice(i, 1);
                    $scope.filterDataObject.filterChildSupporterList.splice(i, 1);
                }
            }
            var supporterModelArray = $scope.supporterListModel;
            for (i = 0; i < supporterModelArray.length; i++) {
                if ($("#filterCheck" + supporterModelArray[i]).is(":checked")) {
                    $("#filterCheck" + supporterModelArray[i]).attr("checked", false);
                }
            }
            $scope.filterTransactions(false);
        }
    }
    //Filtering transaction details
    $scope.filterTransactions = function (modifiedata) {
        $scope.filterBooleanShowDate = false;
        $scope.filterBooleanShowSupporter = false;
        $scope.filterBooleanShowTransaction = false;
        $scope.filterBooleanShowPlan = false;
        $scope.filterBooleanShowAmount = false;
        $scope.showClearFilterButton = false;

        if($scope.filterShowDateIfSelected){
            $scope.filterBooleanShowDate = true;
        }

        if($scope.filterShowSupporterIfSelected){
            $scope.filterBooleanShowSupporter = true;
        }

        if($scope.filterShowTransactionIfSelected){
            $scope.filterBooleanShowTransaction = true;    
        }

        if($scope.filterShowPlanIfSelected){
            $scope.filterBooleanShowPlan = true;
        }

        if($scope.filterShowAmountIfSelected){
            $scope.filterBooleanShowAmount = true;
        }

        if ($scope.filterBooleanShowDate || $scope.filterBooleanShowSupporter || $scope.filterBooleanShowTransaction || $scope.filterBooleanShowPlan || $scope.filterBooleanShowAmount) {
            $scope.showClearFilterButton = true;
        }
        var culture = "EN";// $.cookie("language");
        var childId = $.cookie("childId");
        if (culture == "EN") {
            culture = 0;
        } else if (culture == "FR") {
            culture = 1;
        } else if (culture == "NL") {
            culture = 2;
        }

        
        var FilterSupporterIds = null;
        var FilterChildIds = null;
        if (!isEmptyOrUndefinedOrNull($scope.supporterListModel) && $scope.supporterListModel.length > 0) {
            if (planFilter) {
                FilterSupporterIds = $scope.supporterListModel;
            } else {
                FilterChildIds = $scope.supporterListModel;
            }
        }

        var responseobject = {
            ChildId: childId,
            SupporterId: supporterId,
            CultureCode: "EN",
            DateRanges: [{ Type: $scope.filterDateRadio, Value: 0 }],
            ParentId: parentId,
            FilterDateRange: null,
            FilterFromDate: startDateMMDDYYYY,
            FilterToDate: endDateMMDDYYYY,
            FilterMaxAmount: $scope.maxRange,
            FilterMinAmount: $scope.minRange,
            FilterSupporterIds: FilterSupporterIds,
            FilterChildIds: FilterChildIds,
            FilterSavingType: $scope.planTypeValue,
            FilterTransactionType: $scope.typeOfTransactionValue,
            IsPagination: true,
            PageNumber: 1
        }
        initializeFiltervariables(responseobject);
    }

    $scope.filterSelection = function (clickedOn) {
        if ($(window).width() < 767) {
            var selectedItemheight = $("." + clickedOn).outerHeight();
            var filterHeaderheight = $(".filter-content-header").outerHeight();
            $(".panel-heading, .filter-footer-btn").hide();
            $("." + clickedOn).css({"display": "block" });
            $("." + clickedOn).animate({
                left: "0%"
            }, 50, function () {
                $(".filter-body").height(selectedItemheight + filterHeaderheight + "px");
            });
        }
    }
    $scope.applyFilter = function (okButton) {
        if ($(window).width() < 767) {
            $(".panel-heading, .filter-footer-btn").show();
            $("." + okButton).css({ "left": "110%", "display": "none" });
            $(".filter-body").css("height", "");
            $(".panel-collapse").css("height", "");
            
        }
    }

    function initializeFiltervariables(requestObject) {
        //$scope.maxRange = 0;
        //$scope.minRange = 0;
        //if ($scope.filterChildSupporterList && $scope.filterChildSupporterList.length > 0) {
        //    $scope.filterBooleanShowSupporter = true;
        //}
        var filterDataObject = {
            filterBooleanShowDate: $scope.filterBooleanShowDate,
            filterBooleanShowSupporter: $scope.filterBooleanShowSupporter,
            filterBooleanShowTransaction: $scope.filterBooleanShowTransaction,
            filterBooleanShowPlan: $scope.filterBooleanShowPlan,
            filterBooleanShowAmount: $scope.filterBooleanShowAmount,
            FilterDateRange: $scope.filterDateRadio,
            filterChildSupporterList: $scope.filterChildSupporterList,
            filterSupporterCheckedListModel: $scope.supporterListModel,
            filterStartDate: $scope.filterStartDateInHeader,
            filterEndDate: $scope.filterEndDateInHeader,
            filterTransactionTypeRadio: $scope.filterTransactionTypeRadio,
            filterPlanTypeRadio: $scope.filterPlanTypeRadio,
            filterAmount: $scope.rangeSelected,
            showClearFilterButton: $scope.showClearFilterButton
        };
        var filterObj = {};
        filterObj.filterDataObj = filterDataObject;
        filterObj.requestObj = requestObject;
        filterObj.locationFromWhereFilterIsCalled = locationFromWhereFilterIsCalled;
        ModalFactory.setData(filterObj);
        if (planFilter) {
            $rootScope.$broadcast("DATAUPDATED");
        } else {
            $rootScope.$broadcast("SUPPORTERDATAUPDATED");
        }
    }

    $scope.modifieddata = ModalFactory.getchangefilterData();
    if (!$scope.modifieddata && $scope.modifieddata == undefined) {
        $scope.modifieddata = ModalFactory.getData();
    } else if ($scope.modifieddata) {
        $scope.clickCount = 0;
        $scope.filterTransactions(true);
    }

    $scope.$on("FilterUPDATED", function () { //Start1
        $scope.filterDataObject = ModalFactory.getchangefilterData();
        var filterToBeRemoved = $scope.filterDataObject.removeFromFilterData;

        if (filterToBeRemoved === "date") {
            $scope.filterDateRadio = $scope.selectFromToDate[0].label;
            $scope.dateRangeUnitChanged();
        } else if (filterToBeRemoved === "plan") {
            $scope.filterPlanTypeRadio = $scope.planType[0].label;
            $scope.filterPlanTypeUnitChanged();
        } else if (filterToBeRemoved === "transaction") {
            $scope.filterTransactionTypeRadio = $scope.typeOfTransaction[0].label
            $scope.typeOfTransactionUnitChanged();
        } else if (filterToBeRemoved === "amount") {
            $scope.selectedRange = "0";
            $scope.unitChanged();
        } else {
            for (var i = 0; i < $scope.filterDataObject.filterSupporterCheckedListModel.length; i++) {
                if ($scope.filterDataObject.filterSupporterCheckedListModel[i] === filterToBeRemoved.idSupporter) {
                    $scope.filterDataObject.filterSupporterCheckedListModel.splice(i, 1);
                    $scope.filterDataObject.filterChildSupporterList.splice(i, 1);
                    //$scope.filterDataObject.filterChildSupporterList[i].filterBooleanShowSupporter = false;
                    break;
                }
            }
            if ($scope.filterDataObject.filterSupporterCheckedListModel.length === 0) {
                $scope.filterShowSupporterIfSelected = false;
            }else{
                $scope.filterShowSupporterIfSelected = true;
            }
        }
         $scope.filterTransactions(false);
     });
}]);
myAppangular.factory("ModalFactory", function () {
    var newData;
    var changefilterData;

    var setData = function (data) {
        newData = data;
        };
    var getData = function () {
        return newData;
        };
    var setchangefilterData = function (data) {
        changefilterData = data;
        };
    var getchangefilterData = function () {
        return changefilterData;
        };
    return {
        setData: setData,
            getData: getData,
            setchangefilterData: setchangefilterData,
            getchangefilterData: getchangefilterData
            };
            });

