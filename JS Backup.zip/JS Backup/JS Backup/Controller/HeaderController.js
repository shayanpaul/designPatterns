﻿myAppangular.controller("HeaderController", ["$scope", '$window', "$state", "$stateParams", "HeaderServices", "ChildProfileService", "HeaderConst", "$rootScope", "savingSchoolService", function ($scope, $window, $state, $stateParams, HeaderServices, ChildProfileService, HeaderConst, $rootScope, savingSchoolService) {
    $scope.personId = $.cookie("personId"); // TODO : use better way to set personId
    $scope.notInfant = true;
    $scope.notificationSkipDetail = {};

    //Set the default parameter for pagination
    $scope.notificationPageNumber = defaultNotifcationPageNumber;
    $scope.notificationPageSize = defaultNotificationPageSize;
    $scope.noChildForContribution = false;
    //$scope.$on("loading:progress'", function (url, loadedPct) {
    //    alert(progress);
    //});
    //$scope.$on("loading:finish'", function (url, loadedPct) {
    //    alert(finish);
    //});
    $scope.getNotifications = function (notificationPageNumber, notificationPageSize) {
        if ($scope.personId != null) {
            var res = HeaderServices.getNotifications($scope.personId, notificationPageNumber, notificationPageSize);
            if (res != undefined) {
                res.then(function (data) {
                    $scope.mapNotifications(data);
                    //if (data.ImageUrl == null) {
                    //    NotificationImage = images.defaultPersonImage;
                    //}

                    $scope.invitesupporter = HeaderConst.invitesupporter;
                    $scope.createevent = HeaderConst.createevent;
                    $scope.becomesupporter = HeaderConst.becomesupporter;
                    $scope.inviteadmin = HeaderConst.inviteadmin;
                    $scope.activateproject = HeaderConst.activateproject;
                    $scope.contribution = HeaderConst.contribution;
                    $scope.payment = HeaderConst.payment;
                    $scope.recurrentpayment = HeaderConst.recurrentpayment;
                    $scope.infobirthdayreminder = HeaderConst.infobirthdayreminder;

                    $scope.send = HeaderConst.send;
                    $scope.approve = HeaderConst.approve;
                    $scope.accept = HeaderConst.accept;
                    $scope.reject = HeaderConst.reject;
                    $scope.decline = HeaderConst.decline;
                    $scope.requestapproval = HeaderConst.requestapproval;
                    $scope.delete = HeaderConst.delete;
                    $scope.failure = HeaderConst.failure;
                    $scope.success = HeaderConst.success;
                    $scope.received = HeaderConst.received;
                    $scope.delete = HeaderConst.delete;
                },
              function (error) {
              });
            }
        }
    }

    $rootScope.$on('refresh-notification', function () {
        $scope.getHeaderCount();
        $scope.getNotifications(defaultNotifcationPageNumber, defaultNotificationPageSize);
    });

    $scope.mapNotifications = function (data) {
        $scope.PendingNotificationCount = data.PendingNotificationCount;
        $scope.OtherNotificationNotificationCount = data.OtherNotificationNotificationCount;

        $scope.pendingNotificationList = [];
        $.each(data.PendingNotificationList, function (item) {
            $scope.pendingNotificationList.push({
                title: data.PendingNotificationList[item].NotificationTitle,
                Image: data.PendingNotificationList[item].ImageUrl,
                Label: data.PendingNotificationList[item].Label,
                Date: data.PendingNotificationList[item].CreationDate,
                Category: data.PendingNotificationList[item].Category,
                MessageTemplateCode: data.PendingNotificationList[item].MessageTemplateCode,
                NegativeButtonAction: data.PendingNotificationList[item].NegativeButtonAction,
                            NotificationId: data.PendingNotificationList[item].NotificationId,
                PositiveButtonAction: data.PendingNotificationList[item].PositiveButtonAction,
                ReceiverId: data.PendingNotificationList[item].ReceiverId,
                SenderId: data.PendingNotificationList[item].SenderId,
                Status: data.PendingNotificationList[item].Status,
                TimeLineId: data.PendingNotificationList[item].TimeLineId,
                CategoryIdentifier: data.PendingNotificationList[item].CategoryIdentifier,
                ReadStatus: data.PendingNotificationList[item].ReadStatus
            });
        });
        $scope.otherNotificationList = [];
        $.each(data.OtherNotificationList, function (item) {
            $scope.otherNotificationList.push({
                title: data.OtherNotificationList[item].NotificationTitle,
                Image: data.OtherNotificationList[item].ImageUrl,
                Label: data.OtherNotificationList[item].Label,
                Date: data.OtherNotificationList[item].CreationDate,
                Category: data.OtherNotificationList[item].Category,
                MessageTemplateCode: data.OtherNotificationList[item].MessageTemplateCode,
                NegativeButtonAction: data.OtherNotificationList[item].NegativeButtonAction,
                NotificationActionCode: data.OtherNotificationList[item].NotificationActionCode,
                NotificationId: data.OtherNotificationList[item].NotificationId,
                PositiveButtonAction: data.OtherNotificationList[item].PositiveButtonAction,
                ReceiverId: data.OtherNotificationList[item].ReceiverId,
                SenderId: data.OtherNotificationList[item].SenderId,
                Status: data.OtherNotificationList[item].Status,
                TimeLineId: data.OtherNotificationList[item].TimeLineId,
                CategoryIdentifier: data.OtherNotificationList[item].CategoryIdentifier,
                ReadStatus: data.OtherNotificationList[item].ReadStatus,
                Skip: false
            });
        });
    }

    $scope.showAllNotification = function () {
        if ($scope.personId != null) {
            var res = HeaderServices.getNotifications($scope.personId, defaultNotifcationPageNumber, defaultNotificationMaximumPageSize);
            if (res != undefined) {
                res.then(function (data) {
                    $scope.mapNotifications(data);
                    $(".notifications-action").addClass('hide');
                },
              function (error) {
              });
            }
        }
        notificationheight();
    }

    $scope.getHeaderCount = function () {
        if ($scope.personId != null) {
            var res = HeaderServices.getHeaderCount($scope.personId);
            if (res != null) {
                res.then(function (data) {
                    $scope.basketCounter = data.BasketCount;
                    $scope.notificationCount = data.NotificationCount;
                    $scope.childCount = data.ChildCount;
                    if(isEmptyOrUndefinedOrNull(data.ChildCount) || data.ChildCount == 0)
                    {
                        $scope.noChildForContribution = true;
                    }
                },
                function (error) {
                });
            }
        }
    }
    $scope.$on('myCustomEvent', function (event, data) {
        $scope.getHeaderCount();// 'Data to send'
        $scope.getNotifications(defaultNotifcationPageNumber, defaultNotificationMaximumPageSize);
    });

    $scope.$on('infant-logged-in', function (event, data) {
        $scope.notInfant = false; 
    });
    $scope.$on('adult-logged-in', function (event, data) {
        $scope.notInfant = true; 
    });
    $scope.instantAcceptOrRejectOfProject = function (notification,acceptFlag) {
        var projectDetails = "";
        if (!savingSchoolService.getSavingSchoolData()) {
            if (notification.SenderId && notification.ReceiverId) {
                savingSchoolService.getSavingSchoolDetail(notification.ReceiverId, notification.SenderId).then(
                        function (data) {
                            projectDetails = data;
                            savingSchoolService.setSavingSchoolData(projectDetails);
                        },
                        function (error) {
                            genericErrorMessageDisplay(Resources.SavingSchoolDetails_Failed);
                        });
            }
        }
        else {
            projectDetails = savingSchoolService.getSavingSchoolData();
        }
        var pendingProjectObj = {};
        var isApprove = acceptFlag;
        pendingProjectObj.projectId = notification.CategoryIdentifier;
        $.each(projectDetails.ShortTermProjects, function () {
            if (this.ProjectId == pendingProjectObj.projectId) {
                pendingProjectObj.PlanId = this.PlanId;
                return false;
            }
        });
        pendingProjectObj.isParentOrAdmin = true;
        savingSchoolService.updatePendingProjectStatus(pendingProjectObj, notification.ReceiverId, notification.SenderId, isApprove, false).then(
        function (data) {
            savingSchoolService.setSavingSchoolData("");
            savingSchoolService.setWishData("");
            $rootScope.$broadcast('refresh-timeline', {});
            angular.element("#notifications-container").removeClass('open');
            if (isApprove) {
                genericSuccessMessageDisplay(Resources.MoveToProject_Success);
            } else {
                genericSuccessMessageDisplay(Resources.MoveToProject_Disapproved);
            }
            
        },
        function (error) {
        }
    );
    }
    $scope.AcceptInvitationSupporter = function (notification) {
        $rootScope.$broadcast('AcceptInvitationBySupporter', { any: { "notificationId": notification.TimeLineId } });
    }

    $scope.DeclineInvitationSupporter = function (notification) {
        $rootScope.$broadcast('DeclineInvitationBySupporter', { any: { "notificationId": notification.TimeLineId } });
    }

    $scope.ApproveorRejectInvitation = function (notification, flag) {

        switch (true) {
            case (notification.Category == category.activateproject):
                $scope.instantAcceptOrRejectOfProject(notification, flag);
                break;
            case (notification.Category == category.invitesupporter):
                $scope.acceptRejectSupporterInvite(notification.TimeLineId, flag);
                break;

            case (notification.Category == category.createevent):
                $scope.acceptRejectSupporterEvent(notification.TimeLineId, flag, notification.CategoryIdentifier);
                break;

            default:
                break;
        }
         angular.element("#notifications-container").removeClass('open');
        

    }; 
    $scope.acceptRejectSupporterEvent = function (timLineID, isApprove,eventId) {
        HeaderServices.acceptRejectSupporterEvent(eventId, isApprove).then(
                    function (data) {
                        if (isApprove) {
                            genericSuccessMessageDisplay(Resources.CreateEvent_Success);
    }
                        else {
                            genericSuccessMessageDisplay(Resources.SupporterRejectByparent);
                        }
                       
                        var notificationId = timLineID;                        
                        angular.element("#notificationIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                        angular.element("#notificationId" + notificationId).find(".notifications-action-btns").find("button").attr("disabled", "disabled").addClass("disabled");
                        angular.element("#timelineIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                        angular.element("#timelineIds" + notificationId).parent().removeClass("actionable").addClass("non-actionable");
                        $rootScope.$broadcast('refresh-timeline', {});
                    },
                    function (error) {
                        genericModalErrorDisplayMessage(Resources.CreateEvent_Failed, "event-failure-msg");
                    }
                );
    };
    $scope.acceptRejectSupporterInvite = function (timLineID, isApprove) {
        HeaderServices.acceptRejectSupporterInvite(timLineID, isApprove).then(
            function (data) {
                if (isApprove) {
                    genericSuccessMessageDisplay(Resources.InviteSupporter_Success);
                }
                else {
                    genericSuccessMessageDisplay(Resources.SupporterRejectByparent);
                }               
                var notificationId = timLineID;                
                angular.element("#notificationIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                angular.element("#notificationId" + notificationId).find(".notifications-action-btns").find("button").attr("disabled", "disabled").addClass("disabled");
                angular.element("#timelineIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                angular.element("#timelineIds" + notificationId).parent().removeClass("actionable").addClass("non-actionable");
                $rootScope.$broadcast('refresh-timeline', {});
            },
            function (error) {                
                genericModalErrorDisplayMessage(Resources.InviteSupporter_Failed, "invite-supporter-failure-msg");
        }
        );
    }

    $scope.skipNotification = function (itemClickedOnNotification, index) {
        var notificationId = itemClickedOnNotification.TimeLineId;
        if ($scope.personId != null) {            
            HeaderServices.skipNotification(itemClickedOnNotification.NotificationId).then(
                function (response) {
                    if (response.data === true) {
                    //if (itemClickedOnNotification.Category === category.contribution) { To generalize the skip functionality, removing the condition check
                        $scope.otherNotificationList[index].skip = true;
                       // $scope.showSkip = false; Use nowhere, that'why commenting
                        angular.element($("#notificationCnt").parent()).scope().notificationCount = $scope.notificationCount - 1;//defect 7024
                        $("#notificationId" + notificationId).attr("disabled", "disabled").addClass("disabled");
                        $("#notificationIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                   // }
                    }
                else {
                    //$scope.showSkip = true;
                }               
                },
                function (error) {
                    genericErrorMessageDisplay(Resources.ThankYouMessage_Failed);
                }
            );
                }
        notificationheight();
      //  window.location.reload();  //defect 7024
    }

    $scope.openThankYouModal = function (event, item) {       
        $rootScope.$broadcast('thankyouModal-getData', { any: { "id": item.CategoryIdentifier } });
    }

    $rootScope.$on('thankyouModal-data', function (event, args) {
            var obj = args.any.data;
            $scope.SayThankYou(obj);
    });
   
    $scope.SayThankYou = function (item) {
        angular.element($("#notificationCnt").parent()).scope().notificationCount = $scope.notificationCount - 1; //defect 7024
        $rootScope.$broadcast('thankyouModal-started', { any: { "data": item } });
    }
   /*Open Invite Supporter modal from become supporter notification message*/ 
    $scope.openInviteSupporterModalFromNotification = function (itemInfo) {
        var timelineId = itemInfo.TimeLineId;
        $rootScope.$broadcast('supportYourChildStart', { any: { "timelineID": timelineId, "fromNotification": true } });
    }

     /*Go to normal Subscription flow from become supporter notification message*/
    $scope.goToSubscriptionFromNotification = function () {
        location.href = "/" + currentLanguage + "/Subscription/start";;
    }

    //Getting list of supporters
    $scope.GetSupporterList = function () {
        var language = $.cookie("language");
        var parentId = $.cookie("parentId");
        ChildProfileService.GetSupporterList(parentId).then(
            function (data) {
            $scope.SupporterInfoList = [];
            $.each(data, function (index) {
                $scope.SupporterInfo = {
                };
                $scope.SupporterInfo.supporterFirstName = data[index].PersonFirstName;
                $scope.SupporterInfo.supporterLastName = data[index].PersonLastName;
                if (data[index].PersonImage != null) {
                    $scope.SupporterInfo.supporterImage = images.dataImage + data[index].PersonImage;
                } else {
                    $scope.SupporterInfo.supporterImage = images.defaultPersonImage;
                }
                $scope.SupporterInfo.supporterID = data[index].PersonId;
                if (data[index].SupporterRoleValue[0] == 3)
                    $scope.SupporterInfoList.push($scope.SupporterInfo);
            })

            
            },
            function (error) {
            }
        );
    }

    //Getting default relationship list
    $scope.DefaultRelationship = function () {
        ChildProfileService.DefaultRelationship().then(
            function (data) {
            var result = [];
            for (var i in data)
                result.push({
                    id: i,
                    name: data[i]
                });
            $scope.defaultRelationship = result;
            },
            function (error) {
            }
        );
    }

    $scope.goToContribute = function (obj, currentLanguageTemp) {
        if (!$scope.noChildForContribution) {
        localStorage.setItem("contributeCond", obj);
        localStorage.setItem("isContributionUpdate", false);
        localStorage.setItem("fromTimeline", false);
        var expires = new Date();
        expires.setUTCFullYear(expires.getUTCFullYear() - 1);
        document.cookie = "entryPoint=; expires=" + expires.toUTCString() + "; path=/";
        //$window.location.href = "/" +currentLanguageTemp + "/Contribute";
        var stateObj = { "hideContributeView": true };
        $state.go("contribute.basket", {
            obj: stateObj,
            locationCalledFrom: ''
        });
        }
   };

    $scope.goToContributeFromNotification = function (obj, item) {
        localStorage.setItem("contributeCond", obj);
        localStorage.setItem("isContributionUpdate", false);
        localStorage.setItem("fromTimeline", false);
        localStorage.setItem("fromNotification", true);
        $rootScope.$broadcast('acceptRejectSupporter', { any: { "timelineID": item.TimeLineId, "popupRequired": false } });        
        $('.notifications-header .close').trigger("click");
    }
    $rootScope.$on('gotocontributeFromNotification', function (event, args) {
        if ($state.current.name == 'contribute') {
            $state.transitionTo($state.current, {
                locationCalledFrom: 'updateViaNotificationView'
            }, {
                reload: true,
                inherit: false,
                notify: true
            });
        }
        else {
            $state.go("contribute", {
                locationCalledFrom: 'updateViaNotificationView'
            });
        }
    });

    $scope.goToEventContributeFromNotification = function (obj, item) {
        var eventId = item.CategoryIdentifier;
        $rootScope.$broadcast('eventDetailsFromTimelineAccept', { any: { "eventId": eventId } });
    }

    $scope.init = function () {
        $scope.getHeaderCount();
        $scope.getNotifications(defaultNotifcationPageNumber, defaultNotificationPageSize);
    }
    
    
    $scope.init();

    $scope.$on('localstorageset', function (event, args) {
        $scope.personId = $.cookie("personId");
    $scope.init();
    });

    window.onpopstate = function () {
        $state.go("members");
    };
    $(window).bind('beforeunload', function () {
        if ($rootScope.isChild) {
            window.location.href="/";
        }
    });
}]);

myAppangular.constant("HeaderConst", {
    "invitesupporter": 0,
    "createevent": 1,
    "becomesupporter": 2,
    "inviteadmin": 3,
    "activateproject": 4,
    "contribution": 5,
    "payment": 6,
    "recurrentpayment": 7,
    "infobirthdayreminder": 8,
    "send": 1,
    "approve": 2,
    "accept": 3,
    "reject": 4,
    "decline": 5,
    "requestapproval": 6,
    "delete": 7,
    "failure": 8,
    "success": 9,
    "received": 10
});
