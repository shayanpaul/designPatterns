﻿var myAppangular = angular.module("myApp", ["ui.router", 'ngAnimate', "chart.js", "angular-svg-round-progressbar", "eventmodelModule", "usermodelModule", "childPage", "checklist-model", "eventinvitationapp", "supporterinvitationapp", 'yaru22.angular-timeago', 'formsModule', 'subscriptionModule', 'AngularAuthApp', 'gemaltoModule', 'admininvitationapp']);
var usermodalModule = angular.module("usermodelModule", []);
var eventmodelModule = angular.module("eventmodelModule", ["formsModule"]);
var childPage = angular.module("childPage", []);
var subscriptionModule = angular.module('subscriptionModule', []);
var gemaltoModule = angular.module('gemaltoModule', []);
var angularAuthApp = angular.module('AngularAuthApp', []);
var eventinvitationapp = angular.module("eventinvitationapp", []);
var supporterinvitationapp = angular.module("supporterinvitationapp", []);
var admininvitationapp = angular.module("admininvitationapp", []);

myAppangular.filter("containsChild", function () {
    return function (array, needle) {
        return array.indexOf(needle) >= 0;
    };
});
myAppangular.config(["timeAgoSettings", function (timeAgoSettings) {
    var oneDay = 60 * 60 * 24;
    timeAgoSettings.allowFuture = true;
    timeAgoSettings.fullDateAfterSeconds = oneDay;
    if (window.location.href.toUpperCase().indexOf("SUBSCRIPTION") === -1) {
        $.cookie("promoCode", "", { path: "/" });
        globalFlagForPromoApplied = false;
    }
}]);


myAppangular.filter("sumOfValue", function () {
    return function (data, key) {
        if (angular.isUndefined(data) && angular.isUndefined(key)) {
            return 0;
        }
        var sum = 0;
        angular.forEach(data, function (value) {
            sum = sum + parseInt(value[key]);
        });
        return sum;
    };
});