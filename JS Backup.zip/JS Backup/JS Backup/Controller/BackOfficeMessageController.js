﻿myAppangular.controller("BOMessageController", ["$scope", "$rootScope", "WebApiService", function ($scope, $rootScope, WebApiService) {
    $scope.serviceCalled = false;
    $scope.personId = $.cookie("personId");
    if ($scope.personId != null) {
        var res = WebApiService.GetBackOfficeMessage();
        $scope.serviceCalled = true;
        if (res != undefined) {
            res.then(function (d) {
                var response = JSON.stringify(d.data);
                var data = JSON.parse(response);
                $scope.MessageEN = data.MessageEN;
                $scope.MessageFR = data.MessageFR;
                $scope.MessageNL = data.MessageNL;
                $scope.MessageForPlatform = data.MessageForPlatform;
            },
          function (error) {
          });
        }
    }

}]);