﻿myAppangular.controller("SupportYourChild", ["$scope", "SupporterService", "$rootScope", function ($scope, SupporterService, $rootScope) {
    
    $rootScope.$on('supportYourChildStart', function (event, args) {
        var timelineId = args.any.timelineID;
        var fromNotification = args.any.fromNotification;
        SupporterService.getBecomeSupporterDetails(timelineId).then(
            function (data) {
                $scope.BecomeSupporterInfo = {};
                $scope.BecomeSupporterInfo.ChildFirstName = data.ChildFirstName;
                $scope.BecomeSupporterInfo.ChildId = data.ChildId;
                $scope.BecomeSupporterInfo.ChildLastName = data.ChildLastName;
                $scope.BecomeSupporterInfo.ParentFirstName = data.ParentFirstName;
                $scope.BecomeSupporterInfo.ParentLastName = data.ParentLastName;
                $scope.BecomeSupporterInfo.SupporterFirstName = data.SupporterFirstName;
                $scope.BecomeSupporterInfo.SupporterLastName = data.SupporterLastName;
                $scope.BecomeSupporterInfo.InvitationMessage = data.InvitationMessage;
                $scope.BecomeSupporterInfo.SupporterEmail = data.SupporterEmail;
                $scope.BecomeSupporterInfo.SupporterNickName = data.SupporterNickName;

                if (data.PersonImageUrl !== null)
                    $scope.BecomeSupporterInfo.PersonImage = data.PersonImageUrl;
                else
                    $scope.BecomeSupporterInfo.PersonImage = images.defaultPersonImage;
                if (fromNotification == true) {
                    $scope.goToInviteSupporter();
                } else if (fromNotification == false) {
                    $("#supportYourChildModal").modal("show");
                }
            },
            function (error) {
                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
            });
});

    $scope.goToSubscription = function () {
        location.href = "/" +currentLanguage + "/Subscription/start";
    }
    
    $scope.goToInviteSupporter = function () {     
        var childList = [];
        $scope.selectedSupporter = {};
        $scope.selectedSupporter.previousFirstName = $scope.BecomeSupporterInfo.SupporterFirstName;
        $scope.selectedSupporter.previousLastName = $scope.BecomeSupporterInfo.SupporterLastName;
        $scope.selectedSupporter.previousNickName = $scope.BecomeSupporterInfo.SupporterNickName;
        $scope.selectedSupporter.previousEmail = $scope.BecomeSupporterInfo.SupporterEmail;      
        childList.push($scope.BecomeSupporterInfo.ChildId);        
        var becomeSupporter = $scope.selectedSupporter;
        $rootScope.$broadcast('inviteSupporterStart', { any: { "selectedSupporter": becomeSupporter, "childList": childList } });             
    }
}]);