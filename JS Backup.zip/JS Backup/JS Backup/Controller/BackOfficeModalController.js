﻿myAppangular.controller("BackOfficeModalController", ["$scope", "$rootScope", "timelineService", function ($scope, $rootScope, timelineService) {
    

        $rootScope.$on('backOfficeAuditId', function (event, arg) {
            var auditId = arg.any.auditId;
            timelineService.getBackOfficeMessage(auditId).then(
                function (data) {
                    $("#backofficeMessageModal").modal("show");
                    $scope.backOfficeMessage = data.data;
                },
                function (error) {
                    genericErrorMessageDisplay(Resources.CustomAmount_Failed);
                }
            );
        });
}]);