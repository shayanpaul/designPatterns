﻿myAppangular.controller("ParenInvitationController", ["$rootScope", "$scope", "SupporterService", function ($rootScope, $scope, SupporterService) {
    
    angular.element("#becomeSupporterModal").on("shown.bs.modal", function () {
            angular.element("#inputSupporterMessageModal").val(Resources.SupporterInvitationDefaultMessage + "\n" + $rootScope.parentName);
        
    });
    $scope.sendInvitation = function () {
        var personId = $.cookie("personId");
        if ($scope.parentEmail != $rootScope.PersonEmail) {

            if (!$('#supporterForm').valid()) {
                $('#supporterForm').valid();
                return;
            } else {
        var data = {
            InvitorPersonId: personId,
            ParentFirstName: $scope.parentFirstName,
            ParentLastName: $scope.parentLastName,
            Email: $scope.parentEmail,
            ChildFirstName: $scope.childFirstName,
            ChildLastName: $scope.childLastName,
            Text: angular.element("#inputSupporterMessageModal").val()
        };
            
        SupporterService.BecomeSupporter(data).then(
            function (data) {
                $("#becomeSupporterModal").modal("hide");
                $('html, body').animate({ scrollTop: '0px' }, 1000);
                genericSuccessMessageDisplay(Resources.RequestSupporter_Success);
            },
            function (error) {
                $('#becomeSupporterModal').animate({ scrollTop: '0px' }, 1000);
                if (error.data) {
                    if (error.data.ExceptionMessage == errorExceptionCode.inviteParentSelf) {
                        genericModalErrorDisplayMessage(error.data.InnerException.ExceptionMessage, "become-supporter-failure-msg");
                    }
                } else {
                    genericModalErrorDisplayMessage(Resources.RequestSupporter_Failed, "become-supporter-failure-msg");
                }
            }
        );
    }
        } else {
            $("#becomeSupporterModal").scrollTop(0);
            genericModalErrorDisplayMessage(Resources.SupporterInvitationAsParent_Failed, "become-supporter-failure-msg");

        }
    }
    $scope.checkMsgField = function () {
        if (!angular.element("#inputSupporterMessageModal").val().trim()) {
            angular.element("#inputSupporterMessageModal").val(Resources.SupporterInvitationDefaultMessage + "\n" + $rootScope.parentName);
        }
    }
}]);
