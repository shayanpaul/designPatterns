﻿myAppangular.controller("ThankYouController", ["$scope", "HeaderServices", "$rootScope", "utilityFactory", function ($scope, HeaderServices, $rootScope, utilityFactory) {
    $scope.thankYouSent = false;
    $scope.showcanvas = false;
    $scope.Charleft = 200;
    $scope.thankyouImageSelected = false;
    $scope.showThankYouModal = false;
    
    $scope.useDefault = function () {
        $scope.thankyouImageSelected = false;
        $scope.setThankYouImage();

        if (!$scope.$$phase) {
            $scope.$apply();
        }
        $scope.showcanvas = false;
        $("#editThankYouImage").show();
    }
    $scope.editPicture = function () {
        $scope.showcanvas = true;
        $scope.thankyouImageSelected = true;
        //var canvas = $("#thankuImage .select-image-preview")[0];
        //var context = canvas.getContext("2d");
        //context.clearRect(0, 0, canvas.width, canvas.height);
        //$scope.thankuImage = '';
        $('#thankuImage #demoImg').attr('src', '');
        $("#thankuImage .image-list").show();
        //$("#thankuImage").find(".select-image-dropzone").trigger("click");
        //return false;
        $("#editThankYouImage").hide();
    }
    $scope.placeholder = Resources.ThankYouMessage_Default;

    $rootScope.$on('thankyouModal-started', function (event, args) {
        if (args.any.thankYouSent) {
            var data = args.any.data;
            $scope.showcanvas = false;
            $scope.languageCulture = currentLanguage;
            $scope.TimelineInfo = {};

            $scope.TimelineInfo.contributeeFirstName = data.ContributeeViewModel.PersonFirstName;
            $scope.TimelineInfo.contributeeLastName = data.ContributeeViewModel.PersonLastName;
            $scope.TimelineInfo.childId = data.ContributeeViewModel.PersonId;

            if (data.ContributeeViewModel.PersonImageUrl != null)
                $scope.TimelineInfo.contributorImage = data.ContributeeViewModel.PersonImageUrl;
            else
                $scope.TimelineInfo.contributorImage = images.defaultPersonImage;

            if (data.ImageGet != null) {
                $scope.imageSrc = data.ImageGet;
            } else {
                $scope.setThankYouImage();
            }
            if (data.Text != null) {
                $scope.TimelineInfo.thankYouSent = true;
                $scope.TimelineInfo.ThankYouMessage = data.Text;
                $scope.TimelineInfo.ThankYouDate = data.ThankYouDate;

                $scope.TimelineInfo.ThankYouDate = utilityFactory.changeDateFormat($scope.TimelineInfo.ThankYouDate);

                $scope.thankYouSent = true;
                $scope.readMoreThankYou = false;
                if ($(window).width() < 768) {
                    if ($scope.TimelineInfo.ThankYouMessage.length > 50) {
                        $scope.readMoreThankYou = true;
                        $scope.reserveTextforReadThankYou = { "text": $scope.TimelineInfo.ThankYouMessage };
                        $scope.TimelineInfo.ThankYouMessage = $scope.TimelineInfo.ThankYouMessage.substring(0, 50);
                    }
                }
            }

            $scope.TimelineInfo.HeaderName = $scope.TimelineInfo.contributeeFirstName + " " + Resources.Timeline_ThankYou;

            $("#thankYouModal_label").text($scope.TimelineInfo.HeaderName);

            $scope.isThankyou = true;
            $("#thankYouModal").modal("show");
            //$scope.showThankYouModal = true;

            $('#thankYouModal').on('shown.bs.modal', function () {

                if ($scope.readMoreThankYou) {
                    if ($("#thankYouMsgTextIdnew").text().length > 0) {
                        $("#thankYouMsgTextIdnew").text($.trim($("#thankYouMsgTextIdnew").text()));
                    }
                    $("#thankYouMsgTextId").text($scope.TimelineInfo.ThankYouMessage.substring(0, 50));
                }
                else {
                    $("#thankYouMsgTextIdnew").text($.trim($scope.TimelineInfo.ThankYouMessage));
                }

            });
        }
        else {
            $scope.TimelineInfo = args.any.data;

            $scope.Charleft = 200;
            $("#charLeftCount").text($scope.Charleft);
            $scope.thankyouImageSelected = false;
            $scope.isThankyou = false;
            $scope.useDefault();

            $scope.TimelineInfo.ThankYouMessage = "";

            $scope.TimelineInfo.ThankYouDate = utilityFactory.changeDateFormat();

            $scope.thankYouSent = true;
            var item = args.any.data;
            if (args.any.alreadyThanked) {
                $scope.thankYouSent = args.any.alreadyThanked;
            }
            $scope.languageCulture = currentLanguage;
            $scope.setThankYouImage();

            setTimeout(function () {
                $scope.ThankYouInfo = {};
                $scope.ThankYouInfo.contributorFirstName = item.contributorFirstName;
                $scope.ThankYouInfo.contributorLastName = item.contributorLastName;

                $scope.ThankYouInfo.Todaydate = getDateInString(new Date(), DATE_FORMAT.DD_MONTH_YYYY, currentLanguage, SEPARATOR.SPACE);
                $("#thankyouDate").text($scope.ThankYouInfo.Todaydate);

                if (item.contributorImage != null)
                    $scope.ThankYouInfo.contributorImage = item.contributorImage;
                else
                    $scope.ThankYouInfo.contributorImage = images.defaultPersonImage;

                $scope.ThankYouInfo.contributorId = $scope.TimelineInfo.ContributorId;
                $scope.ThankYouInfo.childId = $scope.TimelineInfo.childId;
                $scope.ThankYouInfo.ContributionId = $scope.TimelineInfo.ContributionId;
                $scope.imagesrc = images.thankYouDefaultImage;
                $scope.ThankYouInfo.contributorId = $scope.TimelineInfo.ContributorId;
                $scope.ThankYouInfo.HeaderName = Resources.Header_ThankYou + ' ' + item.contributorFirstName + '!';
                $scope.ThankYouInfo.thankYouSent = false;
                $("#thankYouModal_label").text($scope.ThankYouInfo.HeaderName);
                $("#transactionDetailModal").modal('hide');
                $('#thankYouModal').modal('show');
                //$scope.showThankYouModal = true;
                $('#thankYouModal').on('shown.bs.modal', function () {
                    $('body').addClass('modal-open');
                    $('body').css('padding', '0');
                });
            }, 200);
        }
    });
    $scope.readMoreTextThankYou = function () {
        $scope.TimelineInfo.ThankYouMessage = $scope.reserveTextforReadThankYou.text;
        $('#thankYouMsgTextId').text($scope.TimelineInfo.ThankYouMessage);
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        $scope.readMoreThankYou = false;
    }

    $scope.SendThankYouMessage = function (ThankYouInfo) {
        var message = $scope.placeholder;
        var data = {};
        if (!isEmptyOrUndefinedOrNull($('#thankuImage .demoImg').attr('src'))) {
            $scope.thankuImage = $('#thankuImage .demoImg').attr('src').split(",")[1];
            data.Image = $scope.thankuImage;
        } else if (!isEmptyOrUndefinedOrNull($('#thankuImage #demoImg').attr('src'))) {
            $scope.thankuImage = $('#thankuImage #demoImg').attr('src').split(",")[1];
            data.Image = $scope.thankuImage;
        }

        if ($scope.thankYouMsg) {
            message = $scope.thankYouMsg;
        }

        data = {
            SenderId: $.cookie('personId'),
            ReceiverId: $scope.ThankYouInfo.contributorId,
            Text: message,
            ChildId: $scope.ThankYouInfo.childId,
            ContributionId: $scope.ThankYouInfo.ContributionId,
            SendDate: $scope.ThankYouInfo.Todaydate,
            ThankYouTitle: 'Thank You'
        };

        if ($scope.thankyouImageSelected != false) {
            data.Image = $scope.thankuImage;//.replace(images.dataImage, '');
        }

        HeaderServices.SendThankYou(data).then(
            function (data) {
                if (data.data === true) {
                    $scope.thankYouMsg = '';
                    $scope.imagesrc = images.thankYouDefaultImage;
                    $('#thankYouModal').modal('hide');
                    $rootScope.$broadcast('refresh-notification', {});
                    //$scope.getNotificationCount();
                } else {
                    $scope.thankYouMsg = '';
                    $scope.imagesrc = images.thankYouDefaultImage;
                    genericErrorMessageDisplay(Resources.ThankYouMessage_Failed);
                }
            },
            function (error) {
                $scope.thankYouMsg = '';
                $scope.imagesrc = images.thankYouDefaultImage;
                genericErrorMessageDisplay(Resources.ThankYouMessage_Failed);
            }
        );
    }

    $scope.CancelThankYou = function () {
        $scope.thankYouMsg = '';
        $scope.imagesrc = images.thankYouDefaultImage;
    }

    $scope.getNotificationCount = function () {
        if ($.cookie("personId") != null) {
            var res = HeaderServices.getHeaderCount();
            if (res != null) {
                res.then(function (data) {
                    $scope.basketCounter = data.BasketCount,
                    $scope.childCounter = data.ChildCount;
                   angular.element($("#notificationCnt").parent()).scope().notificationCount = data.NotificationCount;
                },
                function (error) {
                });
            }
        }
    }

    $scope.setThankYouImage = function () {
        if (currentLanguage == "fr") {
            $scope.imageSrc = images.thankYouImage_fr;
        }
        if (currentLanguage == "nl") {
            $scope.imageSrc = images.thankYouImage_nl;
        }
        else {
            $scope.imageSrc = images.thankYouImage_en;
        }
    }
}]);
$(document).ready(function () {
    function charLeftCalc(idInput, idSpan, event) {
        var fillUpLength = $(idInput).val().length;
        if (fillUpLength > 200 && event.which != 08 && event.which != 127) {
            event.preventDefault();
        }
        else {
            var charLeft = Number(200 - fillUpLength);
            $(idSpan).text(charLeft);
        }
    }

    $("#thankYouMsgBox").on("keydown keypress", function (e) {
        setTimeout(function () {
            charLeftCalc("#thankYouMsgBox", "#charLeftCount", e);

            if (e.which == 08 || e.which == 127) {
                charLeftCalc("#thankYouMsgBox", "#charLeftCount", e);
            }
        }, 50)
    });
    $("#thankYouMsgBox").bind("paste cut", function (e) {
        setTimeout(function (e) {
            charLeftCalc("#thankYouMsgBox", "#charLeftCount", e);
        }, 50);
    });
});