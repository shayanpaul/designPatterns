﻿myAppangular.controller("MessageController", ["$scope", "$rootScope", "WebApiService", "DisplaySupportersService", "timelineService", 'HeaderServices', function ($scope, $rootScope, WebApiService, DisplaySupportersService, timelineService, HeaderServices) {
    //var url = "/members";
    var language = $.cookie("language");
    $scope.refreshTimeline = false;
    $scope.isLoaded = false;
    $scope.BecomeSupporterInfo = [];
    $scope.childList = [];
    $scope.busy = false;
    $scope.serviceCalled = false;
    $scope.isTimelineVisible = false;
    $scope.timelineList = [];
    //Set the default parameter for pagination
    $scope.timelinePageNumber = defaultTimelinePageNumber;
    $scope.timelinePageSize = defaultTimelinePageSize;
    $scope.lastLoadedId = defaultTimelinePageNumber;
    $scope.serviceCalled = false;

    $scope.personId = $.cookie("personId");

    $scope.getNextTimelineList = function (fromWhereItIsCalled) {
        //alert('infinite');
        if ($scope.serviceCalled) {
            if (($scope.NewInfoList != undefined) && ($scope.NewInfoList.length <= 9)) return;
        }
        if ($scope.busy) return;
        if (!((fromWhereItIsCalled === 'timeline') && ($scope.isTimelineVisible || $scope.isTimelineVisible=='true'))) {
            return;
        }
        if (($scope.personId == undefined) || ($scope.personId == 'null')) {
            return;
        }
        var lastLoadedPage = $scope.timelinePageNumber;
        if (lastLoadedPage == undefined) {
            $scope.timelinePageNumber = 1;
            lastLoadedPage = 1;
        }
        $scope.busy = true;
        // $scope.timelinePageNumber = $scope.lastLoadedId;
        $scope.getTimelineList($scope.timelinePageNumber, defaultNotificationMaximumPageSize);
    }

    $rootScope.$on('refresh-timeline', function () {
        $scope.refreshTimeline = true;
        $scope.getTimelineListWhenRefresh(defaultTimelinePageNumber, defaultNotificationMaximumPageSize);
    });

    $scope.getTimelineListWhenRefresh = function (timelinePageNumber, timelinePageSize) {
        var onboardinState = false;
        
        if ($scope.personId != null) {
            var res = timelineService.getTimelineList(timelinePageNumber, timelinePageSize);
            $scope.serviceCalled = true;
            if (res != undefined) {
                res.then(function (d) {
                    var response = JSON.stringify(d.data);
                    var data = JSON.parse(response);
                    $scope.timelineList = [];
                    $scope.NewInfoList = [];
                    for (i = 0; i < data.length; i++) {
                        $scope.Info = {};
                        $scope.Info.Category = data[i].Category;
                        $scope.Info.CategoryIdentifier = data[i].CategoryIdentifier;
                        $scope.Info.CreationDate = data[i].CreationDate;
                        $scope.Info.NewCreationDate = new Date($scope.Info.CreationDate);
                        $scope.Info.CategoryIdentifier = data[i].CategoryIdentifier;
                        $scope.Info.Label = data[i].Label;
                        $scope.Info.MessageTemplateCode = data[i].MessageTemplateCode;
                        $scope.Info.NegativeButtonAction = data[i].NegativeButtonAction;
                        $scope.Info.PositiveButtonAction = data[i].PositiveButtonAction;
                        $scope.Info.ReceiverId = data[i].ReceiverId;
                        $scope.Info.SenderId = data[i].SenderId;
                        $scope.Info.Status = data[i].Status;
                        $scope.Info.TimeLineId = data[i].TimeLineId;
                        $scope.Info.TimelineTitle = data[i].TimelineTitle;
                        $scope.Info.ReadStatus = data[i].ReadStatus;

                        $scope.timelinePageNumber = 0;
                        Date.fromISO = (function () {
                            var testIso = '2011-11-24T09:00:27+0200';
                            // Chrome
                            var diso = Date.parse(testIso);
                            if (diso === 1322118027000) return function (s) {
                                return new Date(Date.parse(s));
                            }
                            // JS 1.8 gecko
                            var noOffset = function (s) {
                                var day = s.slice(0, -5).split(/\D/).map(function (itm) {
                                    return parseInt(itm, 10) || 0;
                                });
                                day[1] -= 1;
                                day = new Date(Date.UTC.apply(Date, day));
                                var offsetString = s.slice(-5)
                                var offset = parseInt(offsetString, 10) / 100;
                                if (offsetString.slice(0, 1) == "+") offset *= -1;
                                day.setHours(day.getHours() + offset);
                                return day.getTime();
                            }
                            if (noOffset(testIso) === 1322118027000) {
                                return noOffset;
                            }
                            return function (s) { // kennebec@SO + QTax@SO
                                var day, tz,
                        //        rx = /^(\d{4}\-\d\d\-\d\d([tT][\d:\.]*)?)([zZ]|([+\-])(\d{4}))?$/,
                                rx = /^(\d{4}\-\d\d\-\d\d([tT][\d:\.]*)?)([zZ]|([+\-])(\d\d):?(\d\d))?$/,

                                p = rx.exec(s) || [];
                                if (p[1]) {
                                    day = p[1].split(/\D/).map(function (itm) {
                                        return parseInt(itm, 10) || 0;
                                    });
                                    day[1] -= 1;
                                    day = new Date(Date.UTC.apply(Date, day));
                                    if (!day.getDate()) return NaN;
                                    if (p[5]) {
                                        tz = parseInt(p[5], 10) / 100 * 60;
                                        if (p[6]) tz += parseInt(p[6], 10);
                                        if (p[4] == "+") tz *= -1;
                                        if (tz) day.setUTCMinutes(day.getUTCMinutes() + tz);
                                    }
                                    return day;
                                }
                                return NaN;
                            }
                        })()

                        $scope.Info.NewCreationDate = new Date(moment.utc($scope.Info.CreationDate, 'YYYY-MM-DDTHH:mm:ss.zz').local());
                        //$scope.Info.NewCreationDate = new Date(Date.fromISO($scope.Info.CreationDate))


                        if (data[i].PersonImageUrl != null) {
                            $scope.Info.PersonImageUrl = data[i].PersonImageUrl;
                        } else {
                            $scope.Info.PersonImageUrl = images.defaultPersonImage;
                        }
                        $scope.NewInfoList.push($scope.Info);
                    }
                    $scope.isTimelineVisible = true;
                    onboardingID = 0;
                    for (i = 0; i < $scope.NewInfoList.length; i++) {
                        //$scope.transHisData.push($scope.transData[i]);
                        //if ($scope.refreshTimeline) {
                        //    $scope.timelineList.unshift($scope.NewInfoList[i]);
                        //}
                        //else {
                        $scope.timelineList.push($scope.NewInfoList[i]);
                        //}
                        if (!$scope.NewInfoList[i].ReadStatus) {
                            if ($scope.NewInfoList[i].Category === category.SubscriptionOnboarding) {
                                $scope.initialiseLibrary(0);
                                // if($scope.NewInfoList[i].ReadStatus!=true)
                                onboardinState = true;
                                onboardingID = $scope.NewInfoList[i].TimeLineId;
                                HeaderServices.markTimelineRead(onboardingID);
                                $scope.NewInfoList[i].ReadStatus = true;

                            } else if ($scope.NewInfoList[i].Category === category.RegistraionOnboarding) {
                                $scope.initialiseLibrary(1);
                                if (!onboardinState) {
                                    onboardinState = true;
                                    onboardingID = $scope.NewInfoList[i].TimeLineId;
                                    HeaderServices.markTimelineRead(onboardingID);
                                    $scope.NewInfoList[i].ReadStatus = true;
                                }

                            }
                        }
                    }
                    if (onboardinState && !(localStorage.getItem(isChild) === boolFlag.trueValue)) {
                        $("#userOnBoardingModal").modal('show');
                        HeaderServices.markTimelineRead(onboardingID);
                        dataLayer.push({
                            'event': 'VirtualPageview',
                            'virtualPageURL': '/en/Home/Account-created',
                            'content category': 'UserRegistration'
                        });
                    }
                    $scope.isLoaded = true;
                    $scope.timelinePageNumber += 1;
                    $scope.busy = false;
                    if ($scope.refreshTimeline) {
                        $rootScope.$broadcast('myCustomEvent', {
                            someProp: 'Sending you an Object!' // send whatever you want
                        });
                        $scope.refreshTimeline = false;
                    }
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                },
              function (error) {
              });
            }
        }
    }
    
    $scope.getTimelineList = function (timelinePageNumber, timelinePageSize) {
        var onboardinState = false;
        if ($scope.personId != null) {
            var res = timelineService.getTimelineList(timelinePageNumber, timelinePageSize);
            $scope.serviceCalled = true;
            if (res != undefined) {
                res.then(function (d) {
                    var response = JSON.stringify(d.data);
                    var data = JSON.parse(response);
                    //$scope.timelineList = [];
                    $scope.NewInfoList = [];
                    for (i = 0; i < data.length; i++) {
                        $scope.Info = {};
                        $scope.Info.Category = data[i].Category;
                        $scope.Info.CategoryIdentifier = data[i].CategoryIdentifier;
                        $scope.Info.CreationDate = data[i].CreationDate;
                        //$scope.Info.NewCreationDate = new Date($scope.Info.CreationDate);
                        $scope.Info.CategoryIdentifier = data[i].CategoryIdentifier;
                        $scope.Info.Label = data[i].Label;
                        $scope.Info.MessageTemplateCode = data[i].MessageTemplateCode;
                        $scope.Info.NegativeButtonAction = data[i].NegativeButtonAction;
                        $scope.Info.PositiveButtonAction = data[i].PositiveButtonAction;
                        $scope.Info.ReceiverId = data[i].ReceiverId;
                        $scope.Info.SenderId = data[i].SenderId;
                        $scope.Info.Status = data[i].Status;
                        $scope.Info.TimeLineId = data[i].TimeLineId;
                        $scope.Info.TimelineTitle = data[i].TimelineTitle;
                        $scope.Info.ReadStatus = data[i].ReadStatus;

                        Date.fromISO = (function () {
                            var testIso = '2011-11-24T09:00:27+0200';
                            // Chrome
                            var diso = Date.parse(testIso);
                            if (diso === 1322118027000) return function (s) {
                                return new Date(Date.parse(s));
                            }
                            // JS 1.8 gecko
                            var noOffset = function (s) {
                                var day = s.slice(0, -5).split(/\D/).map(function (itm) {
                                    return parseInt(itm, 10) || 0;
                                });
                                day[1] -= 1;
                                day = new Date(Date.UTC.apply(Date, day));
                                var offsetString = s.slice(-5)
                                var offset = parseInt(offsetString, 10) / 100;
                                if (offsetString.slice(0, 1) == "+") offset *= -1;
                                day.setHours(day.getHours() + offset);
                                return day.getTime();
                            }
                            if (noOffset(testIso) === 1322118027000) {
                                return noOffset;
                            }
                            return function (s) { // kennebec@SO + QTax@SO
                                var day, tz,
                        //        rx = /^(\d{4}\-\d\d\-\d\d([tT][\d:\.]*)?)([zZ]|([+\-])(\d{4}))?$/,
                                rx = /^(\d{4}\-\d\d\-\d\d([tT][\d:\.]*)?)([zZ]|([+\-])(\d\d):?(\d\d))?$/,

                                p = rx.exec(s) || [];
                                if (p[1]) {
                                    day = p[1].split(/\D/).map(function (itm) {
                                        return parseInt(itm, 10) || 0;
                                    });
                                    day[1] -= 1;
                                    day = new Date(Date.UTC.apply(Date, day));
                                    if (!day.getDate()) return NaN;
                                    if (p[5]) {
                                        tz = parseInt(p[5], 10) / 100 * 60;
                                        if (p[6]) tz += parseInt(p[6], 10);
                                        if (p[4] == "+") tz *= -1;
                                        if (tz) day.setUTCMinutes(day.getUTCMinutes() + tz);
                                    }
                                    return day;
                                }
                                return NaN;
                            }
                        })()

                        $scope.Info.NewCreationDate= new Date(moment.utc($scope.Info.CreationDate, 'YYYY-MM-DDTHH:mm:ss.zz').local());
                        //$scope.Info.NewCreationDate = new Date(Date.fromISO($scope.Info.CreationDate))





                        if (data[i].PersonImageUrl != null) {
                            $scope.Info.PersonImageUrl = data[i].PersonImageUrl;
                        } else {
                            $scope.Info.PersonImageUrl = images.defaultPersonImage;
                        }
                        $scope.NewInfoList.push($scope.Info);
                    }
                    $scope.isTimelineVisible = true;
                    onboardingID = 0;
                    for (i = 0; i < $scope.NewInfoList.length; i++) {
                        //$scope.transHisData.push($scope.transData[i]);
                        $scope.timelineList.push($scope.NewInfoList[i]);
                        if (!$scope.NewInfoList[i].ReadStatus) {
                            if ($scope.NewInfoList[i].Category === category.SubscriptionOnboarding) {
                                $scope.initialiseLibrary(0);
                                // if($scope.NewInfoList[i].ReadStatus!=true)
                                onboardinState = true;
                                onboardingID = $scope.NewInfoList[i].TimeLineId;
                                HeaderServices.markTimelineRead(onboardingID);
                                $scope.NewInfoList[i].ReadStatus = true;

                            } else if ($scope.NewInfoList[i].Category === category.RegistraionOnboarding) {
                                $scope.initialiseLibrary(1);
                                if (!onboardinState) {
                                    onboardinState = true;
                                    onboardingID = $scope.NewInfoList[i].TimeLineId;
                                    HeaderServices.markTimelineRead(onboardingID);
                                    $scope.NewInfoList[i].ReadStatus = true;
                                }

                            }
                        }
                    }
                    if (onboardinState && !(localStorage.getItem(isChild) === boolFlag.trueValue)) {
                        $("#userOnBoardingModal").modal('show');
                        HeaderServices.markTimelineRead(onboardingID);
                        dataLayer.push({
                            'event': 'VirtualPageview',
                            'virtualPageURL': '/en/Home/Account-created',
                            'content category': 'UserRegistration',
                            'Own children': '0',
                            'Children supported': '0'

                        });
                    }
                    $scope.isLoaded = true;
                    $scope.timelinePageNumber += 1;
                    $scope.busy = false;
                },
              function (error) {
              });
            }
        }
    }

    $scope.init = function () {
        $scope.getTimelineList(defaultTimelinePageNumber, defaultNotificationMaximumPageSize);
    }

    $scope.init();
}]);

