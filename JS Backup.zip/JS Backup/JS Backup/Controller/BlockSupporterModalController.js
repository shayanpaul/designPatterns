﻿myAppangular.controller("blockSupporter", ["$scope", "$rootScope", "WebApiService", function ($scope, $rootScope, WebApiService) {

   
}]);