﻿/*global $, jQuery, alert, window*/
/*jslint browser: true*/
myAppangular.controller("SupportersController", ["$scope", "$rootScope", "WebApiService", "DisplaySupportersService", "ChildProfileService", "allSupporterData", "$window", "ModalFactory", function ($scope, $rootScope, WebApiService, DisplaySupportersService, ChildProfileService, allSupporterData, $window, ModalFactory) {
    $('#blockSupporter').on('shown.bs.modal', function () {
        //$(".thankyou-greeting-text").text($.trim($(".thankyou-greeting-text").text()));
        unfreezeBackground();
    });
    $(".navigation-menu > li").removeClass("active");
    angular.element(".all-supporter").addClass("active");
    var supporterData = "";
    $scope.nameRegexp = newnameRegex;
    $scope.emailRegexp = emailRegex;
    $scope.getAllSupporterDetailsByParent = function () {
        var url = "/members/" + $.cookie("personId") + "/supporters";
        $scope.parentId = $.cookie("personId");
        var language = $.cookie("language");
        $scope.languageid = $.cookie("language");
        $scope.supporterChildIds = [];
        $scope.relationship = [];
        $scope.relationshipcount = [];
        $scope.childListSelect = [];
        $scope.languageCulture = $.cookie("language");
        $scope.initSupporter = function () {
            $scope.$on("SUPPORTERDATAUPDATED", function () {
                var filterObject = ModalFactory.getData();
                $scope.filterDataObject = filterObject.filterDataObj;
                $scope.filterRequestObj = filterObject.requestObj;
                $scope.getTransactionsWithFilterCriteria();
            });
            $scope.lastLoadedId = 1;
            $scope.transHisData = [];
            $scope.isSupporterHistoryVisible = false;
            $scope.isTransactionHistoryVisible = false;
            $scope.isChildSupporterListToBeshown = false;
        }
        var allSupporterInfo = allSupporterData.getData('Dataname');
        if ($.isEmptyObject(allSupporterInfo)) {
            if ($.cookie("personId") != null && $.cookie("personId") != undefined) {
                WebApiService.getWebApiData(url, language).then(function (d) {
                    var response = JSON.stringify(d.data);
                    var data = JSON.parse(response);
                    supporterData = data;
                    allSupporterData.setData('Dataname', { 'supporterArr': supporterData });
                    $scope.ActiveSupporterInfo = [];
                    $scope.WaitForApprovalSupporterInfo = [];
                    $scope.PendingSupporterInfo = [];
                    $scope.BlockedSupporterInfo = [];
                    if (data.length > 0) {
                        var iterationId = 0;
                        $.each(data, function (index) {
                            var activeSupporterCount = 0;
                            var blockSupporterCount = 0;
                            var pendingSupporterCount = 0;
                            $scope.ChildrenSupportedInfo = [];
                            $scope.Info = {};
                            $scope.Info.cultureCode = $.cookie("language");
                            $scope.Info.firstName = data[index].PersonFirstName;
                            $scope.Info.lastName = data[index].PersonLastName;
                            if (data[index].PersonNickName) {
                                $scope.Info.nickName = data[index].PersonNickName;
                            } else {
                                $scope.Info.nickName = data[index].PersonFirstName;
                            }
                            $scope.Info.email = data[index].PersonEmail;
                            $scope.Info.roleValue = data[index].SupporterRoleValue;
                            $scope.Info.roleText = data[index].SupporterRoleText;
                            if (data[index].PictureUrl != null) {
                                $scope.Info.image = data[index].PictureUrl;
                            } else {
                                $scope.Info.image = images.defaultPersonImage;
                            }
                            $scope.Info.parentId = $.cookie("personId");
                            $scope.Info.supporterId = data[index].PersonId;
                            $scope.Info.UniqueId = iterationId;
                            //change
                            $.each(data[index].SupportedChildren, function (suppchildindex) {
                                //var activeSupporterCount = 0;
                                //var blockSupporterCount = 0;
                                //var pendingSupporterCount = 0;

                                if (data[index].SupportedChildren[suppchildindex].Status == Status.Active && data[index].SupportedChildren[suppchildindex].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                                    if (data[index].SupportedChildren[suppchildindex].PersonImageUrl == null) {
                                        data[index].SupportedChildren[suppchildindex].PersonImage = images.defaultPersonImage;
                                    } else {
                                        data[index].SupportedChildren[suppchildindex].PersonImage = data[index].SupportedChildren[suppchildindex].PersonImageUrl;
                                    }

                                    $scope.Info.childInfo = data[index].SupportedChildren;
                                    $("#divActive").css("display", "block");
                                    if (activeSupporterCount == 0) {
                                        $scope.ActiveSupporterInfo.push($scope.Info);
                                    }
                                    activeSupporterCount++;
                                }

                                if (data[index].SupportedChildren[suppchildindex].Status == Status.Active && data[index].SupportedChildren[suppchildindex].RoleParticularityCode == RoleParticularityCode.Blocked) {
                                    $("#divBlocked").css("display", "block");
                                    if (blockSupporterCount == 0) {
                                    $scope.BlockedSupporterInfo.push($scope.Info);
                                }
                                    blockSupporterCount++;
                                }
                                if (data[index].SupportedChildren[suppchildindex].Status == Status.Pending && data[index].SupportedChildren[suppchildindex].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                                    $("#divPending").css("display", "block");
                                    if (pendingSupporterCount == 0) {
                                    $scope.PendingSupporterInfo.push($scope.Info);
                                }
                                    pendingSupporterCount++;
                                }
                                if (data[index].SupportedChildren[suppchildindex].Status == Status.Draft && data[index].SupportedChildren[suppchildindex].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                                    $("#divWait").css("display", "block");
                                    $scope.WaitForApprovalSupporterInfo.push($scope.Info);
                                }
                            });
                            
                            iterationId++;
                        });
                    }
                }, function (error) {
                    //alert(supporterInfoError);
                });
            }
        }
        else {
            data = allSupporterData.getData('Dataname')["supporterArr"];
            supporterData = data;
            $scope.ActiveSupporterInfo = [];
            $scope.WaitForApprovalSupporterInfo = [];
            $scope.PendingSupporterInfo = [];
            $scope.BlockedSupporterInfo = [];
            if (data.length > 0) {
                var iterationId = 0;
                $.each(data, function (index) {
                    var activeSupporterCount = 0;
                    var blockSupporterCount = 0;
                    var pendingSupporterCount = 0;
                    $scope.ChildrenSupportedInfo = [];
                    $scope.Info = {};
                    $scope.Info.cultureCode = $.cookie("language");
                    $scope.Info.firstName = data[index].PersonFirstName;
                    $scope.Info.lastName = data[index].PersonLastName;
                    if (data[index].PersonNickName) {
                        $scope.Info.nickName = data[index].PersonNickName;
                    } else {
                        $scope.Info.nickName = data[index].PersonFirstName;
                    }
                    $scope.Info.email = data[index].PersonEmail;
                    $scope.Info.roleValue = data[index].SupporterRoleValue;
                    $scope.Info.roleText = data[index].SupporterRoleText;
                    if (data[index].PictureUrl != null) {
                        $scope.Info.image = data[index].PictureUrl;
                    } else {
                        $scope.Info.image = images.defaultPersonImage;
                    }
                    $scope.Info.parentId = $.cookie("personId");
                    $scope.Info.supporterId = data[index].PersonId;
                    $scope.Info.UniqueId = iterationId;
                    //change
                    $.each(data[index].SupportedChildren, function (suppchildindex) {
                        // Reseting Loop Every time 
                        //var activeSupporterCount = 0;
                        //var blockSupporterCount = 0;
                        //var pendingSupporterCount = 0;

                        if (data[index].SupportedChildren[suppchildindex].Status == Status.Active && data[index].SupportedChildren[suppchildindex].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                            //PersonImageUrl
                            if (data[index].SupportedChildren[suppchildindex].PersonImageUrl == null) {
                                data[index].SupportedChildren[suppchildindex].PersonImage = images.defaultPersonImage;
                            } else {
                                data[index].SupportedChildren[suppchildindex].PersonImage = data[index].SupportedChildren[suppchildindex].PersonImageUrl;
                            }

                            $scope.Info.childInfo = data[index].SupportedChildren;
                            $("#divActive").css("display", "block");
                            if (activeSupporterCount == 0) {
                            $scope.ActiveSupporterInfo.push($scope.Info);
                        }
                            activeSupporterCount++;
                            }

                        if (data[index].SupportedChildren[suppchildindex].Status == Status.Active && data[index].SupportedChildren[suppchildindex].RoleParticularityCode == RoleParticularityCode.Blocked) {
                            $("#divBlocked").css("display", "block");
                            if (blockSupporterCount == 0) {
                            $scope.BlockedSupporterInfo.push($scope.Info);
                        }
                            blockSupporterCount++;
                        }
                        if (data[index].SupportedChildren[suppchildindex].Status == Status.Pending && data[index].SupportedChildren[suppchildindex].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                            $("#divPending").css("display", "block");
                            if (pendingSupporterCount == 0) {
                            $scope.PendingSupporterInfo.push($scope.Info);
                        }
                            pendingSupporterCount++;
                        }
                        if (data[index].SupportedChildren[suppchildindex].Status == Status.Draft && data[index].SupportedChildren[suppchildindex].RoleParticularityCode == RoleParticularityCode.NotApplicable) {
                            $("#divWait").css("display", "block");
                            $scope.WaitForApprovalSupporterInfo.push($scope.Info);
                        }
                    });
                    iterationId++;
                });
            }
        }
    }
    $scope.showChildSupporter = function (supporterInfo) {
        $("#supporterDetailsPage").hide();
        $("#supporterDetailsHistory").show();
        $("#inviteASupporter .nav-parental").show();
        $scope.supporterSelected = true;
        $scope.selectedSupporter = supporterInfo;
        $scope.selectedSupporter.previousFirstName = $scope.selectedSupporter.firstName;
        $scope.selectedSupporter.previousLastName = $scope.selectedSupporter.lastName;
        $scope.selectedSupporter.previousNickName = $scope.selectedSupporter.nickName;
        $scope.selectedSupporter.previousEmail = $scope.selectedSupporter.email;
        for (var i = 0; i < $scope.selectedSupporter.childInfo.length; i++) {
            $scope.supporterChildIds.push($scope.selectedSupporter.childInfo[i].PersonId)
        }
        $scope.getTransactionSupporterHistory(supporterInfo.supporterId);
    }

    $scope.showchildsupporterinfo = function (childSupporterInfo) {
        $("#supporter-details-pageForChild").hide();
        $("#supporter-details-historyForChild").show();
    }

    $scope.allSupportersLink = function () {
        allSupporterData.setData('Dataname', {});
        $scope.getAllSupporterDetailsByParent();
        $("#supporterDetailsPage").css("display", "block");
        $("#supporterDetailsHistory").css("display", "none");
        $("#blockImage").hide();
        $("#blockImageMobile").hide();
        $("#blockBtn").show();
        $("#unblockBtnMobile").hide();
        $("#blockBtnMobile").show();
        $("#unblockBtn").hide();
        $("#inviteASupporter .nav-parental").hide();
        //$rootScope.$broadcast('resetInviteSupporterForm');
        $scope.selectedSupporter = null;
    }

    $scope.supporterLoadItems = function (fromWhereItIsCalled) {
        if ($scope.busy) return;
        if (!((fromWhereItIsCalled === 'supporter') && $scope.isSupporterHistoryVisible)) {
            return;
        }
        if ($scope.serviceCalled) {
            if (($scope.transData != undefined) && ($scope.transData.length <= 9)) return;
        }
        if (($scope.selectedSupporter == undefined) || ($scope.selectedSupporter == 'null')) {
            return;
        }
        var supporterId = $scope.selectedSupporter.supporterId;
        var lastLoadedPage = $scope.lastLoadedId;
        if (lastLoadedPage == undefined) {
            $scope.lastLoadedId = 1;
            lastLoadedPage = 1;
        }
        $scope.busy = true;
        if ($scope.isFilter) {
            var webApiurl = "/contribution/allcontributiondetail/";
            // var webApiResponse = WebApiService.getWebApiData1(webApiurl, "", responseobject);
            $scope.filterRequestObj.PageNumber = $scope.lastLoadedId;
            WebApiService.getWebApiData1(webApiurl, "", $scope.filterRequestObj).success(function (data, status) {
                $scope.serviceCalled = true;
                if ((data != 'null') && (data != undefined)) {
                    if (data.length > 0) {
                        $scope.transData = data;
                        for (i = 0; i < $scope.transData.length; i++) {
                            if ($scope.transData[i].ContributorAvatarUri != null) {
                                $scope.transData[i].ContributorAvatar = $scope.transData[i].ContributorAvatarUri;
                                } 
                            //else {
                            //    $scope.transData[i].ContributorAvatar = images.defaultPersonImage;
                            //}
                        }
                        $.each($scope.transData, function () {
                            var contributionDate = this.ContributionFormattedDate.split(" ");
                            var day = contributionDate[0];
                            var month = contributionDate[1].slice(0, 3);
                            var year = contributionDate[2];
                            this.ContributionFormattedDate = day + " " + month + " " + year;
                        });
                        for (i = 0; i < $scope.transData.length; i++) {
                            $scope.transHisData.push($scope.transData[i]);
                        }
                        lastLoadedPage = lastLoadedPage + 1;
                        $scope.lastLoadedId = lastLoadedPage;
                    }
                }
                $scope.busy = false;
            }).error(function (dataRes, status) {
                $scope.busy = false;
                //alert('error');
            });
        } else {
            WebApiService.GetSupporterTransactionHistory(supporterId, lastLoadedPage).success(function (data, status) {
                if ((data != 'null') && (data != undefined)) {
                    if (data.length > 0) {
                        $scope.serviceCalled = true;
                        $scope.transData = data;
                        for (i = 0; i < $scope.transData.length; i++) {
                            if ($scope.transData[i].ContributorAvatarUri) {
                                $scope.transData[i].ContributorAvatar = $scope.transData[i].ContributorAvatarUri;
                            }
                            //else {
                            //    $scope.transData[i].ContributorAvatar = images.defaultPersonImage;
                            //}
                        }
                        $.each($scope.transData, function () {
                            var contributionDate = this.ContributionFormattedDate.split(" ");
                            var day = contributionDate[0];
                            var month = contributionDate[1].slice(0, 3);
                            var year = contributionDate[2];
                            this.ContributionFormattedDate = day + " " + month + " " + year;
                        });
                        for (i = 0; i < $scope.transData.length; i++) {
                            $scope.transHisData.push($scope.transData[i]);
                        }
                        $scope.lastLoadedId = lastLoadedPage + 1;
                    }
                }

                $scope.busy = false;
            }).error(function (dataRes, status) {
                $scope.busy = false;
            });
        }
    }
    $scope.getTransactionsWithFilterCriteria = function () {
        $scope.transHisData = [];
        $scope.serviceCalled = false;
        if ($scope.filterDataObject.filterBooleanShowAmount || $scope.filterDataObject.filterBooleanShowDate || $scope.filterDataObject.filterBooleanShowPlan || $scope.filterDataObject.filterBooleanShowSupporter || $scope.filterDataObject.filterBooleanShowTransaction) {
            $scope.isFilter = true;
            $scope.lastLoadedId = 1;
        } else {
            $scope.isFilter = false;
            $scope.lastLoadedId = 1;
        }
        $scope.isSupporterHistoryVisible = true;
        $scope.isTransactionHistoryVisible = false;
        $scope.isChildSupporterListToBeshown = false;
        $scope.supporterLoadItems('supporter');
    }
    $scope.getTransactionSupporterHistory = function (supporterId) {
        $scope.transHisData = [];
        $scope.serviceCalled = false;
        $scope.isFilter = false;
        $scope.lastLoadedId = 1;
        $scope.busy = false;
        $scope.isSupporterHistoryVisible = true;
        $scope.isTransactionHistoryVisible = false;
        $scope.isChildSupporterListToBeshown = false;
        $scope.supporterLoadItems('supporter');
    }

    $rootScope.$on('getAllSupporterbyParent', function () {
        //allSupporterData.setData('Dataname', {});
        if ($scope.loginAsChildEntry) {
            $.cookie("childId", $.cookie("personId"), { path: "/" });
            //$.cookie("childId") = $.cookie("personId");
        }
        allSupporterData.setData('Dataname', {});
        $scope.getAllSupporterDetailsByParent();
    });

    $scope.showChildSupporterUnblock = function (supporterInfo) {
        $scope.selectedSupporterUnblock = supporterInfo;
        $("#unblockSupporterAll").modal("show");
        unfreezeBackground();
    }
    $scope.cancelModal = function (modalID) {
        $("#" + modalID).modal("hide");
    }
    $scope.responseBlock = false;
    $scope.responseUnBlock = true;
    $scope.unblockSupporter = function (supporterItem) {
         var personId = $.cookie("personId");
        WebApiService.GetBlockedSupporterStatus(personId, supporterItem.supporterId, $scope.responseUnBlock).success(function (data, status) {
            $scope.responseUnBlock = JSON.stringify(data);
            if ($scope.responseUnBlock == "true") {
                $("#unblockBtnAll" + supporterItem.supporterId).css("display", "none");
                $("#blockBtnAll" + supporterItem.supporterId).css("display", "block");
                $("#blockImageSupporters" + supporterItem.supporterId).hide();
                $("#blockImage").hide();
                $("#blockImageMobile").hide();
                $("#blockBtn").show();
                $("#unblockBtnMobile").hide();
                $("#blockBtnMobile").show();
                $("#unblockBtn").hide();
                $("#childrenSupported").show();
                $("#unblockSupporter").modal("hide");
                allSupporterData.setData('Dataname', {});
                $scope.getAllSupporterDetailsByParent();
                $scope.supporterSelected = false;
                $scope.showBlockSupporterImage = false;
            }
            //else if ($scope.responseUnBlock == "true") {
            //    $("#unblockBtnAll" + supporterItem.supporterId).css("display", "block");
            //    $("#blockBtnAll" + supporterItem.supporterId).css("display", "none");
            //    $("#blockImageSupporters" + supporterItem.supporterId).show();   
            //}
            //$("#unblockSupporter").modal("hide");
            $("#blockSupporterAll").modal("hide");
            $("#unblockSupporterAll").modal("hide");
        });
    }
    $scope.blockSupporter = function (selectedSupporter) {
        var personId = $.cookie("personId");
        WebApiService.GetBlockedSupporterStatus(personId, selectedSupporter.supporterId, $scope.responseBlock).success(function (data, status) {
            $scope.responseBlock = JSON.stringify(data);
            if ($scope.responseBlock == "false") {
                $("#blockImage").show();
                $("#blockImageMobile").show();
                $("#unblockBtn").show();
                $("#blockBtn").hide();
                $("#unblockBtnMobile").show();
                $("#blockBtnMobile").hide();
                $("#childrenSupported").hide();
                $("#blockSupporter").modal("hide");
                $scope.showBlockSupporterImage = true;/*for block supporter image black and white*/
            } else if ($scope.responseBlock == "true") {
                $("#blockImage").hide();
                $("#blockImageMobile").hide();
                $("#blockBtn").show();
                $("#unblockBtnMobile").hide();
                $("#blockBtnMobile").show();
                $("#unblockBtn").hide();
                $("#childrenSupported").show();
                $("#unblockSupporter").modal("hide");
                $scope.showBlockSupporterImage = false;
            }
            $("#pageLoader").removeClass('show');
        }).error(function (data, status) {
            $("#blockSupporter").modal("hide");
            if ($scope.responseBlock == false) {
                genericErrorMessageDisplay(Resources.BlockSupporter_Failed);
            }
            if ($scope.responseBlock == true) {
                genericErrorMessageDisplay(Resources.UnblockSupporter_Failed);
            }
        });
    }

    //Invite Supporter code starts here US 321
    $scope.inviteSupporter = function () {
        var childGroupInfo = $scope.childGroupInfo;
        var selectedSupporter = $scope.selectedSupporter;
        $rootScope.$broadcast('inviteSupporterStart', { any: { "selectedSupporter": selectedSupporter, "childGroupInfo": childGroupInfo, "supporterData": supporterData, "personEmail": $rootScope.PersonEmail, "fromTimeLine": false } });
    }
    //$rootScope.$on('getAllSupporterbyParent', function () {
    //    allSupporterData.setData('Dataname', {});
    //    angular.element("#inviteASupporter").scope().getAllSupporterDetailsByParent();

    //    });

    $scope.isNullOrEmptyOrUndefined = function (value) {
        if (value === "" || value === null || typeof value === "undefined") {
            return true;
        }
    }

    function init() {
        $scope.getAllSupporterDetailsByParent();
    };
    init();

    //Invite Supporter code ends here US 321
    $scope.changeFiltersSupporter = function (data) {
        $scope.filterDataObject.removeFromFilterData = data;
        ModalFactory.setchangefilterData($scope.filterDataObject);
        $rootScope.$broadcast("FilterUPDATED");
    };
}]);

myAppangular.filter("contains", function () {
    return function (array, needle) { };
});