﻿/*global $, jQuery, alert, window*/
/*jslint browser: true*/
//var childPage = angular.module("childPage", []);


myAppangular.controller("ChildController", ["$scope", "$state", "WebApiService", "$rootScope", "savingSchoolService", function ($scope, $state, WebApiService, $rootScope, savingSchoolService) {
    var url = "/members/" + $.cookie("personId") + "/children";
    $scope.parentId = $.cookie("personId");
    var language = $.cookie("language");
    $scope.showMyChildButton = false;
   
    parentID = $scope.parentId;
    $scope.linkUrl = "/" + currentLanguage + "/Subscription/" + $scope.parentId;
    var res = WebApiService.getWebApiData(url, language);
    if (res != undefined) {
        res.then(function (d) {
            var response = JSON.stringify(d.data);
            var data = JSON.parse(response);
            $rootScope.totalChildCount = d.data.length;
            $scope.GroupInfo = [];
            $scope.$on("localstorageset", function (event, args) {
                if (localStorage.getItem(isChild) === boolFlag.trueValue) {
                    if (Number(localStorage.getItem(personRole)) == roles.child) {
                        $scope.ShowNameAndPicture = false;
                        $scope.showMyChildren = false;
                        $scope.timelineClass = timelineClass.withNoChild;
                    } else {
                        $scope.ShowNameAndPicture = true;
                        if (localStorage.getItem(isInfantSupporter) === boolFlag.trueValue) {
                            $scope.showMyChildren = false;
                        } else {
                            $scope.showMyChildren = true;
                        }
                        $scope.timelineClass = timelineClass.withChild;
                    }
                }
            });

            dataLayer = [{
                'Own children': $rootScope.totalChildCount
            }];

            //end

            $scope.setChildFlag = function (isChildExists, childId, linkUrl) {
                $scope.isChildExists = isChildExists;
                localStorage.setItem("MandateId", "");
                if (isChildExists) {
                    localStorage.setItem("isChildExists", isChildExists);
                } else {
                    localStorage.setItem("isChildExists", isChildExists);
                    linkUrl = "/" + currentLanguage + "/Subscription/start";
                    location.href = linkUrl;
                }
            };

            if (data.length > 0) {
                $scope.showMyChildButton = false;
                $("a[id^='addChildren']").show();
            } else {
                $scope.showMyChildButton = true;
                $("a[id^='addChildren']").hide();
            }
            
            $.each(data, function (index) {
                $scope.Info = {};
                $scope.Info.childFirstName = data[index].PersonFirstName;
                $scope.Info.childLastName = data[index].PersonLastName;
                $scope.Info.childNickName = data[index].PersonNickName;
                $scope.Info.DateOfBirth = data[index].DateOfBirth;
                if (data[index].PersonImageUrl !== null) {
                    $scope.Info.image = data[index].PersonImageUrl;
                    $scope.Info.imageIn = true;
                }
                $scope.Info.parentId = $.cookie("personId");
                $scope.Info.childId = data[index].PersonId;
                $scope.Info.cultureCode = $.cookie("language");
                //Change US6747
                $scope.Info.isPending = data[index].IsPending;
                if (data[index].IsPending == true) {
                    $scope.Info.lastStepSavedCode = data[index].LastStepSavedAtCode;
                    $scope.Info.stepsLeft = 5 - (data[index].LastStepSavedAtCode + 1);
                    
                }
                $scope.Info.isPersonLongTermActive = data[index].IsPersonLongTermActive;
                $scope.Info.isPersonShortTermActive = data[index].IsPersonShortTermActive;
                $scope.GroupInfo.push($scope.Info);
            });

        },
            function (error) {
            });
    }
    $scope.childNaviagtion = function (item, customEvent) {
        if (item.isPending) {
            if (!item.isPersonLongTermActive && !item.isPersonShortTermActive) {
                location.href = "/" + currentLanguage + "/Subscription/start?pageName=childDetails" + "&childId=" + item.childId;
            }
            else {
                $('#pendingSubscriptionModal').modal('show');
                $rootScope.$broadcast("pendingChildSelected", { any: { childData: item, customEvent: customEvent } });
            }
        }
        else {
            savingSchoolService.setSavingSchoolData("");
            $state.go("child.detail.plan", {
                childId: item.childId,
                childEntry: false
            });
        }
    };
    $scope.checkchildrenSubscriptionStatus = function () {
        if (!$("#pendingSubscriptionModalWhom .pending-child-block").length) {
            location.href = "/" + currentLanguage + "/Subscription/start";
        } else {
            $("#pendingSubscriptionModalWhom").modal('show');
        }
    }
  
}]);
