﻿/*global $, jQuery, alert, window*/
/*jslint browser: true*/
/*jslint white:true, for:true */

myAppangular.controller("paymentFreeSupporterController", ["$scope", "$filter", "$state", "$stateParams", "$window", "FormSubmitter", "AnonymousUserService", "$rootScope", function ($scope, $filter, $state, $stateParams, $window, FormSubmitter, AnonymousUserService, $rootScope) {
    var entrypoint = $.cookie("entryPoint");
    var invitation = $.cookie("invitationGuid");
    $scope.paymentDetail = {};
    $scope.showCreaeAccount = false;
    $scope.showMessage = false;
    $scope.childFirstName = '';
    $scope.amount = '';
    AnonymousUserService.AnonymousPaymentOneShot(entrypoint, invitation).then(
        function (data) {
            $scope.paymentDetail = data;
            $scope.childFirstName = data.ChildFirstName;
            $scope.childLastName = data.ChildLastName;
            $scope.amount = data.MaxContributionValue;
            if (data.ChildImageUrl != null) {
                $scope.childImage = data.ChildImageUrl;
            }
            else {
                $scope.childImage = images.defaultPersonImage;
            }
            $scope.hideLongTerm = data.IsShortTermPreBirth;
            if (!isEmptyOrUndefinedOrNull(data.LongTermPlanView)) {
                $scope.maxValueLT = data.LongTermPlanView.MaxValue;
                $scope.minValueLT = data.LongTermPlanView.MinValue;
            }
            else {
                $scope.hideLongTerm = true;
            }

            if (!isEmptyOrUndefinedOrNull(data.ShortTermPlanView)) {
                $scope.maxValueST = data.ShortTermPlanView.MaxValue;
                $scope.minValueST = data.ShortTermPlanView.MinValue;
            }
            else {
                $scope.hideShortTerm = true;
            }
        },
        function (error) {
        }
    );

    $scope.singInPage = function () {
        $window.location.href = '/';
    }

    $scope.freeSupporterOneShotPayment = function () {
        if (!$('#contributeForm').valid()) {
            $('#contributeForm').valid();
            return;
        }
        $scope.freeContribution = {};
        $scope.LongTermPlanView = {};
        $scope.ShortTermPlanView = {};
        $scope.Entrypoint;
        $scope.InvitationCode;
        $scope.PaymentReferenceId;

        $scope.freeContribution.Message = $scope.userMessage;

        if (!isEmptyOrUndefinedOrNull($scope.longTermAmount)) {
            $scope.freeContribution.LongTermPlanView = {};
            $scope.freeContribution.LongTermPlanView.NewAmount = $scope.longTermAmount;
        }
        if (!isEmptyOrUndefinedOrNull($scope.shortTermAmount)) {
            $scope.freeContribution.ShortTermPlanView = {};
            $scope.freeContribution.ShortTermPlanView.NewAmount = $scope.shortTermAmount;
        }

        $scope.freeContribution.Entrypoint = entrypoint;
        $scope.freeContribution.InvitationCode = invitation;

        var uniqueId = createUUID();
        $scope.freeContribution.PaymentReferenceId = uniqueId;
        var res = AnonymousUserService.PayOneShotAsAnonymous($scope.freeContribution);

        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (d) {
                var transactionId = d.data;
                var paymentReferenceNumber = uniqueId;

                var shortTermPlanView = 0;
                if ($scope.freeContribution.ShortTermPlanView != null && $scope.freeContribution.ShortTermPlanView.NewAmount != "") {
                    shortTermPlanView = $scope.freeContribution.ShortTermPlanView.NewAmount;
                }

                var longTermPlanView = 0;
                if ($scope.freeContribution.LongTermPlanView != null && $scope.freeContribution.LongTermPlanView.NewAmount != "") {
                    longTermPlanView = $scope.freeContribution.LongTermPlanView.NewAmount;
                }
                var totalAmount = parseFloat(longTermPlanView) + parseFloat(shortTermPlanView);
                $scope.paymentServicesOSP(transactionId, paymentReferenceNumber, totalAmount, 0);
            }, function (error) {
                genericErrorMessageDisplay();
            });
        }
    }

    $scope.paymentServicesOSP = function (transactionId, paymentReferenceNumber, totalAmount, personId) {
        var postData = {
            UserId: personId,
            Amount: totalAmount,
            TransactionId: transactionId,
            PaymentReference: paymentReferenceNumber,
            IsFreeContribution: true
        };
        var res = AnonymousUserService.PaymentGateway(postData);
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (paymentRes) {
                FormSubmitter.submit(paymentRes.data.RedirectionUrl, "POST", paymentRes.data);
            }, function (error) {
                genericErrorMessageDisplay();
            });
        }
    }

    function createUUID() {
        // http://www.ietf.org/rfc/rfc4122.txt
        var s = [];
        var hexDigits = "0123456789abcdef";
        for (var i = 0; i < 36; i++) {
            s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
        }
        s[14] = "4"; // bits 12-15 of the time_hi_and_version field to 0010
        s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
        s[8] = s[13] = s[18] = s[23] = "-";

        var uuid = s.join("");
        return uuid;
    }

    function genericErrorMessageDisplay() {
        $("#failedSomethingWentWrongTryAgainLater").text("Something went wrong.Please try again");
        $("#failSuccessGlyphicon").removeClass("success-notification");
        $("#failSuccessGlyphicon").addClass("failure-notification");
    }

    $scope.updateTransactionStatus = function () {
        $scope.paymentDetail.PaymentReferenceNumber = $scope.paymentTransactionId;

        paymentService.updateTransactionStatus($scope.paymentDetail).success(function (data, status) {
        })
            .error(function (data, status) {
            });
    };

    $scope.changeValue = function (evt) {
        var shortTermInput = $(".short-term-input").find("input");
        var valueToCheckLongTerm = parseInt($scope.longTermAmount);
        var valueToCheckShortTerm = parseInt($scope.shortTermAmount);

        if (!$(".long-term-input").find("input").val()) {
            valueToCheckLongTerm = 0
        }
        if (!$(".short-term-input").find("input").val()) {
            valueToCheckShortTerm = 0
        }

        if ((evt == "btnLongUp")) {
            if (valueToCheckLongTerm >= parseInt($scope.maxValueLT)) {
                return false;
            }
            //$(".long-term-input").find("input").val(parseInt(valueToCheckLongTerm) + paymentDetail.IncrementalValue);
            $scope.longTermAmount = valueToCheckLongTerm + 10;//TODO Amitabh paymentDetail.IncrementalValue;
        } else if ((evt == "btnLongDown")) {
            if (valueToCheckLongTerm <= parseInt($scope.minValueLT)) {
                return false;
            }
            //$(".long-term-input").find("input").val(parseInt(valueToCheckLongTerm) - paymentDetail.IncrementalValue);
            $scope.longTermAmount = valueToCheckLongTerm - 10;//TODO Amitabh paymentDetail.IncrementalValue;
        }

        if ((evt == "btnShortUp")) {
            if (valueToCheckShortTerm >= parseInt($scope.maxValueST)) {
                return false;
            }
            //$(".short-term-input").find("input").val(parseInt(valueToCheckShortTerm) + paymentDetail.IncrementalValue);
            $scope.shortTermAmount = valueToCheckShortTerm + 10;//TODO Amitabh  paymentDetail.IncrementalValue;
        } else if ((evt == "btnShortDown")) {
            if (valueToCheckShortTerm <= parseInt($scope.minValueST)) {
                return false;
            }
            //$(".short-term-input").find("input").val(parseInt(valueToCheckShortTerm) - paymentDetail.IncrementalValue);
            $scope.shortTermAmount = valueToCheckShortTerm - 10;//TODO Amitabh paymentDetail.IncrementalValue;
        }

        var totalAmount = $scope.paymentDetail.TotalAmount;
        if ($scope.shortTermAmount) {
            totalAmount = totalAmount + returnANumberWithoutFormating($scope.shortTermAmount, currentLanguage);
        }
        if ($scope.longTermAmount) {
            totalAmount = totalAmount + returnANumberWithoutFormating($scope.longTermAmount, currentLanguage);
        }

        if (totalAmount >= $scope.paymentDetail.MaxContributionValue) {
            $scope.showCreaeAccount = true;
            $scope.showMessage = true;
        } else {
            $scope.showCreaeAccount = false;
            $scope.showMessage = false;
        }

        setTimeout(function () {
            $("#longTermValue").valid();
            $("#shortTermValue").valid();
        }, 50);
    }

    $scope.goBack = function () {
        history.go(-1)
    }
}]);