﻿/*global $, jQuery, alert, window*/
/*jslint browser: true*/
//supporterinvitationapp.controller("InvitationController", ["$scope", "$state", "$stateParams", "WebApiService", function ($scope, $state, $stateParams, WebApiService) {
supporterinvitationapp.controller("InvitationController", ["$scope", "FactoryHelper", "WebApiService", function ($scope, FactoryHelper, WebApiService) {
    var url = "/invitations/" + document.getElementById('invitationGuid').value;// $.cookie("invitationGuid");
    var language = $.cookie("language");
    var res = FactoryHelper.CallApiGetAnonymous(url);
    if (res !== undefined) {
        res.then(function (d) {
            //   var response = JSON.stringify(d.data.Result);
            var data = d;
            $scope.parentFirstName = data.ParentFirstName;
            $scope.parentLastName = data.ParentLastName;
            $scope.childFirstName = data.ChildFirstName;
            $scope.supporterFirstName = data.SupporterFirstName;
        }, function (error) {
            //alert(supporterInfoError);
        });
    }

    $scope.goToFreeContributionPage = function () {
        window.location.href = "/" + currentLanguage + "/freeContribute";
    }
    $scope.validateUser = function () {
        var hostName = window.location.host;
        window.location.href = location.protocol + '//' + hostName;
    }
}]);