myAppangular.controller("connectivServiceController", ["$scope", "$filter", "WebApiService", "connectiveService", "$window", "FormSubmitter", function ($scope, $filter, WebApiService, connectiveService, $window, FormSubmitter) {
    $('#pageLoader').addClass('show');
    $('html').addClass('no-scroll');
    $scope.init = function () {
        $.cookie("promoCode", "", { path: "/" });
        var packageExternalReference = $.cookie("PackageExternalReference");
        var status = $.cookie("Status")
        $scope.updatePackage(packageExternalReference, status);

        $scope.getPackageDetail(packageExternalReference);
    }

    $scope.updatePackage = function (packageExternalReference, Status) {
        connectiveService.updatePackage(packageExternalReference, Status).success(function (data, status) {
            $('#pageLoader').addClass('show');
            $('html').addClass('no-scroll');
        });
    }

    $scope.getPackageDetail = function (packageExternalReference) {
        connectiveService.getPackageDetail(packageExternalReference).success(function (data, status) {
            $('#pageLoader').addClass('show');
            $('html').addClass('no-scroll');
            //call the confirm service
            var packageData = data;

            if ($.cookie("Status") == "SIGNED") {
                connectiveService.confirmPackage(data).success(function (successData, status) {
                    $('#pageLoader').addClass('show');
                    $('html').addClass('no-scroll');
                    if (packageData.CallType == 0) {
                        window.location.href = baseFrontEndUrl + ConnectiveManualResponseUrlForSubscription;
                    } else if (packageData.CallType == 1) {
                        window.location.href = baseFrontEndUrl + ConnectiveManualResponseUrlForPayment.replace("{childId}", $.cookie("childId"));
                    }
                });
            }
                //window.location.href = "/" + currentLanguage + "/Home/Members";

            else {
                if (packageData.CallType == 0) {
                    window.location.href = baseFrontEndUrl + ConnectiveManualResponseUrlForSubscription;
                }
                else if (packageData.CallType == 1) {
                    window.location.href = baseFrontEndUrl + ConnectiveManualResponseUrlForPayment.replace("{childId}", $.cookie("childId"));
                }
            }
        });
    }
}]);