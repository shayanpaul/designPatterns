﻿//ENUM definations of the constant values
var VALUE = { EMPTY: "", NULL: null, UNDEFINED:'undefined', ZERO:0 };
var SHORT_TERM = { MAX_AMOUNT: 2500, MIN_AMOUNT: 10 };
var LONG_TERM = { MAX_AMOUNT: 9999, MIN_AMOUNT: 10 };
var LANGUAGE = { ENGLISH: 'EN', FRENCH: 'FR', DUTCH: 'NL' };
var BOOLEAN = { TRUE: true, FALSE: false };
var DATE_FORMAT = { DDMMYYYY: 'ddmmyyyy', MMDDYYYY: 'mmddyyyy', DD_MONTH_YYYY: 'ddmonthnameyyyy' };
var SEPARATOR = { MINUS: '-', FORWARD: '/', SPACE: ' ' };

//[days, years, months, seconds, ...]
function ageDifferenceCalculator(firstDateVal, secondDateVal, inYearsMonthsDays) {
    var firstDateFormat = firstDateVal.split("/");
    var secondDateFormat = secondDateVal.split("/");
    var firstDate = moment([firstDateFormat[2], firstDateFormat[1] - 1, firstDateFormat[0]]);
    var secondDate = moment([secondDateFormat[2], secondDateFormat[1] - 1, secondDateFormat[0]]);
    return secondDate.diff(firstDate, inYearsMonthsDays);
}


//[ddmmyyyy, mmddyyyy] send a date object or a string of date, it will work
//if user pass date as null, then it will return ""
var getDateInString = function (dateObj, format, language, separator) {
    var SEPARATING_SIGN = SEPARATOR.FORWARD;
    if (!isEmptyOrUndefinedOrNull(separator)) {
        SEPARATING_SIGN = separator;
    }
    var monthNamesEN = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var monthNamesNL = ['Jan', 'Feb', 'Maa', 'Apr', 'Mei', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'];//["Jan", "Feb", "Mrt", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"];
    var monthNamesFR = ['Jan', 'Fev', 'Mar', 'Avr', 'Mai', 'Jui', 'Juil', 'Aou', 'Sep', 'Oct', 'Nov', 'Dec'];//["Janv.", "Févr.", "Mars", "Avril", "Mai", "Juin", "Juil.", "Août", "Sept.", "Oct.", "Nov.", "Déc."];
    var monthNames = monthNamesEN;
    var month = VALUE.ZERO; //months from 1-12
    var monthName = VALUE.EMPTY; //January is 0!
    var day = VALUE.ZERO;
    var year = VALUE.ZERO;

    if (isEmptyOrUndefinedOrNull(dateObj)) {
        return VALUE.EMPTY;
    }

    if (language) {
        if (language.toUpperCase() === LANGUAGE.ENGLISH) {
            monthNames = monthNamesEN;
        } else if (language.toUpperCase() === LANGUAGE.DUTCH) {
            monthNames = monthNamesNL;
        } else if (language.toUpperCase() === LANGUAGE.FRENCH) {
            monthNames = monthNamesFR;
        }
    }
    
    if (typeof (dateObj) === "object") {
        month = dateObj.getMonth() + 1; //months from 1-12
        monthName = monthNames[dateObj.getMonth()]; //January is 0!
        day = dateObj.getDate();
        year = dateObj.getFullYear();
    } else if (typeof (dateObj) === "string") {
        var dateArray = null;
        var lengthOfDate = dateObj.length;
        if (lengthOfDate <= 14) {
            if (dateObj.indexOf('-') !== -1) {
                dateArray = dateObj.split("-");
            } else if (dateObj.indexOf('/') !== -1) {
                dateArray = dateObj.split("/");
            } else if (dateObj.indexOf(' ') !== -1) {
                dateArray = dateObj.split(" ");
            }
            if (isNaN(dateArray[1])) {
                if (monthNames.indexOf(dateArray[1]) === -1) {
                    return "";
                } else {
                    month = monthNames.indexOf(dateArray[1]) + 1;
                    monthName = dateArray[1]; //January is 0!
                }
            } else {
                month = parseInt(dateArray[1]);
                monthName = monthNames[month - 1]; //January is 0!
            }
            day = parseInt(dateArray[0]);
            year = parseInt(dateArray[2]);
        } else {
            dateObj = new Date(dateObj);
            month = dateObj.getMonth() + 1; //months from 1-12
            monthName = monthNames[dateObj.getMonth()]; //January is 0!
            day = dateObj.getDate();
            year = dateObj.getFullYear();
        }
        
    }
   
    if (day < 10) {
        day = "0" + day;
    }
    if (month < 10) {
        month = "0" + month;
    }
    var formattedDate = VALUE.EMPTY;
    if (format === DATE_FORMAT.DDMMYYYY) {
        formattedDate = day + SEPARATING_SIGN + month + SEPARATING_SIGN + year;
    } else if (format === DATE_FORMAT.MMDDYYYY) {
        formattedDate = month + SEPARATING_SIGN + day + SEPARATING_SIGN + year;
    } else if (format === DATE_FORMAT.DD_MONTH_YYYY) {        
        formattedDate = day + SEPARATING_SIGN + monthName + SEPARATING_SIGN + year;
    } else {
        formattedDate = day + SEPARATING_SIGN + month + SEPARATING_SIGN + year;
    }
    return formattedDate;
}

/*Use this function to get the boolean value if you have a doubt that you will get string*/
function isTrue(value) {
    if (typeof (value) == 'string') {
        value = value.toLowerCase();
    }
    switch (value) {
        case true:
        case "true":
        case 1:
        case "1":
        case "on":
        case "yes":
            return true;
        default:
            return false;
    }
}

function returnANumberWithoutFormating(amountStr,language) {
    if (amountStr) {
        var amountStr = amountStr.toString();
        var splitSymbol = ".";
        
        if (language) {
            if (language.toUpperCase() === "FR") {
                splitSymbol = ",";
            } else if (language.toUpperCase() === "NL") {
                splitSymbol = ",";
            }
        }
        
        var amountArray = amountStr.split(splitSymbol);
        
        var amountToBeReturned = amountArray[0].replace(/[^\-0-9]/g, "");
        
        return Number(amountToBeReturned);
        // }
    } else {
        return 0;
    }
}
function formatAmountField(amount, language) {
    var formattedAmount = Number(amount);
    if (language == "fr" || language == "FR") {
        language = "NL";
    }
    
    return formattedAmount.toLocaleString(language, {
        minimumFractionDigits: 2
    });

}

//Method to check if any variable is Empty / undefined / null. Save lots of if statement.
var isEmptyOrUndefinedOrNull = function (value) {
    var type = typeof value;
    if (type === 'undefined') {
        return true;
    } else if (type === 'boolean') {
        if (value === false) {
            return true;
        }
    } else if (type === 'object') {
        if (value === null) {
            return true;
        }
    } else if (type === 'string') {
        if (value.length < 1) {
            return true;
        }
    } else if (type === 'number') {
        if (value === 0) { // need to be validated. If change required please make the change. Do specify why ?
            return false;
        }
    }    
    return false;
}

myAppangular.factory('utilityFactory', [function () {

    var changeDateFormat = function (date) {
        var m_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        if (date) {
            var today = new Date(date);
        }
        else {
            var today = new Date();
        }
        var dd = today.getDate();
        var mm = m_names[today.getMonth()]; //January is 0!

        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd
        }

        today = dd + ' ' + mm + ' ' + yyyy;

        return today;

    };

    function getDateInStringFormatted(dateObj) {
        dateObj = dateObj.toString();
        var res = dateObj.substring(0, 10);
        var res1 = res.split("-");
        
        res = res1[1] + '/' + res1[2] + '/' + res1[0];
        return res;
    }
    var validEmail = function (email) {
        var inputSupporterEmail = {
            "required": false,
            "pattern": false
        };
       isAValidEmailID = true;
        var regexpemailFirstPart = /^[a-z0-9A-Z\! \# \$ \% \& \' \* \+ \- \/ \= \? \^ \_ \` \{ \| \} \~]+([\.-]?[a-z0-9A-Z\! \# \$ \% \& \' \* \+ \- \/ \= \? \^ \_ \` \{ \| \} \~]+)*$/;
        var regexpemaillastPart = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        
        if (!email || email == "" || email == null || email == 0) {
            inputSupporterEmail = {
                "required": true,
                "pattern": false
            };
           isAValidEmailID = false;
        }
        else {
            if (email.indexOf('@') == -1 || (email.match(/@/g) || []).length > 1) {
                inputSupporterEmail = {
                    "required": false,
                    "pattern": true
                };
               isAValidEmailID = false;
            }
            else {
                var emailArrayforval = email.split("@");
                var firstPartEmailVal = emailArrayforval[0];
                var lastPartEmailVal = emailArrayforval[1];


                if (!firstPartEmailVal || firstPartEmailVal == "" || firstPartEmailVal == null || firstPartEmailVal == 0) {
                    inputSupporterEmail = {
                        "required": false,
                        "pattern": true
                    };
                   isAValidEmailID = false;
                }
                else if (!lastPartEmailVal || lastPartEmailVal == "" || lastPartEmailVal == null || lastPartEmailVal == 0) {
                    inputSupporterEmail = {
                        "required": false,
                        "pattern": true
                    };
                   isAValidEmailID = false;
                }
                else if (!regexpemailFirstPart.test(firstPartEmailVal) || !regexpemaillastPart.test(lastPartEmailVal)) {
                    inputSupporterEmail = {
                        "required": false,
                        "pattern": true
                    };
                   isAValidEmailID = false;
                }

                else {
                    inputSupporterEmail = {
                        "required": false,
                        "pattern": false
                    };
                   isAValidEmailID = true;
                }
            }
        }

        return ([inputSupporterEmail, isAValidEmailID])
    }

    return {
        changeDateFormat: changeDateFormat,
        validEmail: validEmail,
        getDateInStringFormatted:getDateInStringFormatted
    };

}]);

