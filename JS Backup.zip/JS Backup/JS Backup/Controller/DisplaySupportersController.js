﻿/*global $, jQuery, alert, window, angular*/
/*jslint browser: true, devel: true*/
var displaySupporters = angular.module("displaySupporters", []);
//displaySupporters.controller("displaySupporterController", function ($scope, $modal, $modalInstance) {
displaySupporters.controller("displaySupporterController", ["$scope", "$uibModal", "DisplaySupportersService", function ($scope, $uibModal, DisplaySupportersService) {
    $scope.openInviteSupporterModal = function () {
        var modalInstance = $uibModal.open({
            animation: $scope.animationsEnabled,
            templateUrl: "myModalContent.html",
            size: "md",
            scope: $scope
        });
    };

    $scope.childDetails = data.IPersonViewModel;
    $scope.relationships = data.Relationship;
    $scope.message = data.invitationMesaageViewModel.inviteMessage;
    $scope.lastName = data.invitationMesaageViewModel.inviterLastName;
    $scope.firstName = data.invitationMesaageViewModel.inviterFirstName;
    $scope.nickname = data.invitationMesaageViewModel.inviterNickName;
    $scope.email = data.invitationMesaageViewModel.InvitedEmail;
}]);