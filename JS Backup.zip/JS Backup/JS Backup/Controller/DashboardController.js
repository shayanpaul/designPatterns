﻿myAppangular.controller("DashboardController", ["$scope", "$rootScope", "$state", "$stateParams", "$window", "WebApiService", "savingSchoolService", "ChildProfileService", "HeaderServices", "$sce", "utilityFactory", "EditProfileService", function ($scope, $rootScope, $state, $stateParams, $window, WebApiService, savingSchoolService, ChildProfileService, HeaderServices, $sce, utilityFactory, EditProfileService) {
    $scope.dashboardPersonId = $.cookie("personId");
    $scope.language = $stateParams.language;
    $scope.childPicURL = "";
    $scope.initiateController = function () {

        $scope.getChildProjects($scope.dashboardPersonId, $scope.dashboardPersonId);// in child's case both the child id and person id are same
        $scope.getChildActiveEvents($scope.dashboardPersonId);
        $scope.getChildWishlist($scope.dashboardPersonId);
        $scope.getFlagForNavigationToOverview($scope.dashboardPersonId);
        $scope.getAuthorizationToChangePicture($scope.dashboardPersonId);
    }
    //for saving school card
    $scope.noProjectsToShow = false;
    $scope.getChildProjects = function (personId, childId) {
        if (!savingSchoolService.getSavingSchoolData()) {
            savingSchoolService.getSavingSchoolDetail(personId, childId).then(
                    function (data) {
                        var childProjectDetails = data;
                        savingSchoolService.setSavingSchoolData(childProjectDetails);
                        //console.log(childProjectDetails);
                        $scope.bindProjectCardData(childProjectDetails);
                    },
                    function (error) {
                        genericErrorMessageDisplay(Resources.SavingSchoolDetails_Failed);
                    });
        } else {
            $scope.bindProjectCardData(savingSchoolService.getSavingSchoolData());
        }
    }
    $scope.bindProjectCardData = function (projectData) {
        $scope.projectDataToView = projectData.ShortTermProjects;
        $scope.shortTermContractAmount = formatAmountField(projectData.ShortTermContractAmount, $scope.language); // this value is for the short-term card
        if ($scope.projectDataToView && $scope.projectDataToView.length < 3) {
            $scope.emptyProjectSlot = Number(3 - $scope.projectDataToView.length);
            if ($scope.emptyProjectSlot == 3) {
                $scope.noProjectsToShow = true;
            }
            else if ($scope.emptyProjectSlot < 3) {
                $scope.noProjectsToShow = false;
            }
        } else if (!$scope.projectDataToView) {
            $scope.noProjectsToShow = true;
        }
    }

    //for events card
    $scope.getChildActiveEvents = function (childId) {
        $scope.EventsDataToView = new Array();
        ChildProfileService.GetAllEvents(childId).then(

                function (data) {
                    
                    //$scope.EventsDataToView = data;
                    //console.log(data);
                    angular.forEach(data, function (value, key) {
                        if (value.IsActiveEvent) {
                            $scope.EventsDataToView.push(value);
                        }
                    });
                },
                function (error) {
                }
            );
    }
    $scope.initiateCarousalForEvent = function (isLast) {
        setTimeout(function () {
            if (isLast) {
                $('.slider-item-event').slick({
                    dots: true,
                    infinite: false,
                    slidesToShow: 1,
                    initialSlide: 0,
                    fade: true,
                    swipe: true,
                    swipeToSlide: true,
                    lazyLoad: 'ondemand',
                    prevArrow: '<button class="btn btn-lnk slick-prev prev-event"><span id="slick-span-previous"><i class="glyphicon glyphicon-aagje-arrow-left slick-i-previous"></i></span></button>',
                    nextArrow: '<button class="btn btn-lnk slick-next next-event"><span id="slick-span-next"><i class="glyphicon glyphicon-aagje-arrow-right slick-i-next"></i></span></button>',
                    slidesToScroll: 1
                });
                $('.slider-item-event').on('afterChange', function (event, slick, currentSlide) {
                    if (currentSlide == 0) {
                        $(".prev-event > span").css('background-color', '#c8d1d7');
                        $(".next-event > span").css('background-color', '#aab5bc');
                    }
                    else {
                        $(".prev-event > span, .next-event > span").css('background-color', '#aab5bc');
                        if (currentSlide == $('.dashboard-event-slides').length - 1) {
                            $(".next-event > span").css('background-color', '#c8d1d7');
                        }
                    }
                });
            }
        },200);
        
    }

    //for wish card
    $scope.getChildWishlist = function (childId) {
        if (!savingSchoolService.getWishData().length) {
            savingSchoolService.getWishList(childId).then(function (data) {
                if (data.length) {
                    $scope.wisheDataToView = data;
                    savingSchoolService.setWishData(data);
                } else {
                    $scope.noWishToBeShown = true;
                }

            });

        } else {
            $scope.wisheDataToView = savingSchoolService.getWishData();
        }
    }
    $scope.initiateCarousalForWish = function (isLast) {
        if (isLast) {
            $('.slider-item-wish').slick({
                dots: true,
                infinite: false,
                slidesToShow: 1,
                initialSlide: 0,
                fade: true,
                swipe: true,
                swipeToSlide: true,
                lazyLoad: 'ondemand',
                prevArrow: '<button class="btn btn-lnk slick-prev prev-wish"><span id="slick-span-previous-wish"><i class="glyphicon glyphicon-aagje-arrow-left slick-i-previous"></i></span></button>',
                nextArrow: '<button class="btn btn-lnk slick-next next-wish"><span id="slick-span-next-wish"><i class="glyphicon glyphicon-aagje-arrow-right slick-i-next"></i></span></button>',
                slidesToScroll: 1
            });
            $('.slider-item-wish').on('afterChange', function (event, slick, currentSlide) {
                if (currentSlide == 0) {
                    $(".prev-wish > span").css('background-color', '#c8d1d7');
                    $(".next-wish > span").css('background-color', '#aab5bc');
                }
                else {
                    $(".prev-wish > span, .next-wish > span").css('background-color', '#aab5bc');
                    if (currentSlide == $('.wish-slides').length - 1) {
                        $(".next-wish > span").css('background-color', '#c8d1d7');
                    }
                }
            });
        }
        
    }

    //for various navigation
    $scope.goToSavingSchool = function (ChildId, flagForWish) {
        
        $state.go("child.detail.savingschool", {
            'childId': ChildId,
            'routingEntry': 'cp',
            childEntry: true,
            'wishFlag': flagForWish
        });
        $rootScope.$broadcast('child-want-to-create-wish');

    }
    $scope.goToOverViewPage = function (selChildId,navigationToEvent) {
        localStorage.setItem("planOverviewChildLoggedIn", "true");
        $state.go("child.detail.plan", {
            childId: selChildId,
            childEntry: true,
            navigateToEventFromChildDB: navigationToEvent
        });
    }
    $scope.getFlagForNavigationToOverview = function (childId) {
        ChildProfileService.ShowItemsOnChildOverview(childId, childId).then(
            function (data) {
                $scope.showShortTerm = data.ShowSTPlan;
                $scope.shortTermExist = data.ShowShortTerm;
            });
    }
    $scope.navigateToWishDetails = function (projectId,childId) {
        $state.go("child.detail.savingschool", {
            'childId': childId,
            'routingEntry': 'cp',
            childEntry: true,
            isTimeline: true,
            projectId: projectId
        });
    }
    //logic for changing child's self profile picture if he/she has the parental settings ON
    $scope.getAuthorizationToChangePicture = function (childId) {
        EditProfileService.GetParentalInformationForImage(childId).then(
            function (data) {
                //console.log(data);
                if (data) {
                    $scope.canEditSelfPicture = true;
                } else {
                    $scope.canEditSelfPicture = false;
                }
            },
            function (error) {
            }
        );
    }
    $scope.updateUserPicture = function () {
        var personImage = $('#changeChild-image-dashboard').find('.demoImg').attr('src');
        var request = {
            profilePictureData: personImage,
        };

        EditProfileService.UpdateUserPicture(request).then(
            function (data) {
                $("#personImageHeader").attr("src", personImage);
                $scope.childPicURL = personImage;
                genericSuccessMessageDisplay(Resources.SuccessfulYourPersonalDetailsAreSaved);
            },
            function (error) {
            }
        );
    }
}])