﻿//var usermodalModule = angular.module("usermodelModule", []);

usermodalModule.controller("usermodalController", ["$scope", "$rootScope", "ChildProfileService", "EditProfileService", "WebApiService", function ($scope, $rootScope, ChildProfileService, EditProfileService, WebApiService) {
    var phoneNumer = "";
    $scope.isChild = false;
    $("#editZipCode").mask('0000');
    $scope.allCountryList = [];
    $scope.allZiplist = [];
    $scope.cityDropDown = false;
    $scope.userProfileDetailsForEdit = {};
    $scope.showOtpBlock = false;
    $scope.phoneNumberNotValidated = false;
    $rootScope.$on('userModal-started', function (event, args) {
        $scope.allCountryList = args.any.countryList;
        if ($rootScope.personPhone) {
            phoneNumer = $rootScope.personPhone.replace(/ +/g, "");
            phoneNumer = phoneNumer.slice(3, phoneNumer.length);
        }
        for (var i = 0; i < $scope.allCountryList.length; i++) {
            $scope.allCountryList[i].Id = $scope.allCountryList[i].Id.toString();
        }
        $scope.userProfileDetailsForEdit = args.any.userProfileDetails;
        $scope.isChild = args.any.isChildProfile;
        $scope.isNickNameVisible = args.any.isChildProfile;
        if (args.any.userProfileDetails.city) {
            $scope.cityDropDown = false;
        }
        $scope.showOtpBlock = false;
        $scope.showotpTextBlock = false;
        angular.element(".invalid-otp-code").css('display', 'none');
        //$scope.isInvalidCode = false;
        $scope.isCodeVerified = false;
        $scope.phoneNumberNotValidated = false;
    });

    $scope.cancelModal = function () {
        $scope.userProfileDetailsForEdit = '';
    };

    $scope.updateSettingData = function () {

        if (!$('#editPersonForm').valid()) {
            return false;
        }
        //if ($scope.isChild) {
        //    $rootScope.$broadcast('userModal-update-child', { userProfileDetailsForEdit: $scope.userProfileDetailsForEdit });
        //}
        //else {
        //    $rootScope.$broadcast('userModal-update', { userProfileDetailsForEdit: $scope.userProfileDetailsForEdit });
        //}
        //alert("valid form");
    }

    $scope.cityDropDownChange = function (CityZipCode) {
        if (CityZipCode) {
            EditProfileService.getallZiplist($scope.userProfileDetailsForEdit.cityZipCodeId).then(
                function (data) {
                    citylistForshowing = data.Result.City;
                    for (var i = 0; i < citylistForshowing.length; i++) {
                        if (citylistForshowing[i].Id.toString() === userProfileDetailsForEdit.cityZipCodeId) {
                            $scope.userProfileDetailsForEdit.city = citylistForshowing[i].Name;
                        }
                    }
                },
                function (error) {
                }
            );
        }
    }

    $scope.getCitybyZip = function (zip) {
        if (zip) {
            EditProfileService.GetCityZipCode(zip).then(
                            function (data) {
                                if (!data || !data.Result || !data.Result.City || data.Result.City.length > 0) {
                                    $scope.userProfileDetailsForEdit.zipCode = data.Result.ZipCode;
                                    $scope.userProfileDetailsForEdit.city = '';
                                }
                                $scope.cityListToDisplay = data.Result.City;

                                if ($scope.cityListToDisplay.length > 1) {
                                    $scope.cityDropDown = true;
                                    for (var i = 0; i < $scope.cityListToDisplay.length; i++) {
                                        $scope.cityListToDisplay[i].Id = $scope.cityListToDisplay[i].Id.toString();
                                        if ($scope.cityListToDisplay[i].Id.toString() === $scope.userProfileDetailsForEdit.cityZipCodeId.toString()) {
                                            $scope.userProfileDetailsForEdit.city = $scope.cityListToDisplay[i].Name;
                                            if (!$scope.$$phase) {
                                                $scope.$apply();
                                            }
                                        }
                                    }
                                } else {
                                    $scope.cityDropDown = false;
                                    if ($scope.cityListToDisplay[0]) {
                                        $scope.userProfileDetailsForEdit.city = $scope.cityListToDisplay[0].Name;
                                        $scope.userProfileDetailsForEdit.cityZipCodeId = $scope.cityListToDisplay[0].Id;

                                    }
                                }
                            },
                            function (error) {
                                $scope.userProfileDetailsForEdit.zipCode = '';
                                $scope.userProfileDetailsForEdit.cityZipCodeId = '';
                                $scope.userProfileDetailsForEdit.city = '';
                            }
            );
        }
    };

    $scope.validatePhoneNumber = function () {
        if (angular.element('#editPhone').valid()) {
            var enteredNumber = angular.element('#editPhone').val().replace(/ +/g, "");
            if (enteredNumber.split("")[0] == '0') {
                enteredNumber = enteredNumber.slice(1, enteredNumber.length); // if number is prefixed with 0
            }
            else if(enteredNumber.split("")[0] == '+') {
                enteredNumber = enteredNumber.slice(3, enteredNumber.length); // if number is prefixed with +32
            }

            if (phoneNumer) {
                if (enteredNumber == phoneNumer) {
                    $scope.showOtpBlock = false;
                    $scope.showotpTextBlock = false;
                    $scope.phoneNumberNotValidated = false;
                }
                else {
                    $scope.phoneNumberNotValidated = true;
                    $scope.showOtpBlock = true;
                    $scope.showsendOtpBtn = true;
                    $scope.isCodeVerified = false;
                    $scope.showotpTextBlock = false;
                    $scope.userProfileOTP = "";
                    angular.element(".invalid-otp-code").css('display', 'none');
                }
            }
        }
        else {
            $scope.showOtpBlock = false;
        }
    }
    $scope.SendCodeToMail = function () {
        $scope.showotpTextBlock = true;
        $scope.showsendOtpBtn = false;
        $scope.userProfileOTP = "";
        angular.element(".invalid-otp-code").css('display', 'none');
        angular.element(".otpContainer .form-group").removeClass('error');
        var otpUrl = "/common/user/" + $.cookie('personId') + "?isEmailCode=true";
        WebApiService.sendOtp(otpUrl).success(function (data, status) {
        });
    }
    $scope.verifyUserOTP = function (otp) {
        var otpVerified = false;
        if (otp) {
            var otpCheckUrl = "/common/code/" + otp + "?userId=" + $.cookie('personId') + "&isEmailCode=true";;
            WebApiService.checkOtp(otpCheckUrl).success(function (data, status) {
                if (data) {
                    if (data.Result) {
                        $scope.showsendOtpBtn = false;
                        $scope.showotpTextBlock = false;
                        $scope.isCodeVerified = true;
                        $scope.showotpTextBlock = false;
                        angular.element(".otpContainer .form-group").removeClass('error');
                        $scope.phoneNumberNotValidated = false;
                    }
                    if (!data.Result) {
                        angular.element(".invalid-otp-code").css('display', 'block');
                        angular.element(".otpContainer .form-group").addClass('error');
                        $scope.phoneNumberNotValidated = true;
                    }
                }
            });

        }
    }
}]);