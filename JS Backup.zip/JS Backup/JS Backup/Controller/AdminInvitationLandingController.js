﻿admininvitationapp.controller("InviteAdminMailController", ["$scope", "FactoryHelper", "WebApiService", function ($scope, FactoryHelper, WebApiService) {
    var url = "/invitations/admininvitationid/" + $.cookie("invitationGuid") + "/admininvitationdetails";
    var language = $.cookie("language");
    var res = FactoryHelper.CallApiGetAnonymous(url);
    if (res !== undefined) {
        res.then(function (d) {
            
            var data = d.Result;
            
            $scope.parentFirstName = data.InvitationMessageViewModel.InviterFirstName;
            $scope.parentLastName = data.InvitationMessageViewModel.InviterLastName;
            $scope.childFirstName = data.ChildFirstName;
            $scope.InviteeFirstName = data.InvitationMessageViewModel.InvitedFirstName;
        }, function (error) {
            
        });
    }

    $scope.validateUser = function () {
        var hostName = window.location.host;
        window.location.href = location.protocol + '//' + hostName;
    }
    
}]);
