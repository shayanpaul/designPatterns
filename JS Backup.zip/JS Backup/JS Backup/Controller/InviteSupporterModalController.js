﻿myAppangular.controller("inviteSupporterModalController", ["$scope", "$rootScope", "WebApiService", "DisplaySupportersService", "InviteSupporterModalService", "ModalFactory", "utilityFactory", "SupporterService", function ($scope, $rootScope, WebApiService, DisplaySupportersService, InviteSupporterModalService, ModalFactory, utilityFactory, SupporterService) {

    //Invite Supporter code starts here US 321
    $scope.showEnterLastname = false;
    $scope.showEnterFirstname = false;
    $scope.showEnterNickname = false;
    $scope.showEnterEmail = false;
    $scope.showNotMatchPattern = false;
    $scope.showEnterMessage = false;
    $scope.nameRegexp = nameRegex;
    $scope.emailRegexp = emailRegex;
    $scope.relationshipcount = [];
    $scope.languageCulture = $.cookie("language");
    $scope.childList = [];
    $scope.childListSelect = [];
    $scope.isAValidEmailID = false;
    $scope.inputSupporterEmail = {
        "required": false,
        "pattern": false
    };
    $scope.fromTimeLine = false;
    //$scope.fromTimeLine = false;
    //$("#inputSupporterEmail").inputmask("email");

    $("input").on("keypress", function (e) {
        if (e.which === 32 && !this.value.length)
            e.preventDefault();
    });

    //$("input").on("focus", function () {
    //    $(this).parent().parent().removeClass("error");
    //    $(this).parent().parent().addClass("focus");
    //});

    //$("input").not("#accountHolderEndDateContribute").on("blur", function () {
    //    $(this).parent().parent().removeClass("focus");
    //    $(this).parent().parent().removeClass("error");
    //});

    //$("#sendInviteSupporter").attr("disabled", "disabled").addClass("disabled");

    $scope.validEmail = function () {
        var resultEmailval = utilityFactory.validEmail($scope.selectedSupporter.email);
        $scope.inputSupporterEmail = resultEmailval[0];
        $scope.isAValidEmailID = resultEmailval[1];

    }
    $scope.removeErrorStyle = function () {
        $scope.isAValidEmailID = false;
        $scope.inputSupporterEmail = {
            "required": false,
            "pattern": false
        };
    }
    var stringAllReplace = function (obj) {
        var retStr = this;
        for (var i = 0; i < obj.length ; i++) {
            retStr = retStr.replace(obj[i], '');
        }
        return retStr;
    };

    $scope.inviteSupporterCheckbox = function (childId) {
        //$scope.isCheckboxclickedFlag = true;
        if ($scope.fromTimeLine) {  
            $("#selectDefaultRel" + childId).val("");
            $("#selectDefaultRel" + childId).selectpicker("val", 0);
            $("#dropdownDiv" + childId).css("display", "inline-block");
            if ($scope.childGroupInfo.length !== 1) {
                var count = 0;
                var arrayindx = '';
                for (var i = 0; i < $scope.childListSelect.length; i++) {
                    if ($scope.childListSelect[i] == childId) {
                        count++;
                        arrayindx = i;
                        break;
                    }
                }
                if (count === 0) {
                    $scope.childListSelect.push(childId);
                }
            }

            var unFilledTextBox = false;
            if ($scope.childGroupInfo.length !== 1 || ($scope.childGroupInfo.length === 1 && $scope.relationshipcount.length === 0)) {
                var newSelectValue = $("#selectDefaultRel" + childId).val();
                if (newSelectValue && newSelectValue !== '' && newSelectValue !== 0 && newSelectValue !== null) {
                    $scope.unitChanged(childId, 'add');
                }
            }

            $("#inviterModal .edit-profile-form-input").each(function () {
                if (!$(this).val()) {
                    unFilledTextBox = true;
                    return false;
                }
            });
            angular.element("#selectDefaultRel" + childId).closest(".invite-supporter-relation").show();
            if ($scope.childList > 0) {
                $scope.childSelectForSupport = false;
            }
            $("#selectDefaultRel" + childId).val($scope.inviterRelationshipChildselecttionTimeline);
        }
        else if ($("#check" + childId).prop("checked")) {
            $("#selectDefaultRel" + childId).val("");
            $("#selectDefaultRel" + childId).selectpicker("val", 0);
            $("#dropdownDiv" + childId).css("display", "inline-block");
            if ($scope.childGroupInfo.length !== 1) {
                var count = 0;
                var arrayindx = '';
                for (var i = 0; i < $scope.childListSelect.length; i++) {
                    if ($scope.childListSelect[i] == childId) {
                        count++;
                        arrayindx = i;
                        break;
                    }
                }
                if (count === 0) {
                    $scope.childListSelect.push(childId);
                }
            }

            var unFilledTextBox = false;
            if ($scope.childGroupInfo.length !== 1 || ($scope.childGroupInfo.length === 1 && $scope.relationshipcount.length === 0)) {
                var newSelectValue = $("#selectDefaultRel" + childId).val();
                if (newSelectValue && newSelectValue !== '' && newSelectValue !== 0 && newSelectValue !== null) {
                    $scope.unitChanged(childId, 'add');
                }
            }

            $("#inviterModal .edit-profile-form-input").each(function () {
                if (!$(this).val()) {
                    unFilledTextBox = true;
                    return false;
                }
            });
            angular.element("#selectDefaultRel" + childId).closest(".invite-supporter-relation").show();
            if ($scope.childList > 0) {
                $scope.childSelectForSupport = false;
            }
        } else {
            $("#selectDefaultRel" + childId).val("");
            $("#selectDefaultRel" + childId).selectpicker("val", 0);
            if ($scope.childGroupInfo.length !== 1) {
                var count = 0;
                var arrayindx = '';
                for (var i = 0; i < $scope.childListSelect.length; i++) {
                    if ($scope.childListSelect[i] == childId) {
                        $scope.childListSelect.splice(i, 1);
                    }

                }
            }

            var checkedBox = false;
            $("#dropdownDiv" + childId).css("display", "none");
            var newSelectValue = $("#selectDefaultRel" + childId).val();
            if (newSelectValue && newSelectValue !== '' && newSelectValue !== 0 && newSelectValue !== null) {
                $scope.unitChanged(childId, 'remove');
            }

            //For Supporter Modal Popup Validation
            $("#inviterModal .text-container .checkboxwith-img .input-block input[type='checkbox']").each(function () {
                var $this = $(this);
                if ($this.prop("checked")) {
                    checkedBox = true;
                    return false;
                }
            });
            angular.element("#selectDefaultRel" + childId).closest(".invite-supporter-relation").removeClass("group-validation-error").hide();
            angular.element("#selectDefaultRel" + childId + "-error").remove();
            if ($scope.childList < 1) {
                $scope.childSelectForSupport = true;
        }
    }
    }
    //GetMyChildDetails
    $scope.GetMyChildren = function () {
        $scope.relationshipcount = [];
        var personId = $.cookie("personId");
        InviteSupporterModalService.getMyChildrenDetail(personId).then(
            function (data) {
                $scope.GroupInfo = [];
                if (data.length == 0) {
                    genericModalErrorDisplayMessage(Resources.LoadPopup_Failed, "invite-supporter-failure-msg");
                } else {
                    $.each(data, function (index) {
                        if (!data[index].IsPending) {
                        $scope.Info = {};
                        $scope.Info.childFirstName = data[index].PersonFirstName;
                        $scope.Info.childLastName = data[index].PersonLastName;
                        if (data[index].PersonImageUrl) {
                            $scope.Info.image = data[index].PersonImageUrl;
                        } else {
                            $scope.Info.image = images.defaultPersonImage;
                        }
                        $scope.Info.ID = data[index].PersonId;
                        $scope.GroupInfo.push($scope.Info);

                        }

                        $scope.inputSupporterEmail = {
                            "required": false,
                            "pattern": false
                        };
                        $scope.childGroupInfo = [];
                        $scope.childList = [];
                        $scope.childListSelect = [];
                        $scope.relationshipcount = [];
                        $scope.selectedSupporter = [];
                        $scope.supporterChildIds = [];

                        $scope.modalformInviesupporter.$setUntouched();
                        $scope.modalformInviesupporter.$setPristine();
                        $("#inviterModal div").removeClass("errornew");
                        $("#inviterModal").find(".errornew").removeClass("errornew");
                        $(".checkboxwith-img input").prop("checked", false);
                        $(".drop-down-small-view").css("display", "none");
                        $("#inviterModal div").removeClass("error");


                        if (broadCastedData.any.selectedSupporter) {
                            $scope.selectedSupporter = broadCastedData.any.selectedSupporter;
                        }
                        //if (args.any.childList) {
                        //    $scope.childList.push(args.any.childList[0]);
                        //    $scope.childListSelect.push(args.any.childList[0]);
                        //}

                        $scope.childGroupInfo = $scope.GroupInfo;

                        $("#inputSupporterMessage").removeClass("errornew");
                        if ($scope.childGroupInfo) {
                            for (var i = 0; i < $scope.childGroupInfo.length; i++) {
                                var childGroupInfoIthvalue = $scope.childGroupInfo[i].ID;
                                $("#selectDefaultRel" + $scope.childGroupInfo[i].ID).val("");
                                $("#selectDefaultRel" + $scope.childGroupInfo[i].ID).selectpicker("val", 0);
                                //alert(childGroupInfoIthvalue);
                                $(document).on('change', "#selectDefaultRel" + childGroupInfoIthvalue, function (childGroupInfoIthvalue) {
                                    var lastCharchildGroupInfoIthvalue = childGroupInfoIthvalue.currentTarget.id;
                                    var lastCharchildGroupInfoIthvalue = lastCharchildGroupInfoIthvalue.substring(16, lastCharchildGroupInfoIthvalue.length);
                                    var newSelectValue = $("#selectDefaultRel" + lastCharchildGroupInfoIthvalue).val();
                                    if (newSelectValue && newSelectValue !== '' && newSelectValue !== 0 && newSelectValue !== null) {
                                        $scope.unitChanged(lastCharchildGroupInfoIthvalue, 'NA');
                                    }
                                });
                            }
                                }
                        if ($scope.selectedSupporter) {
                            $scope.selectedSupporter.firstName = $scope.selectedSupporter.previousFirstName;
                            $scope.selectedSupporter.lastName = $scope.selectedSupporter.previousLastName;
                            $scope.selectedSupporter.nickName = $scope.selectedSupporter.previousNickName;
                            $scope.selectedSupporter.email = $scope.selectedSupporter.previousEmail;
                            if ($scope.selectedSupporter.email != null) {
                                $scope.isAValidEmailID = true;
                            }
                            $scope.message = "";
                        }

                        if ((localStorage.getItem("isChild") && localStorage.getItem("isChild") == "true") && !(localStorage.getItem("IssubscribingParent") && localStorage.getItem("IssubscribingParent")=="true")) {
                            $(".select-label").hide();
                            $scope.InvitationByChild = true;
                            $scope.childListSelect.push($.cookie("personId"));


                            $("#dropdownDiv").css("display", "inline-block");

                            $("#selectDefaultRel").val("");
                            $("#selectDefaultRel").selectpicker("val", 0);
                            var newSelectValue = $("#selectDefaultRel").val();
                            if (newSelectValue && newSelectValue !== '' && newSelectValue !== 0 && newSelectValue !== null) {
                                $scope.relationshipChanged();
                            }
                        }
                        if ($scope.childGroupInfo) {
                            if ($scope.childGroupInfo.length > 0 || (localStorage.getItem("isChild") && localStorage.getItem("isChild") == "true")) {
                                $("#inviterModal").modal('show');
                                $("#supportYourChildModal").modal('hide');
                            }
                            else {
                                $("#inviterModal").modal('hide');
                                genericErrorMessageDisplay(Resources.LoadPopup_Failed);
                            }
                        }
                    })
                    if ($scope.childGroupInfo.length == 1) {
                        
                        $("#inviterModal").on('shown.bs.modal', function () {
                            angular.element("#check" + $scope.childGroupInfo[0].ID).trigger("click");
                        });
                        $scope.childListSelect.push($scope.childGroupInfo[0].ID);
                        var newSelectValue = $("#selectDefaultRel" + $scope.childGroupInfo[0].ID).val();
                        if (newSelectValue && newSelectValue !== '' && newSelectValue !== 0 && newSelectValue !== null) {
                            $scope.unitChanged($scope.childGroupInfo[0].ID, 'add');
                }
                    } else {
                        $("#inviterModal").on('shown.bs.modal', function () {
                            if (!$("#check" + broadCastedData.any.childId).prop("checked")) {
                                angular.element("#check" + broadCastedData.any.childId).trigger("click");
                            }
                        });
                    }
                }
            },
            function (error) {
    }
        )
    }
    //Getting relationship list
    $scope.GetDefaultInviterDetails = function () {
        var language = $.cookie("language");
        DisplaySupportersService.GetDefaultInviterDetails().then(
            function (data) {
            $scope.relationships = data.Relationship;
            },
            function (error) {
    }
        );
    }

      

    //Post Invited Supporter Details
    $scope.postInvitedSupporterDetail = function (childList, lastName, firstName, nickname, message, supporterEmail) {

        

        $scope.showOwnEmailError = false;
        $scope.showOtherPersonEmailError = false;
        if ($scope.childList < 1) {
            $scope.childSelectForSupport = true;
        }
        $.each(supporterData, function (index) {
            var matchedChildId = false;
            if (supporterEmail != undefined && supporterEmail == supporterData[index].PersonEmail) {
                $.each(supporterData[index].SupportedChildren, function (index) {
                    var supportedChildId = this.PersonId;

                    $.each(childList, function (i) {
                            if (childList[i] == supportedChildId) {
                $scope.showOtherPersonEmailError = true;
                            matchedChildId =true;
                            return false;
            }
                        i++;
                    });
                    if (matchedChildId) {
                        return false;
                    }
                });
            }
        if (matchedChildId) {
            return false;
        }

        })

        if (supporterEmail != undefined && supporterEmail == userEmail)
        {
            $scope.showOwnEmailError = true;
        }

        if ($scope.showOwnEmailError != true && $scope.showOtherPersonEmailError != true)
        {
        if (!$('#inviteSupporterForm').valid()) {
            $('#inviteSupporterForm').valid();
            return;
            //TODO proper validation for the whole form
        }
        else {
            //$scope.callService = false;
            $scope.count = 0;

            if ($scope.count < 1) {
                $scope.showErrorChild = true;
            } else {
                $scope.showErrorChild = false;
            }
          
            $scope.callServiceToUpdate($scope.childList, $scope.selectedSupporter.lastName, $scope.selectedSupporter.firstName, $scope.selectedSupporter.nickName, $scope.message, $scope.selectedSupporter.email);
        }
        }
        else
        {
            if ($scope.showOwnEmailError == true) {

                $("#inviterModal").scrollTop(0);

                genericModalErrorDisplayMessage(Resources.SupporterInvitationAsParent_Failed, "invite-supporter-failure-msg");
    }

            if($scope.showOtherPersonEmailError== true)
            {
                $("#inviterModal").scrollTop(0);
                genericModalErrorDisplayMessage(Resources.SupporterInvitationAsOtherSuuporter_Failed, "invite-supporter-failure-msg");
            }
        }
    }

    $scope.callServiceToUpdate = function (childList, lastName, firstName, nickname, message, supporterEmail) {
        //$("#supporterDetailsPage").show();
        $scope.selectedChilds = [];
        for (i = 0; i < childList.length; i++) {
            if ($("#check" + childList[i]).prop("checked")) {
                var dropId = "#selectDefaultRel" + childList[i];
                $scope.selectedChilds.push({
                    ID: childList[i],
                    Relation: $(dropId).children("option").filter(":selected").text()
                })
            }
        }
        
        if ($scope.showForChildEntry) {
            var dropId = "#selectDefaultRel";
            $scope.selectedChilds.push({
                ID: $.cookie("personId"),
            Relation: $(dropId).val()
            })
            var childId = 0;
            var invitationByChild = true;
        }
        else {
            var parentId = $.cookie("personId");
            var childId = 0;
            var invitationByChild = false;
        }
        callServiceToUpdateForm($scope, $rootScope, childList, lastName, firstName, nickname, message, supporterEmail, DisplaySupportersService, parentId, childId, invitationByChild);
    }
    $scope.resetInvitationForm = function () {
        if ($("#firstName").hasClass("error")) {
            $("#firstName").removeClass("error");
        }
        if ($("#lastName").hasClass("error")) {
            $("#lastName").removeClass("error");
        }
        if ($("#emailField").hasClass("error")) {
            $("#emailField").removeClass("error");
        }
        if ($("#messageField").hasClass("error")) {
            $("#messageField").removeClass("error");
        }
        if ($scope.GroupInfo) {
        for (j = 0; j < $scope.GroupInfo.length; j++) {
            var id = $scope.GroupInfo[j].ID;
            if ($("#check" + id).is(":checked")) {
                if ($("#dropdownDiv" + id).hasClass("error")) {
                    $("#dropdownDiv" + id).removeClass("error");
                }
            }
        }
        }
       // if ($scope.isNullOrEmptyOrUndefined($scope.selectedSupporter.previousFirstName)) {
         //   $("#inputSupporterFirstName").val("");
        //} else {
           // $("#inputSupporterFirstName").val($scope.selectedSupporter.previousFirstName);
       // }
        if ($scope.isNullOrEmptyOrUndefined($scope.selectedSupporter.previousLastName)) {
            $("#inputSupporterLastname").val("");
        } else {
            $("#inputSupporterLastname").val($scope.selectedSupporter.previousLastName);
        }
        if ($scope.isNullOrEmptyOrUndefined($scope.selectedSupporter.previousNickName)) {
            $("#inputSupportNickName").val("");
        } else {
            $("#inputSupportNickName").val($scope.selectedSupporter.previousNickName);
        }
        if ($scope.isNullOrEmptyOrUndefined($scope.selectedSupporter.previousEmail)) {
            $("#inputSupportEmail").val("");
        } else {
            $("#inputSupportEmail").val($scope.selectedSupporter.previousEmail);
        }
        $("#Message").val("");

        $("#inviterModal").css("overflow-y", "auto");
    }

    var broadCastedData = null;
    var supporterData = "";
    var userEmail = "";
    $rootScope.$on('inviteSupporterStart', function (event, args) {

        broadCastedData = args;
        
        
        $scope.isSTExceedLmt = args.any.isSTExceedLmtSendfromChild;
        $scope.ChildFirstName = args.any.ChildFirstName;
        $scope.shortTermAmount = args.any.shortTermAmount;

        supporterData = args.any.supporterData;
        userEmail = args.any.personEmail;
        


        $scope.fromTimeLine = args.any.fromTimeLine;
        if (args && args.any && args.any.fromTimeLine) {
            var supporterId = args.any.timelineID;
            var personId = $.cookie("personId");
            $scope.notificationId = supporterId;
            $scope.selectedSupporter = {
                firstName: "",
                lastName: "",
                nickName: "",
                email: ""
            };
            $scope.message = "";
            $("#selectDefaultRel").val("");
                SupporterService.GetSupporterInvitation(supporterId).then(
                    function (data) {
                        $scope.selectedSupporter = {
                            firstName: data.InvitedFirstName,
                            lastName: data.InvitedLastName,
                            nickName: data.InvitedNickName,
                            email: data.InvitedEmail                    
                        };
                        $scope.message = data.InviteMessage;
                        if (!$scope.$$phase) {
                            $scope.$apply();
                        }
                        var inviterChildId = data.InviterChildId;
                        var inviterRelationship = data.InviterRelationship;
                        InviteSupporterModalService.getMyChildrenDetail(personId).then(
                        function (data) {
                            if (data.length == 0) {
                                genericModalErrorDisplayMessage(Resources.LoadPopup_Failed, "invite-supporter-failure-msg");
                            } else {
                                $scope.GroupInfo = [];
                                $scope.childGroupInfo = [];
                                $.each(data, function (index) {
                                    if (data[index].PersonId == inviterChildId) {
                                        $scope.Info = {};
                                        //$scope.childGroupInfo = [];
                                        $scope.Info.childFirstName = data[index].PersonFirstName;
                                        $scope.Info.childLastName = data[index].PersonLastName;
                                        if (data[index].PersonImageUrl) {
                                            $scope.Info.image = data[index].PersonImageUrl;
                                        } else {
                                            $scope.Info.image = images.defaultPersonImage;
                                        }
                                        $scope.Info.ID = data[index].PersonId;
                                        $scope.GroupInfo.push($scope.Info);
                                        $scope.childGroupInfo = $scope.GroupInfo;                                        
                                        $scope.dataforChildselecttionTimeline = data;
                                        $scope.indexforChildselecttionTimeline = index;
                                        $scope.inviterRelationshipChildselecttionTimeline = inviterRelationship;
                                        $("#inviterModal").modal('show');
                                        //$("#selectDefaultRel" + data[index].PersonId).selectpicker("refresh");
                                        return false;
                                    }
                                });
                            }
                        },
                        function (error) {
                        });
                                                
                    },
                        function (error) {
                        }
                );            
        }
        else if (!args.any.setChildLoginEntry) {
            $scope.GetMyChildren();
            $scope.showForChildEntry = false;
            $scope.fromTimeLine = false;
        } else {
            $scope.showForChildEntry = args.any.setChildLoginEntry;

            $scope.selectedSupporter = {
                firstName:"",
                lastName: "",
                nickName: "",
                email: ""
            };
            $scope.message = "";
            $("#selectDefaultRel").val("");
            if (!$scope.$$phase) {
                $scope.$apply();
            }
            $("#inviterModal").modal('show');
            $scope.fromTimeLine = false;
        }
    }
    );
    $("#inviterModal").on('shown.bs.modal', function () {
        if ($scope.fromTimeLine) {
            // $scope.checkvalue = 1;
            var personId = $.cookie("personId");
            if (!$("#check" + $scope.dataforChildselecttionTimeline[$scope.indexforChildselecttionTimeline].PersonId).hasClass("ng-not-empty")) {
                $("#check" + $scope.dataforChildselecttionTimeline[$scope.indexforChildselecttionTimeline].PersonId).trigger("click");
            }
            else {
                angular.element("#selectDefaultRel" + $scope.dataforChildselecttionTimeline[$scope.indexforChildselecttionTimeline].PersonId).closest(".invite-supporter-relation").show();
                //if ($scope.childList > 0) {
                 //   $scope.childSelectForSupport = false;
                //}
                $("#selectDefaultRel" + $scope.dataforChildselecttionTimeline[$scope.indexforChildselecttionTimeline].PersonId).val($scope.inviterRelationshipChildselecttionTimeline);
}
            
            
        }
    });
    $scope.isNullOrEmptyOrUndefined = function (value) {
        if (value === "" || value === null || typeof value === "undefined") {
            return true;
        }
    }
    $scope.init = function () {
        
        $scope.GetDefaultInviterDetails();

        
    }
    $scope.init();

    $scope.unitChanged = function (child, index, relationship) {
        var newvarrel = {
            "index": index,
            "child": child
        };
        
        if ($scope.relationshipcount.length === 0) {
            $scope.relationshipcount.push(newvarrel);
        }
        else {
            if (index === 'add') {
                $scope.relationshipcount.push(newvarrel);
            }
            else {
                var count = 0;
                var arrayindx = '';
                for (var i = 0; i < $scope.relationshipcount.length; i++) {
                    if ($scope.relationshipcount[i].child == child) {
                        count++;
                        arrayindx = i;
                        break;
                    }
                }
                if (count === 0) {
                    $scope.relationshipcount.push(newvarrel);
                }
                else if (index === 'remove') {
                    $scope.relationshipcount.splice(arrayindx, 1);
                }
            }
        }
        if (!$scope.$$phase) {
            $scope.$apply();
        }

    };
    $scope.relationshipChanged = function () {
        var newSelectValue = $("#selectDefaultRel").val()
        var newvarrel = {
            "index": newSelectValue,
            "child": $scope.childListSelect
        };
        if ($scope.relationshipcount.length === 0) {
            $scope.relationshipcount.push(newvarrel);
        }
       
        if (!$scope.$$phase) {
            $scope.$apply();
        }

    };

    $rootScope.$on('ApproveInvitation', function (event, args) {
        $scope.notificationId = args.any.notificationId;
        $scope.approveRejectChildRequest($scope.childList, $scope.selectedSupporter.lastName, $scope.selectedSupporter.firstName, $scope.selectedSupporter.nickName, $scope.message, $scope.selectedSupporter.email, true)
    });
    $rootScope.$on('RejectInvitation', function (event, args) {
        $scope.notificationId = args.any.notificationId;
        $scope.approveRejectChildRequest($scope.childList, $scope.selectedSupporter.lastName, $scope.selectedSupporter.firstName, $scope.selectedSupporter.nickName, $scope.message, $scope.selectedSupporter.email, false)
    });

    $scope.approveRejectChildRequest = function (childList, lastName, firstName, nickname, message, supporterEmail, isApproved) {
            if (!$('#inviteSupporterForm').valid()) {
                $('#inviteSupporterForm').valid();
                return;
            } else {
                var selectedChildren = [];
                for (i = 0; i < childList.length; i++) {
                    if ($("#check" + childList[i]).prop("checked")) {
                        var dropId = "#selectDefaultRel" + childList[i];
                        selectedChildren.push({
                            ID: childList[i],
                            Relation: $(dropId).children("option").filter(":selected").text()
                        })
                    }
                }
                var InvitationMessageViewModel = {
                    InviterFirstName: firstName,
                    InviterLastName: lastName,
                    InviterNickName: nickname,
                    InvitedEmail: supporterEmail,
                    InviteMessage: message
    };
                var postData = {
                    InvitationMessageViewModel: InvitationMessageViewModel,
                    ParentId: $.cookie("personId"),
                    childList: childList,
                    SelectedChildren: selectedChildren,
                    IsApproveByParent: isApproved
                }
                DisplaySupportersService.ApproveRequestByParent(postData).then(
                    function (data) {
                        $scope.sendInvitation = true;
                        //$("#sendTheInvitationModal").modal("hide");
                        $("#inviterModal").modal("hide");
                        if(isApproved)
                        genericSuccessMessageDisplay(Resources.InviteSupporter_Success);
                        else
                            genericSuccessMessageDisplay(Resources.SupporterRejectByparent);
                        $rootScope.$broadcast('getAllSupporterbyParent');
                        var notificationId = $scope.notificationId;
                        //$("#notificationId" + notificationId).attr("disabled", "disabled").addClass("disabled");
                        angular.element("#notificationIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                        angular.element("#notificationId" + notificationId).find(".notifications-action-btns").find("button").attr("disabled", "disabled").addClass("disabled");
                        angular.element("#timelineIds" + notificationId).attr("disabled", "disabled").addClass("disabled");
                        angular.element("#timelineIds" + notificationId).parent().removeClass("actionable").addClass("non-actionable");
                        $rootScope.$broadcast('refresh-timeline', {});//added by anshul for invite supporter module
                    },
                    function (response) {
                        //$("#sendTheInvitationModal").modal("hide");
                        genericModalErrorDisplayMessage(Resources.InviteSupporter_Failed, "invite-supporter-failure-msg");
                        $('html, body').animate({ scrollTop: '0px' }, 1000);
                        $('#inviterModal').animate({ scrollTop: '0px' }, 1000);

                    }
                );
            }

    }
}]);

function callServiceToUpdateForm($scope, $rootScope, childList, lastName, firstName, nickname, message, supporterEmail, DisplaySupportersService, parentId, childId, invitationByChild) {

    // Disable button to prevent multiple invitations
    //$("#sendInviteSupporter").attr("disabled", "disabled").addClass("disabled");
    var languageid = 0;
    if ($scope.languageid == "FR") {
        languageid = 1;
    } else if ($scope.language == "NL") {
        languageid = 2;
    }

    localStorage.setItem("supporterEmail", supporterEmail);


    var InvitationMessageViewModel = {
        InviterFirstName: firstName,
        InviterLastName: lastName,
        InviterNickName: nickname,
        InvitedEmail: supporterEmail,
        InviteMessage: message
    };
    var Relationship = [];
    var IPersonViewModel = [];
    var selectedChildId = childList;
    var inviterRelationShip = "";



    var postData = {
        InvitationMessageViewModel: InvitationMessageViewModel,
        IPersonViewModel: IPersonViewModel,
        InviterRelationship: inviterRelationShip,
        Relationship: Relationship,
        SelectedChildId: null,
        SelectedChildren: $scope.selectedChilds,
        ParentId: parentId,
        OldSelectedChildId: childId,
        InvitationId: 0,
        InvitationByChild: invitationByChild,
        InvitationStatus: 0,
        LanguageId: languageid
    }

    DisplaySupportersService.PostInvitedSupporterDetail(postData).then(
        function (data) {
        $scope.sendInvitation = true;
        //$("#sendTheInvitationModal").modal("hide");
        $("#inviterModal").modal("hide");
        genericSuccessMessageDisplay(Resources.InviteSupporter_Success);

        $rootScope.$broadcast('getAllSupporterbyParent');
        },
        function (error) {
            //$("#sendTheInvitationModal").modal("hide");
            // genericModalErrorDisplayMessage(Resources.InviteSupporter_Failed, "invite-supporter-failure-msg");
            if (error.data) {
                
                if (error.data.ExceptionMessage == errorExceptionCode.inviteParentSelf) {
                    genericModalErrorDisplayMessage(Resources.SupporterInvitationAsParent_Failed, "invite-supporter-failure-msg");
                }
                else if (error.data.ExceptionMessage == errorExceptionCode.invitationBlockSupporter) {
                    genericModalErrorDisplayMessage(Resources.SupporterInvitationAsOtherSuuporter_Failed, "invite-supporter-failure-msg");
                }
                else if (error.data.ExceptionMessage == errorExceptionCode.invitationToAdmin) {
                    genericModalErrorDisplayMessage(Resources.SupporterInvitationToAdmin_Failed, "invite-supporter-failure-msg");
                }
                else if (error.data.ExceptionMessage == errorExceptionCode.invitationToPendingSupporter) {
                    genericModalErrorDisplayMessage(Resources.SupporterInvitationAsOtherSuuporter_Failed, "invite-supporter-failure-msg");
                }
                else if (error.data.ExceptionMessage == errorExceptionCode.invitationToExistingSupporter) {
                    genericModalErrorDisplayMessage(Resources.SupporterInvitationAsOtherSuuporter_Failed, "invite-supporter-failure-msg");
                }
                else if (error.data.ExceptionMessage == errorExceptionCode.invitationToAwaitingSupporter) {
                    genericModalErrorDisplayMessage(Resources.SupporterInvitationToAwaiting_Failed, "invite-supporter-failure-msg");
                }
                else if (error.data.ExceptionMessage == errorExceptionCode.inviationToOwnChild) {
                    genericModalErrorDisplayMessage(Resources.SupporterInvitationToOwnChild, "invite-supporter-failure-msg");
                } else {
                    genericModalErrorDisplayMessage(error.data, "invite-supporter-failure-msg");
                }
            } else {
            genericModalErrorDisplayMessage(Resources.InviteSupporter_Failed, "invite-supporter-failure-msg");
            }
            $('html, body').animate({ scrollTop: '0px' }, 1000);
            $('#inviterModal').animate({ scrollTop: '0px' }, 1000);
            
        }
    );
}