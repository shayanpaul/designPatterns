﻿childPage.controller("parentalSettingChangeController", ["$scope", "$rootScope", "$stateParams", "$state", function ($scope, $rootScope, $stateParams, $state) {
    $scope.showMsgForProjects = false;
    $scope.showMsgForShortTerm = false;
    $scope.showBtnsFromSavingsAcademy = false;
    $scope.$on("parental-setting-change-triggered", function (event, args) {
        $scope.childSelectedFirstName = args.childFirstName;
        $scope.showMsgForProjects = args.showMsgForProjects;
        $scope.showMsgForShortTerm = args.showMsgForShortTerm;
        $scope.showBtnsFromSavingsAcademy = args.showBtnsFromSavingsAcademy;
        if ($scope.showMsgForProjects || $scope.showBtnsFromSavingsAcademy) {
            angular.element(".msg-for-projects-option").css('display', 'block');
            angular.element(".msg-for-short-term-option").css('display', 'none');
        }
        else {
            angular.element(".msg-for-projects-option").css('display', 'none');
            angular.element(".msg-for-short-term-option").css('display', 'block');
        }
    });

    $scope.revertBackSetting = function (flag) {
        if (flag) {
            $rootScope.$broadcast("revert-setting-for-saving-academy-option");
        }
        else {
            $rootScope.$broadcast("revert-setting-for-short-term-option");
        }
    }
    $scope.implementNewSetting = function (flag) {
        if (flag) {
            $rootScope.$broadcast("implement-setting-for-saving-academy-option");
        }
        else {
            $rootScope.$broadcast("implement-setting-for-short-term-option");
        }
    }
    $scope.implementNewSettingFromSavingsAcademy = function () {
        $rootScope.$broadcast("implement-setting-for-level-two", {'forId':1});
    }
}]);
