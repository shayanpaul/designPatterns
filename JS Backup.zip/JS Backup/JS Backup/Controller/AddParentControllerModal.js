﻿childPage.controller("addParentController", ["$scope", "$rootScope", "$filter", "EditProfileService", "InvitationService", "ChildProfileService", "WebApiService", "savingSchoolService", "DisplaySupportersService", "$window", "ModalFactory", "utilityFactory", function ($scope, $rootScope, $filter, EditProfileService, InvitationService, ChildProfileService, WebApiService, savingSchoolService, DisplaySupportersService, $window, ModalFactory, utilityFactory) {

    $rootScope.$on('getSelected-childId', function (event, args) {
        $scope.selectedChildID = args.any.selectedChildId;
        $scope.parentPersonId = args.any.parentPersonId;
        $scope.childFirstName = args.any.childFirstName;
    });


    $rootScope.$on('deleteParent-started', function (event, args) {
        $scope.adminNickName = args.any.adminNickName;
        $scope.delfirstName = args.any.firstName;
        $("#deleteParentConfirmModal").modal("show");
    });
    $scope.DeleteAdmin = function (deleteBtnEvent) {
        $rootScope.$broadcast('deleteParent-confirm');
    };

    $scope.validEmail = function () {
        var resultEmailval = utilityFactory.validEmail($scope.email);
        $scope.inputAdminEmail = resultEmailval[0];
        $scope.isAValidEmailID = resultEmailval[1];

    }
    $scope.removeErrorStyle = function () {
        $scope.isAValidEmailID = false;
        $scope.inputAdminEmail = {
            "required": false,
            "pattern": false
        };
    }
    $scope.SaveAdminForChild = function (firstName, lastName, nickName, adminEmail) {

        if (adminEmail != $rootScope.PersonEmail) {

        if (!$('#addParentform').valid()) {
            $('#addParentform').valid();
            return;
        } else {

                var invitationMessageViewModel = {
                    invitedFirstName: firstName,
                    invitedLastName: lastName,
                    invitedNickName: nickName,
                    invitedEmail: adminEmail,
                };
                var postData = {
                    invitationMessageViewModel: invitationMessageViewModel,
                    ParentId: $scope.parentPersonId,
                    selectedChildId: $scope.selectedChildID,
                    invitationId: 0,
                    cultureCode: $scope.language,
                }
                
                InvitationService.PostInvitedAdminDetail(postData).then(
                    function (data) {
                        $("#addParentModal").modal("hide");
                        $scope.ResetAdminForChild();
                        genericSuccessMessageDisplay(Resources.InviteAdmin_Success);
                        $rootScope.$broadcast('addParent-confirm');
                    },
                    function (error) {
                        $('#addParentModal').animate({ scrollTop: '0px' }, 1000);
                        if (error.data) {
                            if (error.data.ExceptionMessage == errorExceptionCode.inviteAdminSelf) {
                                genericModalErrorDisplayMessage(error.data.InnerException.ExceptionMessage, "add-admin-failure-msg");
                            }
                            else if (error.data.ExceptionMessage == errorExceptionCode.inviteExistingAdmin) {
                                genericModalErrorDisplayMessage(error.data.InnerException.ExceptionMessage, "add-admin-failure-msg");
                            }
                            else {
                                genericModalErrorDisplayMessage(Resources.InviteAdmin_Failed, "add-admin-failure-msg");
                            }

                        } else {
                            genericModalErrorDisplayMessage(Resources.InviteAdmin_Failed, "add-admin-failure-msg");
                        }
                        
                    }
                );
            }
        }
        else
        {
            $('#addParentModal').animate({ scrollTop: '0px' }, 1000);
            genericModalErrorDisplayMessage(Resources.AdminInvitationAsParent_Failed, "add-admin-failure-msg");

        }

    };
    $scope.ResetAdminForChild = function (firstName, lastName, nickName, adminEmail) {
        $scope.firstName = "",
        $scope.lastName = "",
        $scope.nickName = "",
        $scope.email = "";
        $scope.iConfirmParent = "";
    };
}]);