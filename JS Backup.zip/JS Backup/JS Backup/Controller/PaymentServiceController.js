﻿/*global $, angular, jQuery, alert, window*/
/*jslint browser: true*/
/*jslint this:true */
/*jslint white:true, for:true */
/*jslint  devel: true */
myAppangular.controller("paymentServiceController", ["$scope", "$filter", "$state", "WebApiService", "HeaderServices", "paymentService", "$window", "FormSubmitter", function ($scope, $filter, $state, WebApiService, HeaderServices, paymentService, $window, FormSubmitter) {
    $scope.paymentSucess = true;
    $scope.paymentError = true;
    $scope.paymentLongType;
    $scope.paymentShortType;
    $scope.LongTermPlanPresent = false;
    $scope.ShortTermPlanPresent = false;
    $scope.hideGoToAaGje = true;
    $scope.hideChildOverview = true;
    $scope.hideGoToHome = true;
    $scope.showGoToContributeButton = true;
    $scope.paymentReference;
    $scope.paymentDetail = {};
    localStorage.fromPaymentStatusScreen = true;
    $scope.init = function (entryPointForContribution) {
        var valuetocheck = $.cookie("PaymentStatus");
        $scope.contributeEntryPoint = $.cookie("entryPoint");// free contributor
        $(".navbar-offcanvas").hide();
        $(".webapp-container #wrapper").css("margin-top", "60px");
        if (valuetocheck !== "" && valuetocheck !== null && valuetocheck !== undefined && valuetocheck !== "null") {
            if ($.cookie("PaymentTransactionId"))/* for free contributor*/ {
                $scope.paymentTransactionId = $.cookie("PaymentTransactionId");
            }

            if (valuetocheck === PaymentAccepted) {
                $scope.paymentSucess = false;
                $scope.paymentError = true;
                if ($scope.paymentTransactionId !== "" || $scope.paymentTransactionId !== null || $scope.paymentTransactionId !== undefined) {
                    $scope.updateTransactionStatus(true);
                    $scope.getTransactionStatus(true);
                }
            } else {
                $scope.paymentSucess = true;
                $scope.paymentError = false;
                if ($scope.paymentTransactionId !== "" || $scope.paymentTransactionId !== null || $scope.paymentTransactionId !== undefined) {
                    $scope.updateTransactionStatus(false);
                    $scope.getTransactionStatus(false);
                }
            }
        }
    };

    $scope.updateTransactionStatus = function (status) {
        $scope.paymentDetail.PaymentReferenceNumber = $scope.paymentTransactionId;
        $scope.paymentDetail.Status = status;
        $scope.paymentDetail.FromBasket = localStorage.getItem("isFromBasket");
        if (status == false) {
            $("#btn-contributer").hide();
            $("#btn-retry").show();
        }
        else if (status == true) {
            $("#btn-retry").hide();
            $("#btn-contributer").show();
        }
        var res = paymentService.updateTransactionStatus($scope.paymentTransactionId, $scope.paymentDetail.Status);//.success(function (data, status) {
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (d) {
            }, function (error) {
            });
        }
    };

    $scope.getTransactionStatus = function (status) {
        $scope.paymentDetail.Status = status;

        var res = paymentService.getTransactionStatus($scope.paymentTransactionId, $scope.paymentDetail.Status);
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (data) {
                $scope.paymentDate = $.cookie("TransactionDate");
                $scope.transactionId = $.cookie("PaymentTransactionId");
                $scope.transChildInfo = {};
                $scope.confirmTransactionDetails = [];
                if (($scope.contributeEntryPoint == eventEntryPoint || $scope.contributeEntryPoint == inviteSupEntryPoint)) {
                    $scope.hideGoToAaGje = false;
                    $scope.showGoToContributeButton = false;
                } else if (localStorage.getItem("fromTimeline") == "true" || localStorage.getItem("fromNotification") == "true") {
                    localStorage.setItem("fromTimeline", false);
                    localStorage.setItem("fromNotification", false);
                    $scope.showGoToContributeButton = true;
                    $scope.hideGoToHome = false;
                } else if ((data.length == 1 && data[0].TotalShortTermAmount > 0 && data[0].TotalLongTermAmount > 0) || data.length > 1) {
                    $scope.showGoToContributeButton = true;
                    $scope.hideGoToHome = false;
                } else if ((data.length == 1 && data[0].TotalShortTermAmount > 0 && data[0].TotalLongTermAmount == 0) || (data.length == 1 && data[0].TotalShortTermAmount == 0 && data[0].TotalLongTermAmount > 0)) {
                    $scope.showGoToContributeButton = true;
                    $scope.hideChildOverview = false;
                }

                $scope.paymentReference = data[0].PaymentReference;

                $.each(data, function (index) {
                    if (data[index].TotalShortTermAmount > 0 && data[index].TotalLongTermAmount > 0) {
                        if (data[index].TotalLongTermAmount > 0) {
                            $scope.transChildInfo.childIdInPayment = data[index].ChildId;
                            $scope.transChildInfo.childNameInPayment = data[index].ChildName;
                            $scope.transChildInfo.totalAmount = data[index].TotalLongTermAmount;
                            $scope.transChildInfo.childPlanName = Resources.LongTerm.toLowerCase();
                            $scope.confirmTransactionDetails.push($scope.transChildInfo);
                            $scope.transChildInfo = {};
                        }
                        if (data[index].TotalShortTermAmount > 0) {
                            $scope.transChildInfo.childIdInPayment = data[index].ChildId;
                            $scope.transChildInfo.childNameInPayment = data[index].ChildName;
                            $scope.transChildInfo.totalAmount = data[index].TotalShortTermAmount;
                            $scope.transChildInfo.childPlanName = Resources.ShortTerm.toLowerCase();
                            $scope.confirmTransactionDetails.push($scope.transChildInfo);
                            $scope.transChildInfo = {};
                        }
                    } else {
                        if (data[index].TotalLongTermAmount > 0) {
                            $scope.childIdConfirm = data[index].ChildId;
                            $scope.childNameConfirm = data[index].ChildName;
                            $scope.transChildInfo.childNameInPayment = data[index].ChildName;
                            $scope.transChildInfo.totalAmount = data[index].TotalLongTermAmount;
                            $scope.transChildInfo.childPlanName = Resources.LongTerm.toLowerCase();
                            $scope.confirmTransactionDetails.push($scope.transChildInfo);
                            $scope.transChildInfo = {};
                        }
                        else if (data[index].TotalShortTermAmount > 0) {
                            $scope.childIdConfirm = data[index].ChildId;
                            $scope.childNameConfirm = data[index].ChildName;
                            $scope.transChildInfo.childNameInPayment = data[index].ChildName;
                            $scope.transChildInfo.totalAmount = data[index].TotalShortTermAmount;
                            $scope.transChildInfo.childPlanName = Resources.ShortTerm.toLowerCase();
                            $scope.confirmTransactionDetails.push($scope.transChildInfo);
                            $scope.transChildInfo = {};
                        }
                    }
                })

                $scope.getUpdatedBasketCount($scope.personId);
            }, function (error) {
            });
        }
    }

    $scope.payOnRetry = function () {
        $scope.amount = 0;
        var newPaymentTransactionId = createUUID();

        var res = paymentService.GetAmountOnRetry($scope.paymentTransactionId, newPaymentTransactionId);//.success(function (data) {
        if (!isEmptyOrUndefinedOrNull(res)) {
            res.then(function (data) {
                var postData = {
                    UserId: $scope.personId,
                    Amount: data,
                    TransactionId: $scope.paymentReference,
                    PaymentReference: newPaymentTransactionId
                };

                paymentService.paymentGateway(postData).success(function (paymentRes, status) {
                    FormSubmitter.submit(paymentRes.RedirectionUrl, "POST", paymentRes);
                })
                    .error(function (paymentRes, status) {
                        genericErrorMessageDisplay(paymentRes);
                    });
            },
            function (error) {
            });
        }
    };

    $scope.childOverview = function (paymentChildId) {
        linkUrl = "/" + currentLanguage + "/home/child/" + paymentChildId + "/plan/";
        location.href = linkUrl;
    };
    $scope.makeAnotherContribution = function (SelectedChild, contributorId) {
        //window.location.href = "/" + currentLanguage + "/Home/Members/" + $.cookie("personId");
        $state.go("contribute");
    };
    $scope.getUpdatedBasketCount = function () {
        if ($scope.personId != null) {
            var res = HeaderServices.getHeaderCount($scope.personId);
            if (res) {
                res.then(function (data) {
                    $scope.basketCounter = data.BasketCount;
                    $scope.childCounter = data.ChildCount;
                    $("#basketCount").html($scope.basketCounter);
                    if ($scope.basketCounter == 0) {
                        $("#basketCount").hide();
                    }
                },
                function (error) {
                });
            }
        }
    }

    function createUUID() {
        // http://www.ietf.org/rfc/rfc4122.txt
        var s = [];
        var hexDigits = "0123456789abcdef";
        for (var i = 0; i < 36; i++) {
            s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
        }
        s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
        s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
        s[8] = s[13] = s[18] = s[23] = "-";

        var uuid = s.join("");
        return uuid;
    }
    $scope.goToContribute = function (obj, onretry) {
        localStorage.setItem("contributeCond", obj);
        localStorage.setItem("isContributionUpdate", false);
        localStorage.setItem("fromTimeline", false);
        localStorage.setItem("fromSuccessPayment", fromSuccessPayment);
        localStorage.setItem("locationCalledFrom", 'updateViaPaymentConfirmationPage');
        if (onretry && onretry == 'onretry') {
            localStorage.setItem("fromSuccessPayment", 'onretry');
            localStorage.setItem("locationCalledFrom", 'updateViaPaymentConfirmationPageOnRetry');
        }
        var expires = new Date();
        expires.setUTCFullYear(expires.getUTCFullYear() - 1);
        document.cookie = "entryPoint=; expires=" + expires.toUTCString() + "; path=/";
        window.location.href = "/" + currentLanguage + "/Contribute";
    };
    $scope.goToAaGje = function () {
        window.location.href = "/AaGje"
    }
    $scope.goToHome = function () {
        window.location.href = "/" + currentLanguage + "/Home/Members";
    }
}]);