﻿$(document).ready(function () {
    var projectId = getParameterByName('pId');
    var isSavingSchoolNavigation = getParameterByName('ss');    
    $("#btnInviteASupporter").hide();
    $("#btnSavingSchool").hide();
    if (localStorage.isChild == "true" && localStorage.isAdultWithParent == "true" && localStorage.clickSS == "false") {
        $('.desc-area').removeClass('active');
        $('#child-plan-page').addClass('active');
    }
    else if (((localStorage.isChild == "true" && localStorage.isShortTermChildPage === "true") || isSavingSchoolNavigation == "true") && localStorage.clickSS == "true") {
        localStorage.setItem("clickSS", false);
        $('.desc-area').removeClass('active');
        $('#child-savingSchool-page').addClass('active');
        $(".child-overview-left-panel-modal ul > li > div ").removeClass("active-menu");
        $("#savingSchool").parent().addClass("active-menu");
        
        setTimeout(function () {
            $("#savingSchool").trigger('click');
        }, 500)
        if ($(window).width() < 768) {
            $("#child-modal-span").html($("#savingSchool").html());
            $("#child-modal-span").append('<span class="glyphicon glyphicon-triangle-bottom hidden-sm hidden-md hidden-lg"></span>');
            $(".secondary-nav-body ul li").removeClass("active-menu");
            $(".secondary-nav-body ul li:nth-child(2)").addClass("active-menu");
            
        }
    }
    else if (localStorage.isChild == "false" || (localStorage.isChild == "true" && localStorage.isShortTermChildPage === "false")) {
        $('.desc-area').removeClass('active');
        $('#child-plan-page').addClass('active');
    }
    if ($(document).width() > 991) {
        $("#myCarousel").removeClass("slide");
    } 

    $("#savingSchool").on("click", function () {
        $("#btninvitesupporter").hide();
        $("#btneventcontribute").hide();
        $("#btnSavingSchool").show();
        $("#btnInviteASupporter").hide();
        $('.desc-area').hide();
        $('#child-savingSchool-page').show();
        $("#mobileMenuSelectedIcon").removeClass();
        $("#mobileMenuSelectedIcon").addClass("glyphicon-aagje-saving-school-1");
    });
    $("#supporter").on("click", function () {
        $("#btneventcontribute").hide();
        $("#btninvitesupporter").show();
        $("#btnInviteASupporter").show();
        $("#btnSavingSchool").hide();
        $('.desc-area').hide();
        $('#child-supporter-page').show();
        $("#mobileMenuSelectedIcon").removeClass();
        $("#mobileMenuSelectedIcon").addClass("glyphicon-aagje-supporter");
    });
    $("#plan").on("click", function () {
        $("#btninvitesupporter").hide();
        $("#btneventcontribute").show();
        $("#btnInviteASupporter").hide();
        $("#btnSavingSchool").hide();
        $('.desc-area').hide();
        $('#child-plan-page').show();
        $("#mobileMenuSelectedIcon").removeClass();
        $("#mobileMenuSelectedIcon").addClass("glyphicon-aagje-plan-pig");
    });
    $("#event").on("click", function () {
        $("#btninvitesupporter").hide();
        $("#btneventcontribute").show();
        $("#btnInviteASupporter").hide();
        $("#btnSavingSchool").hide();
        $('.desc-area').hide();
        $('#child-event-page').show();
        $("#mobileMenuSelectedIcon").removeClass();
        $("#mobileMenuSelectedIcon").addClass("glyphicon-aagje-calendar");
    });
    $("#editProfile").on("click", function () {
        $("#btninvitesupporter").hide();
        $("#btneventcontribute").show();
        $("#btnInviteASupporter").hide();
        $("#btnSavingSchool").hide();
        $('.desc-area').hide();
        $('#child-profile-page').show();
        $("#mobileMenuSelectedIcon").removeClass();
        $("#mobileMenuSelectedIcon").addClass("glyphicon-aagje-edit-profile");
    });
    $(".slide-left").click(function () {
        $(".trans-history").animate({ "left": '0%' }, function () {            
            //var tranheight = $(".trans-history").outerHeight();
            //$("#divDescription").css("height", tranheight + "px");
            //$(".about-metnav-desc").css("height", tranheight + "px");
        });
        $(".about-metnav-desc > .clearfix,.about-metnav-desc .long-term,.about-metnav-desc .short-term").animate({ "left": "-100%" });
    });
    $(".prev-nav-item").click(function () {
        $(".trans-history").animate({ "left": '100%' }, function () {
            //$("#divDescription").css("height", "auto");
            //$(".about-metnav-desc").css("height", "auto");
        });
        $(".about-metnav-desc > .clearfix,.about-metnav-desc .long-term,.about-metnav-desc .short-term").animate({ "left": "0%" });
    });
    
    var elementHeight = $("#divDescription").height();
   // $(".trans-history").css("min-height", elementHeight);
    var prevX = -1;
    var widthOfTheWindow = $(window).width();
    var widthOfTheDragItem = $('.longterm-graph').width();
    var s = widthOfTheWindow - (widthOfTheDragItem + 20);
    var rightScroll = 0;
    var leftScroll = 0;
    $('.longterm-graph').draggable({
        axis: "x",
        scrollSpeed: 100,
        scrollSensitivity: 100,
        drag: function (e, ui) {
            
            if (ui.originalPosition.left > ui.position.left) {
                leftScroll = leftScroll + (ui.originalPosition.left - ui.position.left);
                rightScroll = rightScroll - (ui.originalPosition.left - ui.position.left);
                if (s >= ui.position.left) {
                    prevX = -1;
                    return false;
                }
            } else {
                leftScroll = leftScroll - (ui.position.left - ui.originalPosition.left);
                rightScroll = rightScroll + (ui.position.left - ui.originalPosition.left);
                if (rightScroll > 20) {
                    return false;
                }
        }
        }
    });
})

function disableDraggle() {
    $('.longterm-graph').draggable({revert: true });
}

function enableDraggable() {
}

function showChildSupporter() {
    $("#supporterDetailsPage").hide();
    $("#supporterDetailsHistory").show();
}
function getParameterByName(name) {
    var regexS = "[\\?&]" + name + "=([^&#]*)",
  regex = new RegExp(regexS),
  results = regex.exec(window.location.search);
    if (results == null) {
        return "";
    } else {
        return decodeURIComponent(results[1].replace(/\+/g, " "));
    }
}