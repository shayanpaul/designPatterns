﻿var u = 'unknown',
    x = 'X',
    m = function (r, h) {
        for (var i = 0; i < h.length; i = i + 1) {
            r = r.replace(h[i][0], h[i][1]);
        }
        return r;
    },
    c = function (i, a, b, c) {
        var r = {
            name: m((a.exec(i) || [u, u])[1], b)
        };
        r[r.name] = true;
        r.version = (c.exec(i) || [x, x, x, x])[3];
        if (r.name.match(/safari/) && r.version > 400) {
            r.version = '2.0';
        }
        if (r.name === 'presto') {
            r.version = ($.browser.version > 9.27) ? 'futhark' : 'linear_b';
        }
        r.versionNumber = parseFloat(r.version, 10) || 0;
        r.versionX = (r.version !== x) ? (r.version + '').substr(0, 1) : x;
        r.className = r.name + r.versionX;
        return r;
    };
a = navigator.userAgent;
a = (a.match(/Opera|Navigator|Minefield|KHTML|Chrome/) ? m(a, [
    [/(Firefox|MSIE|KHTML,\slike\sGecko|Konqueror)/, ''],
    ['Chrome Safari', 'Chrome'],
    ['KHTML', 'Konqueror'],
    ['Minefield', 'Firefox'],
    ['Navigator', 'Netscape']
]) : a).toLowerCase();
var browser = c(a, /(camino|chrome|firefox|netscape|konqueror|lynx|msie|opera|safari|rv|Edge)/, [], /(camino|chrome|firefox|netscape|netscape6|opera|version|konqueror|lynx|msie|safari|rv|Edge)(\/|\s)([a-z0-9\.\+]*?)(\;|dev|rel|\s|$)/);
var layout = c(a, /(gecko|konqueror|msie|opera|webkit)/, [
    ['konqueror', 'khtml'],
    ['msie', 'trident'],
    ['opera', 'presto']
], /(applewebkit|rv|konqueror|msie)(\:|\/|\s)([a-z0-9\.]*?)(\;|\)|\s)/);
var os = {
    name: (/(win|mac|linux|sunos|solaris|iphone|ipad)/.exec(navigator.platform.toLowerCase()) || [u])[0].replace('sunos', 'solaris')
};
var d = document.getElementsByTagName('html');
d[0].className = d[0].className + " " + [os.name, browser.name, browser.className, layout.name, layout.className].join(' ');


function get_browser() {
    var ua = navigator.userAgent,
        tem, M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
    if (/trident/i.test(M[1])) {
        tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
        return 'IE ' + (tem[1] || '');
    }
    if (M[1] === 'Chrome') {
        tem = ua.match(/\bOPR\/(\d+)/)
        if (tem != null) {
            return 'Opera ' + tem[1];
        }
    }
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
    if ((tem = ua.match(/version\/(\d+)/i)) != null) {
        M.splice(1, 1, tem[1]);
    }
    return M[0];
}

function get_browser_version() {
    var ua = navigator.userAgent,
        tem, M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
    if (/trident/i.test(M[1])) {
        tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
        return 'IE ' + (tem[1] || '');
    }
    if (M[1] === 'Chrome') {
        tem = ua.match(/\bOPR\/(\d+)/)
        if (tem != null) {
            return 'Opera ' + tem[1];
        }
    }
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
    if ((tem = ua.match(/version\/(\d+)/i)) != null) {
        M.splice(1, 1, tem[1]);
    }
    return M[1];
}