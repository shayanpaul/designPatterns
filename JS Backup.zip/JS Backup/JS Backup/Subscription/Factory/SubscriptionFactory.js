﻿subscriptionModule.factory('subscriptionFactory', ['$http', "$rootScope", "FactoryHelper", function ($http,$rootScope, FactoryHelper) {
    var subscriptionDetails = {
        "personalDetails": '',
        "childDetails": '',
        "questionDetails": '',
        "productDetails": '',
        "orderDetails": ''
    };
    var promocodeapplied = '';
    var fullProduct = '';
    var allPoliticalRealtionDetails = [];
    var allProfessionalDetails = [];
    var allfunctionDetails = [];
    var allCountryList = [];
    var allZiplist = [];

    var questionNumber = false;
    var subscriptionParentQstxt = '';
    var subscriptionchildQstxt = '';
    //var allcountires =
    var parentPage = false;
    var eidCheck = false;
    var parentDOB = "";
    var childStatus = false;
    var partnershipId = 0;
  
   
    var changeDateFormat = function(date) {
        var m_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        if (date) {
            var today = new Date(date);
        } else {
            var today = new Date();
        }
        var dd = today.getDate();
        var mm = m_names[today.getMonth()]; //January is 0!

        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd
        }

        today = dd + ' ' + mm + ' ' + yyyy;

        return today;
    };

   
    
    var convertUTCDateToLocalDate = function(date) {
        var newDate = new Date(date.getTime() + date.getTimezoneOffset() * 60 * 1000);

        var offset = date.getTimezoneOffset() / 60;
        var hours = date.getHours();

        newDate.setHours(hours - offset);

        return newDate;
    }
    var getChildDataforRadio = function () {
        return subscriptionDetails.personalDetails.PendingSubscriptionView;
    }
    var validEmail = function (email) {
        var inputSupporterEmail = {
            "required": false,
            "pattern": false
        };
        isAValidEmailID = true;
        var regexpemailFirstPart = /^[a-z0-9A-Z\! \# \$ \% \& \' \* \+ \- \/ \= \? \^ \_ \` \{ \| \} \~]+([\.-]?[a-z0-9A-Z\! \# \$ \% \& \' \* \+ \- \/ \= \? \^ \_ \` \{ \| \} \~]+)*$/;
        var regexpemaillastPart = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        //$scope.isAValidEmailID = Inputmask.isValid(email, { alias: "email" });
        if (!email || email == "" || email == null || email == 0) {
            inputSupporterEmail = {
                "required": true,
                "pattern": false
            };
            isAValidEmailID = false;
        } else {
            if (email.indexOf('@') == -1 || (email.match(/@/g) || []).length > 1) {
                inputSupporterEmail = {
                    "required": false,
                    "pattern": true
                };
                isAValidEmailID = false;
            } else {
                var emailArrayforval = email.split("@");
                var firstPartEmailVal = emailArrayforval[0];
                var lastPartEmailVal = emailArrayforval[1];

                if (!firstPartEmailVal || firstPartEmailVal == "" || firstPartEmailVal == null || firstPartEmailVal == 0) {
                    inputSupporterEmail = {
                        "required": false,
                        "pattern": true
                    };
                    isAValidEmailID = false;
                } else if (!lastPartEmailVal || lastPartEmailVal == "" || lastPartEmailVal == null || lastPartEmailVal == 0) {
                    inputSupporterEmail = {
                        "required": false,
                        "pattern": true
                    };
                    isAValidEmailID = false;
                } else if (!regexpemailFirstPart.test(firstPartEmailVal) || !regexpemaillastPart.test(lastPartEmailVal)) {
                    inputSupporterEmail = {
                        "required": false,
                        "pattern": true
                    };
                    isAValidEmailID = false;
                } else {
                    inputSupporterEmail = {
                        "required": false,
                        "pattern": false
                    };
                    isAValidEmailID = true;
                }
            }
        }

        return ([inputSupporterEmail, isAValidEmailID])
    };
    var getallZiplist = function (zip) {
         
        var apiUrl = '/common/zipcode/' + zip + '/cityzipcodedetails';

        return FactoryHelper.CallApiGet(apiUrl);
    };
    var setMappingDetails = function (allPoliticalRealtionDetailsSet, allProfessionalDetailsSet, allfunctionDetailsSet, allCountryListSet, allZiplist) {
        allPoliticalRealtionDetails = allPoliticalRealtionDetailsSet;
        allProfessionalDetails = allProfessionalDetailsSet;
        allfunctionDetails = allfunctionDetailsSet;
        allCountryList = allCountryListSet;
        allZiplist = allZiplist;
    };

    var getMappingDetails = function() {
        var mappingDetails = {
            "allPoliticalRealtionDetails": allPoliticalRealtionDetails,
            "allProfessionalDetails": allProfessionalDetails,
            "allfunctionDetails": allfunctionDetails,
            "allCountryList": allCountryList,
            "allZiplist": allZiplist
        };
        return mappingDetails;
    }
    var setfullproduct = function (data) {
        fullProduct = data;
        };
    var getfullproduct = function (data) {
        return fullProduct;
        };

    function OrderService(quoteDetail) {
        var apiUrl = '/productonboarding/orderservice';

        return FactoryHelper.CallApiPost(apiUrl, quoteDetail);
    };

    var setquestionDetails = function(data) {
        subscriptionDetails.questionDetails = data;
    }
    var getquestionDetails = function() {
        return subscriptionDetails.questionDetails;
    }

    var setproductDetails = function(data) {
        subscriptionDetails.productDetails = data;
    }
    var getproductDetails = function() {
        return subscriptionDetails.productDetails;
    }
    var setPersonalDetails = function(data) {
        subscriptionDetails.personalDetails = data;
    }

    var wholeSubDetails = function(data) {
        return subscriptionDetails;
    }

    var getPersonalDetails = function(data) {
        return subscriptionDetails.personalDetails;
    }

    var setProofOfIdentity = function(data) {
        subscriptionDetails.personalDetails.ProofOfIdentity.FrontImage = data.fornt;
        subscriptionDetails.personalDetails.ProofOfIdentity.BackImage = data.back;
    }

    var setOrderDetails = function(data) {
        subscriptionDetails.orderDetails = data;
    }
    var getOrderDetails = function() {
        return subscriptionDetails.orderDetails;
    }

    var getallpoliticalRealations = function(ischild) {
        if (ischild) {
            var apiUrl = '/common/ischild/true/politicalrelations';
        } else {
            var apiUrl = '/common/ischild/false/politicalrelations';
        }
        // var apiUrl = '/members/ischild'+ +'allpoliticalrelations';
        //var apiUrl = '/members/allprofessions';
        return FactoryHelper.CallApiGet(apiUrl);
    };
    var getallCountries = function(parentID) {
        var apiUrl = '/common/countries';
        //var apiUrl = '/members/allprofessions';
        return FactoryHelper.CallApiGet(apiUrl);
    };
    var getchilddetails = function (DateOfBirth, ChildFirstName, ChildLastName, parentId) {
        var month = (parseInt(DateOfBirth.getMonth().toString()) + 1).toString();
        var newres = DateOfBirth.getFullYear() + '-' + month + '-' + DateOfBirth.getDate();
        var apiUrl = '/members/childDetails/firstname/' + ChildFirstName + '/lastname/' + ChildLastName + '/parent/' + parentId + '/dateofbirth/' + newres;
        //var apiUrl = '/members/allprofessions';
        return FactoryHelper.CallApiGet(apiUrl);
    };
    var getOrderServiceDetails = function() {};

    var setChildIdParially = function(data) {
        subscriptionDetails.childDetails.childDetails.PersonId = data;
    }

    var getSubscriptionData = function (parentID,child) {
        var apiUrl = '/productonboarding/person/' + parentID + '/child/' +child+ '/subscriberdetails';
        return FactoryHelper.CallApiGet(apiUrl);
    };
    var postSubscriptionData = function(data) {
        var apiUrl = '/productonboarding/savesubscriptiondetails';
        return FactoryHelper.CallApiPost(apiUrl, data);
    };

    //var postSubscriptionData = function (data) {
    //    var apiUrl = '/productonboarding/savesubscriptiondetails';
    //    return FactoryHelper.CallApiPost(apiUrl, data);
    //};

    var getallFunctions = function(ischild) {
        if (ischild) {
            var apiUrl = '/common/ischild/true/politicalfunctions';
        } else {
            var apiUrl = '/common/ischild/false/politicalfunctions';
        }

        //var apiUrl = '/members/allprofessions';
        return FactoryHelper.CallApiGet(apiUrl);
    };
    var getallProfession = function(parentID) {
        var apiUrl = '/common/professions';
        //var apiUrl = '/members/allprofessions';
        return FactoryHelper.CallApiGet(apiUrl);
    };
    var getallConratcduration = function(dateOfBirth) {
        //var res = subscriptionDetails.childDetails.childDetails.DateOfBirth.split("/");
        //var newres = res[0]+ '-' +res[1]+ '-' +res[2];
        //var res = subscriptionDetails.childDetails.childDetails.DateOfBirth;
        // item.date = $filter('date')(item.date, "dd/MM/yyyy");
        if (dateOfBirth) {
            var month = (parseInt(dateOfBirth.getMonth().toString()) + 1).toString();
        } else {
        var month = (parseInt(subscriptionDetails.childDetails.childDetails.DateOfBirth.getMonth().toString()) + 1).toString();
        }
        
        var newres = subscriptionDetails.childDetails.childDetails.DateOfBirth.getFullYear() + '-' + month + '-' + subscriptionDetails.childDetails.childDetails.DateOfBirth.getDate();
        var apiUrl = '/productonboarding/contractminimumduration/dateofbirth/' + newres;
        //var apiUrl = '/members/allprofessions';
        return FactoryHelper.CallApiGet(apiUrl);
    };
    var getallConratcinfo = function(fromPendingChild,fromPendingDob) {
        // var res = subscriptionDetails.childDetails.childDetails.DateOfBirth.split("/");
        // var newres = res[1] + '/' + res[0] + '/' + res[2];
        //var newres = subscriptionDetails.childDetails.childDetails.DateOfBirth.getFullYear() + '-' +subscriptionDetails.childDetails.childDetails.DateOfBirth.getMonth() + '-' +subscriptionDetails.childDetails.childDetails.DateOfBirth.getDate();

        if (fromPendingChild)
        {
            subscriptionDetails.childDetails.childDetails.PersonId = fromPendingChild;
            subscriptionDetails.childDetails.childDetails.DateOfBirth = fromPendingDob;
        }

        var data = {
            "ChildId": subscriptionDetails.childDetails.childDetails.PersonId,
            "DateofBirth": subscriptionDetails.childDetails.childDetails.DateOfBirth,
            "ParentId": subscriptionDetails.personalDetails.PersonalDetails.PersonId,
            "QuestionAnswer": subscriptionDetails.questionDetails
        };

        for (var i = 0; i < data.QuestionAnswer.length; i++) {
            if (data.QuestionAnswer[i].Answer == 'FirstOption' ||  data.QuestionAnswer[i].Answer == data.QuestionAnswer[i].FirstOption) {
                data.QuestionAnswer[i].Answer = data.QuestionAnswer[i].FirstOption;
                data.QuestionAnswer[i].AnswerOptionId = '1';
            } else {
                data.QuestionAnswer[i].Answer = data.QuestionAnswer[i].SecondOption;
                data.QuestionAnswer[i].AnswerOptionId = '2';
            }
        }
        //  data = JSON.stringify(data);
        var apiUrl = '/productonboarding/productgenericinformation/filtered';
        //var apiUrl = '/members/allprofessions';
        return FactoryHelper.CallApiPost(apiUrl, data);
    };

    var getallquestion = function(fromPending) {
        if (fromPending) {
            var apiUrl = '/productonboarding/questionsbycategory/categorytype/1/parent/' + subscriptionDetails.personalDetails.PersonalDetails.PersonId + '/child/' + fromPending;
        } else {
        var apiUrl = '/productonboarding/questionsbycategory/categorytype/1/parent/' + subscriptionDetails.personalDetails.PersonalDetails.PersonId + '/child/' + subscriptionDetails.childDetails.childDetails.PersonId;
        }
        
        //var apiUrl = '/members/allprofessions';
        return FactoryHelper.CallApiGet(apiUrl);

    };
    var setEId = function(id) {
        eidCheck = id;
        //var apiUrl = '/members/allprofessions';
        // return FactoryHelper.CallApiGetNew(apiUrl);
    };
    var getEid = function() {
        return eidCheck;
    };
    var setPersonDetailsPage = function(id) {
        parentPage = id;
        //var apiUrl = '/members/allprofessions';
        // return FactoryHelper.CallApiGetNew(apiUrl);
    };
    var getPersonDetailsPage = function() {
        return parentPage;
    };
    var setChildDetails = function(data) {
        subscriptionDetails.childDetails = data;
    }
    var getChildDetailsfactory = function(data) {
        return subscriptionDetails.childDetails;
    }

    var setDOB = function (data) {
        subscriptionDetails.personalDetails.PersonalDetails.DateOfBirth = data;
    }
    var getDOB = function (data) {
        return parentDOB;
    }

    var setGender = function (data) {
        
        subscriptionDetails.personalDetails.PersonalDetails.Gender = data;
    }
    var getGender = function (data) {
        return subscriptionDetails.personalDetails.PersonalDetails.Gender;
    }

    var setChildStatus = function(data) {
        childStatus = data;
    }
    var getChildStatus = function(data) {
        return childStatus;
    }

    $rootScope.$on('PartnerShip', function (event, args) {
        partnershipId = args.any.partnershipId;

    });
    var setpartnershipIdForOther = function (data) {
        partnershipId = data;
    };
    var saveSubscriptionDetails = function(id, data) {
        var saveData = {};
        saveData.PartnershipId = partnershipId;
        if (id == "child") {
            if (subscriptionDetails.personalDetails.IsIdentitySkipped) {
                saveData.ProofOfIdentity = [];
            } else {
                saveData.ProofOfIdentity = angular.copy(subscriptionDetails.personalDetails.ProofOfIdentity);
            }
            for (var i = 0; i < saveData.ProofOfIdentity.length; i++) {
                if (saveData.ProofOfIdentity[i].ImageBase64[0].substring(0, 4) == 'data') {
                    var array = saveData.ProofOfIdentity[i].ImageBase64[0].split(",");
                    saveData.ProofOfIdentity[i].ImageBase64[0] = array[1];
                } else {
                    saveData.ProofOfIdentity[i].ImageBase64[0] = null;
                }
            }

            //saveData.FiscalResidenceDetails = subscriptionDetails.personalDetails.FiscalResidenceDetails;

            //for (var i = 0; i < saveData.FiscalResidenceDetails.length; i++) {
            //    if (saveData.FiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence == 'false') {
            //        saveData.FiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = false;
            //    }
            //    else {
            //        saveData.FiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = true;
            //    }
            //    //if (saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence && saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence != "" && saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence != "select") {
            //    //    saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence = 0
            //    //}
            //    //else {
            //    //    saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence = null;
            //    //}
                //}

            saveData.OtherDetails = subscriptionDetails.personalDetails.OtherDetails;

            if (saveData.OtherDetails.HasUsaCitizenship == 'false' || saveData.OtherDetails.HasUsaCitizenship == false) {
                saveData.OtherDetails.HasUsaCitizenship = false;
            } else {
                saveData.OtherDetails.HasUsaCitizenship = true;
            }
            if (saveData.OtherDetails.IsUsaCitizenOrResident == 'false' || saveData.OtherDetails.IsUsaCitizenOrResident == false) {
                saveData.OtherDetails.IsUsaCitizenOrResident = false;
            } else {
                saveData.OtherDetails.IsUsaCitizenOrResident = true;
            }
            if (saveData.OtherDetails.IsBelgiumOnlyFiscalResidence == 'false' || saveData.OtherDetails.IsBelgiumOnlyFiscalResidence == false) {
                saveData.OtherDetails.IsBelgiumOnlyFiscalResidence = false;
            }
            else {
                saveData.OtherDetails.IsBelgiumOnlyFiscalResidence = true;
            }
            if (saveData.OtherDetails.IsBelgiumOnlyFiscalResidence) {
                saveData.FiscalResidenceDetails = [];
            }
            else {
                saveData.FiscalResidenceDetails = subscriptionDetails.personalDetails.FiscalResidenceDetails;

                for (var i = 0; i < saveData.FiscalResidenceDetails.length; i++) {
                    if (saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                        saveData.FiscalResidenceDetails.splice(i, 1);
                        i--;
                    }
                }
            }
            if (saveData.OtherDetails.ImportantPublicFunction == "Me" || saveData.OtherDetails.ImportantPublicFunction == enumMelinked) {
                saveData.OtherDetails.ImportantPublicFunction = enumMelinked;
            } else if (saveData.OtherDetails.ImportantPublicFunction == "true" || saveData.OtherDetails.ImportantPublicFunction == enumPersonLinkedToMe) {
                saveData.OtherDetails.ImportantPublicFunction = enumPersonLinkedToMe;
            } else {
                saveData.OtherDetails.ImportantPublicFunction = enumNolinked;
            }

            saveData.PersonalDetails = subscriptionDetails.personalDetails.PersonalDetails;
            saveData.PersonalDetails.CountryCode = 0;
            if (saveData.PersonalDetails.Gender == 'Male' || saveData.PersonalDetails.Gender == enumMale) {
                saveData.PersonalDetails.Gender = enumMale;
            } else {
                saveData.PersonalDetails.Gender = enumFemale;
            }
            saveData.PersonalDetails.City = saveData.PersonalDetails.ZipCode;
            //saveData.ChildFiscalResidenceDetails = data.FiscalResidenceDetails;

            //for (var i = 0; i < saveData.ChildFiscalResidenceDetails.length; i++) {
            //    if (saveData.ChildFiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence == 'false') {
            //        saveData.ChildFiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = false;
            //    }
            //    else {
            //        saveData.ChildFiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = true;
            //    }
            //    //if (saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence && saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence != "" && saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence != "select") {
            //    //    saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence = 0
            //    //}
            //    //else {
            //    //    saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence = null;
            //    //}
                //}

            saveData.ChildsOtherDetails = data.OtherDetails;

            if (saveData.ChildsOtherDetails.HasUsaCitizenship == 'false' || saveData.ChildsOtherDetails.HasUsaCitizenship == false) {
                saveData.ChildsOtherDetails.HasUsaCitizenship = false;
            } else {
                saveData.ChildsOtherDetails.HasUsaCitizenship == true;
            }
            if (saveData.ChildsOtherDetails.IsUsaCitizenOrResident == 'false' || saveData.ChildsOtherDetails.IsUsaCitizenOrResident == false) {
                saveData.ChildsOtherDetails.IsUsaCitizenOrResident = false;
            } else {
                saveData.ChildsOtherDetails.IsUsaCitizenOrResident == true;
            }
            if (saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence == 'false' || saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence == false) {
                saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence = false;
            }
            else {
                saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence == true;
            }
            if (saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence) {
                saveData.ChildFiscalResidenceDetails = [];
            }
            else {
                saveData.ChildFiscalResidenceDetails = data.FiscalResidenceDetails;

                for (var i = 0; i < saveData.ChildFiscalResidenceDetails.length; i++) {
                    if (saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                        saveData.ChildFiscalResidenceDetails.splice(i, 1);
                        i--;
                    }
                }
            }

            if (saveData.ChildsOtherDetails.ImportantPublicFunction == "Me" || saveData.ChildsOtherDetails.ImportantPublicFunction == enumMelinked) {
                saveData.ChildsOtherDetails.ImportantPublicFunction = enumMelinked;
            } else if (saveData.ChildsOtherDetails.ImportantPublicFunction == "true" || saveData.ChildsOtherDetails.ImportantPublicFunction == enumPersonLinkedToMe) {
                saveData.ChildsOtherDetails.ImportantPublicFunction = enumPersonLinkedToMe;
            } else {
                saveData.ChildsOtherDetails.ImportantPublicFunction = enumNolinked;
            }

            saveData.ChildDetails = data.childDetails;
            saveData.ChildDetails.CountryCode = 0;
            if (saveData.ChildDetails.Gender == 'Boy' || saveData.ChildDetails.Gender == enumMale) {
                saveData.ChildDetails.Gender = enumMale;
            } else {
                saveData.ChildDetails.Gender = enumFemale;
            }
            saveData.ChildDetails.City = saveData.ChildDetails.ZipCode;
            if (saveData.ChildsOtherDetails.Relationship == 'Mother' || saveData.ChildsOtherDetails.Relationship == enumMother) {
                saveData.ChildsOtherDetails.Relationship = enumMother;
            } else if (saveData.ChildsOtherDetails.Relationship == 'Father' || saveData.ChildsOtherDetails.Relationship == enumFather) {
                saveData.ChildsOtherDetails.Relationship = enumFather;
            } else if (saveData.ChildsOtherDetails.Relationship == 'Tutor' || saveData.ChildsOtherDetails.Relationship == enumTutor) {
                saveData.ChildsOtherDetails.Relationship = enumTutor;
            } else {
                saveData.ChildsOtherDetails.Relationship = enumOther;
            }
            saveData.LastStepSaved = 0;
            return saveData;
        }
        if (id == "question") {
            if (subscriptionDetails.personalDetails.IsIdentitySkipped) {
                saveData.ProofOfIdentity = [];
            } else {
                saveData.ProofOfIdentity = angular.copy(subscriptionDetails.personalDetails.ProofOfIdentity);
            }
            for (var i = 0; i < saveData.ProofOfIdentity.length; i++) {
                if (saveData.ProofOfIdentity[i].ImageBase64[0].substring(0, 4) == 'data') {
                    var array = saveData.ProofOfIdentity[i].ImageBase64[0].split(",");
                    saveData.ProofOfIdentity[i].ImageBase64[0] = array[1];
                } else {
                    saveData.ProofOfIdentity[i].ImageBase64[0] = null;
                }
            }

           // saveData.FiscalResidenceDetails = subscriptionDetails.personalDetails.FiscalResidenceDetails;

            //for (var i = 0; i < saveData.FiscalResidenceDetails.length; i++) {
            //    if (saveData.FiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence == 'false') {
            //        saveData.FiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = false;
            //    }
            //    else {
            //        saveData.FiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = true;
            //    }
            //    //if (saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence && saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence != "" && saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence != "select") {
            //    //    saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence = 0
            //    //}
            //    //else {
            //    //    saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence = null;
            //    //}
                //}

            saveData.OtherDetails = subscriptionDetails.personalDetails.OtherDetails;

            //saveData.OtherDetails.Relationship = saveData.ChildsOtherDetails.Relationship;
            if (saveData.OtherDetails.HasUsaCitizenship == 'false' || saveData.OtherDetails.HasUsaCitizenship == false) {
                saveData.OtherDetails.HasUsaCitizenship = false;
            } else {
                saveData.OtherDetails.HasUsaCitizenship = true;
            }
            if (saveData.OtherDetails.IsUsaCitizenOrResident == 'false' || saveData.OtherDetails.IsUsaCitizenOrResident == false) {
                saveData.OtherDetails.IsUsaCitizenOrResident = false;
            } else {
                saveData.OtherDetails.IsUsaCitizenOrResident = true;
            }
            if (saveData.OtherDetails.IsBelgiumOnlyFiscalResidence == 'false' || saveData.OtherDetails.IsBelgiumOnlyFiscalResidence == false) {
                saveData.OtherDetails.IsBelgiumOnlyFiscalResidence = false;
            }
            else {
                saveData.OtherDetails.IsBelgiumOnlyFiscalResidence = true;
            }
            if (saveData.OtherDetails.IsBelgiumOnlyFiscalResidence) {
                saveData.FiscalResidenceDetails = [];
            }
            else {
                saveData.FiscalResidenceDetails = subscriptionDetails.personalDetails.FiscalResidenceDetails;

                for (var i = 0; i < saveData.FiscalResidenceDetails.length; i++) {
                    if (saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                        saveData.FiscalResidenceDetails.splice(i, 1);
                        i--;
                    }
                }
            }
            if (saveData.OtherDetails.ImportantPublicFunction == "Me" || saveData.OtherDetails.ImportantPublicFunction == enumMelinked) {
                saveData.OtherDetails.ImportantPublicFunction = enumMelinked;
            } else if (saveData.OtherDetails.ImportantPublicFunction == "true" || saveData.OtherDetails.ImportantPublicFunction == enumPersonLinkedToMe) {
                saveData.OtherDetails.ImportantPublicFunction = enumPersonLinkedToMe;
            } else {
                saveData.OtherDetails.ImportantPublicFunction = enumNolinked;
            }

            saveData.PersonalDetails = subscriptionDetails.personalDetails.PersonalDetails;
            saveData.PersonalDetails.CountryCode = 0;
            if (saveData.PersonalDetails.Gender == 'Male' || saveData.PersonalDetails.Gender == enumMale) {
                saveData.PersonalDetails.Gender = enumMale;
            } else {
                saveData.PersonalDetails.Gender = enumFemale;
            }
            saveData.PersonalDetails.City = saveData.PersonalDetails.ZipCode;
            //saveData.ChildFiscalResidenceDetails = subscriptionDetails.childDetails.FiscalResidenceDetails;

            //for (var i = 0; i < saveData.ChildFiscalResidenceDetails.length; i++) {
            //    if (saveData.ChildFiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence == 'false') {
            //        saveData.ChildFiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = false;
            //    } else {
            //        saveData.ChildFiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = true;
            //    }
            //    //if (saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence && saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence != "" && saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence != "select") {
            //    //    saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence = 0
            //    //}
            //    //else {
            //    //    saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence = null;
            //    //}
            //}

            saveData.ChildsOtherDetails = subscriptionDetails.childDetails.OtherDetails;

            if (saveData.ChildsOtherDetails.HasUsaCitizenship == 'false' || saveData.ChildsOtherDetails.HasUsaCitizenship == false) {
                saveData.ChildsOtherDetails.HasUsaCitizenship = false;
            } else {
                saveData.ChildsOtherDetails.HasUsaCitizenship == true;
            }
            if (saveData.ChildsOtherDetails.IsUsaCitizenOrResident == 'false' || saveData.ChildsOtherDetails.IsUsaCitizenOrResident == false) {
                saveData.ChildsOtherDetails.IsUsaCitizenOrResident = false;
            } else {
                saveData.ChildsOtherDetails.IsUsaCitizenOrResident == true;
            }
            if (saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence == 'false' || saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence == false) {
                saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence = false;
            }
            else {
                saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence == true;
            }
            if (saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence) {
                saveData.ChildFiscalResidenceDetails = [];
            }
            else {
                saveData.ChildFiscalResidenceDetails = subscriptionDetails.childDetails.FiscalResidenceDetails;

                for (var i = 0; i < saveData.ChildFiscalResidenceDetails.length; i++) {
                    if (saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                        saveData.ChildFiscalResidenceDetails.splice(i, 1);
                        i--;
                    }
                }
            }
            if (saveData.ChildsOtherDetails.ImportantPublicFunction == "Me" || saveData.ChildsOtherDetails.ImportantPublicFunction == enumMelinked) {
                saveData.ChildsOtherDetails.ImportantPublicFunction = enumMelinked;
            } else if (saveData.ChildsOtherDetails.ImportantPublicFunction == "true" || saveData.ChildsOtherDetails.ImportantPublicFunction == enumPersonLinkedToMe) {
                saveData.ChildsOtherDetails.ImportantPublicFunction = enumPersonLinkedToMe;
            } else {
                saveData.ChildsOtherDetails.ImportantPublicFunction = enumNolinked;
            }

            saveData.ChildDetails = subscriptionDetails.childDetails.childDetails;
            saveData.ChildDetails.CountryCode = 0;
            if (saveData.ChildDetails.Gender == 'Boy' || saveData.ChildDetails.Gender == enumMale) {
                saveData.ChildDetails.Gender = enumMale;
            } else {
                saveData.ChildDetails.Gender = enumFemale;
            }
            saveData.ChildDetails.City = saveData.ChildDetails.ZipCode;
            if (saveData.ChildsOtherDetails.Relationship == 'Mother' || saveData.ChildsOtherDetails.Relationship == enumMother) {
                saveData.ChildsOtherDetails.Relationship = enumMother;
            } else if (saveData.ChildsOtherDetails.Relationship == 'Father' || saveData.ChildsOtherDetails.Relationship == enumFather) {
                saveData.ChildsOtherDetails.Relationship = enumFather;
            } else if (saveData.ChildsOtherDetails.Relationship == 'Tutor' || saveData.ChildsOtherDetails.Relationship == enumTutor) {
                saveData.ChildsOtherDetails.Relationship = enumTutor;
            } else {
                saveData.ChildsOtherDetails.Relationship = enumOther;
            }
            saveData.QuestionListView = data.questiondeatils;
            for (var i = 0; i < saveData.QuestionListView.length; i++) {
                if (saveData.QuestionListView[i].Answer == 'FirstOption') {
                    saveData.QuestionListView[i].Answer = saveData.QuestionListView[i].FirstOption;
                } else {
                    saveData.QuestionListView[i].Answer = saveData.QuestionListView[i].SecondOption;
                }
            }

            saveData.LastStepSaved = 1;
            return saveData;
        }

        if (id == "product") {
            if (subscriptionDetails.personalDetails.IsIdentitySkipped) {
                saveData.ProofOfIdentity = [];
            } else {
                saveData.ProofOfIdentity = angular.copy(subscriptionDetails.personalDetails.ProofOfIdentity);
            }
            for (var i = 0; i < saveData.ProofOfIdentity.length; i++) {
                if (saveData.ProofOfIdentity[i].ImageBase64[0].substring(0, 4) == 'data') {
                    var array = saveData.ProofOfIdentity[i].ImageBase64[0].split(",");
                    saveData.ProofOfIdentity[i].ImageBase64[0] = array[1];
                } else {
                    saveData.ProofOfIdentity[i].ImageBase64[0] = null;
                }
            }

           // saveData.FiscalResidenceDetails = subscriptionDetails.personalDetails.FiscalResidenceDetails;

            //for (var i = 0; i < saveData.FiscalResidenceDetails.length; i++) {
            //    if (saveData.FiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence == 'false') {
            //        saveData.FiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = false;
            //    }
            //    else {
            //        saveData.FiscalResidenceDetails[i].IsBelgiumOnlyFiscalResidence = true;
            //    }
            //    //if (saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence && saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence != "" && saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence != "select") {
            //    //    saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence = 0
            //    //}
            //    //else {
            //    //    saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence = null;
            //    //}
                //}

            saveData.OtherDetails = subscriptionDetails.personalDetails.OtherDetails;

            if (saveData.OtherDetails.HasUsaCitizenship == 'false' || saveData.OtherDetails.HasUsaCitizenship == false) {
                saveData.OtherDetails.HasUsaCitizenship = false;
            } else {
                saveData.OtherDetails.HasUsaCitizenship = true;
            }
            if (saveData.OtherDetails.IsUsaCitizenOrResident == 'false' || saveData.OtherDetails.IsUsaCitizenOrResident == false) {
                saveData.OtherDetails.IsUsaCitizenOrResident = false;
            } else {
                saveData.OtherDetails.IsUsaCitizenOrResident = true;
            }
            if (saveData.OtherDetails.IsBelgiumOnlyFiscalResidence == 'false' || saveData.OtherDetails.IsBelgiumOnlyFiscalResidence == false) {
                saveData.OtherDetails.IsBelgiumOnlyFiscalResidence = false;
            }
            else {
                saveData.OtherDetails.IsBelgiumOnlyFiscalResidence = true;
            }
            if (saveData.OtherDetails.IsBelgiumOnlyFiscalResidence) {
                saveData.FiscalResidenceDetails = [];
            }
            else {
                saveData.FiscalResidenceDetails = subscriptionDetails.personalDetails.FiscalResidenceDetails;

                for (var i = 0; i < saveData.FiscalResidenceDetails.length; i++) {
                    if (saveData.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                        saveData.FiscalResidenceDetails.splice(i, 1);
                        i--;
                    }
                }
            }
            if (saveData.OtherDetails.ImportantPublicFunction == "Me" || saveData.OtherDetails.ImportantPublicFunction == enumMelinked) {
                saveData.OtherDetails.ImportantPublicFunction = enumMelinked;
            } else if (saveData.OtherDetails.ImportantPublicFunction == "true" || saveData.OtherDetails.ImportantPublicFunction == enumPersonLinkedToMe) {
                saveData.OtherDetails.ImportantPublicFunction = enumPersonLinkedToMe;
            } else {
                saveData.OtherDetails.ImportantPublicFunction = enumNolinked;
            }

            saveData.PersonalDetails = subscriptionDetails.personalDetails.PersonalDetails;
            saveData.PersonalDetails.CountryCode = 0;
            if (saveData.PersonalDetails.Gender == 'Male' || saveData.PersonalDetails.Gender == enumMale) {
                saveData.PersonalDetails.Gender = enumMale;
            } else {
                saveData.PersonalDetails.Gender = enumFemale;
            }
            saveData.PersonalDetails.City = saveData.PersonalDetails.ZipCode;

            saveData.ChildsOtherDetails = subscriptionDetails.childDetails.OtherDetails;;

            if (saveData.ChildsOtherDetails.HasUsaCitizenship == 'false' || saveData.ChildsOtherDetails.HasUsaCitizenship == false) {
                saveData.ChildsOtherDetails.HasUsaCitizenship = false;
            } else {
                saveData.ChildsOtherDetails.HasUsaCitizenship == true;
            }
            if (saveData.ChildsOtherDetails.IsUsaCitizenOrResident == 'false' || saveData.ChildsOtherDetails.IsUsaCitizenOrResident == false) {
                saveData.ChildsOtherDetails.IsUsaCitizenOrResident = false;
            } else {
                saveData.ChildsOtherDetails.IsUsaCitizenOrResident == true;
            }
            if (saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence == 'false' || saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence == false) {
                saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence = false;
            }
            else {
                saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence == true;
            }
            if (saveData.ChildsOtherDetails.IsBelgiumOnlyFiscalResidence) {
                saveData.ChildFiscalResidenceDetails = [];
            }
            else {
                saveData.ChildFiscalResidenceDetails = subscriptionDetails.childDetails.FiscalResidenceDetails;

                for (var i = 0; i < saveData.ChildFiscalResidenceDetails.length; i++) {
                    if (saveData.ChildFiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                        saveData.ChildFiscalResidenceDetails.splice(i, 1);
                        i--;
                    }
                }
            }

            if (saveData.ChildsOtherDetails.ImportantPublicFunction == "Me" || saveData.ChildsOtherDetails.ImportantPublicFunction == enumMelinked) {
                saveData.ChildsOtherDetails.ImportantPublicFunction = enumMelinked;
            } else if (saveData.ChildsOtherDetails.ImportantPublicFunction == "true" || saveData.ChildsOtherDetails.ImportantPublicFunction == enumPersonLinkedToMe) {
                saveData.ChildsOtherDetails.ImportantPublicFunction = enumPersonLinkedToMe;
            } else {
                saveData.ChildsOtherDetails.ImportantPublicFunction = enumNolinked;
            }

            saveData.ChildDetails = subscriptionDetails.childDetails.childDetails;
            saveData.ChildDetails.CountryCode = 0;
            if (saveData.ChildDetails.Gender == 'Boy' || saveData.ChildDetails.Gender == enumMale) {
                saveData.ChildDetails.Gender = enumMale;
            } else {
                saveData.ChildDetails.Gender = enumFemale;
            }
            saveData.ChildDetails.City = saveData.ChildDetails.ZipCode;
            if (saveData.ChildsOtherDetails.Relationship == 'Mother' || saveData.ChildsOtherDetails.Relationship == enumMother) {
                saveData.ChildsOtherDetails.Relationship = enumMother;
            } else if (saveData.ChildsOtherDetails.Relationship == 'Father' || saveData.ChildsOtherDetails.Relationship == enumFather) {
                saveData.ChildsOtherDetails.Relationship = enumFather;
            } else if (saveData.ChildsOtherDetails.Relationship == 'Tutor' || saveData.ChildsOtherDetails.Relationship == enumTutor) {
                saveData.ChildsOtherDetails.Relationship = enumTutor;
            } else {
                saveData.ChildsOtherDetails.Relationship = enumOther;
            }
            saveData.QuestionListView = subscriptionDetails.questionDetails;
            for (var i = 0; i < saveData.QuestionListView.length; i++) {
                if (saveData.QuestionListView[i].Answer == 'FirstOption' || saveData.QuestionListView[i].Answer == saveData.QuestionListView[i].FirstOption) {
                    saveData.QuestionListView[i].Answer = saveData.QuestionListView[i].FirstOption;
                } else {
                    saveData.QuestionListView[i].Answer = saveData.QuestionListView[i].SecondOption;
                }
            }
            //var res = subscriptionDetails.childDetails.childDetails.DateOfBirth.getFullYear();
            ////var newres = res[2];
            //res = res.toString();
            //var adddate = parseInt(res);
            //var adddate = adddate + data.contractMaxDuration;
            //newres = subscriptionDetails.childDetails.childDetails.DateOfBirth.getFullYear() + "/" + subscriptionDetails.childDetails.childDetails.DateOfBirth.getMonth() + "/" + adddate.toString();
            var res = subscriptionDetails.childDetails.childDetails.DateOfBirth.getFullYear();
            var res1 = subscriptionDetails.childDetails.childDetails.DateOfBirth.getMonth();
            var res2 = subscriptionDetails.childDetails.childDetails.DateOfBirth.getDate();

            //DateOfBirth.getFullYear() + '-' + DateOfBirth.getMonth() + '-' + DateOfBirth.getDate();
            //var newres = res[2];
            res = res.toString();
            res1 = res1.toString();
            res1 = parseInt(res1);
            res1 = res1 + 1;
            res1 = res1.toString();
            if (res1.length == 1) {
                res1 = "0" + res1;
            }
            res2 = res2.toString();
            var adddate = parseInt(res);
            var adddate = adddate + data.contractMaxDuration;
            newres = res1 + "/" + res2 + "/" + adddate.toString();

            saveData.ProductRecommendationView = {
                "ChildId": subscriptionDetails.childDetails.childDetails.PersonId,
                "DateOfBirth": subscriptionDetails.childDetails.childDetails.DateOfBirth,
                "ParentId": subscriptionDetails.personalDetails.PersonalDetails.PersonId,
                "ProductRecommendation": data.arrayofProduct,
                "QuestionAnswer": saveData.QuestionListView,
                "ContractEndDate": newres,
                "ContractMaxDuration": data.contractMaxDuration
            };

            saveData.LastStepSaved = 2;
            return saveData;
        }
    }
    var setquestionnumber = function(number) {
        questionNumber = number;
    };
    var getquestionnumber = function() {
        return questionNumber;
    };
    var setPromoCode = function (data) {
        promocodeapplied = data;
    }
    var getPromoCode = function (data) {
        return promocodeapplied;
    }

    var getPendingSubscriptionData = function (parentID) {
        var apiUrl = '/productonboarding/person/' + parentID + '/pendingSubscriptionDetails';
        return FactoryHelper.CallApiGet(apiUrl);
    };

    return {
        changeDateFormat: changeDateFormat,
        validEmail: validEmail,
        setPersonalDetails: setPersonalDetails,
        getPersonalDetails: getPersonalDetails,
        setProofOfIdentity: setProofOfIdentity,
        getSubscriptionData: getSubscriptionData,
        getallpoliticalRealations: getallpoliticalRealations,
        getallFunctions: getallFunctions,
        getallProfession: getallProfession,
        setEId: setEId,
        getEid: getEid,
        getchilddetails: getchilddetails,
        setChildDetails: setChildDetails,
        getChildDetailsfactory: getChildDetailsfactory,
        saveSubscriptionDetails: saveSubscriptionDetails,
        postSubscriptionData: postSubscriptionData,
        getallquestion: getallquestion,
        getallConratcduration: getallConratcduration,
        setquestionDetails: setquestionDetails,
        getquestionDetails: getquestionDetails,
        getallConratcinfo: getallConratcinfo,
        setPersonDetailsPage: setPersonDetailsPage,
        getPersonDetailsPage: getPersonDetailsPage,
        setproductDetails: setproductDetails,
        getproductDetails: getproductDetails,
        wholeSubDetails: wholeSubDetails,
        OrderService: OrderService,
        getChildStatus: getChildStatus,
        setChildStatus: setChildStatus,
        getallCountries: getallCountries,
        setOrderDetails: setOrderDetails,
        getOrderDetails: getOrderDetails,
        setChildIdParially: setChildIdParially,
        setquestionnumber: setquestionnumber,
        getquestionnumber: getquestionnumber,
        setMappingDetails: setMappingDetails,
        getMappingDetails: getMappingDetails,
        convertUTCDateToLocalDate: convertUTCDateToLocalDate,
        setfullproduct:setfullproduct,
        getfullproduct :getfullproduct,
        getChildDataforRadio: getChildDataforRadio,
        getallZiplist: getallZiplist,
        setDOB: setDOB,
        getDOB: getDOB,
        getGender: getGender,
        setGender:setGender,
        setpartnershipIdForOther: setpartnershipIdForOther,
        getPromoCode: getPromoCode,
        setPromoCode: setPromoCode,
        getPendingSubscriptionData: getPendingSubscriptionData

    };
}]);