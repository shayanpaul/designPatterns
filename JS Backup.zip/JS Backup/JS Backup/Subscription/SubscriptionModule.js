﻿//var subscriptionModule = angular.module('subscriptionModule', []);

//Function to show the process
var progreesStateColorChangeHeader = function (page) {
    var StepOneOfSeven = $("#stepOneOfSeven").val();
    var StepTwoOfSeven = $("#stepTwoOfSeven").val();
    var StepThreeOfSeven = $("#stepThreeOfSeven").val();
    var StepFourOfSeven = $("#stepFourOfSeven").val();
    var StepFiveOfSeven = $("#stepFiveOfSeven").val();
    var StepSixOfSeven = $("#stepSixOfSeven").val();
    var StepSevenOfSeven = $("#stepSevenOfSeven").val();
    var Step = $("#step").val();
    switch(page){
        case 1:
            $("#step_one_of_seven").html(StepOneOfSeven);
            $("#step_1_one_two").addClass('active');
            $("#step_1_one_two").removeClass('done');
            $("#step_2_three").removeClass('active done');
            $("#step_3_four_five").removeClass('active done');
            $("#step_4_six").removeClass('active done');
            $("#step_5_seven").removeClass('active done');
            break;
        case 2:
            $("#step_one_of_seven").html(StepTwoOfSeven);
            $("#step_1_one_two").addClass('active');
            $("#step_1_one_two").removeClass('done');
            $("#step_2_three").removeClass('active done');
            $("#step_3_four_five").removeClass('active done');
            $("#step_4_six").removeClass('active done');
            $("#step_5_seven").removeClass('active done');
            break;
        case 3:
            $("#step_one_of_seven").html(StepThreeOfSeven);
            $("#step_1_one_two").addClass('active done');
            $("#step_2_three").addClass('active');
            $("#step_2_three").removeClass('done');
            $("#step_3_four_five").removeClass('active done');
            $("#step_4_six").removeClass('active done');
            $("#step_5_seven").removeClass('active done');
            break;
        case 4:
            $("#step_one_of_seven").html(StepFourOfSeven);
            $("#step_1_one_two").addClass('active done');
            $("#step_2_three").addClass('active done');
            $("#step_3_four_five").addClass('active');
            $("#step_3_four_five").removeClass('done');
            $("#step_4_six").removeClass('active done');
            $("#step_5_seven").removeClass('active done');
            break;
        case 5:
            $("#step_one_of_seven").html(StepFiveOfSeven);
            $("#step_1_one_two").addClass('active done');
            $("#step_2_three").addClass('active done');
            $("#step_3_four_five").addClass('active');
            $("#step_3_four_five").removeClass('done');
            $("#step_4_six").removeClass('active done');
            $("#step_5_seven").removeClass('active done');
            break;
        case 6:
            $("#step_one_of_seven").html(StepSixOfSeven);
            $("#step_1_one_two").addClass('active done');
            $("#step_2_three").addClass('active done');
            $("#step_3_four_five").addClass('active done');
            $("#step_4_six").addClass('active');
            $("#step_4_six").removeClass('done');
            $("#step_5_seven").removeClass('active done');
            break;
        case 7:
            $("#step_one_of_seven").html(StepSevenOfSeven);
            $("#step_1_one_two").addClass('active done');
            $("#step_2_three").addClass('active done');
            $("#step_3_four_five").addClass('active done');
            $("#step_4_six").addClass('active done');
            $("#step_5_seven").addClass('active');
            $("#step_5_seven").removeClass('done');
            break;
        default:
            break;
    }
}

//$(document).keyup(function (e) {
//    if (e.keyCode == 27) { // escape key maps to keycode `27`
//        // <DO YOUR WORK HERE>
//    }
//});

//$(document).keydown(function (e) {
//    if (e.keyCode == 27) { // escape key maps to keycode `27`
//        // <DO YOUR WORK HERE>
//    }
//});

//$(document).keypress(function (e) {
//    if (e.keyCode == 27) { // escape key maps to keycode `27`
//        // <DO YOUR WORK HERE>
//    }
//});