﻿/*global $, jQuery, alert, window*/
/*jslint browser: true*/

subscriptionModule.controller('subscriptionEidController', ["$scope", "subscriptionFactory", "$rootScope", "$state", "gemaltoFactory", function ($scope, subscriptionFactory, $rootScope, $state, gemaltoFactory) {
    var personalDetails = {};
    $scope.hidepromocodeButtons = hidepromocodeButtons;
    $('#userSetting').show();

    if (eidSwitch == true) {
        $scope.eidSwitch = true;
    } else {
        $scope.eidSwitch = false;
    }
    

    $rootScope.$on('promoCanceled', function (event, args) {
       $('#pageLoader').addClass('show');
        $('html').addClass('no-scroll');
        if ($scope.promoCodeDetails) {
            $scope.promoCodeDetails.IsApplied = false;
            }
        $scope.isPromoApplied = false;
        setTimeout(function () {
            $('#pageLoader').removeClass('show');
            $('html').removeClass('no-scroll');
            }, 500);
    });

    if (!globalFlagForPromoApplied) {
        if ($.cookie("promoCode") == "" || $.cookie("promoCode") == undefined || $.cookie("promoCode") == null) {
            globalFlagForPromoApplied = false;
    }
        else {
            globalFlagForPromoApplied = true;
            }
            }
    $scope.isPromoApplied = globalFlagForPromoApplied;
    /*---initial data manupulation ----*/
    $scope.eidUploaded = false;
    if ($rootScope.eidUploaded && localStorage.getItem("gemaltoFailed") == "false") {

        
        genericSuccessMessageDisplay(Resources.EidDataSavedSucessfully);
        $scope.isEidUploaded = $rootScope.eidUploaded;
        $scope.reader = "eidreader";
    }
    if (localStorage.getItem("gemaltoFailed") == "true") {
        localStorage.setItem("gemaltoFailed", false);
        if (localStorage.getItem("hasFailedAge") == "true") {
            localStorage.setItem("hasFailedAge", false);
            genericErrorMessageDisplay(Resources.TinErrorParent);
        }
        else {
        genericErrorMessageDisplay(Resources.EidProcessingCancelled);
        }
         $scope.isEidUploaded = $rootScope.eidUploaded;
         $scope.reader = "";
    }
    if (location.search) {
        var isThirdParty = getParameterByName("thirdparty");
        if (isThirdParty) {
            var personId = $.cookie("personId");

            var PersonalDetails = {
                "Address": "",
                "Birthplace": null,
                "City": "",
                "CountryCode": "",
                "DateOfBirth": "",
                "EmailAddress": "",
                "FormattedUpdatedDate": null,
                "Gender": "",
                "HouseNumber": "",
                "IsChild": false,
                "IsEligibleForSubscription": true,
                "IsInfantSupporter": false,
                "PersonCode": 0,
                "PersonFirstName": "",
                "PersonId": 1,
                "PersonImage": null,
                "PersonImageUrl": null,
                "PersonLastName": "",
                "PersonNickName": "",
                "PersonRole": 0,
                "Phone": "",
                "Relationship": 0,
                "UpdatedBy": null,
                "UpdatedDate": "",
                "UserLanguage": "",
                "ZipCode": "",
                "CityZipID": 0

            }

            var ProofOfIdentity = [{
                "Barcode": "",
                "ChildId": 0,
                "ExpiryDate": "",
                "IdentityProofNumber": "",
                "Image": "",
                "ImageBase64": [],
                "ImageBase64ForSingleImage": "",
                "ImageForSingleImage": "",
                "ImageName": "BackImage",
                "ImageTypeCode": 2,
                "ImageUri": "",
                "IsUserSettings": "",
                "PersonId": personId
            }, {
                "Barcode": "",
                "ChildId": 0,
                "ExpiryDate": "",
                "IdentityProofNumber": "",
                "Image": "",
                "ImageBase64": [],
                "ImageBase64ForSingleImage": "",
                "ImageForSingleImage": "",
                "ImageName": "FrontID",
                "ImageTypeCode": 3,
                "ImageUri": "",
                "IsUserSettings": "",
                "PersonId": personId
            }];

            var FiscalResidenceDetails = [{
                "IsBelgiumOnlyFiscalResidence": false,
                "CountryCodeForFiscalResidence": "",
                "TinNumber": ""
            }];

            var OtherDetails = {
                "HasUsaCitizenship": false,
                "ImportantPublicFunction": 0,
                "IsUsaCitizenOrResident": false,
                "PoliticalFirstName": null,
                "PoliticalFunctionCode": 0,
                "PoliticalLastName": null,
                "PoliticalRelationCode": 0,
                "ProfessionCategory": 0,
                "ProfessionDetailedText": 0,
                "ProfessionLabel": 0
            };

            if (!$scope.childID) {
                $scope.childID = 0;
            }
         

            subscriptionFactory.getSubscriptionData(personId, $scope.childID).then(
                function (data) {
                    var personalDetailsData = data;
                    if ($scope.childID == 0) {

                        if (personalDetailsData.IsIdentitySkipped && personalDetailsData.ProofOfIdentity.length == 0) {
                            personalDetailsData.IsIdentitySkipped = false;
                        }

                        if (personalDetailsData.IsIdentitySkipped) {
                            if (!personalDetailsData.IsSubscribingForFirstTime && personalDetailsData.PersonalDetails && personalDetailsData.OtherDetails &&
                                personalDetailsData.PersonalDetails.PersonFirstName && personalDetailsData.PersonalDetails.PersonLastName) {
                                personalDetailsData.PersonalDetails.DateOfBirth = personalDetailsData.PersonalDetails.DateOfBirth;
                                subscriptionFactory.setPersonalDetails(personalDetailsData);
                                subscriptionFactory.setPersonDetailsPage('parentSaved');
                                $state.go('parentSaved');

                            } else {
                                subscriptionFactory.setPersonalDetails(personalDetailsData);
                                subscriptionFactory.setPersonDetailsPage('parentDetails');
                                $state.go('parentDetails');
                            }
                        } else {
                            if (!personalDetailsData.PersonalDetails || personalDetailsData.PersonalDetails == "" || personalDetailsData.PersonalDetails == 0 || personalDetailsData.PersonalDetails == null) {
                                personalDetailsData.PersonalDetails = PersonalDetails;
                            }
                            if (!personalDetailsData.ProofOfIdentity || personalDetailsData.ProofOfIdentity == "" || personalDetailsData.ProofOfIdentity == 0 || personalDetailsData.ProofOfIdentity == null) {
                                personalDetailsData.ProofOfIdentity = ProofOfIdentity;
                            }
                            else {
                            }
                            if (!personalDetailsData.FiscalResidenceDetails || personalDetailsData.FiscalResidenceDetails == "" || personalDetailsData.FiscalResidenceDetails == 0 || personalDetailsData.FiscalResidenceDetails == null) {
                                personalDetailsData.FiscalResidenceDetails = FiscalResidenceDetails;
                            }
                            if (!personalDetailsData.OtherDetails || personalDetailsData.OtherDetails == "" || personalDetailsData.OtherDetails == 0 || personalDetailsData.OtherDetails == null) {
                                personalDetailsData.OtherDetails = OtherDetails;
                            }
                            subscriptionFactory.setPersonalDetails(personalDetailsData);
                           // $state.go("Eidupload");
                        }
                    }
                    personalDetails = subscriptionFactory.getPersonalDetails();
                   $scope.eidDataApply();

                },
                function (error) {
                    //alert('error - ' + error);
                    genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
                }
            );
        }
    }
    $scope.goBack = function () {
        location.href = "/" +currentLanguage + "/subscription/Start"
    };

    //if ($.cookie("promoCode") == undefined) {
    //    globalFlagForPromoApplied = false;
    //}
    //else {
    //    globalFlagForPromoApplied = true;
    //}

    
    $scope.openIFrame = function () {
        var iframe = $("#gemaltoContainer");
        iframe.attr("src", iframe.data("src").replace("{lang}", currentLanguage));
        $('#userSetting').hide();
    };
    $scope.openEidFrame = function (readerVal) {
    }
    $scope.changeFooterShow = function () {
        if (!$scope.showfooter) {
            $scope.showfooter = true;
        }
        else {
            $scope.showfooter = false;
        }
        if (!$scope.openFaq) {
            $scope.openFaq = true;
        }
        else {
            $scope.openFaq = false;
        }
        //$scope.openFaq != $scope.openFaq;
    };

    $scope.isPromoApplied = globalFlagForPromoApplied;

    // Code added to clear the local storage

    localStorage.setItem('parentDataObjectSaved', "NO");
    angular.element(".sb-eid-selection .sb-eid-container .image-radio").height(Math.max(Number(angular.element(".sb-eid-selection .sb-eid-container:eq(0) .image-radio").height()), Number(angular.element(".sb-eid-selection .sb-eid-container:eq(1) .image-radio").height())) + "px");
    $scope.Eid = {
        "front": "",
        "back": ""
    };
    progreesStateColorChangeHeader(1);
    var reader = subscriptionFactory.getEid();
    if (reader) {
        $scope.reader = reader;
    }
    else {
        if ($rootScope.eidUploaded && $rootScope.eidUploaded !="false") {
            $scope.reader = 'eidreader';
        } else {
        $scope.reader = false;
    }
    }
    
    $scope.$on('promoComplete', function (event, args) {

        $scope.promoCodeDetails = args.any.promocodedetails;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        globalFlagForPromoApplied = $scope.promoCodeDetails.IsApplied;
        $scope.isPromoApplied = globalFlagForPromoApplied;
    });
    $scope.isPromoApplied = globalFlagForPromoApplied;
    //$('#tinExpDateId').inputmask('FilterDate');
    $('#tinExpDateId').mask(DateFormat, {
        translation: {
            'r': {
                pattern: /[\/]/,
                fallback: '/'
            },
            placeholder: "__/__/____"
        }
    });
    
    $('#tinNumber').mask(TINnumber);

    $scope.IsIdentitySkipped = false;
    personalDetails = subscriptionFactory.getPersonalDetails();
    if (personalDetails.IsIdentitySkipped) {
        $scope.reader = "picture";
        $("#editEidForm").css("pointer-events", "none");
        $scope.IsIdentitySkipped = true;
    }
 


    $scope.goBack = function () {
        // $state.go($rootScope.$previousState);
        linkUrl = "/" + currentLanguage + "/Subscription/start";
        location.href = linkUrl;
    };
    $scope.Eid = {
        "front": "",
        "back": ""
    };
    $scope.editPic = false;
    $scope.showPromoCodeDetail = function () {
        if (!Promocodepesnding) {
        $('#applyPromoCodeSucessful').modal('show');
            if ($.cookie("promoCode") || subscriptionFactory.getPromoCode) {
            $rootScope.$broadcast("code-in-cookie-present");
        }
    }
    }

    $scope.editPic = false;
    $scope.eidDataApply = function () {
        if (personalDetails.ProofOfIdentity.length) {

            if (personalDetails.ProofOfIdentity.length == 1) {
                $scope.reader = 'eidreader';
                $scope.isEidUploaded = true;
                $scope.Eid.front = personalDetails.ProofOfIdentity[0].ImageBase64[0];
                $scope.Eid.back = personalDetails.ProofOfIdentity[0].ImageBase64[0];
                $scope.tinNumber = personalDetails.ProofOfIdentity[0].IdentityProofNumber;
                $scope.tinExpDate = personalDetails.ProofOfIdentity[0].ExpiryDate;
                $('#eid-card').prop('checked', true);
                setTimeout(function () {
                    $('#eid-card').trigger("click");
                    // $('html').removeClass('no-scroll');
                    $("html").css({ 'overflow-y': 'auto' });
                    $scope.IsIdentitySkipped = true;
                    angular.element("#tinNumber").trigger("focus");
                    angular.element("#tinNumber").trigger("blur");
                    angular.element(".sb-pic-upload").height(246);
                    $("#editEidFormWithEidData").css("pointer-events", "none");
                   // $("#tinNumber").focus();
                   // $("#tinNumber").blur();                    
                }, 500);


            }
            else {
            if (personalDetails.ProofOfIdentity[0] && personalDetails.ProofOfIdentity[0].ImageBase64[0] && personalDetails.ProofOfIdentity[0].ImageBase64[0] != null
                && personalDetails.ProofOfIdentity[0].ImageBase64[0] != 0 && personalDetails.ProofOfIdentity[0].ImageBase64[0] != "") {
                if (personalDetails.ProofOfIdentity[0].ImageTypeCode == 2) {
                    $scope.Eid.front = personalDetails.ProofOfIdentity[0].ImageBase64[0];
                }
                else {
                    $scope.Eid.back = personalDetails.ProofOfIdentity[0].ImageBase64[0];
                }
            }


            if (personalDetails.ProofOfIdentity[1] && personalDetails.ProofOfIdentity[1].ImageBase64[0] && personalDetails.ProofOfIdentity[1].ImageBase64[0] != null
                && personalDetails.ProofOfIdentity[1].ImageBase64[0] != 0 && personalDetails.ProofOfIdentity[1].ImageBase64[0] != "") {
                if (personalDetails.ProofOfIdentity[1].ImageTypeCode == 2) {
                    $scope.Eid.front = personalDetails.ProofOfIdentity[1].ImageBase64[0];
                }
                else {
                    $scope.Eid.back = personalDetails.ProofOfIdentity[1].ImageBase64[0];
                }
            }

            if (personalDetails.ProofOfIdentity.length > 0 && personalDetails.ProofOfIdentity[1] && personalDetails.ProofOfIdentity[1].ExpiryDate != null
                && personalDetails.ProofOfIdentity[1].ExpiryDate != 0 && personalDetails.ProofOfIdentity[1].ExpiryDate != "") {
                $scope.tinNumber = personalDetails.ProofOfIdentity[0].IdentityProofNumber;
                $scope.typeOfProofCode = personalDetails.ProofOfIdentity[0].TypeOfProofCode;
            }

            if (personalDetails.ProofOfIdentity.length > 0 && personalDetails.ProofOfIdentity[0] && personalDetails.ProofOfIdentity[0].ExpiryDate != null
               && personalDetails.ProofOfIdentity[0].ExpiryDate != 0 && personalDetails.ProofOfIdentity[0].ExpiryDate != "") {
                $scope.tinNumber = personalDetails.ProofOfIdentity[0].IdentityProofNumber;
                $scope.typeOfProofCode = personalDetails.ProofOfIdentity[0].TypeOfProofCode;


            }
            if (personalDetails.ProofOfIdentity.length > 0 && personalDetails.ProofOfIdentity[1] && personalDetails.ProofOfIdentity[1].IdentityProofNumber && personalDetails.ProofOfIdentity[1].IdentityProofNumber != null
                && personalDetails.ProofOfIdentity[1].IdentityProofNumber != 0 && personalDetails.ProofOfIdentity[1].IdentityProofNumber != "") {
                $scope.tinExpDate = personalDetails.ProofOfIdentity[0].ExpiryDate;

            }
            if (personalDetails.ProofOfIdentity.length > 0 && personalDetails.ProofOfIdentity[0] && personalDetails.ProofOfIdentity[0].IdentityProofNumber && personalDetails.ProofOfIdentity[0].IdentityProofNumber != null
            && personalDetails.ProofOfIdentity[0].IdentityProofNumber != 0 && personalDetails.ProofOfIdentity[0].IdentityProofNumber != "") {
                $scope.tinExpDate = personalDetails.ProofOfIdentity[0].ExpiryDate;
            }
        }
    }

    }
    $scope.eidDataApply();
    /*---initial data manupulation ----*/


    /*---other functionality ----*/

    $scope.$watch('editPic', function (newValue, oldValue) {
        if (newValue == "front") {
            $("#frontImage").click();
            $scope.editPic = false;
        }
        if (newValue == "back") {
            $("#backImage").click();
            $scope.editPic = false;
        }
    });
    $scope.$watch('Eid.front', function (newValue, oldValue) {
        if (!newValue || newValue == "") {
            $('#frontImage').val('');
        }
    });
    $scope.$watch('Eid.back', function (newValue, oldValue) {
        if (!newValue || newValue == "") {
            $('#backImage').val('');
        }
    });


    $scope.$watch('reader', function (newValue, oldValue) {
        if (newValue == "eidreader") {
            if (!$scope.isEidUploaded || $scope.isEidUploaded == 'false') {
                freezeBackground();
                $scope.isEidUploaded = false;
        }
            angular.element("#gemaltoContainer").attr('src', '/' + angular.element("#gemaltoContainer").attr('lang') + '/Gemalto/StartRead');
            angular.element(".sb-pic-upload").height(Number(window.innerHeight - 60));
            angular.element('html').css('overflow-y','hidden');
        }
        else if (newValue == "picture") {
            unfreezeBackground();
            $scope.reader = 'picture';
            angular.element('html').css('overflow-y', 'auto');
            angular.element(".sb-pic-upload").height(1020);
        }
        if (newValue == "") {
            unfreezeBackground();
            angular.element('html').css('overflow-y', 'auto');
        }
    })

    /*---other functionality ----*/




    /*------go back and front---*/
    //$scope.goBack = function () {
    //    $state.go($rootScope.$previousState);
    //};

    $scope.updateEidData = function () {
        /*-------------------validations to be done ------------*/
        var personId = $.cookie("personId");
        if (!$('#editEidForm').valid()) {
            $('#editEidForm').valid();
            return;
        }
        else {
            if (!personalDetails.ProofOfIdentity.length) {
                personalDetails.ProofOfIdentity=[{
                    "Barcode": "",
                    "ChildId": 0,
                    "ExpiryDate": "",
                    "IdentityProofNumber": "",
                    "Image": "",
                    "ImageBase64": [],
                    "ImageBase64ForSingleImage": "",
                    "ImageForSingleImage": "",
                    "ImageName": "BackImage",
                    "ImageTypeCode": 2,
                    "ImageUri": "",
                    "IsUserSettings": "",
                    "PersonId": personId
                }, {
                    "Barcode": "",
                    "ChildId": 0,
                    "ExpiryDate": "",
                    "IdentityProofNumber": "",
                    "Image": "",
                    "ImageBase64": [],
                    "ImageBase64ForSingleImage": "",
                    "ImageForSingleImage": "",
                    "ImageName": "FrontID",
                    "ImageTypeCode": 3,
                    "ImageUri": "",
                    "IsUserSettings": "",
                    "PersonId": personId
                }];
            }
            if (!$scope.isEidUploaded) {
                
                if (personalDetails.ProofOfIdentity[0].ImageTypeCode == 2) {
                    if (personalDetails.ProofOfIdentity[0].ImageBase64[0]) {
                        personalDetails.ProofOfIdentity[0].ImageBase64[0] = $scope.Eid.front;
                    }
                    else {
                        personalDetails.ProofOfIdentity[0].ImageBase64.push($scope.Eid.front);
                    }

                }
                else {
                    if (personalDetails.ProofOfIdentity[0].ImageBase64[0]) {
                        personalDetails.ProofOfIdentity[0].ImageBase64[0] = $scope.Eid.back;
                    }
                    else {
                        personalDetails.ProofOfIdentity[0].ImageBase64.push($scope.Eid.back);
                    }
                }
                if (personalDetails.ProofOfIdentity[1].ImageTypeCode == 2) {
                    if (personalDetails.ProofOfIdentity[1].ImageBase64[0]) {
                        personalDetails.ProofOfIdentity[1].ImageBase64[0] = $scope.Eid.front;
                    }
                    else {
                        personalDetails.ProofOfIdentity[1].ImageBase64.push($scope.Eid.front);
                    }

                }
                else {
                    if (personalDetails.ProofOfIdentity[1].ImageBase64[0]) {
                        personalDetails.ProofOfIdentity[1].ImageBase64[0] = $scope.Eid.back;;
                    }
                    else {
                        personalDetails.ProofOfIdentity[1].ImageBase64.push($scope.Eid.back);
                    }
                }

                personalDetails.ProofOfIdentity[0].IdentityId = 1;
                personalDetails.ProofOfIdentity[1].IdentityId = 2;
                personalDetails.ProofOfIdentity[0].IdentityProofNumber = $scope.tinNumber;
                personalDetails.ProofOfIdentity[1].IdentityProofNumber = $scope.tinNumber;
                personalDetails.ProofOfIdentity[0].ExpiryDate = $scope.tinExpDate;
                personalDetails.ProofOfIdentity[1].ExpiryDate = $scope.tinExpDate;
            }

                subscriptionFactory.setProofOfIdentity(personalDetails.ProofOfIdentity);
                subscriptionFactory.setEId($scope.reader);            
                var DOBArray = [];
                DOBArray = $scope.tinNumber.substring(0, 6).match(/.{2}/g);
                var GenderIdentity = $scope.tinNumber.substring(6, 9).match(/.{3}/g);
                var GenderBoolean = GenderIdentity % 2;
                if (GenderBoolean == 1) {
                    subscriptionFactory.setGender(enumMale);
                }
                else if (GenderBoolean == 0) {
                    subscriptionFactory.setGender(enumFemale);
                }

                var personDOB = DOBArray[1] + "/" + DOBArray[2] + "/" + DOBArray[0];
                subscriptionFactory.setDOB(personDOB);
                var PersonDetailsPage = subscriptionFactory.getPersonDetailsPage();
                if (PersonDetailsPage) {
                    $state.go(PersonDetailsPage);
                }
                else {
                    if (!personalDetails.IsSubscribingForFirstTime && personalDetails.PersonalDetails && personalDetails.OtherDetails
                                   && personalDetails.PersonalDetails.PersonFirstName && personalDetails.PersonalDetails.PersonLastName) {
                        personalDetails.PersonalDetails.DateOfBirth = personalDetails.PersonalDetails.DateOfBirth;
                        subscriptionFactory.setPersonDetailsPage('parentSaved');
                        $state.go('parentSaved');
                    }
                    else {
                        subscriptionFactory.setPersonDetailsPage('parentDetails');
                        $state.go('parentDetails');
                    }
                }
            //}
           // else {
                //angular.element("#tinNumber").parent().addClass("group-validation-error error-wrapper");
                //angular.element("#tinNumber").parent().append("<label class='error invalid-tin-Num'>" + angular.element('#invalidTinNumberMsg').val() + "</label>")
            //}
        }
    }

    /*------go back and front---*/
    $scope.tinFocusToRemoveError = function (event) {
        var selectedId = event.currentTarget.id;
        if (angular.element("#" + selectedId).parent().hasClass("error-wrapper")) {
            angular.element("#" + selectedId).parent().removeClass("group-validation-error error-wrapper");
            angular.element(".invalid-tin-Num").remove()
        }
    }
    $scope.$on("eid-card-read-success", function () {
       // alert('completed');
    });

    $(document).bind("deleteFrontImage", function (e, status) {
        $scope.Eid.front = '';
        $('#frontImage').val('');
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    });
    $(document).bind("deleteBackImage", function (e, status) {
        $scope.Eid.back = '';
        $('#backImage').val('');
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    });
    $('#pageLoader').removeClass('show');
    $('html').removeClass('no-scroll');

    $scope.sendGemaltoData = function (gemaltoData) {
        var encryptedData = {};
        encryptedData.personId = $.cookie('personId');
        encryptedData.GemaltoResponse = gemaltoData;
        encryptedData.FromSubscription = true;
        gemaltoFactory.eidUploadResponse(encryptedData).then(function (data) {
            if (data.data.Result) {
                window.location.href = "/" + $.cookie('language') + "/subscription/Start?eid=" + data.data.Result;
            }
            else if (data.data && data.data.ErrorCode == '403' && data.data.Message == "InvalidEID") {
                localStorage.setItem("hasFailedAge", "true");
                window.location.href = "/" + $.cookie('language') + "/subscription/Start?eid=false";
            }
            else {
                localStorage.setItem("hasFailedAge", "false");
                window.location.href = "/" + $.cookie('language') + "/subscription/Start?eid=false";
            }
        },
            function (error) {                
                    // genericErrorMessageDisplay();
                    localStorage.setItem("hasFailedAge", "false");
                    window.location.href = "/" + $.cookie('language') + "/subscription/Start?eid=false";
               
                
        });
    }

}]);
subscriptionModule.directive("appFilereader", ["$q", function ($q) {
    var slice = Array.prototype.slice;

    return {
        restrict: 'A',
        require: '?ngModel',
        link: function (scope, element, attrs, ngModel) {
            if (!ngModel) return;

            ngModel.$render = function () { };

            element.bind('change', function (e) {
                var element = e.target;
                var file = e.target.files[0];
                if (file) {
                    var imageIdofElement = e.target.id;
                    var nameArray = file.name.split('.');
                    if (nameArray[nameArray.length - 1].toUpperCase() != 'JPG' && nameArray[nameArray.length - 1].toUpperCase() != 'PNG' && nameArray[nameArray.length - 1].toUpperCase() != 'TIFF') {
                        if (imageIdofElement == 'frontImage') {
                            $(document).trigger('deleteFrontImage', [false]);
                        }
                        else {
                            $(document).trigger('deleteBackImage', [false]);
                        }
                        $(element).closest(".sb-picture-blk").find(".sb-file-type-error").show();
                        $(element).closest(".sb-picture-blk").find(".sb-max-file-size").hide();
                        return;
                    }
                    else {
                        $(element).closest(".sb-picture-blk").find(".sb-file-type-error").hide();
                    }
                    var validFile = true;
                    if (attrs.maxSize != null) {

                        var maxSize = attrs.maxSize;
                        if (((file.size / 1024) / 1024) > maxSize) {
                            var validFile = false;
                        }

                    }

                    if (validFile) {

                        function readFile(file) {
                            var deferred = $q.defer();

                            var reader = new FileReader();
                            reader.onload = function (e) {
                                deferred.resolve(e.target.result);
                            };
                            reader.onerror = function (e) {
                                deferred.reject(e);
                            };
                            reader.readAsDataURL(file);
                            $(element).closest(".sb-picture-blk").find(".sb-max-file-size").hide();
                            $(element).closest(".sb-picture-blk").find(".sb-file-type-error").hide();
                            return deferred.promise;
                        }

                        $q.all(slice.call(element.files, 0).map(readFile))
                            .then(function (values) {
                                if (element.multiple) ngModel.$setViewValue(values);
                                else ngModel.$setViewValue(values.length ? values[0] : null);
                            });



                    }
                    else {
                        //alert('Maximum Size limit of file is ' + maxSize + ' MB');
                        if (imageIdofElement == 'frontImage') {
                            $(document).trigger('deleteFrontImage', [false]);
                        }
                        else {
                            $(document).trigger('deleteBackImage', [false]);
                        }
                        $(element).closest(".sb-picture-blk").find(".sb-max-file-size").show();
                        return;
                    }
                }
                else {
                    return;
                }

            }); //change

        } //link
    }; //return
}]);

subscriptionModule.directive('messageParsing', function () {
    return {
        restrict: 'C',
        link: function (scope, element, attrs) {
            element.html($.parseHTML(element.text()));
        },
    };
});

