﻿/*global $, jQuery, alert, window*/
/*jslint browser: true*/
var globalFlagForPromoApplied = false;
var Promocodepesnding = false;
var hidepromocodeButtons = false;
var hideCrossButton = false;
subscriptionModule.controller('subscriptionMainController', ["$scope", "$rootScope", "subscriptionFactory", "$state", "utilityFactory", "$window", function ($scope, $rootScope, subscriptionFactory, $state, utilityFactory, $window) {
    
    if (location.search) {
        $rootScope.onGoingSubscriptionChildId = getParameterByName("childId");
    } else {
        $rootScope.onGoingSubscriptionChildId = 0;
    }
    $scope.allPoliticalRealtionDetails = [];
    $scope.allProfessionalDetails = [];
    $scope.allfunctionDetails = [];
    $scope.allCountryList = [];
   // $.cookie("promoCode", "", { path: "/" });
    var allpoli = false;
    var allProf = false;
    var allFunc = false;
    var allCoun = false;
    var pageName = '';
    $rootScope.entryFrom = "";
    $rootScope.eidUploaded = false;
    localStorage.setItem("isSubscriptionFlow", true);
    if (location.search) {
        if (getParameterByName("from")) {
        $rootScope.entryFrom = getParameterByName("from");
    }
        if (getParameterByName("eid")) {
            $rootScope.eidUploaded = getParameterByName("eid");
            angular.element("#subscribe").trigger('click');
            angular.element("#subscribe").parent().parent().find('button').trigger('click');
            
         
            if ($rootScope.eidUploaded=='false') {
                localStorage.setItem("gemaltoFailed", true);
        }
            else {
                localStorage.setItem("gemaltoFailed", false);
    }

            
        }
    }

    /*----get mapping data for select filed---*/
    var getallpoliticalRealations = function () {
        subscriptionFactory.getallpoliticalRealations(false).then(
            function (data) {
                for (var key in data) {
                    $scope.allPoliticalRealtionDetails.push(data[key]);
                }
                allpoli = true;
                if (location.search && allCoun && allFunc && allProf && allpoli) {
                    pageName = getParameterByName("pageName");
                    $scope.childID = getParameterByName("childId");
                    $scope.startSubscription();
                    //$state.go(pageName, { childId: childId, dateOfBirth: DOB });
                }
            },
            function (error) {
                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
            }
        );
    };
    getallpoliticalRealations();

    var getallProfession = function () {

        subscriptionFactory.getallProfession().then(
                function (data) {
                    for (var key in data) {
                        $scope.allProfessionalDetails.push(data[key]);
                    }
                    allProf = true;
                    if (location.search && allCoun && allFunc && allProf && allpoli) {
                        pageName = getParameterByName("pageName");
                        $scope.childID = getParameterByName("childId");
                        $scope.startSubscription();
                        //$state.go(pageName, { childId: childId, dateOfBirth: DOB });
                    }
                },
                function (error) {
                    genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
                }
            );
    };
    getallProfession();

    var getallFunctions = function () {
        subscriptionFactory.getallFunctions(false).then(
                function (data) {
                    for (var key in data) {
                        $scope.allfunctionDetails.push(data[key]);
                    }
                    allFunc = true;                    
                    if (location.search && allCoun && allFunc && allProf && allpoli) {
                        pageName = getParameterByName("pageName");
                        $scope.childID = getParameterByName("childId");
                        $scope.startSubscription();
                        //$state.go(pageName, { childId: childId, dateOfBirth: DOB });
                    }
                },
                function (error) {
                    genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
                }
            );
    };
    getallFunctions();

    subscriptionFactory.getallCountries().then(
            function (data) {
                var countryArray = [];
                $scope.allCountryList = [];
               
                for (i=0; i<data.Result.length; i++){
                        $scope.allCountryList.push(data.Result[i]);
                }
                
                allCoun = true;
                if (location.search && allCoun && allFunc && allProf && allpoli) {
                    pageName = getParameterByName("pageName");
                    $scope.childID = getParameterByName("childId");
                    $scope.startSubscription();
                    //$state.go(pageName, { childId: childId, dateOfBirth: DOB });
                }

            },
            function (error) {
                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
            }
        );

    /*----get mapping data for select filed---*/










    /*---initial data manupulation ----*/

    var parentID = $.cookie("personId");
    var PersonalDetails = {
        "Address": "",
        "Birthplace": null,
        "City": "",
        "CountryCode": "",
        "DateOfBirth": "",
        "EmailAddress": "",
        "FormattedUpdatedDate": null,
        "Gender": "",
        "HouseNumber": "",
        "IsChild": false,
        "IsEligibleForSubscription": true,
        "IsInfantSupporter": false,
        "PersonCode": 0,
        "PersonFirstName": "",
        "PersonId": 1,
        "PersonImage": null,
        "PersonImageUrl": null,
        "PersonLastName": "",
        "PersonNickName": "",
        "PersonRole": 0,
        "Phone": "",
        "Relationship": 0,
        "UpdatedBy": null,
        "UpdatedDate": "",
        "UserLanguage": "",
        "ZipCode": "",
        "CityZipID":0

    }
    var FiscalResidenceDetails = [{
        "IsBelgiumOnlyFiscalResidence": false,
        "CountryCodeForFiscalResidence": "",
        "TinNumber": ""
    }];


    var OtherDetails = {
        "HasUsaCitizenship": false,
        "ImportantPublicFunction": 0,
        "IsUsaCitizenOrResident": false,
        "PoliticalFirstName": null,
        "PoliticalFunctionCode": 0,
        "PoliticalLastName": null,
        "PoliticalRelationCode": 0,
        "ProfessionCategory": 0,
        "ProfessionDetailedText": 0,
        "ProfessionLabel": 0
    }


    var ProofOfIdentity = [{
        "Barcode": "",
        "ChildId": 0,
        "ExpiryDate": "",
        "IdentityProofNumber": "",
        "Image": "",
        "ImageBase64": [],
        "ImageBase64ForSingleImage": "",
        "ImageForSingleImage": "",
        "ImageName": "BackImage",
        "ImageTypeCode": 2,
        "ImageUri": "",
        "IsUserSettings": "",
        "PersonId": parentID
    }, {
        "Barcode": "",
        "ChildId": 0,
        "ExpiryDate": "",
        "IdentityProofNumber": "",
        "Image": "",
        "ImageBase64": [],
        "ImageBase64ForSingleImage": "",
        "ImageForSingleImage": "",
        "ImageName": "FrontID",
        "ImageTypeCode": 3,
        "ImageUri": "",
        "IsUserSettings": "",
        "PersonId": parentID
    }];
    $scope.subcribehomepageCheckbox = false;

    /*---initial data manupulation ----*/





    /*---Start Subscription ----*/
    $scope.startSubscription = function () {
        $('body').removeClass('subscriptionStart');
        subscriptionFactory.setMappingDetails($scope.allPoliticalRealtionDetails, $scope.allProfessionalDetails, $scope.allfunctionDetails, $scope.allCountryList);
        if (!parentID) {
            $window.location.href = '/' + currentLanguage + '/account/signin?redirectUrl=' + '/' + currentLanguage + '/subscription/Eidupload?thirdparty=true';
        }
        else {

            if (!$scope.childID) {
                $scope.childID = 0;
            }
            subscriptionFactory.getSubscriptionData(parentID, $scope.childID).then(
                function (data) {
                    var personalDetailsData = data;
                   // personalDetailsData.IsIdentitySkipped = false;
                    if ($scope.childID == 0) {
          //              personalDetailsData.ProofOfIdentity =[
          //              {
	      //"Barcode": "",
	      //"Image": null,
	      //"ImageForSingleImage": null,
	      //"ImageBase64": [
	      //  "https://aagjebusd000.blob.core.windows.net/person2/ProofOfIdentity20170104180144?sv=2015-12-11&sr=b&sig=vAqPsonvgOLE%2BNCRVrvCZiYdrjKe3LpGqPHlhEDwnms%3D&st=2017-01-04T16%3A57%3A03Z&se=2017-01-04T17%3A17%3A03Z&sp=r"
          //              ],
	      //"ImageBase64ForSingleImage": null,
	      //"PersonId": 2,
	      //"ChildId": 0,
	      //"IsUserSettings": false,
	      //"ImageTypeCode": 1,
	      //"IdentityProofNumber": "85041062713",
	      //"ExpiryDate": "2017-05-21T00:00:00",
	      //"ImageName": null,
	      //"ImageUri": null,
	      //"IdentityId": 1,
	      //"TypeOfProofCode": 2
          //              }
                        //          ];
                        if (personalDetailsData.IsSubscribedForLongTermWithoutPromoCode) {
                            hidepromocodeButtons = true;
                        }
                        if (personalDetailsData.IsSubscribedForLongTermWithoutPromoCode) {
                            hideCrossButton = true;
                        }
                        if (personalDetailsData.PromoCode) {
                            $.cookie('promocode', personalDetailsData.PromoCode);
                            subscriptionFactory.setpartnershipIdForOther(personalDetailsData.PartnershipId);
                            $rootScope.$broadcast('PartnerShip', { any: { "partnershipId": personalDetailsData.PartnershipId } });
                            globalFlagForPromoApplied = true;
                            Promocodepesnding = false;
                        }

                    if (personalDetailsData.IsIdentitySkipped && personalDetailsData.ProofOfIdentity.length == 0) {
                        personalDetailsData.IsIdentitySkipped = false;
                    }

                        if (personalDetailsData.IsIdentitySkipped && !location.search) {
                        if (!personalDetailsData.IsSubscribingForFirstTime && personalDetailsData.PersonalDetails && personalDetailsData.OtherDetails &&
                            personalDetailsData.PersonalDetails.PersonFirstName && personalDetailsData.PersonalDetails.PersonLastName) {
                            personalDetailsData.PersonalDetails.DateOfBirth = personalDetailsData.PersonalDetails.DateOfBirth;
                            subscriptionFactory.setPersonalDetails(personalDetailsData);
                            subscriptionFactory.setPersonDetailsPage('parentSaved');
                            $state.go('parentSaved');

                        } else {
                            subscriptionFactory.setPersonalDetails(personalDetailsData);
                            subscriptionFactory.setPersonDetailsPage('parentDetails');
                            $state.go('parentDetails');
                        }
                    } else {
                        if (!personalDetailsData.PersonalDetails || personalDetailsData.PersonalDetails == "" || personalDetailsData.PersonalDetails == 0 || personalDetailsData.PersonalDetails == null) {
                            personalDetailsData.PersonalDetails = PersonalDetails;
                        }
                        if (!personalDetailsData.ProofOfIdentity || personalDetailsData.ProofOfIdentity == "" || personalDetailsData.ProofOfIdentity == 0 || personalDetailsData.ProofOfIdentity == null) {
                            personalDetailsData.ProofOfIdentity = ProofOfIdentity;
                        }
                        else {
                        }
                        if (!personalDetailsData.FiscalResidenceDetails || personalDetailsData.FiscalResidenceDetails == "" || personalDetailsData.FiscalResidenceDetails == 0 || personalDetailsData.FiscalResidenceDetails == null) {
                            personalDetailsData.FiscalResidenceDetails = FiscalResidenceDetails;
                        }
                        if (!personalDetailsData.OtherDetails || personalDetailsData.OtherDetails == "" || personalDetailsData.OtherDetails == 0 || personalDetailsData.OtherDetails == null) {
                            personalDetailsData.OtherDetails = OtherDetails;
                        }
                        subscriptionFactory.setPersonalDetails(personalDetailsData);
                      
                        $state.go("Eidupload", {
                            "isEidInserted": $rootScope.eidUploaded
                            });
                    }
                    }
                    else {
                        if (personalDetailsData.IsIdentitySkipped && personalDetailsData.ProofOfIdentity.length == 0) {
                            personalDetailsData.IsIdentitySkipped = false;
                        }
                        if (personalDetailsData.IsSubscribedForLongTermWithoutPromoCode) {
                            hidepromocodeButtons = true;
                        }
                        if (personalDetailsData.IsSubscribedForLongTermWithoutPromoCode) {
                            hideCrossButton = true;
                        }
                        if (personalDetailsData.PromoCode) {
                            $.cookie('promocode', personalDetailsData.PromoCode);
                            subscriptionFactory.setpartnershipIdForOther(personalDetailsData.PartnershipId);
                            $rootScope.$broadcast('PartnerShip', { any: { "partnershipId": personalDetailsData.PartnershipId } });
                            globalFlagForPromoApplied = true;
                            Promocodepesnding = false;
                            subscriptionFactory.setPromoCode(personalDetailsData.PromoCode);
                        }
                        personalDetailsData.ChildDetails.DateOfBirth = new Date(personalDetailsData.ChildDetails.DateOfBirth);
                        var childDetailsSaving = {
                            "childDetails": personalDetailsData.ChildDetails,
                            "FiscalResidenceDetails": personalDetailsData.ChildFiscalResidenceDetails,
                            "OtherDetails": personalDetailsData.ChildsOtherDetails

                        };
                        subscriptionFactory.setChildDetails(childDetailsSaving);
                        

                        subscriptionFactory.setPersonalDetails(personalDetailsData);

                        if (pageName == "productDetails" || pageName == "questionDetails") {
                            subscriptionFactory.setquestionDetails(personalDetailsData.QuestionListView);
                        }
                       
                        if (personalDetailsData.IsSubscribingForFirstTime) {
                            if (!personalDetailsData.IsIdentitySkipped) {
                                $state.go("Eidupload");
                            }
                            else {
                                $state.go("parentDetails");
                            }
                        }
                        else {
                            if (!personalDetailsData.IsIdentitySkipped) {
                                $state.go("Eidupload");
                            }
                            else {

                                $state.go("parentSaved");

                            }
                        }
                        
                    }
                },
                function (error) {
                    genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
                }
            );
        }
    };

    window.onpopstate = function () {
        $state.go("subscription");
    };
}]);