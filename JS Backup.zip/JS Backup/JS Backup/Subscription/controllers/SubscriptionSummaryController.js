﻿subscriptionModule.controller('subscriptionSummController', ["$scope", "subscriptionFactory", "$rootScope", "$state", function ($scope, subscriptionFactory, $rootScope, $state) {
    $scope.$on('promoComplete', function (event, args) {
        $scope.promoCodeDetails = args.any.promocodedetails;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        globalFlagForPromoApplied = $scope.promoCodeDetails.IsApplied;
        $scope.isPromoApplied = globalFlagForPromoApplied;
    });
    $scope.hidechilddate = false;
    $scope.hidepromocodeButtons = hidepromocodeButtons;
    $scope.showPromoCodeDetail = function () {
        if (!Promocodepesnding) {
            $('#applyPromoCodeSucessful').modal('show');
            setTimeout(function () { $rootScope.$broadcast("deleteCross"); }, 10);
            if ($.cookie("promoCode") || subscriptionFactory.getPromoCode) {
                $rootScope.$broadcast("code-in-cookie-present");
            }
        }
    }
    $scope.goBack = function () {
        $state.go('productDetails');
    };
    $scope.editdetails = function (state) {
        $state.go(state);
    };
    var citylistForshowing = [];
    var citylistForshowingChild = [];
    $scope.isPromoApplied = globalFlagForPromoApplied;

    var summaryData = subscriptionFactory.wholeSubDetails();
    var newParentDate = getDateInString(new Date(summaryData.personalDetails.PersonalDetails.DateOfBirth), 'ddmmyyyy');
    var newChildDate = getDateInString(new Date(summaryData.childDetails.childDetails.DateOfBirth), 'ddmmyyyy');
    progreesStateColorChangeHeader(6);



    $scope.parentData = {
        "name": summaryData.personalDetails.PersonalDetails.PersonFirstName + ' ' + summaryData.personalDetails.PersonalDetails.PersonLastName,
        "address": summaryData.personalDetails.PersonalDetails.Street + ' ' + summaryData.personalDetails.PersonalDetails.HouseNumber + ' ' + summaryData.personalDetails.PersonalDetails.ZipCode + ' ' + summaryData.personalDetails.PersonalDetails.CityNew + ' ',
        "birthDetails": newParentDate,
        "birthDetailsPlace": summaryData.personalDetails.PersonalDetails.Birthplace,
        "phone": summaryData.personalDetails.PersonalDetails.Phone,
        "email": summaryData.personalDetails.PersonalDetails.EmailAddress
    };
    $scope.childdetails = {
        "name": summaryData.childDetails.childDetails.PersonFirstName + ' ' + summaryData.childDetails.childDetails.PersonLastName,
        "address": summaryData.childDetails.childDetails.Street + ' ' + summaryData.childDetails.childDetails.HouseNumber + ' ' + summaryData.childDetails.childDetails.ZipCode + ' ' + summaryData.childDetails.childDetails.CityNew + ' ',
        "birthDetails": newChildDate,
        "birthDetailsPlace": summaryData.childDetails.childDetails.Birthplace,
    };
    $scope.product = {
        "longterm": [],
        "shortterm": []
    };
    $scope.goNext = function () {
        
        $rootScope.$broadcast('orderDetailsData', { any: { "name": summaryData.childDetails.childDetails.PersonFirstName } });
        $('#userOnBoardingSummaryScreenModal').modal('show');
             
        $scope.RetryOnboarding();

       
    }

    $scope.RetryOnboarding = function () {
        $rootScope.$broadcast('reloadSummaryOrderModal');
        subscriptionFactory.OrderService($scope.EmptyQuote).then(
                    function (data) {
                        subscriptionFactory.setOrderDetails(data.data);
                        $rootScope.$broadcast('orderDetailssuccess');
                    },
                    function (error) {
                        $rootScope.$broadcast('oderDetailsFailure', { any: { "error": error } });
                    }
                );
    }

    $rootScope.$on('onboardingRetry', function (event, args) {

        $scope.RetryOnboarding();

    });

    for (var i = 0; i < summaryData.productDetails.arrayofProduct.length; i++) {
        summaryData.productDetails.arrayofProduct[i].moreInfo = false;
        summaryData.productDetails.arrayofProduct[i].checked = false;
        if (summaryData.productDetails.arrayofProduct[i].ProductType == 0) {
            $scope.product.longterm.push(summaryData.productDetails.arrayofProduct[i]);
        }
        else if (summaryData.productDetails.arrayofProduct[i].ProductType == 1) {
            $scope.product.longterm.push(summaryData.productDetails.arrayofProduct[i]);
        }
        else {
            $scope.product.shortterm.push(summaryData.productDetails.arrayofProduct[i]);
        }
    };
    if (summaryData.productDetails.extendSTContract) {
        var contractNeedSub = angular.copy(subscriptionFactory.getfullproduct());
        for (var i = 0; i < contractNeedSub.length; i++) {
            if (contractNeedSub[i].ProductType != 0 || contractNeedSub[i].ProductType != 1) {
                $scope.product.shortterm.push(contractNeedSub[i]);
                break;
            }
        };
    }
    $scope.checkDate = function (inputDate) {
        if (inputDate) {
            var splitArr = [];
            if (angular.element("#childbirthDateSubscription").val()) {
                splitArr = angular.element("#childbirthDateSubscription").val().split("/");
            } else if (inputDate) {
                try {
                    var constructedDate = inputDate.getDate() + "/" + (parseInt(inputDate.getMonth()) + 1) + "/" + inputDate.getFullYear();
                    splitArr = constructedDate.split("/");
                } catch (err) {
                    var res = inputDate.getUTCFullYear();
                    var res1 = inputDate.getUTCMonth();
                    var res2 = inputDate.getUTCDate();
                    res = res.toString();
                    res1 = res1.toString();
                    res1 = parseInt(res1);
                    res1 = res1 + 1;
                    res1 = res1.toString();
                    if (res1.length == 1) {
                        res1 = "0" + res1;
                    }
                    res2 = res2.toString();
                    var newres = res2 + "/" + res1 + "/" + res;
                    splitArr = newres.split("/");
                }
            }
            if (splitArr[1].length == 1) {
                splitArr[1] = "0" + splitArr[1];
            }
            if (splitArr[0].length == 1) {
                splitArr[0] = "0" + splitArr[0];
            }
            var childDate = splitArr[2] + "-" + splitArr[1] + "-" + splitArr[0];
           

            if (new Date(childDate) > new Date() || new Date(childDate) == new Date()) {
                //alert("future");
                var res = summaryData.childDetails.childDetails.DateOfBirth.getUTCFullYear();
                var res1 = summaryData.childDetails.childDetails.DateOfBirth.getUTCMonth();
                var res2 = summaryData.childDetails.childDetails.DateOfBirth.getUTCDate();

                res = res.toString();
                res1 = res1.toString();
                res1 = parseInt(res1);
                res1 = res1 + 1;
                var adddate = parseInt(res);
                if (res1 > 6) {
                    res1 = res1 - 6;
                    adddate = adddate + 1;
                }
                else {
                    res1 = res1 + 6;
                }
                res2 = res2.toString();
                res = res.toString();
                res1 = res1.toString();
                if (res1.length == 1) {
                    res1 = "0" + res1;
                }
                newres = res2 + "/" + res1 + "/" + adddate.toString();
                $scope.contractMinDuration = newres;
                $scope.hidechilddate = true;
            }
            else {
                var res = summaryData.childDetails.childDetails.DateOfBirth.getUTCFullYear();
                var res1 = summaryData.childDetails.childDetails.DateOfBirth.getUTCMonth();
                var res2 = summaryData.childDetails.childDetails.DateOfBirth.getUTCDate();

                res = res.toString();
                res1 = res1.toString();
                res1 = parseInt(res1);
                res1 = res1 + 1;
                res1 = res1.toString();
                if (res1.length == 1) {
                    res1 = "0" + res1;
                }
                res2 = res2.toString();
                var adddate = parseInt(res);
                var adddate = adddate + summaryData.productDetails.contractMaxDuration;
                newres = res2 + "/" + res1 + "/" + adddate.toString();
                $scope.contractMinDuration = newres;
            }
        }
    };
    $scope.checkDate(summaryData.childDetails.childDetails.DateOfBirth);

    $scope.PopulateQuoteDetails = function () {
        $scope.EmptyQuote = {
            "CustomerNeedViewModel": [],
            "ProductNeedViewModel": [],
            "ProductNeedViewModel": [],
            "ChoiceViewModel": [],
            "RecurrentPaymentViewModel": [],
            "ProspectIdentificationViewModel": [],
            "QuestionAnswerNeedViewModel": []
        };

        var subscriptionDetails = subscriptionFactory.wholeSubDetails();
        var newParentDate = subscriptionDetails.personalDetails.PersonalDetails.DateOfBirth;
        var newChildDate = subscriptionDetails.childDetails.childDetails.DateOfBirth;

        $scope.EmptyQuote.ParentId = subscriptionDetails.personalDetails.PersonalDetails.PersonId;
        $scope.EmptyQuote.ChildId = subscriptionDetails.childDetails.childDetails.PersonId;
        $scope.EmptyQuote.SubscriptionDate = new Date();//Today Date
        $scope.EmptyQuote.QuoteDate = new Date();//Today Date
        $scope.EmptyQuote.ContractDuration = subscriptionDetails.productDetails.contractMaxDuration;

        var ProspectDetail = {};
        ProspectDetail.ProspectLanguage = currentLanguage;

        ProspectDetail.ProspectNickName = "";
        ProspectDetail.ProspectCategoryOfProfession = subscriptionDetails.personalDetails.OtherDetails.ProfessionCategory;
        ProspectDetail.ProspectSupposedDob = newParentDate;

        var childProspectDetail = {};
        childProspectDetail.ProspectLanguage = currentLanguage;
        childProspectDetail.ProspectNickName = ""
        childProspectDetail.ProspectCategoryOfProfession = "";
        childProspectDetail.ProspectSupposedDob = newChildDate;

        $scope.EmptyProspectIdentifier = { "ProspectAddressViewModel": [] };
        $scope.EmptyChildProspectIdentifier = { "ProspectAddressViewModel": [] };
        $scope.EmptyProspectIdentifier.ProspectDetailViewModel = ProspectDetail;
        $scope.EmptyChildProspectIdentifier.ProspectDetailViewModel = childProspectDetail;

        $scope.EmptyProspectIdentifier.ProspectFirstName = subscriptionDetails.personalDetails.PersonalDetails.PersonFirstName;
        $scope.EmptyProspectIdentifier.ProspectLastName = subscriptionDetails.personalDetails.PersonalDetails.PersonLastName;
        $scope.EmptyProspectIdentifier.Gender = subscriptionDetails.personalDetails.PersonalDetails.Gender;
        if ($scope.EmptyProspectIdentifier.Gender == 'Male' || $scope.EmptyProspectIdentifier.Gender == enumMale) {
            $scope.EmptyProspectIdentifier.Gender = enumMale;
        }
        else {
            $scope.EmptyProspectIdentifier.Gender = enumFemale;
        }
        $scope.EmptyProspectIdentifier.ProspectDateOfBirth = subscriptionDetails.personalDetails.PersonalDetails.DateOfBirth;
        $scope.EmptyProspectIdentifier.ProspectNationality = subscriptionDetails.personalDetails.PersonalDetails.CountryCode;
        $scope.EmptyProspectIdentifier.ProspectPlaceOfBirth = subscriptionDetails.personalDetails.PersonalDetails.Birthplace;
        $scope.EmptyProspectIdentifier.ProspectNationalResidentNumber = subscriptionDetails.personalDetails.ProofOfIdentity[0].IdentityProofNumber;//ProspectNationalResidentNumber;

        $scope.EmptyChildProspectIdentifier.ProspectFirstName = subscriptionDetails.childDetails.childDetails.PersonFirstName;
        $scope.EmptyChildProspectIdentifier.ProspectLastName = subscriptionDetails.childDetails.childDetails.PersonLastName;
        $scope.EmptyChildProspectIdentifier.Gender = subscriptionDetails.childDetails.childDetails.Gender;
        if ($scope.EmptyProspectIdentifier.Gender == 'Boy' || $scope.EmptyChildProspectIdentifier.Gender == enumMale) {
            $scope.EmptyChildProspectIdentifier.Gender = enumMale;
        }
        else {
            $scope.EmptyChildProspectIdentifier.Gender = enumFemale;
        }

        $scope.EmptyChildProspectIdentifier.ChildRelationship = subscriptionDetails.childDetails.OtherDetails.Relationship;
        $scope.EmptyChildProspectIdentifier.ProspectDateOfBirth = subscriptionDetails.childDetails.childDetails.DateOfBirth;
        $scope.EmptyChildProspectIdentifier.ProspectNationality = subscriptionDetails.personalDetails.PersonalDetails.CountryCode;
        $scope.EmptyChildProspectIdentifier.ProspectPlaceOfBirth = subscriptionDetails.childDetails.childDetails.Birthplace;
        $scope.EmptyChildProspectIdentifier.ProspectNationalResidentNumber = "";//ProspectNationalResidentNumber;

        var ProspectAddressDetails = {
        };

        ProspectAddressDetails.CountryCode = subscriptionDetails.personalDetails.PersonalDetails.CountryCode;
        ProspectAddressDetails.Street = subscriptionDetails.personalDetails.PersonalDetails.Street;
        ProspectAddressDetails.HouseNumber = subscriptionDetails.personalDetails.PersonalDetails.HouseNumber;
        ProspectAddressDetails.AdditionalInfo = "";
        ProspectAddressDetails.ZipCode = subscriptionDetails.personalDetails.PersonalDetails.ZipCode;
        ProspectAddressDetails.City = subscriptionDetails.personalDetails.PersonalDetails.CityNew;

        var ProspectChildAddressDetails = {
        };

        ProspectChildAddressDetails.CountryCode = subscriptionDetails.childDetails.childDetails.CountryCode;
        ProspectChildAddressDetails.Street = subscriptionDetails.childDetails.childDetails.Street;
        ProspectChildAddressDetails.HouseNumber = subscriptionDetails.childDetails.childDetails.HouseNumber;
        ProspectChildAddressDetails.AdditionalInfo = "";
        ProspectChildAddressDetails.ZipCode = subscriptionDetails.childDetails.childDetails.ZipCode;
        ProspectChildAddressDetails.City = subscriptionDetails.childDetails.childDetails.CityNew;

        $scope.EmptyProspectIdentifier.ProspectAddressViewModel.push(ProspectAddressDetails);
        $scope.EmptyChildProspectIdentifier.ProspectAddressViewModel.push(ProspectChildAddressDetails);

        $scope.EmptyProspectIdentifier.FiscalResidence = subscriptionDetails.personalDetails.FiscalResidenceDetails;
        $scope.EmptyChildProspectIdentifier.FiscalResidence = subscriptionDetails.childDetails.FiscalResidenceDetails;

        $scope.EmptyProspectIdentifier.OtherDetails = subscriptionDetails.personalDetails.OtherDetails;
        $scope.EmptyChildProspectIdentifier.OtherDetails = subscriptionDetails.childDetails.OtherDetails;
        $scope.EmptyQuote.ProspectIdentificationViewModel.push($scope.EmptyProspectIdentifier);
        $scope.EmptyQuote.ProspectIdentificationViewModel.push($scope.EmptyChildProspectIdentifier);

        var ChoiceLongTerm = {
        };
        if ($scope.product.longterm.length > 0) {
            ChoiceLongTerm.ProductType = $scope.product.longterm[0].ProductType;
            ChoiceLongTerm.ProductName = $scope.product.longterm[0].ProductName;
            ChoiceLongTerm.DateofChoice = new Date();
            ChoiceLongTerm.DateofChoice = new Date();
            ChoiceLongTerm.EndDateOfContract = new Date();
        }
        $scope.EmptyQuote.ChoiceViewModel.push(ChoiceLongTerm);
        var ChoiceShortTerm = {
        };
        if ($scope.product.shortterm.length > 0) {
            ChoiceShortTerm.ProductType = $scope.product.shortterm[0].ProductType;
            ChoiceShortTerm.ProductName = $scope.product.shortterm[0].ProductName;
            ChoiceShortTerm.DateofChoice = new Date();
            ChoiceShortTerm.EndDateOfContract = new Date();
        }

        if (summaryData.productDetails.extendSTContract) {
            $scope.product.shortterm = [];
            $scope.EmptyQuote.IsContractExtended = true;
            var contractNeedSubST = angular.copy(subscriptionFactory.getfullproduct());
            for (var i = 0; i < contractNeedSubST.length; i++) {
                if (contractNeedSubST[i].ProductType != 0 && contractNeedSubST[i].ProductType != 1) {
                    ChoiceShortTerm.ProductType = contractNeedSubST[i].ProductType;
                    ChoiceShortTerm.ProductName = contractNeedSubST[i].ProductName;
                    ChoiceShortTerm.DateofChoice = new Date();
                    ChoiceShortTerm.EndDateOfContract = new Date();
                    $scope.product.shortterm.push(contractNeedSubST[i]);
                    break;

                }
            };
        }
        $scope.EmptyQuote.ChoiceViewModel.push(ChoiceShortTerm);
        for (var questionnum = 0; questionnum < subscriptionDetails.questionDetails.length; questionnum++) {
            $scope.QuestionAnswerNeedDetails = {
            };
            $scope.QuestionAnswerNeedDetails.QuestionIdentifier = subscriptionDetails.questionDetails[questionnum].QuestionId;
            $scope.QuestionAnswerNeedDetails.Answer = subscriptionDetails.questionDetails[questionnum].Answer;
            //$scope.QuestionAnswerNeedDetails.NeedType = 3;
            $scope.QuestionAnswerNeedDetails.AnswerOptionId = subscriptionDetails.questionDetails[questionnum].AnswerOptionId;
            $scope.QuestionAnswerNeedDetails.AnswerDate = new Date();
            $scope.EmptyQuote.QuestionAnswerNeedViewModel.push($scope.QuestionAnswerNeedDetails);
        };

        var contractNeed = angular.copy(subscriptionFactory.getfullproduct());

        var longtermNeed = [];
        var shorttermNeed = [];
        for (var i = 0; i < contractNeed.length; i++) {
            if (contractNeed[i].ProductType == 0 && contractNeed[i].IsRecommended) {
                longtermNeed.push(contractNeed[i]);
            }
            else if (contractNeed[i].ProductType == 1 && contractNeed[i].IsRecommended) {
                longtermNeed.push(contractNeed[i]);
            }
            else {
                if (contractNeed[i].IsRecommended) {
                    shorttermNeed.push(contractNeed[i]);
                }
            }
        };
        $scope.LongTermProductNeedDetails = [];
        if (longtermNeed.length > 0) {
            for (var i = 0 ; i < longtermNeed.length; i++) {
                var newdateForNeed = new Date();
                $scope.EmptyQuote.ProductNeedViewModel.push({
                    "ProductType": longtermNeed[i].ProductType,
                    "ProductName": longtermNeed[i].ProductName,
                    "AnswerDate": newdateForNeed,
                    "NeedType": 2
                });
            }
        }

        $scope.ShortTermProductNeedDetails = [];
        if (shorttermNeed.length > 0) {
            for (var i = 0; i < shorttermNeed.length; i++) {
                var newdateForNeed = new Date();
                $scope.EmptyQuote.ProductNeedViewModel.push({
                    "ProductType": shorttermNeed[i].ProductType,
                    "ProductName": shorttermNeed[i].ProductName,
                    "AnswerDate": newdateForNeed,
                    "NeedType": 2
                });
            }
        }

        $scope.CustomerNeedDetails = {
        };
        $scope.CustomerNeedDetails.AnswerDate = new Date();
        $scope.CustomerNeedDetails.CheckSave = 1;
        $scope.CustomerNeedDetails.NeedType = 1;

        $scope.EmptyQuote.CustomerNeedViewModel.push($scope.CustomerNeedDetails);

    };

    $scope.changeFooterShow = function () {
        if (!$scope.showfooter) {
            $scope.showfooter = true;
        }
        else {
            $scope.showfooter = false;
        }
        if (!$scope.openFaq) {
            $scope.openFaq = true;
        }
        else {
            $scope.openFaq = false;
        }
    };

    $scope.PopulateQuoteDetails();
}]);