﻿subscriptionModule.controller('subscriptionParentDetailsController', ["$scope", "subscriptionFactory", "utilityFactory", "$state", "$stateParams", "$rootScope", function ($scope, subscriptionFactory, utilityFactory, $state, $stateParams, $rootScope) {
    var mappingDteails = subscriptionFactory.getMappingDetails();
    $scope.activeaddFiscal = false;
    $scope.allPoliticalRealtionDetails = mappingDteails.allPoliticalRealtionDetails
    $scope.allProfessionalDetails = mappingDteails.allProfessionalDetails;
    $scope.allfunctionDetails = mappingDteails.allfunctionDetails;
    $scope.allCountryList = mappingDteails.allCountryList;
    $scope.cityDropDown = true;
    $scope.cityListToDisplay = [];
    $scope.hidepromocodeButtons = hidepromocodeButtons;

    $rootScope.$on('promoCanceled', function (event, args) {
        $('#pageLoader').addClass('show');
        $('html').addClass('no-scroll');
        if($scope.promoCodeDetails) {
            $scope.promoCodeDetails.IsApplied = false;
            }
        $scope.isPromoApplied = false;
        setTimeout(function () {
            $('#pageLoader').removeClass('show');
            $('html').removeClass('no-scroll');
            }, 500);
    });

    $scope.showPromoCodeDetail = function () {
        if (!Promocodepesnding) {
            $('#applyPromoCodeSucessful').modal('show');
            if ($.cookie("promoCode") || subscriptionFactory.getPromoCode) {
                $rootScope.$broadcast("code-in-cookie-present");
            }
        }
    }
    if (!globalFlagForPromoApplied) {
        if ($.cookie("promoCode") == "" || $.cookie("promoCode") == undefined || $.cookie("promoCode") == null) {
            globalFlagForPromoApplied = false;
        }
        else {
            globalFlagForPromoApplied = true;
        }
    }

    $scope.changeFooterShow = function () {
        if (!$scope.showfooter) {
            $scope.showfooter = true;
        }
        else {
            $scope.showfooter = false;
        }
        if (!$scope.openFaq) {
            $scope.openFaq = true;
        }
        else {
            $scope.openFaq = false;
        }
        //$scope.openFaq != $scope.openFaq;
    };
    $scope.$on('promoComplete', function (event, args) {
        $scope.promoCodeDetails = args.any.promocodedetails;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        globalFlagForPromoApplied = $scope.promoCodeDetails.IsApplied;
        $scope.isPromoApplied = globalFlagForPromoApplied;
    });

    $scope.isPromoApplied = globalFlagForPromoApplied;

    /*---initial data manupulation ----*/
    progreesStateColorChangeHeader(2);
    $scope.nameOfemployeer = '';
    $scope.nameOfemployeerShow = false;
    var personalDetails = subscriptionFactory.getPersonalDetails();
    $('#birthDateSubscription').mask(DateFormat, {
        translation: {
            'r': {
                pattern: /[\/]/,
                fallback: '/'
            },
            placeholder: "__/__/____"
        }
    });
    $('#subZipCode').mask(ZIPNumber);
    $("#subTinNumber").mask(TINnumber);
    //$('#subHouseNumber').inputmask('STREETNumber');
    $scope.parentDetails = personalDetails.PersonalDetails;
    $scope.parentDetails.countryList = [{ id: 'BE', Name: 'Belgium' }];

    var retrievedObject = localStorage.getItem('parentDataObjectSaved');
    if (retrievedObject != null && retrievedObject == "YES") {
        angular.element("#firstNameform").prop("disabled", true);
        angular.element("#lastNameform").prop("disabled", true);
        angular.element("#subBirthplace").prop("disabled", true);
        angular.element("#birthDateSubscription").prop("disabled", true);
    }
    /*--*/
    //$scope.$watch('OtherDetails.IsBelgiumOnlyFiscalResidence', function (newVal, oldVal) {
    //    if ($scope.OtherDetails.IsBelgiumOnlyFiscalResidence == 'false') {
    //        if ($scope.FiscalResidenceDetails.length == 0 || $scope.FiscalResidenceDetails[$scope.FiscalResidenceDetails.length - 1].CountryCodeForFiscalResidence != '') {
    //            $scope.FiscalResidenceDetails.push({
    //                "CountryCodeForFiscalResidence": "",
    //                "FiscalResidenceId": 0,
    //                "TinNumber": ""
    //            });
    //        }
    //    }
    //}, true);
    /*--*/
    //$scope.$watch(OtherDetails.IsBelgiumOnlyFiscalResidence = 'true')
    $scope.hasfiscalDetails = false;
    $scope.OtherDetails = personalDetails.OtherDetails;
//    if (subscriptionFactory.getDOB() != '') {
//    $scope.parentDetails.DateOfBirth = subscriptionFactory.getDOB();
//}
    //$scope.allProfessionalDetails = [];
    //$scope.allPoliticalRealtionDetails = [];
    //$scope.allfunctionDetails = [];
    $scope.FiscalResidenceDetails = personalDetails.FiscalResidenceDetails; 

    if ($scope.parentDetails.CountryCode == 0 || $scope.parentDetails.CountryCode) {
        $scope.parentDetails.CountryCode = 'BE';
    }
    if ($scope.parentDetails.Phone) {
        angular.element("#subPhone").prop("disabled", true);
    }
    if ($scope.parentDetails.Gender == enumMale || $scope.parentDetails.Gender == 'Male') {
        $scope.parentDetails.Gender = 'Male';
        } else {
        $scope.parentDetails.Gender = 'Female';
        }

    if ($scope.parentDetails.ZipCode) {
        $scope.parentDetails.CityZipCode = $scope.parentDetails.CityZipCode.toString();
        subscriptionFactory.getallZiplist($scope.parentDetails.ZipCode).then(
            function (data) {
                $scope.cityListToDisplay = data.Result.City;
                if ($scope.cityListToDisplay.length > 1) {
                    $scope.cityDropDown = true;
                for (var i = 0; i < $scope.cityListToDisplay.length; i++) {
                    $scope.cityListToDisplay[i].Id = $scope.cityListToDisplay[i].Id.toString();
                        if ($scope.cityListToDisplay[i].Id.toString() === $scope.parentDetails.CityZipCode.toString()) {
                            $scope.parentDetails.CityNew = $scope.cityListToDisplay[i].Name;
                            if (!$scope.$$phase) {
                                $scope.$apply();
                }
                        }
                    }
                } else {
                    $scope.cityDropDown = false;
                    if ($scope.cityListToDisplay[0]) {
                        $scope.parentDetails.CityNew = $scope.cityListToDisplay[0].Name;
                        $scope.parentDetails.CityZipCode = $scope.cityListToDisplay[0].Id;

            }
        }
            },
            function (error) {
                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
}
);
}

if (!$scope.OtherDetails.HasUsaCitizenship || $scope.OtherDetails.HasUsaCitizenship == "false" || $scope.OtherDetails.HasUsaCitizenship == 0 || $scope.OtherDetails.HasUsaCitizenship == "" || $scope.OtherDetails.HasUsaCitizenship == null) {
    $scope.OtherDetails.HasUsaCitizenship = 'false';
    } else {
    $scope.OtherDetails.HasUsaCitizenship = 'true';
    }
if (!$scope.OtherDetails.IsUsaCitizenOrResident || $scope.OtherDetails.IsUsaCitizenOrResident == "false" || $scope.OtherDetails.IsUsaCitizenOrResident == 0 || $scope.OtherDetails.IsUsaCitizenOrResident == "" || $scope.OtherDetails.IsUsaCitizenOrResident == null) {
    $scope.OtherDetails.IsUsaCitizenOrResident = 'false';
    } else {
    $scope.OtherDetails.IsUsaCitizenOrResident = 'true';
    }

if (!$scope.OtherDetails.IsBelgiumOnlyFiscalResidence || $scope.OtherDetails.IsBelgiumOnlyFiscalResidence == "false") {
    $scope.OtherDetails.IsBelgiumOnlyFiscalResidence = 'false';
        //$scope.hasfiscalDetails = 'Yes';
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
            $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence = $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence.toString();
        }
            $scope.activeaddFiscal = true;
   
        } else {
            $scope.OtherDetails.IsBelgiumOnlyFiscalResidence = 'true';
            $scope.activeaddFiscal = false;
                    $scope.FiscalResidenceDetails =[];
                    $scope.FiscalResidenceDetails.push({
                                        "CountryCodeForFiscalResidence" : "",
                                        "FiscalResidenceId": 0,
                                        "TinNumber": ""
});
    // $scope.hasfiscalDetails = 'No';
    }

if (!$scope.OtherDetails.ImportantPublicFunction || $scope.OtherDetails.ImportantPublicFunction == 0 || $scope.OtherDetails.ImportantPublicFunction == "" || $scope.OtherDetails.ImportantPublicFunction == null || $scope.OtherDetails.ImportantPublicFunction == "false") {
        //$scope.OtherDetails.ImportantPublicFunctionnew = 'No';
        $scope.OtherDetails.ImportantPublicFunction = "false";
    } else {
        // $scope.OtherDetails.ImportantPublicFunctionnew = 'Yes';
        if ($scope.OtherDetails.ImportantPublicFunction === enumMelinked || $scope.OtherDetails.ImportantPublicFunction == "Me") {
            $scope.OtherDetails.ImportantPublicFunction = "Me";
            if ($scope.OtherDetails.PoliticalFunctionCode != 0 && (!$scope.OtherDetails.PoliticalFunctionCode || $scope.OtherDetails.PoliticalFunctionCode == "" || $scope.OtherDetails.PoliticalFunctionCode == null)) {
                $scope.OtherDetails.PoliticalFunctionCode = '';
            }
            else {
                $scope.OtherDetails.PoliticalFunctionCode = $scope.OtherDetails.PoliticalFunctionCode.toString();
            }
            }
        if ($scope.OtherDetails.ImportantPublicFunction === enumPersonLinkedToMe || $scope.OtherDetails.ImportantPublicFunction == "true") {
            $scope.OtherDetails.ImportantPublicFunction = "true";
            if (!$scope.OtherDetails.PoliticalFirstName || $scope.OtherDetails.PoliticalFirstName == 0 || $scope.OtherDetails.PoliticalFirstName == "" || $scope.OtherDetails.PoliticalFirstName == null) {
                $scope.OtherDetails.PoliticalFirstNamenew = '';
            }
            if (!$scope.OtherDetails.PoliticalLastName || $scope.OtherDetails.PoliticalLastName == 0 || $scope.OtherDetails.PoliticalLastName == "" || $scope.OtherDetails.PoliticalLastName == null) {
                $scope.OtherDetails.PoliticalLastName = '';
            }
            if ($scope.OtherDetails.PoliticalRelationCode != 0 && (!$scope.OtherDetails.PoliticalRelationCode || $scope.OtherDetails.PoliticalRelationCode == "" || $scope.OtherDetails.PoliticalRelationCode == null)) {
                $scope.OtherDetails.PoliticalRelationCode = '';
            }
            else {
                $scope.OtherDetails.PoliticalRelationCode = $scope.OtherDetails.PoliticalRelationCode.toString();
            }
            if ($scope.OtherDetails.PoliticalFunctionCode != 0 && (!$scope.OtherDetails.PoliticalFunctionCode || $scope.OtherDetails.PoliticalFunctionCode == "" || $scope.OtherDetails.PoliticalFunctionCode == null)) {
                $scope.OtherDetails.PoliticalFunctionCode = '';
            }
            else {
                $scope.OtherDetails.PoliticalFunctionCode = $scope.OtherDetails.PoliticalFunctionCode.toString();
            }
            }
            }
    if ($scope.OtherDetails.ProfessionCategory != 0 && (!$scope.OtherDetails.ProfessionCategory || $scope.OtherDetails.ProfessionCategory == "" || $scope.OtherDetails.ProfessionCategory == null)) {
        $scope.OtherDetails.ProfessionCategory = '';
    }
    else {
        $scope.OtherDetails.ProfessionCategory = $scope.OtherDetails.ProfessionCategory.toString();
        }
    if (!$scope.OtherDetails.ProfessionDetailedText || $scope.OtherDetails.ProfessionDetailedText == 0 || $scope.OtherDetails.ProfessionDetailedText == "" || $scope.OtherDetails.ProfessionDetailedText == null) {
        $scope.OtherDetails.ProfessionDetailedText = '';
}

    /*---initial data manupulation ----*/

    $scope.showPromoCodeDetail = function () {
        if (!Promocodepesnding) {
            $('#applyPromoCodeSucessful').modal('show');
        }
}


    /*------city and Zip and other functionality---*/
    $scope.citylist = [];
    if (currentLanguage.toUpperCase() == "EN") {
        $scope.citylist = constantzip.arrayofZip;
        } else if (currentLanguage.toUpperCase() == "FR") {
            $scope.citylist = constantzip_FR.arrayofZip;
            } else if (currentLanguage.toUpperCase() == "NL") {
                $scope.citylist = constantzip_NL.arrayofZip;
                }

            $scope.ziplist = constantZipCode.arrayOfzipCode;
    //$scope.getCitybyZip = function (zip) {
    //    if (zip) {
    //        var countofmatchZip = 0;
    //        var countofMatchCity = 0;
    //        var cityList = [];
    //        $scope.parentDetails.City = '';
    //        $scope.cityListToDisplay = [];
    //        $scope.cityDropDown = false;
    //        for (var i = 0; i < $scope.ziplist.length; i++) {
    //            if ($scope.ziplist[i].name == zip) {
    //                countofmatchZip = 1;
    //                for (var j = 0; j < $scope.citylist.length; j++) {
    //                    if ($scope.ziplist[i].id == $scope.citylist[j].id) {
    //                        countofMatchCity++;
    //                        cityList.push($scope.citylist[j].name)
    //                        //$scope.childDetails.City = $scope.citylist[j].name;
    //                    }
    //                }
    //            }
    //        }
    //        if (countofMatchCity == 0) {
    //            $scope.parentDetails.City = '';
    //            $scope.parentDetails.ZipCode = '';
    //            //alert('no matching city found');
    //        } else if (countofmatchZip == 0) {
    //            $scope.parentDetails.City = '';
    //            $scope.parentDetails.ZipCode = '';
    //            //alert('no matching Zipcode found');
    //        } else if (countofMatchCity == 1) {
    //            $scope.parentDetails.City = cityList[0];
    //            $scope.cityDropDown = false;
    //        } else if (countofMatchCity > 1) {
    //            $scope.cityDropDown = true;
    //            $scope.parentDetails.City = cityList[0];
    //            $scope.cityListToDisplay = null;
    //            $scope.cityListToDisplay = cityList;
    //            //$scope.cityListToDisplay = cityList;
    //        }
    //        setTimeout(function () {
    //            $("#subCity").selectpicker("destroy");
    //            $("#subCity").selectpicker();
    //        }, 800);
    //    }
    //}

    $scope.cityDropDownChange = function (CityZipCode) {
        if (CityZipCode) {
            subscriptionFactory.getallZiplist($scope.parentDetails.ZipCode).then(
                function (data) {
                    citylistForshowing = data.Result.City;
                    for (var i = 0; i < citylistForshowing.length; i++) {
                        if (citylistForshowing[i].Id.toString() === CityZipCode) {
                            $scope.parentDetails.CityNew = citylistForshowing[i].Name;
                        }
                    }
                },
                function (error) {
                    genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
                }
            );
        }
    }

    $scope.getCitybyZip = function (zip) {
        if (zip) {
            subscriptionFactory.getallZiplist(zip).then(
                            function (data) {
                                if (!data || !data.Result || !data.Result.City || data.Result.City.length > 0) {

                                    $scope.parentDetails.ZipCode = data.Result.ZipCode;
                                    //$scope.parentDetails.CityZipCode = '';
                                    $scope.parentDetails.CityNew = '';
                            }
                                $scope.cityListToDisplay = data.Result.City;
                                //for (var i = 0; i < $scope.cityListToDisplay.length; i++) {
                                //    $scope.cityListToDisplay[i].Id = $scope.cityListToDisplay[i].Id.toString();
                                //}
                                





                                if ($scope.cityListToDisplay.length > 1) {
                                    $scope.cityDropDown = true;
                                for (var i = 0; i < $scope.cityListToDisplay.length; i++) {
                                    $scope.cityListToDisplay[i].Id = $scope.cityListToDisplay[i].Id.toString();
                                        if ($scope.cityListToDisplay[i].Id.toString() === $scope.parentDetails.CityZipCode.toString()) {
                                            $scope.parentDetails.CityNew = $scope.cityListToDisplay[i].Name;
                                            if (!$scope.$$phase) {
                                                $scope.$apply();
                                            }
                                        }
                            }
                                } else {
                $scope.cityDropDown = false;
                                    if ($scope.cityListToDisplay[0]) {
                                        $scope.parentDetails.CityNew = $scope.cityListToDisplay[0].Name;
                                        $scope.parentDetails.CityZipCode = $scope.cityListToDisplay[0].Id;

                            }
                            }
        },
                            function (error) {
                                $scope.childDetails.ZipCode = '';
                                $scope.childDetails.CityZipCode = '';
                                $scope.childDetails.CityNew = '';
                                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
        }
                        );
                        }
                        };

    $scope.changeprofessionText = function () {
        // "Salaried", "CivilServant", "Liberal", "Profession", "Administrator",
        //"Student", "Unemployed", "Annuitant", "Freelancer", "Retired", "Other"]
        if ($.trim($scope.OtherDetails.ProfessionCategory) === '0') {
            $scope.nameOfemployeer = Resources.ProfessionCategory_EmployerName//'Name of the employer';

            // begin: for fix 8683
            $scope.OtherDetails.ProfessionLabel = 0;
            //$scope.OtherDetails.ProfessionDetailedText = 0;
            //end

            $scope.nameOfemployeerShow = true;
            }
            else if ($.trim($scope.OtherDetails.ProfessionCategory) === '7') {
                $scope.nameOfemployeer = Resources.ProfessionCategory_SectorName;//'Sector of activity';
                $scope.nameOfemployeerShow = true;

                // begin: for fix 8683
                $scope.OtherDetails.ProfessionLabel = 1;
                //$scope.OtherDetails.ProfessionDetailedText = 1;
                //end
                }
                else if ($.trim($scope.OtherDetails.ProfessionCategory) === '3') {
                    $scope.nameOfemployeer = Resources.ProfessionCategory_CompanyName;//'Company name';
                    $scope.nameOfemployeerShow = true;

                    // begin: for fix 8683
                    $scope.OtherDetails.ProfessionLabel = 2;
                    // $scope.OtherDetails.ProfessionDetailedText = 2;
                    //end
                    }
                    else if ($.trim($scope.OtherDetails.ProfessionCategory) === '2') {
                        $scope.nameOfemployeer = Resources.ProfessionCategory_TypeLiberalProfession;//'Type of Liberal profession';
                        $scope.nameOfemployeerShow = true;

                        // begin: for fix 8683
                        $scope.OtherDetails.ProfessionLabel = 3;
                        //$scope.OtherDetails.ProfessionDetailedText = 3;
                        //end
                        }
                        else if ($.trim($scope.OtherDetails.ProfessionCategory) === '9') {
                            $scope.nameOfemployeer = Resources.ProfessionCategory_Other;//'Precise';
                            $scope.nameOfemployeerShow = true;

                            // begin: for fix 8683
                            $scope.OtherDetails.ProfessionLabel = null;
                            $scope.OtherDetails.ProfessionDetailedText = null;
                            //end
                        }
                            //else if ($scope.OtherDetails.ProfessionCategory === '' || !$scope.OtherDetails.ProfessionCategory || $scope.OtherDetails.ProfessionCategory === 'Choose an option') {
                            //    $scope.nameOfemployeer = '';
                            //    $scope.nameOfemployeerShow = false;
                            //}
        else {
                        $scope.nameOfemployeer = '';
                        $scope.nameOfemployeerShow = false;

                            // begin: for fix 8683
                            $scope.OtherDetails.ProfessionLabel = null;
                            $scope.OtherDetails.ProfessionDetailedText = null;
    //end
}
}

    /*------city and Zip  and other  functionality---*/

    /*------go back and front---*/

    $scope.goToChilddetails = function () {
        if (!$('#parentForm').valid()) {
            $('#parentForm').valid();
            return;
        }

        var countofRepeate = 0;
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
            var j = 0;
            for (j = 0; j < $scope.FiscalResidenceDetails.length; j++) {
                if (i != j && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[j].CountryCodeForFiscalResidence) {
                    countofRepeate++;
                }
            }
        }
        if (countofRepeate > 0) {
            return;
        }
        else {
            for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                if ($scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                    $scope.FiscalResidenceDetails.splice(i, 1);
                    i--;
                }
            }
        }
        personalDetails.PersonalDetails = $scope.parentDetails;
        personalDetails.OtherDetails = $scope.OtherDetails;
        personalDetails.FiscalResidenceDetails = $scope.FiscalResidenceDetails;
        subscriptionFactory.setPersonalDetails(personalDetails);

        if ($scope.parentDetails.Gender == enumMale || $scope.parentDetails.Gender == 'Male') {
            subscriptionFactory.setGender(enumMale);
        } else {
            subscriptionFactory.setGender(enumFemale);
        }
        $state.go("childDetails");
    }

    $scope.goBack = function () {
        personalDetails.PersonalDetails = $scope.parentDetails;
        personalDetails.OtherDetails = $scope.OtherDetails;
        personalDetails.FiscalResidenceDetails = $scope.FiscalResidenceDetails;
        subscriptionFactory.setPersonalDetails(personalDetails);
        $state.go("Eidupload");
};
    /*------go back and front---*/

    $scope.changeprofessionText();

    
      $(document).on("change", "[name ^='inputParentFiscalCountry_']", function() {
         $scope.childfiscalresidenceselected($(this))
    });

    $scope.childfiscalresidenceselected = function (element) {

        // if()
        //bc.substring(24, abc.length);
        index = Number(element[0].id.substring(25, element[0].id.length));
        var countofsame = 0;
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
            if (i != index && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[index].CountryCodeForFiscalResidence) {
                $("#inputParentFiscalCountry_" + index).closest(".fiscal-country-dropdown").find(".sb-max-file-size").show();
                $("#inputParentFiscalCountry_" + index).closest(".bootstrap-select").find("button").addClass("subscription-fiscal-dropdown-error-color");
                countofsame = 1;
                break;
            }
        }
        if (countofsame == 0) {
            $("#inputParentFiscalCountry_" + index).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
            $("#inputParentFiscalCountry_" + index).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
            var countofRepeate = 0;
            for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                var countofMatch = 0;
                var j = 0;
                for (j = 0; j < $scope.FiscalResidenceDetails.length; j++) {
                    if (i != j && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[j].CountryCodeForFiscalResidence) {
                        // $("#inputParentFiscalCountry_" + index).closest(".fiscal-country-dropdown").find(".sb-max-file-size").show();
                        // $("#inputParentFiscalCountry_" + index).addClass("error");
                        countofMatch = 1;
                        countofRepeate = 1;
                        //return false;
                    }
                  }
                if (countofMatch == 0) {
                    $("#inputParentFiscalCountry_" + i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                    $("#inputParentFiscalCountry_" + i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
                }
            }
            if (countofRepeate > 0) {
                $scope.activeaddFiscal = false;
            } else {
                $scope.activeaddFiscal = true;
                for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                     $("#inputParentFiscalCountry_" +i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                     $("#inputParentFiscalCountry_" +i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
                    }
            }
        }
        else {
            $scope.activeaddFiscal = false;
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
            var countofMatch = 0;
            var j = 0;
            for (j = 0; j < $scope.FiscalResidenceDetails.length; j++) {
                if (i != j && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[j].CountryCodeForFiscalResidence) {
                    // $("#inputParentFiscalCountry_" + index).closest(".fiscal-country-dropdown").find(".sb-max-file-size").show();
                    // $("#inputParentFiscalCountry_" + index).addClass("error");
                    countofMatch = 1;
                    countofRepeate = 1;
                    //return false;
                }
            }
                if(countofMatch == 0) {
                    $("#inputParentFiscalCountry_" + i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                    $("#inputParentFiscalCountry_" +i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
                    }
                    }
    }
          for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
              if ($scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == "") {
                  $scope.activeaddFiscal = false;
                }
           }
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };
    $scope.addSourceBlock = function () {
            $scope.FiscalResidenceDetails.push({
                "CountryCodeForFiscalResidence": "",
                        "FiscalResidenceId": 0,
                "TinNumber": ""
            });
            if (!$scope.$$phase) {
            $scope.$apply();
        }
            $scope.activeaddFiscal = false;
        };
    $scope.removeSourceBlock = function (index) {
        $scope.FiscalResidenceDetails.splice(index, 1);

        var countofRepeate = 0;
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
            var countofMatch = 0;
            var j = 0;
            for (j = 0; j < $scope.FiscalResidenceDetails.length; j++) {
                if (i != j && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[j].CountryCodeForFiscalResidence) {
                    // $("#inputParentFiscalCountry_" + index).closest(".fiscal-country-dropdown").find(".sb-max-file-size").show();
                    // $("#inputParentFiscalCountry_" + index).addClass("error");
                    countofMatch = 1;
                    countofRepeate = 1;
                    //return false;
                }
            }
            if (countofMatch == 0) {
                $("#inputParentFiscalCountry_" + i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                $("#inputParentFiscalCountry_" + i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
            }
        }
        if (countofRepeate > 0) {
            $scope.activeaddFiscal = false;
        } else {
            $scope.activeaddFiscal = true;
            for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                $("#inputParentFiscalCountry_" + i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                $("#inputParentFiscalCountry_" + i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
            }
        }
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
              if ($scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == "") {
                  $scope.activeaddFiscal = false;
                }
        }

        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };
}]);