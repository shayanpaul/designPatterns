﻿subscriptionModule.controller('subscriptionProductController', ["$scope", "subscriptionFactory", "$state", "$timeout", "$stateParams", "$rootScope", function ($scope, subscriptionFactory, $state, $timeout, $stateParams, $rootScope) {

    $rootScope.$on('promoCanceled', function (event, args) {
        $('#pageLoader').addClass('show');
        $('html').addClass('no-scroll');
        if($scope.promoCodeDetails) {
            $scope.promoCodeDetails.IsApplied = false;
            }
        $scope.isPromoApplied = false;
        setTimeout(function () {
            $('#pageLoader').removeClass('show');
            $('html').removeClass('no-scroll');
            }, 500);
    });


    $scope.$on('promoComplete', function (event, args) {
        $scope.extendSTContract = false;
        $scope.promoCodeDetails = args.any.promocodedetails;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        globalFlagForPromoApplied = $scope.promoCodeDetails.IsApplied;
        $scope.isPromoApplied = globalFlagForPromoApplied;
    });
    $scope.hidepromocodeButtons = hidepromocodeButtons;
    $('#contractDurationDate').css("pointer-events", "none");
    $scope.isPromoApplied = globalFlagForPromoApplied;
    $scope.contract = [];
    $scope.shortTerm = [];
    $scope.longTerm = [];
    progreesStateColorChangeHeader(5);
    $scope.contractMaxDuration = 24;
    $scope.contractMinimumDuration = 0;
    $scope.arrayofProduct = [];
    $scope.enableButton = false;
    $scope.changeContractDuration = function (x) {
        $scope.contractMaxDuration = $scope.contractMaxDuration + x;
        if (Number($scope.contractMaxDuration) < 25 && Number($scope.contractMaxDuration) > Number($scope.contractMinimumDuration - 1)) {

            angular.element("#contractDateErrorMsg").parent().removeClass("error");
            angular.element("#contractDateErrorMsg").parent().find("#contractDateErrorMsg").empty();
        }

    }


    $scope.ShowCheckBox = function (id) {
        id = id.tostring();
        $('#agreeTermDiv' + id).removeClass('ng-hide');
    }
    $scope.removeError = function (event) {
        var selectedId = event.currentTarget.id;
        angular.element("#" + selectedId).parent().removeClass('error')
        angular.element("#" + selectedId).parent().find("#contractDateErrorMsg").empty();
    }

    $scope.goNext = function () {

        if (Number($scope.contractMaxDuration) > 24) {
            angular.element("#contractDateErrorMsg").text(angular.element("#ContractDate_More").val());
            angular.element("#contractDateErrorMsg").parent().addClass("error");
        }
        else if (Number($scope.contractMaxDuration) < 18) {
            angular.element("#contractDateErrorMsg").text(angular.element("#ContarctDate_Less").val());
            angular.element("#contractDateErrorMsg").parent().addClass("error");
        }
        else if (Number($scope.contractMaxDuration) > 18 && Number($scope.contractMaxDuration) < $scope.contractMinimumDuration) {
            angular.element("#contractDateErrorMsg").text(angular.element("#ContarctDate_Invalid").val());
            angular.element("#contractDateErrorMsg").parent().addClass("error");
        }
        else if (Number($scope.contractMaxDuration) == 18 && Number($scope.contractMaxDuration) < $scope.contractMinimumDuration) {
            angular.element("#contractDateErrorMsg").text(angular.element("#ContarctDate_Invalid").val());
            angular.element("#contractDateErrorMsg").parent().addClass("error");
        }
        else {

            var contractNeedSubST = angular.copy(subscriptionFactory.getfullproduct());
            if (!contractNeedSubST[0].IsPreBirthContractExist || (contractNeedSubST[0].IsPreBirthContractExist && $scope.extendSTContract)) {
                var data = {
                    "arrayofProduct": $scope.arrayofProduct,
                    "contractMaxDuration": $scope.contractMaxDuration,
                    "extendSTContract": $scope.extendSTContract
                }
                subscriptionFactory.setproductDetails(data);
                var saveData = subscriptionFactory.saveSubscriptionDetails("product", data);
                var childDob = saveData.ChildDetails.DateOfBirth;
                var formattedDate = childDob.getFullYear() + '-' + (Number(childDob.getMonth() + 1) > 9 ? Number(childDob.getMonth() + 1) : '0' + Number(childDob.getMonth() + 1)) + '-' + (Number(childDob.getDate()) > 9 ? childDob.getDate() : '0' + childDob.getDate());
                var millisecs = new Date(formattedDate).getTime();
                saveData.ChildDetails.DateOfBirth = new Date(millisecs);
                
                saveData.ProductRecommendationView.DateOfBirth = saveData.ChildDetails.DateOfBirth;
                subscriptionFactory.postSubscriptionData(saveData).then(
                            function (data) {
                                if (data) {
                                    subscriptionFactory.setChildIdParially(data.data);
                                }
                                $state.go('summary');

                            },
                            function (error) {
                                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
                            }
                );

            }
            else {
                $('#subscriptionSTextendModalDate').text(' ' + $scope.dateofSTExpiry + '. ')
                $('#subscriptionSTextendModal').modal('show');
            }

        }
    }

    $('#okSubscriptionSTextendModal').click(function () {
        $scope.okClicked();
    });

    $('#cancelSubscriptionSTextendModal').click(function () {
        $scope.cancelClicked();
    });

    $scope.cancelClicked = function () {
        $('#subscriptionSTextendModal').modal('hide');
    }
    $scope.okClicked = function () {
        var data = {
            "arrayofProduct": $scope.arrayofProduct,
            "contractMaxDuration": $scope.contractMaxDuration,
            "extendSTContract": $scope.extendSTContract
        }
        subscriptionFactory.setproductDetails(data);
        $('#subscriptionSTextendModal').modal('hide');
        var saveData = subscriptionFactory.saveSubscriptionDetails("product", data);
        subscriptionFactory.postSubscriptionData(saveData).then(
            function (data) {
                if (data) {
                    subscriptionFactory.setChildIdParially(data.data);
                }
                $state.go('summary');

            },
            function (error) {
                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
            }
        );
    }

    $scope.goBack = function () {
        $state.go('questionDetails');
    }

    $scope.changeFooterShow = function () {
        if (!$scope.showfooter) {
            $scope.showfooter = true;
        }
        else {
            $scope.showfooter = false;
        }
        if (!$scope.openFaq) {
            $scope.openFaq = true;
        }
        else {
            $scope.openFaq = false;
        }
    };

    $scope.expandSubProductDetail = function (event) {
        $(event.target).parents('.selection-expand').children('.selection-collapsed').toggleClass('show');
    };

    subscriptionFactory.getallConratcduration($stateParams.dateOfBirth).then(
       function (data) {
           $scope.contractMinimumDuration = data;
       },
       function (error) {
           genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
       }
   );

    $scope.showPromoCodeDetail = function () {
        if (!Promocodepesnding) {
            $('#applyPromoCodeSucessful').modal('show');
            if ($.cookie("promoCode") || subscriptionFactory.getPromoCode) {
                $rootScope.$broadcast("code-in-cookie-present");
            }
        }
    }
    subscriptionFactory.getallConratcinfo($stateParams.childId, $stateParams.dateOfBirth).then(
        function (data) {
            $scope.contract = data.data;

            subscriptionFactory.setfullproduct($scope.contract);

            if ($scope.contract[0].IsPreBirthContractExist) {
                $scope.dateofSTExpiry = $scope.contract[0].PreBirthContractEndDate.substring(0, 10);
                for (var i = 0; i < $scope.contract.length; i++) {
                    $scope.contract[i].moreInfo = false;
                    $scope.contract[i].checked = false;
                    if ($scope.contract[i].ProductType == 1) {
                        $scope.contract[i].TileType = $scope.contract[i].ProductName; //'Aagje Dynamic';
                        $scope.contract[i].TitleNew = 'Branch 23';
                        $scope.longTerm.push($scope.contract[i]);
                    }
                    else if ($scope.contract[i].ProductType == 0) {
                        $scope.contract[i].TileType = $scope.contract[i].ProductName;
                        $scope.contract[i].TitleNew = 'Branch 21';
                        $scope.longTerm.push($scope.contract[i]);
                    }

                }
            }
            else {
                for (var i = 0; i < $scope.contract.length; i++) {
                    $scope.contract[i].moreInfo = false;
                    $scope.contract[i].checked = false;
                    if ($scope.contract[i].ProductType == 1) {
                        $scope.contract[i].TileType = $scope.contract[i].ProductName; //'Aagje Dynamic';
                        $scope.contract[i].TitleNew = 'Branch 23';
                        $scope.longTerm.push($scope.contract[i]);
                    }
                    else if ($scope.contract[i].ProductType == 0) {
                        $scope.contract[i].TileType = $scope.contract[i].ProductName;
                        $scope.contract[i].TitleNew = 'Branch 21';
                        $scope.longTerm.push($scope.contract[i]);
                    }

                    else {
                        $scope.contract[i].TileType = $scope.contract[i].ProductName; //'Aagje Fun';
                        $scope.contract[i].TitleNew = 'Branch 26';
                        $scope.shortTerm.push($scope.contract[i]);
                    }
                }
            }
            $timeout(reProductdata, 500);
        },
        function (error) {
            genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
        }
    );

    var reProductdata = function () {
        var dataFromFac = subscriptionFactory.getproductDetails();
        if (dataFromFac && dataFromFac != '' && dataFromFac != null) {
            $scope.enableButton = true;
            $scope.contractMaxDuration = dataFromFac.contractMaxDuration;
            $scope.extendSTContract = dataFromFac.extendSTContract;
            $scope.arrayofProduct = dataFromFac.arrayofProduct;
            if ($scope.longTerm.length > 0) {
                if (dataFromFac.arrayofProduct.length == 1) {
                    $scope.shorttermChecked = 'shortermhecked';
                    for (var i = 0; i < $scope.longTerm.length; i++) {
                        if ($scope.longTerm[i].ProductType != dataFromFac.arrayofProduct[0].ProductType) {
                            $scope.longTerm[i].moreInfo = false;
                            $scope.longTerm[i].checked = false;
                        } else {
                            $scope.longTerm[i].moreInfo = 'true';
                            $scope.longTerm[i].checked = 'checked';
                            $('#agreeTerm' + $scope.longTerm[i].ProductType).prop('checked', true);
                        }
                    }
                } else if (dataFromFac.arrayofProduct.length == 2) {
                    $scope.shorttermChecked = false;
                    for (var i = 0; i < dataFromFac.arrayofProduct.length; i++) {
                        if (dataFromFac.arrayofProduct[i].Title == "Short term") {
                            for (var j = 0; j < $scope.shortTerm.length; j++) {
                                if ($scope.shortTerm[j].ProductType != dataFromFac.arrayofProduct[i].ProductType) {
                                    $scope.shortTerm[j].moreInfo = false;
                                    $scope.shortTerm[j].checked = false;
                                } else {
                                    $scope.shortTerm[j].moreInfo = 'true';
                                    $scope.shortTerm[j].checked = 'checked';
                                    $('#agreeTerm' + $scope.shortTerm[j].ProductType).prop('checked', true);
                                }
                            }
                        } else if (dataFromFac.arrayofProduct[i].Title == "Long term") {
                            for (var j = 0; j < $scope.longTerm.length; j++) {
                                if ($scope.longTerm[j].ProductType != dataFromFac.arrayofProduct[i].ProductType) {
                                    $scope.longTerm[j].moreInfo = false;
                                    $scope.longTerm[j].checked = false;
                                } else {
                                    $scope.longTerm[j].moreInfo = 'true';
                                    $scope.longTerm[j].checked = 'checked'; gemalto: apiUrl
                                    $('#agreeTerm' + $scope.longTerm[j].ProductType).prop('checked', true);
                                }
                            }
                        }
                    }

                } else {
                }
            } else {
                if (dataFromFac.arrayofProduct.length == 1) {

                    for (var i = 0; i < $scope.shortTerm.length; i++) {
                        if ($scope.shortTerm[i].ProductType != dataFromFac.arrayofProduct[0].ProductType) {
                            $scope.shortTerm[i].moreInfo = false;
                            $scope.shortTerm[i].checked = false;
                        } else {
                            $scope.shortTerm[i].moreInfo = 'true';
                            $scope.shortTerm[i].checked = 'checked';
                            $('#agreeTerm' + $scope.shortTerm[i].ProductType).trigger("click");
                            $('#agreeTerm' + $scope.shortTerm[i].ProductType).prop('checked', true);
                        }
                    }
                } else {
                    $scope.shorttermChecked = 'shortermhecked';
                }
            }
        }
    }

    $scope.noShortterm = function () {
        for (var i = 0; i < $scope.arrayofProduct.length; i++) {
            if ($scope.arrayofProduct[i].Title == "Short term") {
                $scope.arrayofProduct.splice(i, 1);
            }
        }
        for (var i = 0; i < $scope.shortTerm.length; i++) {
            $scope.shortTerm[i].checked = false;
            $scope.shortTerm[i].moreInfo = false;
        }
        $scope.shorttermChecked = 'shortermhecked';

        if ($scope.longTerm.length > 0 && $scope.shortTerm.length > 0) {
            if ($scope.arrayofProduct.length == 2) {
                $scope.enableButton = true;
            } else if ($scope.arrayofProduct.length == 1 && $scope.shorttermChecked) {
                $scope.enableButton = true;
            } else {
                $scope.enableButton = false;
            }
        }
        else {
            if ($scope.longTerm.length > 0) {
                if ($scope.arrayofProduct.length == 1) {
                    $scope.enableButton = true;
                } else {
                    $scope.enableButton = false;
                }
            }
            else {
                if ($scope.arrayofProduct.length == 1 || $scope.shorttermChecked) {
                    $scope.enableButton = true;
                } else {
                    $scope.enableButton = false;
                }
            }
        }

    };
    $scope.changeArrayofProduct = function (flag, id) {
        if ($('#agreeTerm' + id).prop("checked") == true) {
            $scope.checkAblity(id, true, true);

        } else {
            $scope.enableButton = false;
            $scope.checkAblity(id, false, false);
        }

    };
    $scope.checkAblity = function (id, flag, checked) {
        var termPlan = '';
        for (var i = 0; i < $scope.contract.length; i++) {
            if ($scope.contract[i].ProductType == id) {
                termPlan = $scope.contract[i];
                break;
            }
        }
        if (termPlan.Title == "Long term") {
            for (var i = 0; i < $scope.arrayofProduct.length; i++) {
                if ($scope.arrayofProduct[i].Title == "Long term") {
                    $scope.arrayofProduct.splice(i, 1);
                }
            }
            for (var i = 0; i < $scope.longTerm.length; i++) {


                if ($scope.longTerm[i].ProductType != id) {
                    $scope.longTerm[i].moreInfo = false;
                    $scope.longTerm[i].checked = false;
                } else {
                    if (!checked) {
                        $scope.longTerm[i].checked = false;
                    }

                }
            }
            if (flag) {
                $scope.arrayofProduct.push(termPlan);
            }
        }
        if (termPlan.Title == "Short term") {
            $scope.shorttermChecked = false;
            for (var i = 0; i < $scope.arrayofProduct.length; i++) {
                if ($scope.arrayofProduct[i].Title == "Short term") {
                    $scope.arrayofProduct.splice(i, 1);
                }
            }
            for (var i = 0; i < $scope.shortTerm.length; i++) {

                if ($scope.shortTerm[i].ProductType != id) {
                    $scope.shortTerm[i].moreInfo = false;
                    $scope.shortTerm[i].checked = false;
                } else {
                    if (!checked) {
                        $scope.shortTerm[i].checked = false;
                    }
                }
            }

            if (flag) {
                $scope.arrayofProduct.push(termPlan);
            }
        }
        if ($scope.longTerm.length > 0 && $scope.shortTerm.length > 0) {
            if ($scope.arrayofProduct.length == 2) {
                $scope.enableButton = true;
            } else if ($scope.arrayofProduct.length == 1 && $scope.shorttermChecked) {
                $scope.enableButton = true;
            } else {
                $scope.enableButton = false;
            }
        }
        else {
            if ($scope.longTerm.length > 0) {
                if ($scope.arrayofProduct.length == 1) {
                    $scope.enableButton = true;
                } else {
                    $scope.enableButton = false;
                }
            }
            else {
                if ($scope.arrayofProduct.length == 1 || $scope.shorttermChecked) {
                    $scope.enableButton = true;
                } else {
                    $scope.enableButton = false;
                }
            }
        }

    };


    $scope.partialSave = function () {
        var data = {
            "arrayofProduct": $scope.arrayofProduct,
            "contractMaxDuration": $scope.contractMaxDuration
        }
        var saveData = subscriptionFactory.saveSubscriptionDetails("product", data);
        subscriptionFactory.postSubscriptionData(saveData).then(
            function (data) {
                genericSuccessMessageDisplay(Resources.SubscribeSuccessDataSaved);
                $("html, body").animate({ scrollTop: 0 }, 800);
                if (data) {
                    subscriptionFactory.setChildIdParially(data.data);
                }
            },
            function (error) {
                genericErrorMessageDisplay(Resources.SubscribeErrorUnableToSaveData);
                $("html, body").animate({ scrollTop: 0 }, 800);
            }
        );
    }

}]);
