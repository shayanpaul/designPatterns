﻿subscriptionModule.controller('subscriptionQuestionController', ["$scope", "subscriptionFactory", "$state", "$timeout", "$stateParams", "$rootScope", function ($scope, subscriptionFactory, $state, $timeout, $stateParams, $rootScope) {
    // $state.go('subscription.main');

    $rootScope.$on('promoCanceled', function (event, args) {
       $('#pageLoader').addClass('show');
        $('html').addClass('no-scroll');
        if ($scope.promoCodeDetails) {
            $scope.promoCodeDetails.IsApplied = false;
    }
        $scope.isPromoApplied = false;
        setTimeout(function () {
            $('#pageLoader').removeClass('show');
            $('html').removeClass('no-scroll');
        }, 500);
    });
    var maxHeightSubscriptionProduct = Math.max.apply(null, $("div.sb-project-inner").map(function ()
    {
        return $(this).outerHeight();
    }).get());
    $('.sb-project-inner').css('height', maxHeightSubscriptionProduct);
    var maxHeightSubscriptionProductWrap = Math.max.apply(null, $("div.sb-plan").map(function ()
    {
        return $(this).outerHeight();
    }).get());
    $('.sb-plan').css('height', maxHeightSubscriptionProductWrap);

    
    var maxHeightSubscriptionProductWrapText = Math.max.apply(null, $("p.sb-plan-txt").map(function () {
        return $(this).outerHeight();
    }).get());
   

    $('.sb-plan .sb-plan-txt').css('height', maxHeightSubscriptionProductWrapText);
   


    $(window).resize(function () {
        $('.sb-project-inner').css('height', maxHeightSubscriptionProduct);
        $('.sb-plan').css('height', maxHeightSubscriptionProductWrap);
        $('.sb-plan .sb-plan-txt').css('height', maxHeightSubscriptionProductWrapText);
    });

    $scope.disableButton = true;
    $scope.hidepromocodeButtons = hidepromocodeButtons;
    $scope.changeFooterShow = function () {
        if (!$scope.showfooter) {
            $scope.showfooter = true;
            }
else {
    $scope.showfooter = false;
    }
if(!$scope.openFaq) {
    $scope.openFaq = true;
        }
        else {
            $scope.openFaq = false;
    }
        //$scope.openFaq != $scope.openFaq;
        };
    $scope.goBack = function () {
        // subscriptionFactory.setquestionDetails($scope.questions);
        if ($scope.questions[7] && $scope.questions[7].Answer == "SecondOption") {
            return;
        }
        else {
            subscriptionFactory.setquestionDetails($scope.questions);
            $state.go('childDetails');
    }
}
    $scope.$on('promoComplete', function (event, args) {

        $scope.promoCodeDetails = args.any.promocodedetails;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        globalFlagForPromoApplied = $scope.promoCodeDetails.IsApplied;
        $scope.isPromoApplied = globalFlagForPromoApplied;
    });
    $scope.isPromoApplied = globalFlagForPromoApplied;
    $scope.getdata = [];
    $scope.questions = [];
    progreesStateColorChangeHeader(4);
    $scope.goNext = function () {
        subscriptionFactory.setquestionDetails($scope.questions);
        subscriptionFactory.setquestionnumber("full");
        $state.go('productDetails');
    };

    var diablelastquestion = function () {
        $("#divtobeDisabled" + $scope.questions[$scope.questions.length - 1].QuestionId).css("pointer-events", "none").addClass("disabled-questions");
    };
    var qdetail = subscriptionFactory.getquestionDetails();
    var questiondeatils = { "questiondeatils": qdetail };
    $scope.disableButton = true;
    var questionNumber = subscriptionFactory.getquestionnumber();

    
    $scope.addquestion = function (flag) {
        if ($scope.questions.length == $scope.getdata.length || !$scope.getdata || $scope.getdata.length == 0) {
            var count = 0 ;
            for (var i = 0; i < $scope.questions.length; i++) {
                if ($scope.questions[i].Answer == '' || !$scope.questions[i].Answer || $scope.questions[i].Answer == 0) {
                    count++;
                    $scope.disableButton = true;
                }
            }
            if (count == 0) {               
                $scope.disableButton = false;
            }
        }
        else {
            $scope.disableButton = true;
        }
        if (($scope.questions[7] && $scope.questions[7].Answer == "SecondOption")){
            $scope.disableButton = true;
        } 
    };
    $scope.showPromoCodeDetail = function () {
        if (!Promocodepesnding) {
            $('#applyPromoCodeSucessful').modal('show');
            if ($.cookie("promoCode") || subscriptionFactory.getPromoCode) {
                $rootScope.$broadcast("code-in-cookie-present");
            }
        }
    }

    $scope.partialSave = function () {
        var questiondeatils = {
            "questiondeatils": $scope.questions
        };
        var saveData = subscriptionFactory.saveSubscriptionDetails("question", questiondeatils);
        subscriptionFactory.postSubscriptionData(saveData).then(
                function (data) {
                    //alert('success');
                     $scope.reQuestionData(saveData.QuestionListView);
                     genericSuccessMessageDisplay(Resources.SubscribeSuccessDataSaved);
                     $("html, body").animate({ scrollTop: 0 }, 800);
                     if (data) {
                         subscriptionFactory.setChildIdParially(data.data);
                     }
                },
                function (error) {
                    //alert('error');
                    $scope.reQuestionData(saveData.QuestionListView);
                    genericErrorMessageDisplay(Resources.SubscribeErrorUnableToSaveData);
                    $("html, body").animate({ scrollTop: 0 }, 800);
                }
            );
    };
    $scope.reQuestionData = function (data) {
        var questiondeatils = { "questiondeatils": [] };
        questiondeatils.questiondeatils = data;
        $scope.disableButton = true;
        if (questiondeatils.questiondeatils && questiondeatils.questiondeatils.length != 0) {
            $scope.disableButton = false;
            for (var i = 0; i < questiondeatils.questiondeatils.length; i++) {
                if (questiondeatils.questiondeatils[i].Answer) {
                    if (questiondeatils.questiondeatils[i].Answer == 'FirstOption' || questiondeatils.questiondeatils[i].Answer == questiondeatils.questiondeatils[i].FirstOption) {
                        questiondeatils.questiondeatils[i].Answer = 'FirstOption';
                    }
                    else {
                        questiondeatils.questiondeatils[i].Answer = 'SecondOption';
                    }
                }
                else {
                    $scope.disableButton = true;
                }

            }

            $scope.questions = questiondeatils.questiondeatils;
           // $scope.disableButton = false;
        }
    }

    if (qdetail && qdetail.length != 0) {
        $scope.reQuestionData(qdetail);
    }
    else {
        subscriptionFactory.getallquestion($stateParams.childId).then(
            function (data) {
                //alert('success');
                $scope.getdata = data;
                //$scope.getdata[0].Answer == '';
                // if()
                var count = 0;
                for (var i = 0; i < $scope.getdata.length; i++) {
                    $scope.questions.push($scope.getdata[$scope.questions.length]);
                    //$scope.questions[i].disabled = false;
                    if ($scope.getdata[i].Answer == '' || !$scope.getdata[i].Answer || $scope.getdata[i].Answer == 0) {
                        count++;
                    }
                }
                if (count == 0) {
                    $scope.reQuestionData($scope.getdata);
                    $scope.disableButton = false;
                }
                else {
                    $scope.disableButton = true;
                    for (var i = 0; i < $scope.getdata.length; i++) {
                        $scope.getdata[i].Answer == null;
                    }
                    // $scope.questions = $scope.getdata;
                    //$scope.questions = questiondeatils.questiondeatils;
                }

            },
            function (error) {
            }
        );
    }
}]);