﻿subscriptionModule.controller('subscriptionConfirmController', ["$scope", "subscriptionFactory", "PromoCodeService", "$window", "$rootScope", "$state", function ($scope, subscriptionFactory, PromoCodeService, $window, $rootScope, $state) {
    $scope.sign1Checkbox = false;
    $scope.sign2Checkbox = false;
    $scope.sign3Checkbox = false;
    $scope.documentChecked = false;
    $('#pageLoader').removeClass('show');
    $('html').removeClass('no-scroll');
    $scope.isPromoApplied = globalFlagForPromoApplied;
    $scope.$on('promoComplete', function (event, args) {
        $scope.hidepromocodeButtons = hidepromocodeButtons;
        $scope.promoCodeDetails = args.any.promocodedetails;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        globalFlagForPromoApplied = $scope.promoCodeDetails.IsApplied;
        $scope.isPromoApplied = globalFlagForPromoApplied;
    });
    $scope.isPromoApplied = globalFlagForPromoApplied;
    $scope.changeFooterShow = function () {
        if (!$scope.showfooter) {
            $scope.showfooter = true;
        }
        else {
            $scope.showfooter = false;
        }
        if (!$scope.openFaq) {
            $scope.openFaq = true;
        }
        else {
            $scope.openFaq = false;
        }
        //$scope.openFaq != $scope.openFaq;
    };
    progreesStateColorChangeHeader(7);
    var summaryData = subscriptionFactory.wholeSubDetails();
    if (summaryData.personalDetails.PersonalDetails != null)
        $scope.subscriberName = summaryData.personalDetails.PersonalDetails.PersonFirstName;

    if (summaryData.childDetails.childDetails.PersonFirstName != null)
        $scope.childName = summaryData.childDetails.childDetails.PersonFirstName + ' ' + summaryData.childDetails.childDetails.PersonLastName;

    var orderServiceData = subscriptionFactory.getOrderDetails();
    $scope.orderServiceData = orderServiceData;
    if ($scope.orderServiceData && $scope.orderServiceData.length > 0) {
        $scope.documentChecked = false;
        for (var i = 0; i < $scope.orderServiceData.length; i++) {
            $scope.orderServiceData[i].documentselect = false;
        }
    }

    else {
        $scope.documentChecked = true;
    }

    $(document).on("change", "[name ^='signDocCheck']", function () {
        $scope.signChecked($(this));
    });
    $(document).on("change", "[name ^='signDoc2Check']", function () {
        $scope.signChecked($(this));
    });
    $scope.signChecked = function (element) {
        setTimeout(function () {
            var countUnselected = 0;
            for (var i = 0; i < $scope.orderServiceData.length; i++) {
                if ($scope.orderServiceData[i].SignedAsRepresentativeDocument || $scope.orderServiceData[i].SignedAsParentDocument) {
                    if ($scope.orderServiceData[i].documentselect == false) {
                     countUnselected++;
                    }
            }
            }
            if (countUnselected > 0) {
                $scope.documentChecked = false;
            }
            else {
                $scope.documentChecked = true;
            }
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        }, 100);
        
    };
    $scope.goback = function () {
        $state.go('summary');
    }
    $scope.showPromoCodeDetail = function () {
        if (!Promocodepesnding) {
            $('#applyPromoCodeSucessful').modal('show');
            setTimeout(function () { $rootScope.$broadcast("deleteCross"); }, 10);
            if ($.cookie("promoCode") || subscriptionFactory.getPromoCode) {
                $rootScope.$broadcast("code-in-cookie-present");
            }
        }
    }
    //***************************************************************************E-Signature Call Code************************************************************************//
    progreesStateColorChangeHeader(7);
    function getDocumentModelForEsignature(documentListModel, callType, ReferencedFrom) {
        $scope.documentModel = {
        };
        $scope.documentModel.lstDocument = documentListModel;
        $scope.documentModel.Signers = [];
        $scope.documentModel.Childrens = [];
        $scope.Signer = {
        };
        $scope.documentModel.Signers.push($scope.Signer);
        $scope.Children = {
        };
        $scope.documentModel.Childrens.push($scope.Children);
        $scope.documentModel.CallType = callType;
        $scope.documentModel.ReferencedFrom = ReferencedFrom;
        //$scope.documentModel.RedirectUrl = "https://aagje-web-d000.azurewebsites.net/" + currentLanguage + "/connective/ConfirmSign";
        $scope.documentModel.RedirectUrl = baseFrontEndUrl + "/connective/ConfirmSign";
        return $scope.documentModel;
        $scope.Signer = {
        };
        //,clearProsperctData();
    }

    $scope.callESignatureGateway = function (callType, ReferencedFrom) {
        $scope.callTypeEsign = callType;
        $scope.referencedFromeEsign = ReferencedFrom;
        if (callType == 'DIGITAL')
            $('#subscriptionEsignAlertModal').modal('show');
        else
            $scope.esignContinue($scope.callTypeEsign, $scope.referencedFromeEsign);
    }

    $('#esignSubscriptionContinue').click(function () {
        $scope.esignContinue($scope.callTypeEsign, $scope.referencedFromeEsign);
    });

    $scope.esignContinue = function (callType, ReferencedFrom) {
        var documentModel = getDocumentModelForEsignature(subscriptionFactory.getOrderDetails(), callType, ReferencedFrom);

        PromoCodeService.CreateSignature(documentModel).then(
            function (data) {
               
                $('#subscriptionEsignAlertModal').modal('hide');
                $window.location.href = data.data.SigningURL[0].Url;
            },
            function (error) {
                $('#subscriptionEsignAlertModal').modal('hide');
                $('#pageLoader').removeClass('show');
                $('html').removeClass('no-scroll');
                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
            }
        );
    };
    //***************************************************************************E-Signature Call Code end here************************************************************************//
}]);