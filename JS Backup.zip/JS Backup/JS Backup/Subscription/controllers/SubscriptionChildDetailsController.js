﻿subscriptionModule.controller('subscriptionChildController', ["$scope", "$rootScope", "subscriptionFactory", "utilityFactory", "$stateParams", "$state", function($scope, $rootScope, subscriptionFactory, utilityFactory, $stateParams, $state) {
    //  $state.go('subscription.main');
    $scope.selectChild = false;
    $scope.hideRadbuttons = false;
    $scope.cityDropDown = true;

    $scope.activeaddFiscal = false;

    $scope.hidepromocodeButtons = hidepromocodeButtons;

    //  $rootScope.$on('promoCanceled', function (event, args) {
    //    $('#pageLoader').addClass('show');
    //    $('html').addClass('no-scroll');
    //    $scope.promoCodeDetails.IsApplied = false;
    //    $scope.isPromoApplied = false;
    //     setTimeout(function () {
    //        $('#pageLoader').removeClass('show');
    //        $('html').removeClass('no-scroll');
    //  }, 500);
    //});

    var mappingDteails = subscriptionFactory.getMappingDetails();
    $scope.allPoliticalRealtionDetails = mappingDteails.allPoliticalRealtionDetails
    $scope.allProfessionalDetails = mappingDteails.allProfessionalDetails;
    $scope.allfunctionDetails = mappingDteails.allfunctionDetails;
    $scope.allCountryList = mappingDteails.allCountryList;
    $scope.childDataforRadio = [];
    var dataforRad = subscriptionFactory.getChildDataforRadio();


    var getallpoliticalRealations = function () {
        subscriptionFactory.getallpoliticalRealations(true).then(
            function (data) {
                $scope.allPoliticalRealtionDetails = [];
                for (var key in data) {
                    $scope.allPoliticalRealtionDetails.push(data[key]);                    
                }
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                 setTimeout(function () {
                     $("[id^='select-default']").selectpicker('refresh');
                }, 1000);
                 
                },
            function (error) {
                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
                }
        );
        };
    getallpoliticalRealations();
   
    
    if (dataforRad) {
        $scope.childDataforRadio = dataforRad;
        if ($scope.childDataforRadio && $scope.childDataforRadio.length) {
            for (var i = 0; i < $scope.childDataforRadio.length; i++) {
                if (($scope.childDataforRadio[i].IsLongTermExisting && $scope.childDataforRadio[i].IsShortTermExisting) || (!$scope.childDataforRadio[i].IsLongTermExisting && !$scope.childDataforRadio[i].IsShortTermExisting)) {
                    $scope.childDataforRadio.splice(i, 1);
                    i--;
                }
            }
        };
        var citylistForshowing = [];
        $scope.cityListToDisplay = [];




        var emptychild = {
            "ChildId": 0,
            "FirstName": "",
            "LastName": "",
            "DateOfBirth": "",
            "NickName": null,
            "IsLongTermExisting": null,
            "IsShortTermExisting": null,
            "IsBorn": null,
            "IsChildExists": null
        };

        $scope.childDataforRadio.push(emptychild);
        if ($scope.childDataforRadio.length == 1) {
            $scope.selectChild = true;
        }
    } else {
        $scope.selectChild = true;
        $scope.hideRadbuttons = true;
        subscriptionFactory.setChildStatus(true);
    }

    $scope.checkChild = function(DOB, Fname, Lname, ID) {
        $scope.selectChild = true;
        if (id == 0) {

        } else {
            $scope.childserviceCall(DOB, Fname, Lname, ID);
        }
    }
    $scope.changeFooterShow = function() {
        if (!$scope.showfooter) {
            $scope.showfooter = true;
        } else {
            $scope.showfooter = false;
        }
        if (!$scope.openFaq) {
            $scope.openFaq = true;
        } else {
            $scope.openFaq = false;
        }
        //$scope.openFaq != $scope.openFaq;
    };
    $scope.$on('promoComplete', function(event, args) {

        $scope.promoCodeDetails = args.any.promocodedetails;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        globalFlagForPromoApplied = $scope.promoCodeDetails.IsApplied;
        $scope.isPromoApplied = globalFlagForPromoApplied;
    });
    $rootScope.$on('promoCanceled', function (event, args) {
        $('#pageLoader').addClass('show');
        $('html').addClass('no-scroll');
        if ($scope.promoCodeDetails) {
        $scope.promoCodeDetails.IsApplied = false;
        }
        $scope.isPromoApplied = false;
        setTimeout(function () {
            $('#pageLoader').removeClass('show');
            $('html').removeClass('no-scroll');
        }, 500);
    });
    $scope.isPromoApplied = globalFlagForPromoApplied;
    progreesStateColorChangeHeader(3);
    
    $('#childbirthDateSubscription').mask(DateFormat, {
        translation: {
            'r': {
                pattern: /[\/]/,
                fallback: '/'
            },
            placeholder: "__/__/____"
        }
    });
    $('#subZipCode').mask(ZIPNumber);
    $('#subTinNumber').mask(TINnumber);
    
    $scope.goBack = function() {
            var childDetailsSaving = {
                "childDetails": $scope.childDetails,
                "FiscalResidenceDetails": $scope.FiscalResidenceDetails,
                "OtherDetails": $scope.OtherDetails

            };
            subscriptionFactory.setChildDetails(childDetailsSaving);
            var PersonDetailsPage = subscriptionFactory.getPersonDetailsPage();
            if (PersonDetailsPage) {
                $state.go(PersonDetailsPage);
            } else {
                $state.go("parentDetails");
            }

    }

    $scope.getCitybyZip = function (zip) {
        if (zip) {
            subscriptionFactory.getallZiplist(zip).then(
                            function (data) {
                                if (!data || !data.Result || !data.Result.City || data.Result.City.length == 0) {
                                    $scope.childDetails.ZipCode = data.Result.ZipCode;
                                    $scope.childDetails.CityZipCode = '';
                                    $scope.childDetails.CityNew = '';
                                }
                                $scope.cityListToDisplay = data.Result.City;
                                for (var i = 0; i < $scope.cityListToDisplay.length; i++) {
                                    $scope.cityListToDisplay[i].Id = $scope.cityListToDisplay[i].Id.toString();
                                }
                                if ($scope.cityListToDisplay.length > 1) {
                                    $scope.cityDropDown = true;
                                    $scope.childDetails.CityZipCode = $scope.cityListToDisplay[0].Id;
                                } else {
                                    $scope.cityDropDown = false;
                                    if ($scope.cityListToDisplay[0]) {
                                        $scope.childDetails.CityNew = $scope.cityListToDisplay[0].Name;
                                        $scope.childDetails.CityZipCode = $scope.cityListToDisplay[0].Id;

                                    }
                                }
                            },
                            function (error) {
                                $scope.childDetails.ZipCode = '';
                                $scope.childDetails.CityZipCode = '';
                                $scope.childDetails.CityNew = '';
                            }
                        );
        }
    };
       
    var childDetails = {
        "Address": "",
        "Birthplace": null,
        "City": "",
        "DateOfBirth": "",
        "EmailAddress": "",
        "FormattedUpdatedDate": null,
        "Gender": 0,
        "HouseNumber": "",
        "IsEligibleForSubscription": "",
        "PersonFirstName": "",
        "PersonId": 0,
        "PersonImage": null,
        "PersonImageUrl": null,
        "PersonLastName": "",
        "PersonNickName": "",
        "Phone": "493397547",
        "Relationship": 0,
        "UpdatedBy": null,
        "UpdatedDate": "",
        "ZipCode": "",
        "PersonRole": 0,
        "IsChild": false,
        "IsInfantSupporter": false,
        "CountryCode": "",
        "UserLanguage": "",
        "PersonCode": 0,
        "Status": 0,
        "RoleParticularityCode": 0,
        "Street": null
    };
    $scope.checkChildStatus = function (childData) {
        if (!$rootScope.onGoingSubscriptionChildId) {
            if (childData.DateOfBirth && childData.PersonFirstName && childData.PersonLastName) {
                $scope.childserviceCall(childData.DateOfBirth, childData.PersonFirstName, childData.PersonLastName, $rootScope.onGoingSubscriptionChildId);
            }
        }
    }

    $scope.childserviceCall = function(childdate, firstName, lastname, ChildId) {
        
        childdate = subscriptionFactory.convertUTCDateToLocalDate(new Date(childdate));

        subscriptionFactory.getchilddetails(childdate, firstName, lastname, $.cookie('personId')).then(
            function(data) {
                
                var ChildDetailsData = data;
                if (ChildDetailsData && ChildDetailsData.ChildDetails && ChildDetailsData.ChildDetails.PersonId)
                {
                    angular.element('#alertForSubscriptionModal').modal('show');
                    $scope.childDetails.DateOfBirth = "";
                    $scope.childDetails.PersonFirstName = "";
                    $scope.childDetails.PersonLastName = "";

                }
                
            },
            function(error) {
            }
        );
        
    }

     
    $scope.resetChild = function() {
        var ChildDetailsData = subscriptionFactory.getChildDetailsfactory();



        if (ChildDetailsData && ChildDetailsData != '' && ChildDetailsData != 0 && ChildDetailsData.childDetails) {

            if ($scope.childDetails && $scope.childDetails.DateOfBirth) {
                ChildDetailsData.childDetails.DateOfBirth = angular.copy($scope.childDetails.DateOfBirth);
            }
            if ($scope.childDetails && $scope.childDetails.PersonLastName) {
                ChildDetailsData.childDetails.PersonLastName = $scope.childDetails.PersonLastName;
            }
            if ($scope.childDetails && $scope.childDetails.Birthplace) {
                ChildDetailsData.childDetails.Birthplace = $scope.childDetails.Birthplace;
            }
            if ($scope.childDetails && $scope.childDetails.Gender) {
                ChildDetailsData.childDetails.Gender = $scope.childDetails.Gender;
            }

            if ($scope.childDetails && $scope.childDetails.PersonFirstName) {
                ChildDetailsData.childDetails.PersonFirstName = $scope.childDetails.PersonFirstName;
            }
            if ($scope.OtherDetails && $scope.OtherDetails.Relationship) {                
                var parentGender = subscriptionFactory.getGender();
                if (parentGender == enumMale) {
                    $scope.OtherDetails.Relationship = 'Father';
                } else {
                    $scope.OtherDetails.Relationship = 'Mother';
                }
                ChildDetailsData.OtherDetails.Relationship = $scope.OtherDetails.Relationship;
            }


            $scope.childDetails = ChildDetailsData.childDetails;
            $scope.OtherDetails = ChildDetailsData.OtherDetails;
            $scope.FiscalResidenceDetails = ChildDetailsData.FiscalResidenceDetails;

            if ($scope.childDetails.DateOfBirth) {
                $scope.checkDate(angular.copy($scope.childDetails.DateOfBirth),'Starting');
            }
            $scope.childValueIntrgrate();
        } else {
            $scope.childDetails = childDetails;
            $scope.OtherDetails = {
                "HasUsaCitizenship": false,
                "ImportantPublicFunction": 0,
                "IsUsaCitizenOrResident": false,
                "PoliticalFirstName": null,
                "PoliticalFunctionCode": 0,
                "PoliticalLastName": null,
                "PoliticalRelationCode": 0,
                "ProfessionCategory": 0,
                "ProfessionDetailedText": 0,
                "ProfessionLabel": 0,
                "Relationship": 0
            };
            $scope.FiscalResidenceDetails = [{
                "CountryCodeForFiscalResidence": "",
                "TinNumber": ""
            }];

        }
    };
    $scope.showPromoCodeDetail = function () {
        if (!Promocodepesnding) {
        $('#applyPromoCodeSucessful').modal('show');
            if ($.cookie("promoCode") || subscriptionFactory.getPromoCode) {
                $rootScope.$broadcast("code-in-cookie-present");
            }
        }
    }

    $scope.childdetailsassign = function () {
        $scope.personalDetails = subscriptionFactory.getPersonalDetails();
        $scope.childDetails = childDetails;

        var ChildDetailsData = subscriptionFactory.getChildDetailsfactory();
        if (ChildDetailsData && ChildDetailsData != '' && ChildDetailsData != 0 && ChildDetailsData.childDetails) {
            if (ChildDetailsData.FiscalResidenceDetails) {
                $scope.FiscalResidenceDetails = ChildDetailsData.FiscalResidenceDetails;
            }
            if (ChildDetailsData.OtherDetails) {
                $scope.OtherDetails = ChildDetailsData.OtherDetails;
            }
            $scope.childDetails.PersonId = ChildDetailsData.childDetails.PersonId;
            $scope.childDetails.DateOfBirth = angular.copy(ChildDetailsData.childDetails.DateOfBirth);
            $scope.childDetails.PersonLastName = ChildDetailsData.childDetails.PersonLastName;
            $scope.childDetails.Birthplace = ChildDetailsData.childDetails.Birthplace;
            $scope.childDetails.PersonFirstName = ChildDetailsData.childDetails.PersonFirstName;
            $scope.childDetails.Gender = ChildDetailsData.childDetails.Gender;
            if ($scope.OtherDetails && $scope.OtherDetails.Relationship) {
                $scope.OtherDetails.Relationship = ChildDetailsData.OtherDetails.Relationship;               

                var parentGender = subscriptionFactory.getGender();
                if (parentGender == enumMale) {
                    $scope.OtherDetails.Relationship = 'Father';
                } else {
                    $scope.OtherDetails.Relationship = 'Mother';
                }
                $scope.personalDetails.OtherDetails.Relationship = $scope.OtherDetails.Relationship;
                ChildDetailsData.OtherDetails.Relationship = $scope.OtherDetails.Relationship;
            }
           

            $scope.childDetails.PersonId = ChildDetailsData.childDetails.PersonId;
        }
    
        $scope.childDetails.Street = $scope.personalDetails.PersonalDetails.Street;
        $scope.childDetails.CityZipCode = $scope.personalDetails.PersonalDetails.CityZipCode;
        $scope.childDetails.ZipCode = $scope.personalDetails.PersonalDetails.ZipCode;
        $scope.childDetails.HouseNumber = $scope.personalDetails.PersonalDetails.HouseNumber;
        $scope.childDetails.CountryCode = $scope.personalDetails.PersonalDetails.CountryCode;
            $scope.FiscalResidenceDetails = $scope.personalDetails.FiscalResidenceDetails;
            $scope.OtherDetails = $scope.personalDetails.OtherDetails;
            $scope.parentDetails = $scope.personalDetails.PersonalDetails;
            if ((!$scope.personalDetails.OtherDetails || !$scope.personalDetails.OtherDetails.Relationship || $scope.personalDetails.OtherDetails.Relationship==4) && (!$scope.OtherDetails.Relationship || $scope.OtherDetails.Relationship==4)) {
       

                var parentGender = subscriptionFactory.getGender();
                if (parentGender == enumMale) {
                    $scope.OtherDetails.Relationship = 'Father';
                } else {
                    $scope.OtherDetails.Relationship = 'Mother';
                }
            }
            

        $scope.parentDetails.DateOfBirthNew = $scope.parentDetails.DateOfBirth;
    
            $scope.childValueIntrgrate('Parent');
            var childDetailsSaving = {
            "childDetails": $scope.childDetails,
            "FiscalResidenceDetails": $scope.personalDetails.FiscalResidenceDetails,
            "OtherDetails": $scope.personalDetails.OtherDetails
    };



        var copiedObjectForSaving = angular.copy(childDetailsSaving);
        subscriptionFactory.setChildDetails(copiedObjectForSaving);
    };

    $scope.cityDropDownChange = function (CityZipCode) {
        if (CityZipCode) {
            subscriptionFactory.getallZiplist($scope.childDetails.ZipCode).then(
                function (data) {
                    citylistForshowing = data.Result.City;
                    for (var i = 0; i < citylistForshowing.length; i++) {
                        if (citylistForshowing[i].Id.toString() === CityZipCode) {
                            $scope.childDetails.CityNew = citylistForshowing[i].Name;
                        }
                    }
                },
                function (error) {
                }
            );
        }
    }

    $scope.childValueIntrgrate = function(flag) {


        if ($scope.childDetails.DateOfBirth) {
            $scope.checkDate(angular.copy($scope.childDetails.DateOfBirth),'Starting');
        }


            if (flag && flag == 'Parent') {
                if ($scope.childDetails.CountryCode == 0 || $scope.childDetails.CountryCode) {
                    $scope.childDetails.CountryCode = 'BE';
                }
                if ($scope.childDetails.Gender) {
                    if ($scope.childDetails.Gender == enumMale || $scope.childDetails.Gender == 'Boy') {
                        $scope.childDetails.Gender = 'Boy';
                    } else {
                        $scope.childDetails.Gender = 'Girl';
                    }
                }

                if ($scope.childDetails.ZipCode) {
                    subscriptionFactory.getallZiplist($scope.childDetails.ZipCode).then(
                        function(data) {
                            citylistForshowing = data.Result.City;
                            for (var i = 0; i < citylistForshowing.length; i++) {
                                if (citylistForshowing[i].Id.toString() === $scope.parentDetails.CityZipCode.toString()) {
                                    $scope.childDetails.CityNew = citylistForshowing[i].Name;
                                }
                            }
                        },
                        function(error) {
                        }
                    );
                }

               

                if ($scope.OtherDetails.Relationship) {
                    if ($scope.OtherDetails.Relationship == enumMother || $scope.OtherDetails.Relationship == 'Mother') {
                        $scope.OtherDetails.Relationship = 'Mother';
                    } else if ($scope.OtherDetails.Relationship == enumFather || $scope.OtherDetails.Relationship == 'Father') {
                        $scope.OtherDetails.Relationship = 'Father';
                    } else if ($scope.OtherDetails.Relationship == enumTutor || $scope.OtherDetails.Relationship == 'Tutor') {
                        $scope.OtherDetails.Relationship = 'Tutor';
                    } else {
                        $scope.OtherDetails.Relationship = 'Other';
                    }
                    var parentGender = subscriptionFactory.getGender();
                    if (parentGender == enumMale) {
                        $scope.OtherDetails.Relationship = 'Father';
                    } else {
                        $scope.OtherDetails.Relationship = 'Mother';
                    }
                }

                if (!$scope.OtherDetails.HasUsaCitizenship || $scope.OtherDetails.HasUsaCitizenship == "false" || $scope.OtherDetails.HasUsaCitizenship == 0 || $scope.OtherDetails.HasUsaCitizenship == "" || $scope.OtherDetails.HasUsaCitizenship == null) {
                    if (currentLanguage.toUpperCase() == "EN") {
                        $scope.OtherDetails.HasUsaCitizenshipnew = 'No';
                    } else if (currentLanguage.toUpperCase() == "FR") {
                        $scope.OtherDetails.HasUsaCitizenshipnew = 'Non';
                    } else if (currentLanguage.toUpperCase() == "NL") {
                        $scope.OtherDetails.HasUsaCitizenshipnew = 'Nee';
                    }
                } else {
                    if (currentLanguage.toUpperCase() == "EN") {
                        $scope.OtherDetails.HasUsaCitizenshipnew = 'Yes';
                    } else if (currentLanguage.toUpperCase() == "FR") {
                        $scope.OtherDetails.HasUsaCitizenshipnew = 'Oui';
                    } else if (currentLanguage.toUpperCase() == "NL") {
                        $scope.OtherDetails.HasUsaCitizenshipnew = 'Ja';
                    }
                }
                if (!$scope.OtherDetails.IsUsaCitizenOrResident || $scope.OtherDetails.IsUsaCitizenOrResident == "false" || $scope.OtherDetails.IsUsaCitizenOrResident == 0 || $scope.OtherDetails.IsUsaCitizenOrResident == "" || $scope.OtherDetails.IsUsaCitizenOrResident == null) {
                    if (currentLanguage.toUpperCase() == "EN") {
                        $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'No';
                    } else if (currentLanguage.toUpperCase() == "FR") {
                        $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Non';
                    } else if (currentLanguage.toUpperCase() == "NL") {
                        $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Nee';
                    }
                } else {
                    if (currentLanguage.toUpperCase() == "EN") {
                        $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Yes';
                    } else if (currentLanguage.toUpperCase() == "FR") {
                        $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Oui';
                    } else if (currentLanguage.toUpperCase() == "NL") {
                        $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Ja';
                    }
                }



                $scope.showpoliticalDetails = false;

                if (!$scope.OtherDetails.ImportantPublicFunction || $scope.OtherDetails.ImportantPublicFunction == 0 || $scope.OtherDetails.ImportantPublicFunction == "" || $scope.OtherDetails.ImportantPublicFunction == null || $scope.OtherDetails.ImportantPublicFunction == "false") {
                    $scope.OtherDetails.ImportantPublicFunctionnew = 'No';
                    $scope.showpoliticalDetails = false;
                } else {

                    if ($scope.OtherDetails.ImportantPublicFunction === enumMelinked || $scope.OtherDetails.ImportantPublicFunction == "Me") {
                        $scope.OtherDetails.ImportantPublicFunctionnew = "Me";
                        $scope.showpoliticalDetails = "Me";
                        for (var j = 0; j < $scope.allfunctionDetails.length; j++) {
                            if ($scope.allfunctionDetails[j].Id == $scope.OtherDetails.PoliticalFunctionCode) {
                                $scope.OtherDetails.PoliticalFunctionCodenew = $scope.allfunctionDetails[j].Name;
                            }
                        }
                    }
                    if ($scope.OtherDetails.ImportantPublicFunction === enumPersonLinkedToMe || $scope.OtherDetails.ImportantPublicFunction == "true") {
                        $scope.OtherDetails.ImportantPublicFunctionnew = "Yes";
                        $scope.showpoliticalDetails = "true";

                        if (!$scope.OtherDetails.PoliticalFirstName || $scope.OtherDetails.PoliticalFirstName == 0 || $scope.OtherDetails.PoliticalFirstName == "" || $scope.OtherDetails.PoliticalFirstName == null) {
                            $scope.OtherDetails.PoliticalFirstNamenew = '-';
                        } else {
                            $scope.OtherDetails.PoliticalFirstNamenew = $scope.OtherDetails.PoliticalFirstName;
                        }

                        if (!$scope.OtherDetails.PoliticalLastName || $scope.OtherDetails.PoliticalLastName == 0 || $scope.OtherDetails.PoliticalLastName == "" || $scope.OtherDetails.PoliticalLastName == null) {
                            $scope.OtherDetails.PoliticalLastNamenew = '';
                        } else {
                            $scope.OtherDetails.PoliticalLastNamenew = $scope.OtherDetails.PoliticalLastName;
                        }

                        if ($scope.OtherDetails.PoliticalRelationCode != 0 && (!$scope.OtherDetails.PoliticalRelationCode || $scope.OtherDetails.PoliticalRelationCode == "" || $scope.OtherDetails.PoliticalRelationCode == null)) {
                            $scope.OtherDetails.PoliticalRelationCodenew = '-';
                        } else {
                            for (var j = 0; j < $scope.allPoliticalRealtionDetails.length; j++) {
                                if ($scope.allPoliticalRealtionDetails[j].Id == $scope.OtherDetails.PoliticalRelationCode) {
                                    $scope.OtherDetails.PoliticalRelationCodenew = $scope.allPoliticalRealtionDetails[j].Name;
                                }
                            }
                        }

                        if ($scope.OtherDetails.PoliticalFunctionCode != 0 && (!$scope.OtherDetails.PoliticalFunctionCode || $scope.OtherDetails.PoliticalFunctionCode == "" || $scope.OtherDetails.PoliticalFunctionCode == null)) {
                            $scope.OtherDetails.PoliticalFunctionCodenew = '-';
                        } else {
                            for (var j = 0; j < $scope.allfunctionDetails.length; j++) {
                                if ($scope.allfunctionDetails[j].Id == $scope.OtherDetails.PoliticalFunctionCode) {
                                    $scope.OtherDetails.PoliticalFunctionCodenew = $scope.allfunctionDetails[j].Name;
                                }
                            }
                        }
                    }


                }

                $scope.showprofessionalDetails = false;
                if ($scope.OtherDetails.ProfessionCategory != 0 && (!$scope.OtherDetails.ProfessionCategory || $scope.OtherDetails.ProfessionCategory == "" || $scope.OtherDetails.ProfessionCategory == null)) {
                    $scope.OtherDetails.ProfessionCategorynew = '';
                    $scope.showprofessionalDetails = false;
                } else {

                    for (var j = 0; j < $scope.allProfessionalDetails.length; j++) {
                        if ($scope.allProfessionalDetails[j].Id == $scope.OtherDetails.ProfessionCategory) {
                            $scope.OtherDetails.ProfessionCategorynew = $scope.allProfessionalDetails[j].Name;
                            if (!$scope.OtherDetails.ProfessionDetailedText || $scope.OtherDetails.ProfessionDetailedText == 0 || $scope.OtherDetails.ProfessionDetailedText == "" || $scope.OtherDetails.ProfessionDetailedText == null) {
                                $scope.OtherDetails.ProfessionDetailedTextnew = '-';
                            } else {
                                $scope.OtherDetails.ProfessionDetailedTextnew = $scope.OtherDetails.ProfessionDetailedText;
                            }
                            $scope.showprofessionalDetails = true;
                        }
                    }


                }


                if (!$scope.OtherDetails.ProfessionLabel || $scope.OtherDetails.ProfessionLabel == 0 || $scope.OtherDetails.ProfessionLabel == "" || $scope.OtherDetails.ProfessionLabel == null) {
                    $scope.OtherDetails.ProfessionLabelnew = '';
                } else {
                    $scope.OtherDetails.ProfessionLabelnew = $scope.OtherDetails.ProfessionLabel;
                }

                $scope.FiscalResidenceDetailstoShow = [];
                if (!$scope.OtherDetails.IsBelgiumOnlyFiscalResidence || $scope.OtherDetails.IsBelgiumOnlyFiscalResidence == "false") {
                    $scope.showfiscalDetails = true;

                    $scope.hasfiscalDetails = Resources.Global_No;


                    for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                        if (($scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence === 0 && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence !== '') || $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence) {
                            for (var j = 0; j < $scope.allCountryList.length; j++) {
                                if ($scope.allCountryList[j].Id == $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence) {
                                    var elementForArray = {
                                        "name:": "",
                                        "TinNumber": ""
                                    };
                                    elementForArray.name = $scope.allCountryList[j].Name;
                                    if (!$scope.FiscalResidenceDetails[i].TinNumber || $scope.FiscalResidenceDetails[i].TinNumber == 0 || $scope.FiscalResidenceDetails[i].TinNumber == "" || $scope.FiscalResidenceDetails[i].TinNumber == null) {
                                        elementForArray.TinNumber = '-';
                                    } else {
                                        elementForArray.TinNumber = $scope.FiscalResidenceDetails[i].TinNumber;
                                    }
                                    $scope.FiscalResidenceDetailstoShow.push(elementForArray);
                                }
                            }

                        }

                    }

                } else {
                    $scope.showfiscalDetails = false;

                    $scope.hasfiscalDetails = Resources.Global_Yes;

                }
            } else {

                if ($scope.childDetails.CountryCode == 0 || $scope.childDetails.CountryCode) {
                    $scope.childDetails.CountryCode = 'BE';
                }
                if ($scope.childDetails.Gender == enumMale || $scope.childDetails.Gender == 'Boy') {
                    $scope.childDetails.Gender = 'Boy';
                } else {
                    $scope.childDetails.Gender = 'Girl';
                }


                if ($scope.childDetails.ZipCode) {
                    $scope.childDetails.CityZipCode = $scope.childDetails.CityZipCode.toString();
                    subscriptionFactory.getallZiplist($scope.childDetails.ZipCode).then(
                        function(data) {
                            $scope.cityListToDisplay = data.Result.City;
                            if ($scope.cityListToDisplay.length > 1) {
                                $scope.cityDropDown = true;
                                for (var i = 0; i < $scope.cityListToDisplay.length; i++) {
                                    $scope.cityListToDisplay[i].Id = $scope.cityListToDisplay[i].Id.toString();
                                    if ($scope.cityListToDisplay[i].Id.toString() === $scope.childDetails.CityZipCode.toString()) {
                                        $scope.childDetails.CityNew = $scope.cityListToDisplay[i].Name;
                                        if (!$scope.$$phase) {
                                            $scope.$apply();
                                        }
                                    }
                                }

                            } else {
                                $scope.cityDropDown = false;
                                if ($scope.cityListToDisplay[0]) {
                                    $scope.childDetails.CityNew = $scope.cityListToDisplay[0].Name;
                                    $scope.childDetails.CityZipCode = $scope.cityListToDisplay[0].Id;

                                }
                            }
                        },
                        function(error) {
                        }
                    );
                }
                if ($scope.OtherDetails.Relationship == enumMother || $scope.OtherDetails.Relationship == 'Mother') {
                    $scope.OtherDetails.Relationship = 'Mother';
                } else if ($scope.OtherDetails.Relationship == enumFather || $scope.OtherDetails.Relationship == 'Father') {
                    $scope.OtherDetails.Relationship = 'Father';
                } else if ($scope.OtherDetails.Relationship == enumTutor || $scope.OtherDetails.Relationship == 'Tutor') {
                    $scope.OtherDetails.Relationship = 'Tutor';
                } else {
                    $scope.OtherDetails.Relationship = 'Other';
                }

                var parentGender = subscriptionFactory.getGender();
                if (parentGender == enumMale ) {
                    $scope.OtherDetails.Relationship = 'Father';
                } else {
                    $scope.OtherDetails.Relationship = 'Mother';
                }


                if (!$scope.OtherDetails.HasUsaCitizenship || $scope.OtherDetails.HasUsaCitizenship == "false" || $scope.OtherDetails.HasUsaCitizenship == 0 || $scope.OtherDetails.HasUsaCitizenship == "" || $scope.OtherDetails.HasUsaCitizenship == null) {
                    $scope.OtherDetails.HasUsaCitizenship = 'false';
                } else {
                    $scope.OtherDetails.HasUsaCitizenship = 'true';
                }
                if (!$scope.OtherDetails.IsUsaCitizenOrResident || $scope.OtherDetails.IsUsaCitizenOrResident == "false" || $scope.OtherDetails.IsUsaCitizenOrResident == 0 || $scope.OtherDetails.IsUsaCitizenOrResident == "" || $scope.OtherDetails.IsUsaCitizenOrResident == null) {
                    $scope.OtherDetails.IsUsaCitizenOrResident = 'false';
                } else {
                    $scope.OtherDetails.IsUsaCitizenOrResident = 'true';
                }


                if (!$scope.OtherDetails.IsBelgiumOnlyFiscalResidence || $scope.OtherDetails.IsBelgiumOnlyFiscalResidence == "false") {
                    $scope.OtherDetails.IsBelgiumOnlyFiscalResidence = 'false';
                    for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                        $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence = $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence.toString();
                    }
                    $scope.activeaddFiscal = true;
                   

                } else {
                    $scope.OtherDetails.IsBelgiumOnlyFiscalResidence = 'true';
                    // $scope.hasfiscalDetails = 'No';
                     $scope.activeaddFiscal = false;
                    $scope.FiscalResidenceDetails = [];
                    $scope.FiscalResidenceDetails.push({
                                        "CountryCodeForFiscalResidence": "",
                                        "FiscalResidenceId": 0,
                                        "TinNumber": ""
                                    });
                }

                if (!$scope.OtherDetails.ImportantPublicFunction || $scope.OtherDetails.ImportantPublicFunction == 0 || $scope.OtherDetails.ImportantPublicFunction == "" || $scope.OtherDetails.ImportantPublicFunction == null || $scope.OtherDetails.ImportantPublicFunction == "false") {
                    //$scope.OtherDetails.ImportantPublicFunctionnew = 'No';
                    $scope.OtherDetails.ImportantPublicFunction = "false";
                } else {
                    // $scope.OtherDetails.ImportantPublicFunctionnew = 'Yes';
                    if ($scope.OtherDetails.ImportantPublicFunction === enumMelinked || $scope.OtherDetails.ImportantPublicFunction == "Me") {
                        $scope.OtherDetails.ImportantPublicFunction = "Me";
                        if ($scope.OtherDetails.PoliticalFunctionCode != 0 && (!$scope.OtherDetails.PoliticalFunctionCode || $scope.OtherDetails.PoliticalFunctionCode == "" || $scope.OtherDetails.PoliticalFunctionCode == null)) {
                            $scope.OtherDetails.PoliticalFunctionCode = '';
                        }
                        else {
                            $scope.OtherDetails.PoliticalFunctionCode = $scope.OtherDetails.PoliticalFunctionCode.toString();
                        }
                    }
                    if ($scope.OtherDetails.ImportantPublicFunction === enumPersonLinkedToMe || $scope.OtherDetails.ImportantPublicFunction == "true") {
                        $scope.OtherDetails.ImportantPublicFunction = "true";
                        if (!$scope.OtherDetails.PoliticalFirstName || $scope.OtherDetails.PoliticalFirstName == 0 || $scope.OtherDetails.PoliticalFirstName == "" || $scope.OtherDetails.PoliticalFirstName == null) {
                            $scope.OtherDetails.PoliticalFirstNamenew = '';
                        }
                        if (!$scope.OtherDetails.PoliticalLastName || $scope.OtherDetails.PoliticalLastName == 0 || $scope.OtherDetails.PoliticalLastName == "" || $scope.OtherDetails.PoliticalLastName == null) {
                            $scope.OtherDetails.PoliticalLastName = '';
                        }
                        if ($scope.OtherDetails.PoliticalRelationCode != 0 && (!$scope.OtherDetails.PoliticalRelationCode || $scope.OtherDetails.PoliticalRelationCode == "" || $scope.OtherDetails.PoliticalRelationCode == null)) {
                            $scope.OtherDetails.PoliticalRelationCode = '';
                        } else {
                            $scope.OtherDetails.PoliticalRelationCode = $scope.OtherDetails.PoliticalRelationCode.toString();
                        }
                        if ($scope.OtherDetails.PoliticalFunctionCode != 0 && (!$scope.OtherDetails.PoliticalFunctionCode || $scope.OtherDetails.PoliticalFunctionCode == "" || $scope.OtherDetails.PoliticalFunctionCode == null)) {
                            $scope.OtherDetails.PoliticalFunctionCode = '';
                        } else {
                            $scope.OtherDetails.PoliticalFunctionCode = $scope.OtherDetails.PoliticalFunctionCode.toString();
                        }
                    }


                }


            }
        }
       
    $scope.$watch('childreuse', function(newValue, oldValue) {
        if (newValue == "true") {
            subscriptionFactory.setChildStatus(false);
            $scope.childdetailsassign();
        }
        if (newValue == "false") {
            subscriptionFactory.setChildStatus(true);
            $scope.resetChild();
        }
    });
    var ifReuse = subscriptionFactory.getChildStatus();
    if (ifReuse) {
        $scope.childreuse = "false";
    } else {
        $scope.childreuse = "true";
        //$scope.childdetailsassign();
    }


    $scope.partialSave = function() {

        if (!$('#myChildrenDetailsFormId').valid()) {
            $('#myChildrenDetailsFormId').valid();
            return;
        }
     
        var countofRepeate = 0;
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {            
            var j = 0;
            for (j = 0; j < $scope.FiscalResidenceDetails.length; j++) {
                if (i != j && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[j].CountryCodeForFiscalResidence) {
                    countofRepeate++;
                }
            }
            }
            if (countofRepeate > 0) {
                return ; 
            } 
            else{
                for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                    if ($scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                        $scope.FiscalResidenceDetails.splice(i, 1);
                        i--;
                }
            }
            }
     
        var childDetailssaving = {
            "childDetails": $scope.childDetails,
            "FiscalResidenceDetails": $scope.FiscalResidenceDetails,
            "OtherDetails": $scope.OtherDetails
          
        };
        subscriptionFactory.setChildDetails(childDetailssaving);
        var saveData = subscriptionFactory.saveSubscriptionDetails("child", childDetailssaving);
        subscriptionFactory.postSubscriptionData(saveData).then(
            function (data) {
                $scope.childDetails.PersonId = data.data;
                subscriptionFactory.setChildIdParially(data.data);
                $scope.resetChild();
                genericSuccessMessageDisplay(Resources.SubscribeSuccessDataSaved);
                $("html, body").animate({
                    scrollTop: 0
                }, 800);
                
            },
            function(error) {
                $scope.resetChild();
                genericErrorMessageDisplay(Resources.SubscribeErrorUnableToSaveData);
                $("html, body").animate({
                    scrollTop: 0
                }, 800);
            }
        );
    };
    $scope.checkDate = function(inputDate,checkFlag) {
        if (inputDate) {
        //inputDate = subscriptionFactory.convertUTCDateToLocalDate(new Date(inputDate));
            var splitArr =[];
            if (angular.element("#childbirthDateSubscription").val()) {
                splitArr = angular.element("#childbirthDateSubscription").val().split("/");
            } else if (inputDate) {
                try {
                    var constructedDate = inputDate.getDate() + "/" + (parseInt(inputDate.getMonth()) + 1) + "/" + inputDate.getFullYear();
                    splitArr = constructedDate.split("/");
                } catch (err) {
                    var res = inputDate.getUTCFullYear();
                    var res1 = inputDate.getUTCMonth();
                    var res2 = inputDate.getUTCDate();                                                                           

                    //DateOfBirth.getUTCFullYear() + '-' + DateOfBirth.getUTCMonth() + '-' + DateOfBirth.getUTCDate();
                    //var newres = res[2];
                    res = res.toString();
                    res1 = res1.toString();
                    res1 = parseInt(res1);
                    res1 = res1 + 1;
                    res1 = res1.toString();
                    if (res1.length == 1) {
                        res1 = "0" + res1;
                    }
                    res2 = res2.toString();
                    // var adddate = parseInt(res);
                    //var adddate = adddate + data.contractMaxDuration;
                    var newres = res2 + "/" + res1 + "/" + res;
                    splitArr = newres.split("/");
                }
            }
            if (splitArr[1].length == 1) {
                splitArr[1] = "0" + splitArr[1];
            }
            if (splitArr[0].length == 1) {
                splitArr[0] = "0" + splitArr[0];
            }

            var childDate = splitArr[2] + "-" + splitArr[1] + "-" + splitArr[0];
            

            if (new Date(childDate) > new Date() || new Date(childDate) == new Date()) {
            
                
                
                angular.element("#firstName,#lastName,#childbirthDateSubscription").prop("disabled", false);
                $('#childbirthDateSubscription').closest(".datepicker").removeClass("disabled");
                
                
                angular.element("#subBirthplace").prop("hidden", true);
                angular.element("#subBirthplace").parent().removeClass("group-validation-error");
                $scope.childDetails.Birthplace = null;
                angular.element("#childGender > .form-selc-radio > input").prop("disabled", true);
                angular.element("#reuseTheSameData > .form-selc-radio > input").prop("disabled", true);
                angular.element("#reuseTheSameData_Yes,#reuseTheSameData_No,#childGender_Male,#childGender_Female").prop("checked", false);
                $scope.isPastDate = false;
                $scope.childreuse = false;
                $scope.childDetails.Gender = null;
                $scope.checkChildAge = true;
                // Disabled based on defect raised by  BA on 10/12
                $("#subBirthplace").parent().hide();
                $("#reuseTheSameData").parent().hide();
                $("#childGender").parent().hide();

            if ($scope.childDetails.IsSubscribedForLongTerm) {
                    angular.element("#firstName,#lastName,#childbirthDateSubscription,#subBirthplace").prop("disabled", true);
                    $('#childbirthDateSubscription').closest(".datepicker").addClass("disabled");
                    $('#childGender').css("pointer-events", "none").addClass("disabled-questions");
            }
                
            } else {
                angular.element("#subBirthplace").prop("disabled", false);
                angular.element("#childGender > .form-selc-radio > input").prop("disabled", false);
                angular.element("#reuseTheSameData > .form-selc-radio > input").prop("disabled", false);
                $scope.isPastDate = true;
                $("#childGender").parent().show();
                $("#subBirthplace").parent().show();
                $("#reuseTheSameData").parent().show();
                $("#childGender").parent().show();
                if($scope.childDetails.IsSubscribedForLongTerm) {
                    angular.element("#firstName,#lastName,#childbirthDateSubscription,#subBirthplace").prop("disabled", true);
                    $('#childbirthDateSubscription').closest(".datepicker").addClass("disabled");
                    $('#childGender').css("pointer-events", "none").addClass("disabled-questions");
                }
                if (!$scope.childreuse) {
                    // angular.element("#reuseTheSameData_Yes").prop("checked", true).trigger("click");
                    $scope.childreuse = "true";
                }

            }
            $scope.checkChildStatus($scope.childDetails);

        }

    }
    $scope.childBirthFieldOnFocus = function () {
        //angular.element("#childbirthDateSubscription").trigger("blur");
        }
    $scope.goNext = function() {

        if (!$('#myChildrenDetailsFormId').valid()) {
            $('#myChildrenDetailsFormId').valid();
            return;
        }

        var countofRepeate = 0;
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {            
            var j = 0;
            for (j = 0; j < $scope.FiscalResidenceDetails.length; j++) {
                if (i != j && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[j].CountryCodeForFiscalResidence) {
                    countofRepeate++;
                }
            }
        }
    if (countofRepeate > 0) {
        return;
            }
            else {
            for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                if ($scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == '') {
                    $scope.FiscalResidenceDetails.splice(i, 1);
                    i--;
                }
            }
    }
        
        
        var childDetailsSaving = {
            "childDetails": $scope.childDetails,
            "FiscalResidenceDetails": $scope.FiscalResidenceDetails,
            "OtherDetails": $scope.OtherDetails

        };
        subscriptionFactory.setChildDetails(childDetailsSaving);
        $state.go('questionDetails');
    }
    
    $(document).on("change", "[name ^='inputChildFiscalCountry_']", function() {
         $scope.childfiscalresidenceselected($(this))
    });

    $scope.childfiscalresidenceselected = function (element) {

        
        index = Number(element[0].id.substring(24, element[0].id.length));
        var countofsame = 0;
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
            if (i != index && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[index].CountryCodeForFiscalResidence) {
                $("#inputChildFiscalCountry_" + index).closest(".fiscal-country-dropdown").find(".sb-max-file-size").show();
                $("#inputChildFiscalCountry_" + index).closest(".bootstrap-select").find("button").addClass("subscription-fiscal-dropdown-error-color");
                countofsame = 1;
                break;
            }
        }
        if (countofsame == 0) {
            $("#inputChildFiscalCountry_" + index).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
            $("#inputChildFiscalCountry_" + index).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
            var countofRepeate = 0;
            for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                var countofMatch = 0;
                var j = 0;
                for (j = 0; j < $scope.FiscalResidenceDetails.length; j++) {
                    if (i != j && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[j].CountryCodeForFiscalResidence) {
                        countofMatch = 1;
                        countofRepeate = 1;
                        //return false;
                    }
                    }
                if (countofMatch == 0) {
                    $("#inputChildFiscalCountry_" + i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                    $("#inputChildFiscalCountry_" + i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
                }
            }
            if (countofRepeate > 0) {
                $scope.activeaddFiscal = false;
            } else {
                $scope.activeaddFiscal = true;
                for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                     $("#inputChildFiscalCountry_" +i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                     $("#inputChildFiscalCountry_" +i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
                    }
            }
        }
        else {
            $scope.activeaddFiscal = false;
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
            var countofMatch = 0;
            var j = 0;
            for (j = 0; j < $scope.FiscalResidenceDetails.length; j++) {
                if (i != j && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[j].CountryCodeForFiscalResidence) {
                    countofMatch = 1;
                    countofRepeate = 1;
                    //return false;
                }
            }
                if(countofMatch == 0) {
                    $("#inputChildFiscalCountry_" + i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                    $("#inputChildFiscalCountry_" +i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
                    }
                    }
    }
          for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
              if ($scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == "") {
                  $scope.activeaddFiscal = false;
                }
           }
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };
    $scope.addSourceBlock = function () {
            $scope.FiscalResidenceDetails.push({
                "CountryCodeForFiscalResidence": "",
                        "FiscalResidenceId": 0,
                "TinNumber": ""
            });
            if (!$scope.$$phase) {
            $scope.$apply();
        }
            $scope.activeaddFiscal = false;
        };
    $scope.removeSourceBlock = function (index) {
        $scope.FiscalResidenceDetails.splice(index, 1);

            var countofRepeate = 0;
            for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
            var countofMatch = 0;
            var j = 0;
            for (j = 0; j < $scope.FiscalResidenceDetails.length; j++) {
                    if (i != j && $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == $scope.FiscalResidenceDetails[j].CountryCodeForFiscalResidence) {
                       // $("#inputChildFiscalCountry_" + index).closest(".fiscal-country-dropdown").find(".sb-max-file-size").show();
                       // $("#inputChildFiscalCountry_" + index).addClass("error");
                    countofMatch = 1;
                        countofRepeate = 1;
                    //return false;
                    }
                }
            if (countofMatch == 0) {
                $("#inputChildFiscalCountry_" + i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                $("#inputChildFiscalCountry_" + i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
            }
        }
            if (countofRepeate > 0) {
                $scope.activeaddFiscal = false;
            } else {
                $scope.activeaddFiscal = true;
            for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
                $("#inputChildFiscalCountry_" + i).closest(".fiscal-country-dropdown").find(".sb-max-file-size").hide();
                $("#inputChildFiscalCountry_" + i).closest(".bootstrap-select").find("button").removeClass("subscription-fiscal-dropdown-error-color");
            }
        }
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
              if ($scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == "") {
                  $scope.activeaddFiscal = false;
                }
        }

        if (!$scope.$$phase) {
            $scope.$apply();
    }
    };


}]);