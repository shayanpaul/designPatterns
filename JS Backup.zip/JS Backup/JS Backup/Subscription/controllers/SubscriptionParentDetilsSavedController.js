﻿subscriptionModule.controller('subscriptionParentSavedController', ["$scope", "subscriptionFactory", "$state", "$stateParams", "utilityFactory", "$rootScope", function ($scope, subscriptionFactory, $state, $stateParams, utilityFactory, $rootScope) {

    $rootScope.$on('promoCanceled', function (event, args) {
        $('#pageLoader').addClass('show');
        $('html').addClass('no-scroll');
        if ($scope.promoCodeDetails) {
            $scope.promoCodeDetails.IsApplied = false;
        }
        $scope.isPromoApplied = false;
        setTimeout(function () {
            $('#pageLoader').removeClass('show');
            $('html').removeClass('no-scroll');
        }, 500);
    });
    $scope.$on('promoComplete', function (event, args) {
        $scope.promoCodeDetails = args.any.promocodedetails;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        globalFlagForPromoApplied = $scope.promoCodeDetails.IsApplied;
        $scope.isPromoApplied = globalFlagForPromoApplied;
    });
    $scope.hidepromocodeButtons = hidepromocodeButtons;
    $scope.showPromoCodeDetail = function () {
        if (!Promocodepesnding) {
            $('#applyPromoCodeSucessful').modal('show');
            if ($.cookie("promoCode") || subscriptionFactory.getPromoCode) {
                $rootScope.$broadcast("code-in-cookie-present");
            }
        }
    }
    $scope.allPoliticalRealtionDetails = [];
    $scope.allProfessionalDetails = [];
    $scope.allfunctionDetails = [];
    $scope.allCountryList = [];
    var citylistForshowing = [];
    var mappingDteails = subscriptionFactory.getMappingDetails();
    $scope.allPoliticalRealtionDetails = mappingDteails.allPoliticalRealtionDetails
    $scope.allProfessionalDetails = mappingDteails.allProfessionalDetails;
    $scope.allfunctionDetails = mappingDteails.allfunctionDetails;
    $scope.allCountryList = mappingDteails.allCountryList;
    if (!globalFlagForPromoApplied) {
        if ($.cookie("promoCode") == "" || $.cookie("promoCode") == undefined || $.cookie("promoCode") == null) {
            globalFlagForPromoApplied = false;
        }
        else {
            globalFlagForPromoApplied = true;
        }
    }
    $scope.isPromoApplied = globalFlagForPromoApplied;
    progreesStateColorChangeHeader(2);
    $scope.personalDetails = subscriptionFactory.getPersonalDetails();
    $scope.parentDetails = $scope.personalDetails.PersonalDetails;
    $scope.OtherDetails = $scope.personalDetails.OtherDetails;
    $scope.RadioValue = 'Yes';
    $scope.FiscalResidenceDetails = $scope.personalDetails.FiscalResidenceDetails;
    $scope.parentDetails.DateOfBirthNew = $scope.parentDetails.DateOfBirth;
    if ($scope.parentDetails.Gender == enumMale) {
        $scope.parentDetails.GenderNew = Resources.Male;
    } else {
        $scope.parentDetails.GenderNew = Resources.Female;
    }
   
    if ($scope.parentDetails.ZipCode) {
        subscriptionFactory.getallZiplist($scope.parentDetails.ZipCode).then(
            function (data) {
                citylistForshowing = data.Result.City;
                for (var i = 0; i < citylistForshowing.length; i++) {
                    if (citylistForshowing[i].Id.toString() === $scope.parentDetails.CityZipCode.toString()) {
                        $scope.parentDetails.CityNew = citylistForshowing[i].Name;
                        if (!$scope.$$phase) {
                            $scope.$apply();
                        }
                    }
                }
            },
            function (error) {
                genericErrorMessageDisplay(Resources.GenericErrorServiceFailed);
            }
        );
    }
    
    //citylistForshowing
    

    $scope.showpoliticalDetails = false;
    $scope.showprofessionalDetails = false;
    $scope.showfiscalDetails = false;
    $scope.OtherDetails = $scope.personalDetails.OtherDetails;


   

    if (!$scope.OtherDetails.HasUsaCitizenship || $scope.OtherDetails.HasUsaCitizenship == 0 || $scope.OtherDetails.HasUsaCitizenship == "" || $scope.OtherDetails.HasUsaCitizenship==null) {
                if (currentLanguage.toUpperCase() == "EN") {
                    $scope.OtherDetails.HasUsaCitizenshipnew = 'No';
                } else if (currentLanguage.toUpperCase() == "FR") {
                    $scope.OtherDetails.HasUsaCitizenshipnew = 'Non';
                } else if (currentLanguage.toUpperCase() == "NL") {
                    $scope.OtherDetails.HasUsaCitizenshipnew = 'Nee';
                }
    }
    else {        
            if (currentLanguage.toUpperCase() == "EN") {
                $scope.OtherDetails.HasUsaCitizenshipnew = 'Yes';
            } else if (currentLanguage.toUpperCase() == "FR") {
                $scope.OtherDetails.HasUsaCitizenshipnew = 'Oui';
            } else if (currentLanguage.toUpperCase() == "NL") {
                $scope.OtherDetails.HasUsaCitizenshipnew = 'Ja';
            }
    }
    if (!$scope.OtherDetails.IsUsaCitizenOrResident || $scope.OtherDetails.IsUsaCitizenOrResident == 0 || $scope.OtherDetails.IsUsaCitizenOrResident == "" || $scope.OtherDetails.IsUsaCitizenOrResident == null) {
        if (currentLanguage.toUpperCase() == "EN") {
          $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'No';
          } else if (currentLanguage.toUpperCase() == "FR") {
             $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Non';
          } else if (currentLanguage.toUpperCase() == "NL") {
              $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Nee';
              }
    }
    else {         
        if (currentLanguage.toUpperCase() == "EN") {
          $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Yes';
        } else if (currentLanguage.toUpperCase() == "FR") {
           $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Oui';
        } else if (currentLanguage.toUpperCase() == "NL") {
            $scope.OtherDetails.IsUsaCitizenOrResidentNew = 'Ja';
        }
    }



    $scope.showpoliticalDetails = false;

    if (!$scope.OtherDetails.ImportantPublicFunction || $scope.OtherDetails.ImportantPublicFunction == 0 || $scope.OtherDetails.ImportantPublicFunction == "" || $scope.OtherDetails.ImportantPublicFunction == null || $scope.OtherDetails.ImportantPublicFunction == "false") {
        $scope.OtherDetails.ImportantPublicFunctionnew = 'No';
        $scope.showpoliticalDetails = false;
    } else {

        if ($scope.OtherDetails.ImportantPublicFunction === enumMelinked || $scope.OtherDetails.ImportantPublicFunction == "Me") {
            $scope.OtherDetails.ImportantPublicFunctionnew = "Me";
            $scope.showpoliticalDetails = "Me";
            for (var j = 0; j < $scope.allfunctionDetails.length ; j++) {
                if ($scope.allfunctionDetails[j].Id == $scope.OtherDetails.PoliticalFunctionCode) {
                    $scope.OtherDetails.PoliticalFunctionCodenew = $scope.allfunctionDetails[j].Name;                    
                }
            }
        }
        if ($scope.OtherDetails.ImportantPublicFunction === enumPersonLinkedToMe || $scope.OtherDetails.ImportantPublicFunction == "true") {
            $scope.OtherDetails.ImportantPublicFunctionnew = "Yes";
            $scope.showpoliticalDetails = "true";

            if (!$scope.OtherDetails.PoliticalFirstName || $scope.OtherDetails.PoliticalFirstName == 0 || $scope.OtherDetails.PoliticalFirstName == "" || $scope.OtherDetails.PoliticalFirstName == null) {
                $scope.OtherDetails.PoliticalFirstNamenew = '-';
            }
            else {
                $scope.OtherDetails.PoliticalFirstNamenew = $scope.OtherDetails.PoliticalFirstName;
            }

            if (!$scope.OtherDetails.PoliticalLastName || $scope.OtherDetails.PoliticalLastName == 0 || $scope.OtherDetails.PoliticalLastName == "" || $scope.OtherDetails.PoliticalLastName == null) {
                $scope.OtherDetails.PoliticalLastNamenew = '';
            }
            else {
                $scope.OtherDetails.PoliticalLastNamenew = $scope.OtherDetails.PoliticalLastName;
            }

            if ($scope.OtherDetails.PoliticalRelationCode != 0 && (!$scope.OtherDetails.PoliticalRelationCode || $scope.OtherDetails.PoliticalRelationCode == "" || $scope.OtherDetails.PoliticalRelationCode == null)) {
                $scope.OtherDetails.PoliticalRelationCodenew = '-';
            }
            else {
                for (var j = 0; j < $scope.allPoliticalRealtionDetails.length ; j++) {
                    if ($scope.allPoliticalRealtionDetails[j].Id == $scope.OtherDetails.PoliticalRelationCode) {
                        $scope.OtherDetails.PoliticalRelationCodenew = $scope.allPoliticalRealtionDetails[j].Name;
                    }
                }
            }

            if ($scope.OtherDetails.PoliticalFunctionCode != 0 && (!$scope.OtherDetails.PoliticalFunctionCode || $scope.OtherDetails.PoliticalFunctionCode == "" || $scope.OtherDetails.PoliticalFunctionCode == null)) {
                $scope.OtherDetails.PoliticalFunctionCodenew = '-';
            }
            else {
                for (var j = 0; j < $scope.allfunctionDetails.length ; j++) {
                    if ($scope.allfunctionDetails[j].Id == $scope.OtherDetails.PoliticalFunctionCode) {
                        $scope.OtherDetails.PoliticalFunctionCodenew = $scope.allfunctionDetails[j].Name;
                    }
                }
            }
        }


    }

    $scope.showprofessionalDetails = false;
    if ($scope.OtherDetails.ProfessionCategory != 0 &&( !$scope.OtherDetails.ProfessionCategory || $scope.OtherDetails.ProfessionCategory == "" || $scope.OtherDetails.ProfessionCategory == null)) {
        $scope.OtherDetails.ProfessionCategorynew = '';
        $scope.showprofessionalDetails = false;
    }
    else {

        for (var j = 0; j < $scope.allProfessionalDetails.length ; j++) {
            if ($scope.allProfessionalDetails[j].Id == $scope.OtherDetails.ProfessionCategory) {
                $scope.OtherDetails.ProfessionCategorynew = $scope.allProfessionalDetails[j].Name;
                if (!$scope.OtherDetails.ProfessionDetailedText || $scope.OtherDetails.ProfessionDetailedText == 0 || $scope.OtherDetails.ProfessionDetailedText == "" || $scope.OtherDetails.ProfessionDetailedText == null) {
                    $scope.OtherDetails.ProfessionDetailedTextnew = '-';
                }
                else {
                    $scope.OtherDetails.ProfessionDetailedTextnew = $scope.OtherDetails.ProfessionDetailedText;
                }
                $scope.showprofessionalDetails = true;
            }
        }
  
       
    }

    
    if (!$scope.OtherDetails.ProfessionLabel || $scope.OtherDetails.ProfessionLabel == 0 || $scope.OtherDetails.ProfessionLabel == "" || $scope.OtherDetails.ProfessionLabel == null) {
        $scope.OtherDetails.ProfessionLabelnew = '';
    }
    else {
        $scope.OtherDetails.ProfessionLabelnew = $scope.OtherDetails.ProfessionLabel;
    }

    $scope.FiscalResidenceDetailstoShow = [];
    if (!$scope.OtherDetails.IsBelgiumOnlyFiscalResidence || $scope.OtherDetails.IsBelgiumOnlyFiscalResidence == "false") {
        $scope.showfiscalDetails = true;
        
        $scope.hasfiscalDetails = Resources.Global_No;
       
        for (var i = 0; i < $scope.FiscalResidenceDetails.length; i++) {
            if ($scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence == 0 || $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence) {
                for (var j = 0; j < $scope.allCountryList.length ; j++) {
                    if ($scope.allCountryList[j].Id == $scope.FiscalResidenceDetails[i].CountryCodeForFiscalResidence) {
                        var elementForArray = {
                            "name:": "",
                            "TinNumber": ""
                        };
                        elementForArray.name = $scope.allCountryList[j].Name;
                        if (!$scope.FiscalResidenceDetails[i].TinNumber || $scope.FiscalResidenceDetails[i].TinNumber == 0 || $scope.FiscalResidenceDetails[i].TinNumber == "" || $scope.FiscalResidenceDetails[i].TinNumber == null) {
                            elementForArray.TinNumber = '-';
                        }
                        else {
                            elementForArray.TinNumber = $scope.FiscalResidenceDetails[i].TinNumber;
                        }
                        $scope.FiscalResidenceDetailstoShow.push(elementForArray);
                    }
                }
                
            }            
            
        }
        
    }
    else{
        $scope.showfiscalDetails = false;

        //if (currentLanguage.toUpperCase() == "EN") {
        //    $scope.hasfiscalDetails = 'Yes';
        //} else if (currentLanguage.toUpperCase() == "FR") {
        //    $scope.hasfiscalDetails = 'Oui';
        //} else if (currentLanguage.toUpperCase() == "NL") {
        //    $scope.hasfiscalDetails = 'Ja';
        //}
        $scope.hasfiscalDetails = Resources.Global_Yes;
        //$scope.hasfiscalDetails = 'No';
    }

    $scope.$watch('RadioValue', function (newValue, oldValue) {
        if (newValue == 'No') {
            // Put the object into storage
            localStorage.setItem('parentDataObjectSaved', "YES");
            subscriptionFactory.setPersonDetailsPage('parentDetails');
            $state.go('parentDetails');
        }
    });

    $scope.changeFooterShow = function () {
        if (!$scope.showfooter) {
            $scope.showfooter = true;
        }
        else {
            $scope.showfooter = false;
        }
        if (!$scope.openFaq) {
            $scope.openFaq = true;
        }
        else {
            $scope.openFaq = false;
        }
    };

    $scope.goNext = function () {
        $state.go('childDetails');
    }
    $scope.goBack = function () {
        $state.go("Eidupload");
    };

    //subscriptionFactory.getGender
}]);