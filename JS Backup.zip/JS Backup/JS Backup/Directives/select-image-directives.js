﻿formsModule.directive('aagjeselectimage', function () {
    return {
        restrict: 'A',
        scope: { ngModel: '=' },
        link: function (scope, element, attrs) {

            if (scope.ngModel != undefined) {
                scope.$watch(
                  function () { return scope.ngModel; },
                  function () {
                      if (element[0].id != "changeChild-image-mobile" && element[0].id != "changeChild-image-web")
                      element.selectImage('setImage', scope.ngModel);
                  }
                );

                element.on('imageChanged', function (e) {
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    scope.$evalAsync(function () {
                        scope.ngModel = $(element).selectImage('getImage');

                        setTimeout(function () {
                            if (e.target[0].id == 'editChild-image' || e.target[0].id == 'changeChild-image-web' || e.target[0].id == 'changeChild-image-mobile') {
                                angular.element(e.target).scope().updateChildPicture(e.target[0].id);
                            }
                            else if (e.target[0].id == 'editPersonImage' || e.target[0].id == 'changeChild-image-dashboard') {
                                angular.element(e.target).scope().updateUserPicture();
                            }
                            else {
                                element.selectImage('setImage', scope.ngModel);
                        }
                        }, 500);
                    });
                });

                element.on('pdfAdded', function (e) {
                    scope.ngModel = e.pdf;

                    addPdfIconToContainer(element);

                    if (!scope.$$phase && !scope.$root.$$phase) {
                        scope.$apply();
                    }
                });

                element.on('removeFile', function (e) {
                    scope.ngModel = null;
                    element.closest('.select-image-container').find('.pdf-icon').remove();
                    clearIdUploadErrors(element);

                    if (!scope.$$phase && !scope.$root.$$phase) {
                        scope.$apply();
                    }
                });
            }

            $(element).selectImage();
        }
    }
});

function processPdfIcon(element) {
    if (element.attr('src').indexOf('ProofOfIdentity') >= 0) {
        addPdfIconToContainer(element);
    }
}

function addPdfIconToContainer(element, src) {
    var $container = element.closest('.select-image-container');

    $container.find('.pdf-icon').remove();

    var $icon = $('<img />', {
        'src': 'data:application/pdf;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADCCAYAAAAMw434AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ODA0MkY4RDQyRTEwMTFFMkJBMEFFMjYyMzBGMzNFNjMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6ODA0MkY4RDUyRTEwMTFFMkJBMEFFMjYyMzBGMzNFNjMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo4MDQyRjhEMjJFMTAxMUUyQkEwQUUyNjIzMEYzM0U2MyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo4MDQyRjhEMzJFMTAxMUUyQkEwQUUyNjIzMEYzM0U2MyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PpHIQCAAABjmSURBVHja7J0JeFTVvcDvPltmJplMJpNdIAlgWGQH2UEIO4Qo2qqvi0ul+tyerX1q7Yb1tbZUfX48y/daxYK1CgZEkVV2WgUMm0ICBDAb2TNLZubu75xA+rWvZsjcTJLJnf/v++6XQO7M3Dn3/M75n3s2ktCAyWRi8/LyJ2ZmZc3JyMi81Ww2D1YUxY3+xBBARJAkSaiqeqWiomL90c/+trq+vr65s3NXrlxJrFmzBhKtF4koQ2dkZOQMGzb8nvSMzOVWq7WAoigDEoPAB6ANJAf+kZOfn/8sSt/iI4cP3XfmzOkjkDL9SJAUlytl8uQpz91008D7GIa2SJJEyLLcfgDRAacpqomHzJu/4GPOYJj3+fFjf4VUiXFBaJomRo8Ze+fEiZNe5jjOLQgCkkKCVOshcIGDahTblKnTSurqrs6prqo6DanSt1Cd/cFgMNALFixaPXPmrHdQKNUuB9Dz4HCVIsnUJUuWbUlPTx8IKRKDgiQ5HOw37753Q/7gwU8Eg0FoY/RBTWI0GgcsKyouSUtPd0OKxJAgDMMQ8+cvXJecnHwn1Bp92yZBtfiIomXFG91udyKkSIwIUlg4/4W0tLRv8DwPqRMDkpjMpsmzZs95G/3TBDV5HwuCGuQLhgwd+gzUHLEDvheoLTK/cN78P5pMJhpSpHchO35JTEy03nPvtz6laXoolFQxeKNIEt0j+9rGhvrveTye9lAY6Hn+nsqjRo1+BDUMh0JoFbu0tnoevHChonX37p1PQyHWi4Kg2iNp6M0FK0VR1PxGuM8E6Bq49zzSDH69x524ZdSoH8qK3LJn967/gpTsJUGGDR+x2Gy2ZPF8KOI3YFkW3zze6/GUo581uG35j6Eb8C8ZXeIMhnyDwTCkI9NHAn7sjmr7F1HbpPXggf2vQ4r2sCC45M/JySnGT0wijYlZlhMuXChfc+zo0dfr6+vOoxsO9f4NwOnsdqdl3rHizmMoDVO1SIIb7hMmTFxDqITn4MH9f4ZU7UFBnM6UTJvNNlZR5IjkQGI1f7Jn152lpZ/vhmSMtBYI1KIQqxGlYarWEA1JQk6cNOkNlVA9hw4e2Aap2jNQmVmZEzjOkBZJSYafoOzbt/c+kEN7uhNhhvl0VRKe5w3jxo1/Ozc3bwokaQ/dKLc7fTSJq4QI5LhaW/uXkydKN0PyxURj375g4aL3Bg4cdAukSA8IYjIZI2osYpc+L/18HTxmjA3aBzdSlHvR4iXvDxo0KA9SJMqCZGRkJkeS2ZFMHr/PB8OwYwg8uBFJMmDhoiXvZ2fnZECKRFGQSORAN4Hw+/1tTU2NzZB0PYPWHnIsCXrtsNmzb3vParUmQUpGr7EYUXiFJ0x1p0MRCJe2cqii4uIfaJrWNFUT3xdHcvKkouW3v2O12syQqr0sCNCzIDGMB/bv+1XZubM/NppMmt4D95GkpKTMXV58+5tIEhjeAILoDm7Xrp0vVn515VWDwaBZEqcz5Y5lRUWvcxwHKQqC6OiGUBSJe9u3bC55rKqy8i3tkvCEK9V9/8xZs1+K4Ck+AIL0D/CYKyTJ/ZWVlVvweDdNkvA8MWLEyKfmFs57jgBJQBDdSRIKih9v+/CeQCCwT+vTrVAohCX5RWHhvEegJgFBdIfX6/Vv/WDLHTzPH++OJCNH3vLqtGnT74EUBUF0R3V1VeOWze8XIUnKuiEJOWr0mP8dNmz4YkhREESHklRXojbJMiRJlZbJaXg4EToMcwsLNyBJpkOKgiB6rEnOHdi/bzmqRZq1tCfwqAlZVqxzCue9iyQZBSkKguiOM2dOH923b28xy3JtWiVRZNk1Z25hSVZWFgxuBEH0x7Gjn+3bv3/v3SzLilolQeFWzrz5CzY7U1LSIEVBED1KsmX//n0P4Ea7Fknw4Ear1Xbz8qLizU5nCgxuBEF0Kcm606dOPW40GjW9Hg9uTLBaxxcVF29EksDgRhBEf+zdu+eVsrJzP+2OJDarbdb8BQvXo5ANVqMDQfQFHrf10Ydbf1ZeVvayVknw4EaXy1W0cNGStbBiIwiiS0k+/HDrE0iSN7SO3sWS5OXlfWfR4iWrGY1jv0AQIGbBE9l27tz+vZaWlhKtgxvxkJS8vPwnFi1a8jwD0RYIojeCwaC4ZXPJvV6fd093JMnPz//ZpEmT/x1SFATRHU1NjW0lmzau8Pm8R7VKgofajxs3/tXx4yfeC4IAOpSkqfn9TZuKfD7fWa2NbtyumTZ9+h/Gj5+wGAQB9FiTVH/yyZ5lJEl+hVejiZTry5uy06bP+DOSZAYIAuiOixfOl2/f/vFyJEhDNySxIEk25ebljQFBAN3x5Rdnju/Y8fEKJIhPqySiKDnmzp23OSsrazAIAuhQki/27dy5/R6apgVtgxtlvONu5pKlRZszM7MyQRBAd3xx5swHp06euB9ldFXL63GjneO4IUuXFeFh8k4QBNAde3bv+tOJE6WPah2Scn3v9rFzC+f/xWw2J4AggK7AVceunTteO3mi9Mda19vCgxvtdvuspcuWv2UymVgQBNAdO3fuWIXaJb/tzgjgjIyMomVFy9eaTGYQBNAf+/fvferq1at/0Dq4EW8XnpGR+W0kycsmjesIgyBAzNLW1kaUvL/xofr6+o3dkQQ12B+bOnX6T0EQQHf4/X4JSfJvdXV1O7UOScHjtkaMHPmTGTNnPQ6CAD1ORz8F/tkbB5Ik+MGWkju8Hs9BLettddQk48aN/92MGbO+rbf7AYP+Y4SOfSIXLV76e0mSvCjz9lbhRcqyHGA5ztydfSexJGPGjn29pra6vLys7AgIAvQIiYmJt/bF515fCqhbgqP3MNx66+TnL1VUzNPLLmQgSB+FUZ0N+cDL8fRXcEeiI9k53e1Oy6+s/Koc2iCAJgRBQAWsIOhyOwJVNZrN5oHQSAc0EwgEiKqqqr1ae7NjOkNRFJHqdtugDQJ0i8OHDv3M6UzJd7lSF3SncdzDwSAK+cSIw77Y/T4gSL+htbWl9b1331mWmZU1DIVaVpyvYu0aURwYKCgYtiIvL//peN36GwTp21BLLC8rK43la0xLS8/WMtEK2iBAvBDXe62DIAAAggAACAIAIAgAgCAAAIIAAAgCACAIAIAgAACCAAAAggAACAIAIAgAgCAAAIIAAAgCACAIAIAgABAPwJx0ICx47S48J72r89Lbz9XRel8gCBAWQeD9/jZ/lcDzwa6cL4qimRcEHwgCxAXHjx3bdaK0NDeS18h4MS0QBIgHUGZX0MFDIx0AAKhBMEk0xeFDubbxKxC/tQPZpqh8ndR5SBg3gmRzjGNegunOYUZucQpDDbZTFAOCgCABVRUrRans86CweYcv+F69JLfGlSAsSRIr7Ja770q0/CaBIt0iUkLCm71A/oh7cB4wofxRYOAG3WLkFiyzmZ8r8QSeXN/q3xQXguAv93SKfVWh1fSsV1EJvwIVBvDP4BzBowKTR7+YKSr7gWTrxgSafO71Jt8Lum+kP5ZiXzknwfRsq6wQigpyAOHBkYUP5ZW77AmrHnRYv6VrQYYY2NzbEoy/9CsQTAGR1ShtKM8U2y2/LDCwaboV5Ha75XscSSaCHoCWtglNEulFdsv9uhTERlPsCCO3kIewCtCIgPJOnoFdqktBBnJMTiJNDZDBD0AjOO84aSpPl4IwBJlCkoQRbjPQzVDLpktBVLz7JNQeQBSAsVgAAIIAAAgCACAIAIAgAACCAAAIAgD9GpiT3kXwvJJoL2Yjqyohx9A1ydfnyUSrC4m8fo29RU/M8wFBunijr4ryzpCqNqDf6W6+Hc5/BnQj3ckMle2gqXSKICleUQgpsvcJ1IjyNkFVRZLolif4erjr15Npp6k0liA5EWU2fKjdSDNJJTw1orRdvTb+r0dNQZ8hJtPUWBNFDlVBkN6FQ6Xgy42eZ0+EhGPRiklxjnHStCXXwOTfajbOG2vm7nYzdEFQuXEpSF476lfVt3yrQpACVJSuJ4WmTS6GzkHXMmGC2bB4AMfMQd/dhq8p0kzHoDRrkKSvHq1p+iYqWJSejuXx9T/rSnxxZoJxaDCKE+NAkK6XUGTHjYgWjbLc1hiQS/8W4EutFPWbYrv5rhV2yyojSWaHbjwSmVSvtyGjdU0NshxEx7kveOHchta2dbkck1lstzww2Wx4BIVKjlDko6NJpQfSLcw9oqJdTUEjPUbwKYr4Zov/T0/WNo85L4hbzVTfLt+J4/lzvFj1Qn3rTx6vbR55hhc2mXW0pCgI0k9BmbLxh7XNy0+FhHeNVGxkyHIkyhM1zbdv8wf/A9V0MggC9Cl+RZVeavDc55GV40wMldqrGzyrt/oC30WSKCQIAvQlNaLsf6PZ/1QsNRLVa5K8tdUb+IGJiklFot7UgUZ6lJhqMY7+riPhxSAq/Yl/7UogUUkkoJqh6QIvXi4XxINHg/wRn6yGXeT5I19g321WY0mBgSvSMn04jaUdGSydLn/9gzF8TfxVSa5vkBSv0MX3x2e90uRdncUx4woM7F2hbk5rzjUwbjtFOZVuZm6UPv5EmkqJ9ixSECRK2GkqNZ/j5oZbRQWXuaNNXPvvtaJ8bF2r/6GdvuDxcO/7aYBfN9KIBYn8muYmmO5+yGF7FV2T2IkgkldRPK2yUn4qJO451BZ6uzQknJdukOnx39c2e3/027Tk29B3cnYnT96fZP3PKRbjo6hg6faK8KKq0tFehwBCrCghq6rCq0r7ZP/ODnzz2pRrh5Ohxj6dYt8x1mQYFu59jwb4wyjzNGgJaCSVoHAJjw72aw4moKpGjiJTUU0zdbHN9NNfpSWdej418eVUhrbe6L2/DIlX/toWerm7oZagEnSYa4zokHsgP4MgfYSAu5dVIhmFZT8Jl8WqRLmxWpLLeqqxjvvU8HKs18U1TjMbH/t1mmN3Osuk3ui1Gz1tb4QUtVHPDXYQpA/BNUoOy0zL4ZiUcOf4ZeVCb90oHwoRUbtl/C/diRuSaSpsCP4lL9agY4tBx/0jIEgfg/KWiyYId7hzWmSlvjcfGuGhGgM4dvaKRMsjNzr3r4FQCaPjKgQE6WNwm1K9wcOSBkkO9faNwstv3pZgehS1T2zhzvssIHzWKqsNFAgC9MgNIMkATZKecOfkG1mH1MvLGOHHpck0PWCGxTQn3HlXJbmhWZZP0zoNs0CQPoQmca+5cqFRkr+6QS2T3RfXJ6K6bbiRnR3uHPzIt5wXz7La/Yhps6AfpA8xkxTxgd//OmpjdDoVxMnQXDbH5Et9sM4wrkXSGHoMHjgZCDOEXFDVC1pzORIrgBr5skISmraOxiN40efbQBCdVNcds+wMKNMdC/Cv/aml7X/Chlccc3MiReWH+kQQFXeAZpkpKjGg/PPWZP9ItSjXaL26tc2+X/ylte13WrbDQwILDoa66Umn7RBHkkYFBInhqhhlegtFEZ1Nd0JiKKgUFtDRUCtJpXv8wd/v8AW33SjjT7EYlyCXqL5YShV/pJEkk1IZ2t4odS5IpSh5tV7eJUHyoh9erdfolGlTT841AUGixLEg/7enr7ZMRKHQ1+UVErU3+Kui3FKLGrVBRQ2IXagRslnGMc5s+G5fbePQLghFMqkMlfBF+FN1u486CBIlakXZUysGP43W++FQ7KFk69MOmsoJ9OHeivgRNAplrPF6X+EpVoxSZDcvn2g2/CDQxxuPXp//fqP1JDgQBOg1ltrMix9y2NahUKzPH4Gi2kNEIV7YJ0wpDG3Va2c6hFgxBGoMmx5Otv1ossXwTEhRmb7eXxGXnl5FCZwXxNZw5w3imDStgsxMMI3LYplhqO0W8XB3lD5SAkW6aNTEU0EQfYJuLpHN0c5pFmPxIpv5iWSaHtwWIzvz4s5xSSEqUS3SFD4MIwdpzaALrKbvTLUYV2pdqqdjV1oQJMbJYZnEUSbDUFG94SMnfIIRlc6pBUY2L51lxuUamKkmknTw6rWbHSuwKOtfEYTScB2ZeDTAYAM7RNSYQ5EYCp5kFlRic0swECRKjDRxE55x2bdHsi87zhJ4iRABz8WIwR15cd/OqZC4Ndw5Tpq2OhiqQNHpjsIgSJTA/RpYjjZFHxkFr6/aKivn9rWFtoU7L9fADk+iqcygok9B4CkW8LXg8Ve7/cGXqkSpLdx5k8yGQphRCMQVVooiToaEt9c2+/4Y7jwbTXGjjFyxoIIgQBxAt8tBEhcF8b3fNXrvu9FwmAVW08I0li6QVP0aAm0QHcOQBIVXHZG7MOUCZ4RmWakqaQ38akOrf01AUcM+bbDTFLXIan5S0Pl+9CCIjvlKlC/tbwsdCClqoJNT8NpYwZCqlp8OCQeOBoUDtaLUpXkZxTbzA+ksPaVNUUEQoH+y1x/cjI9ov+9Yk2Fosd2yKqhzOaANAkRMvoF1/DjVvp4mSacSB98XahCgyww3cs4nnLaNJpIazatqXHxnEAToEhPMhlHPuOzrzRR1Mw6t4mX7AxAECAtep/fBZOuTUy3GH8qqag7FkRwgSHRR9fKZeNPSgRyTPSvB+I05Cebv22gyW8tGntevT43BdANBop0LUxg6zcXQLgNJmv7/3/EccwdNpyq9e00MKt1xxvWxJNmdralxa4IbbGCTLBSZPZBjbxliYCcP4JjxLElYcI2hZVYj1gk15LlMlslB7RWJ+poHQoKq+o0UaYvlh2EgSBfAWxc85rS9Q1wbfNsZdG899rz+KenPuhKPRqEEbl+bwUSRLLYMSy6h/xIVlehOJyBeCTKJpvJeSXecutFnx3KDHwTpIijuNsVYjIXnM1mi9WY9JDdeczuh38ZXIEhsNzD64zX1x2sMazhkfQAAQQAABAEAEAQAQBAAAEF6EhJuLQCCdG4HT4IiQPdRdCkIr6q1skp4wRGgmwVtnS4FKePF6ipROsVANQJoBOedWkk+rUtB8Nip0qCwwQiCABoxoKzziT+0QbdPsd71tL1ZJ0mfG0ASIELwcP9qUT68zRd4R7eC1Ety6JVG30qJUD0sSAJEEFqxJFH/+2bf9z2yIui6H+RIIPTZC3WeJbKq1pnQFwdNgDANcsKMN2FVicr/bvQuPtQWah+mr/vRvIcDoQOP10pjv59sX1VgYFcwJGFSID8A/wCeByOqROBokN/wx2bf8+W8ePXvNUo8JMB5Xqr6QW3Tt3M59udTLcbZ2Rw9QlYJB0EQ4EqcVxxIjuYLgnTiRFD45GRIuPwvIVe8pASe4XaOFyvwAfkC6CowFgsAQBAA0AZMuQXC4k5LS3W73WNlRJcavIi6urrjtTU1V0EQQPcMzh8yZcq0aRv5UKhL5xsMRuLw4YN3IkHeBUEA3SPJEoHl4Hm+66+RJGiDAAA00gEABAEAAAQBABAEAEAQAIhlQUiChPkV8UTEAzopitJNBqEi+TKKohBWq5VLdjpNkG/ihohWkFcUlWhoaPDrRpCWlhZvV2sEVVUJhmGcSYlJeZBv4oOEhISRagT7d6iqQvh9Xv0I0tTUeBnVIhG9KDcv7w7IOvrHjMjOzlkcSc84KmwFkqQadCOIz+s9FskLRFEkcnPzHszLyx8GWUjfTJo0+WGbzTYYh9ZdjNeJYDDY2OpprdKNIJcvXz6GSojmSMIsdCTMnDV7g8vlyoRspE9GjRpdPHzkyFW4QIyg9kCCBM60+f1evaQDjYxvGDxk6AKTyXRTV2NNfJ7RaEwdMmToclmWqzweTzlKSBWyVf/H5Up1zJlT+NyYseNWy5LERdL+4DiOOHv27NqKiouH9ZIe7dXG9Bkznxo3bvxLkYzY7KhSUaOdCAQCZ6urqg4GQ8FqEp4B90dUFEZxjiTH4LT09GnonroEQYj4TViW5TdtfG/MlSuXv9CVIOkZGTetWHHXCZRIdlXDjqNYFJqmoX+kn4PbGnhelJY8gO9/a2vrBxvWv7U0krAs1mmfD1JTXY2aIpfXDxo06GEtJQdO2K425AB9gmoP4tTJE6/pSY72wr/jl+PHPluNSo9GqAUALXJUVVW9f+rUyV16+250xy9er7fFaDLx2dk58/U0Iwzo4RgdFagoxG7evXvnN5ubmpp0K0h7qFVT/enAgYNGWK3WoV2cow/EOSaTmThy5PDDp0+d3K3H7/dPgmApKr+6smfAgIG3mc3mNGhXAOEwGo3EubNf/nrf3k9e0tKw73eCYIKIy5cufYRqEixJKkgCdCrHubNrt2378DE9Rxv01/1nKBT0IUk+QJKMR+FWDrRJgA7wI30sx9mzX77w8baPntR7KE539gcsyaVLFe8kORzWlJSU8agmIfVajQJdA/eUo8Ky7tChg985eGD/a/HQTqXD/TEUCknlZee2N7e0HEhLSxuakJCQgf8fwq74AT+lwmLQNCNVVFx8c9u2j+46X17+abwUll3u9LBYLPSw4SMW5+XlP+JyuSajhDN2dBCCMPoLozoOSZIbLl26WHLmzOk1lyoqTsZbFBFxryDuFMrKysrLzMoudLvdU2w2W4HZbHGhhDPjWvj6AfQ/8NqiuBvc4/N5Kz0ez4mLFy/sqa2p2d+IiNfw+v8EGABAlMweAY+LRgAAAABJRU5ErkJggg==',
        'class': 'pdf-icon'
    });

    element.closest('.select-image-container').find('.demoImg').before($icon);
}