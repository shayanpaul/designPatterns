﻿//http://stackoverflow.com/questions/15399958/closing-twitter-bootstrap-modal-from-angular-controller
myAppangular.directive('aagjemodal', function () {
    return {
        restrict: 'A',
        scope: { aagjeModalOpen: '=' },
        link: function (scope, element, attrs) {
            scope.$watch(
              function () { return scope.aagjeModalOpen; },
              function () { element.modal(scope.aagjeModalOpen ? 'show' : 'hide'); }
            );

            element.on('hide.bs.modal', function (e) {
                if (e.target.id == element.eq(0).id) {
                    scope.updateVisibility(false);
                }
            }).on('show.bs.modal', function (e) {
                if (e.target.id == element.eq(0).id) {
                    scope.updateVisibility(true);
                }
            });

            scope.updateVisibility = function (value) {
                scope.aagjeModalOpen = value;
                if (!scope.$$phase && !scope.$root.$$phase) {
                    scope.$apply();
                }
            }
        }
    }
});






