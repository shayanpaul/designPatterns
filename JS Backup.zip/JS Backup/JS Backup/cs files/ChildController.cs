﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ageas.Aagje.FrontEnd.Controllers
{
    [RoutePrefix("{culture}/home/ang/child")]
    public class ChildController : BaseController
    {
        // GET: Child
        [Route("")]
        public ActionResult Index()
        {
            return View();
        }

        [Route("{childId}")]
        public ActionResult ChildDetail(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }

        [Route("{childId}/PlanOverview")]
        public ActionResult ChildPlan(int childId)
        {
            ViewBag.ChildId = childId;

            return View();
        }

        [Route("{childId}/TransactionHistory")]
        public ActionResult TransactionHistory(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }

        [Route("{childId}/PlanOverview/RecurrentPayment")]
        public ActionResult RecurrentPayment(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }

        [Route("{childId}/PlanOverview/Contract")]
        public ActionResult Contract(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }

        [Route("{childId}/PlanOverview/LongTermPlan")]
        public ActionResult LongTermPlan(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }

        [Route("{childId}/PlanOverview/ShortTermPlan")]
        public ActionResult ShortTermPlan(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }

        [Route("{childId}/ChildSavingSchool")]
        public ActionResult ChildSavingSchool(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }

        [Route("{childId}/supporter")]
        public ActionResult ChildSupporter(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }

        [Route("{childId}/Event")]
        public ActionResult Event(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }

        [Route("{childId}/event/{eventId}/detail")]
        public ActionResult eventDetails(int childId, int eventId)
        {
            ViewBag.ChildId = childId;
            ViewBag.EventId = eventId;
            return View();
        }

        [Route("{childId}/profile")]
        public ActionResult ChildProfile(int childId)
        {
            ViewBag.ChildId = childId;
            return View();
        }
    }
}