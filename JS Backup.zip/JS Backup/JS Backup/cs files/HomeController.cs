﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Resources;
using System.Security.Claims;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using Aagje;
using Ageas.Aagje.FrontEnd.Models;
using Ageas.Aagje.FrontEnd.Utilities;

namespace Ageas.Aagje.FrontEnd.Controllers
{
    //#if !DEBUG
    [Authorize]
    //#endif
    [RoutePrefix("{culture}/Home")]
    public class HomeController : BaseController
    {
        [Route("")]
        [Route("~/Home")]
        [OutputCache(Duration = 0)]
        public ActionResult HomePage()
        {
            return View("Default");
        }

        [Route("ang/Members", Name = RouteNames.Home_Members)]
        public ActionResult DisplayPerson(string culture)
        {
            HttpContext.Response.SetCookie(new HttpCookie("childId", null));

            SetCulture(culture);

            return View("DisplayPerson");
        }

        private void SetCulture(string lang)
        {
            if (!string.IsNullOrEmpty(lang))
            {
                HttpContext.Response.SetCookie(new HttpCookie("language", lang));
                this.RouteData.Values["culture"] = lang;
                //Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo(lang);
                //Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(lang);
            }
        }

        [Route("ang/EditPerson", Name = RouteNames.Home_EditPerson)]
        public ActionResult EditPerson()
        {
            return View();
        }

        [Route("ang/Profile", Name = RouteNames.Home_EditProfile)]
        public ActionResult EditProfile()
        {
            return View("EditPerson_PersonalData");
        }

        [Route("ang/EditPreference", Name = RouteNames.Home_EditPreference)]
        public ActionResult EditPreference()
        {
            return View("EditPerson_Preferences");
        }

        [Route("ang/ProfileDocuments", Name = RouteNames.Home_ProfileDocuments)]
        public ActionResult ProfileDocuments()
        {
            return View("EditPerson_MyDocuments");
        }

        [Route("ang/Members/{personId}", Name = RouteNames.Home_Members_By_Id)]
        public ActionResult DisplayPersonById(int personId)
        {
            HttpContext.Response.SetCookie(new HttpCookie("childId", null));
            ViewData["WebApiUrl"] = ConfigurationManager.AppSettings["WebApiUrl"];
            Session["PersonId"] = personId;

            var parentCookie = new HttpCookie("personId", personId.ToString());

            ClaimsIdentity identity = (ClaimsIdentity)User.Identity;
            IEnumerable<Claim> claims = identity.Claims;

            var parentNameCookie = new HttpCookie("personName",
                claims.Where(c => c.Type == ClaimTypes.GivenName)
                .Select(c => c.Value).SingleOrDefault());
            HttpContext.Response.Cookies.Add(parentCookie);
            HttpContext.Response.Cookies.Add(parentNameCookie);

            return View("DisplayPerson");
        }

        ////[Route("BackOffice/Members/{personId}")]
        ////public ActionResult LoginPerson(int personId)
        ////{
        ////    HttpContext.Response.SetCookie(new HttpCookie("childId", null));
        ////    ViewData["WebApiUrl"] = ConfigurationManager.AppSettings["WebApiUrl"];
        ////    Session["PersonId"] = personId;

        ////    var parentCookie = new HttpCookie("personId", personId.ToString());

        ////    //ClaimsIdentity identity = (ClaimsIdentity)User.Identity;
        ////    //IEnumerable<Claim> claims = identity.Claims;

        ////    //var parentNameCookie = new HttpCookie("personName",
        ////    //    claims.Where(c => c.Type == ClaimTypes.GivenName)
        ////    //    .Select(c => c.Value).SingleOrDefault());
        ////    HttpContext.Response.Cookies.Add(parentCookie);
        ////    //HttpContext.Response.Cookies.Add(parentNameCookie);

        ////    return View("DisplayPerson");
        ////}

        [Route("~/{culture}/ang/Supporters", Name = RouteNames.Home_AllSupporters)]
        public ActionResult Supporters()
        {
            return View("Supporters");
        }

        [Route("~/{culture}/ang/Dashboard", Name = RouteNames.Home_Dashboard)]
        public ActionResult Dashboard()
        {
            return View("Dashboard");
        }

        [Route("~/{culture}/ang/Partner", Name = RouteNames.Home_Partners)]
        public ActionResult DisplayPartner()
        {
            ViewBag.Message = "This is a Community Section";
            return View("AaGjePage");
        }

        [Route("~/{culture}/ang/Credits", Name = RouteNames.Home_Credits)]
        public ActionResult DisplayCredits()
        {
            ViewBag.Message = "This is a Credit Section";
            return View("AaGjePage");
        }

        public ActionResult Subscription()
        {
            return View();
        }

        public ActionResult Payment()
        {
            return View("Payment");
        }

        [Route("~/{culture}/ang/Basket")]
        public ActionResult Basket()
        {
            return View("Basket");
        }

        [Route("~/{culture}/ang/Contribute")]
        public ActionResult Contribute()
        {
            return View("ContributeView");
        }

        [AllowAnonymous]
        [Route("~/{culture}/FreeContribute")]
        public ActionResult FreeContribute()
        {
            return View("ContributionFreeSupporter");
        }

        [Route("~/{culture}/ang/Moneyout")]
        public ActionResult Moneyout()
        {
            return View("MoneyOutView");
        }

        [Route("~/SavingSchool")]
        public ActionResult SavingSchool()
        {
            return View("SavingSchoolView");
        }

        [Route("~/AaGje")]
        public ActionResult AaGje()
        {
            return View("AaGjePage");
        }

        [Route("Child/{childId}/UploadFiles")]
        public void UploadFiles()
        {
        }

        [Route("Error")]
        [Route("~/Home/Error")]
        [AllowAnonymous]
        public ActionResult ErrorPage(string message = "")
        {
            return View("Error");
        }
    }
}