# AngularJS Form Validation

This is the demo to go along with the [scotch.io](http://scotch.io) tutorial: [AngularJS Form Validation](http://scotch.io/tutorials/javascript/angularjs-form-validation).

## Demonstration of:

- Form Properties ($valid, $invalid, $pristine, $dirty)
- Showing Errors (ngShow)
- Conditional Classes (ngClass)
- Disabled Form (ngDisabled)
- Custom Validation (ngMinlength and ngMaxlength)