var app = angular.module('MyApp', []);
      app.controller('MyCtrl', function($scope) {
          $scope.start = '1/12/2017';
		  $scope.end = '03/12/2017';
      });
	  
	app.directive('jqdatepicker', function () {
    return {
        restrict: 'A',
         link: function (scope, element, attrs) {
            var thisAttr = attrs;
			element.datepicker({
                dateFormat: 'dd/mm/yy',
				numberOfMonths : 19,
				showCurrentAtPos: 6,
                beforeShowDay: function(date) {
					var date1 = $.datepicker.parseDate('dd/mm/yy', scope.start);
					//console.log(date1);
					var date2 = $.datepicker.parseDate('dd/mm/yy', scope.end);
					//console.log(date2);
					return [true, date1 && ((date.getTime() == date1.getTime()) || (date2 && date >= date1 && date <= date2)) ? "dp-highlight" : ""];
					//return [true, '',''];
				},
                onSelect: function(date){
                    element.datepicker( "option", { numberOfMonths: 19,showCurrentAtPos:6 } );
                    scope.start = date;
                    scope.$apply();
                    setTimeout(function(){ 
                        element.scrollTop($(element.find(".dp-highlight")[0]).closest(".ui-datepicker-group").position().top);
                    });
                    
                }
            });
        }
    };
});

app.directive('detectCalendarScroll', function ($timeout) {
    return {
        restrict: 'A',
         link: function (scope, element, attrs) {
			//element.datepicker("setDate", scope.start);
			element.scrollTop($(element.find(".dp-highlight")[0]).closest(".ui-datepicker-group").position().top);
        }
    };
});
	