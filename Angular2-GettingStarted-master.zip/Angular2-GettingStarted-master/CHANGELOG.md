#Changes made to the course since its release:
- October 18, 2016 - The course was updated for Angular 2 Final.

#Changes made to the project files since its release:
- March 24, 2017 - APM-Start-Updated and APM-Final-Updated were added. These are updates to the sample code for Angular version 4. Note that the changes include modifications to the boilerplate files and the addition of an src folder to make these files compatible with the current version of the Angular Quick Start files.
